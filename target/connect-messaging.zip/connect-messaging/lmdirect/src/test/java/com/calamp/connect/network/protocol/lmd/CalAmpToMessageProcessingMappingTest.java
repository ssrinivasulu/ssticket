package com.calamp.connect.network.protocol.lmd;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.network.protocol.lmd.converter.LMDirectToNetworkMessageConverter;
import com.calamp.connect.network.protocol.lmd.converter.NetworkAdapterConverterConfig;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.builders.EventReportMessageBuilder;
import com.calamp.connect.network.protocol.lmd.domain.builders.LocationStatusInfoBuilder;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;


/**
 * Test class to verify all the peg specific mappings work
 * for example EventCode 2 maps to an abstract message type of IGON and should have 2 accumulators
 *
 * This doesn't test to make sure the generic mappings are mapped. For example, doesn't verify that
 * lat gets mapped with lat. All that should be the same regardless of the event code since it's position related
 * info.
 *
 * @author ssrinivasulu
 *
 */
@SpringBootTest(classes = {NetworkAdapterConverterConfig.class})
@RunWith(SpringRunner.class)
public class CalAmpToMessageProcessingMappingTest
{

	@Autowired
	private LMDirectToNetworkMessageConverter lmDirectToNetworkMesageConverter;
	
    @Test
    public void testAliveMessage()
    {
        long expectedOdometer = 10000l;
        EventCode code = EventCode.ALIVE;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        //assertEquals(AbstractMessageType.ALIVE.toString(), eventMessage.getAbstractMsgTypeCode());
        assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
        assertEquals(0, eventMessage.getOdometer(), 0);
        assertEquals(0, eventMessage.getRawObdOdometer(), 0);        
        //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

    @Test
    public void testPowerOnMessage()
    {
        long expectedOdometer = 10000l;
        EventCode code = EventCode.POWUP;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        //assertEquals(AbstractMessageType.POWUP.toString(), eventMessage.getAbstractMsgTypeCode());
        assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
        assertEquals(0, eventMessage.getOdometer(), 0);
        assertEquals(0, eventMessage.getRawObdOdometer(), 0);
        //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

//    @Test
    public void testIgonMessage()
    {
        long expectedOdometer = 1000l;
        long expectedIgonTime = 32;
        EventCode code = EventCode.IGON;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        accumulators.add(expectedIgonTime);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        //assertEquals(AbstractMessageType.IGON.toString(), eventMessage.getAbstractMsgTypeCode());
        assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getOdometer());
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getRawOdometer());
        //what does this map to?
        assertEquals(expectedIgonTime, 0);
    }

//    @Test
    public void testIgoffMessage()
    {
        long expectedOdometer = 1000l;
        long expectedIgonTime = 32;
        long expectedIgoffTime = 545;
        EventCode code = EventCode.IGOFF;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        accumulators.add(expectedIgonTime);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getOdometer());
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getRawOdometer());
        //what does this map to?
        assertEquals(expectedIgoffTime, 0);
        assertEquals(expectedIgonTime, 0);
    }

//    @Test
    public void testStartMessage()
    {
        long expectedOdometer = 1000l;
        long expectedIgonTime = 32;
        long expectedIgoffTime = 545;
        long expectedIdleTime = 23;
        long expectedStopThreshold = 643;
        long expectedStartThreshold = 2342;

        EventCode code = EventCode.START;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.ordinal())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        accumulators.add(expectedIgonTime);
        accumulators.add(expectedIgoffTime);
        accumulators.add(expectedIdleTime);
        accumulators.add(expectedStopThreshold);
        accumulators.add(expectedStartThreshold);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getOdometer());
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getRawOdometer());
        //what does this map to?
        assertEquals(expectedIdleTime, 0);
        assertEquals(expectedStopThreshold, 0);
        assertEquals(expectedStartThreshold, 0);
        assertEquals(expectedIgoffTime, 0);
        assertEquals(expectedIgonTime, 0);
    }

//    @Test
    public void testStopMessage()
    {
        long expectedOdometer = 1000l;
        long expectedIgonTime = 32;
        long expectedIgoffTime = 545;
        long expectedIdleTime = 23;
        long expectedStopThreshold = 643;

        EventCode code = EventCode.START;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.ordinal())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        accumulators.add(expectedIgonTime);
        accumulators.add(expectedIgoffTime);
        accumulators.add(expectedIdleTime);
        accumulators.add(expectedStopThreshold);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getOdometer());
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getRawOdometer());
        //what does this map to?
        assertEquals(expectedIdleTime, 0);
        assertEquals(expectedStopThreshold, 0);
        assertEquals(expectedIgoffTime, 0);
        assertEquals(expectedIgonTime, 0);
    }

    @Test
    public void testMovingMessage()
    {
        long expectedOdometer = 1000l;
        EventCode code = EventCode.PRIOD;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        //assertEquals(AbstractMessageType.PRIOD.toString(), eventMessage.getAbstractMsgTypeCode());
        assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
        assertEquals(0, eventMessage.getOdometer(), 0);
        assertEquals(0, eventMessage.getRawObdOdometer(), 0);
        //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

    @Test
    public void testMovingMessageWithOBDOdometer()
    {
        long expectedOBDOdometer = 1000l;
        EventCode code = EventCode.PRIOD;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        //Set the first 8 accumulators as 0.
        for ( int i = 0; i < 8; i++ )
            accumulators.add(0l);
        
        accumulators.add(expectedOBDOdometer);

        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);

        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        //assertEquals(AbstractMessageType.PRIOD.toString(), eventMessage.getAbstractMsgTypeCode());
        assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
        assertEquals(0, eventMessage.getOdometer(), 0);
        assertEquals(0, eventMessage.getRawOdometer(), 0);
        //assertEquals(convertMetersToMiles(expectedOBDOdometer), eventMessage.getRawObdOdometer());
    }


    @Test
    public void testMovingMessageWithOBDAndGPSOdometers()
    {
        long expectedOBDOdometer = 1000l;
        EventCode code = EventCode.PRIOD;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        //The first accumulator is the gps odo.
        accumulators.add(expectedOBDOdometer);
        //Set the next 7 accumulators as 0.
        for ( int i = 0; i < 7; i++ )
            accumulators.add(0l);
        //The 9th accumulator is the OBD odo
        accumulators.add(expectedOBDOdometer);

        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);

        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        //assertEquals(AbstractMessageType.PRIOD.toString(), eventMessage.getAbstractMsgTypeCode());
        assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
        assertEquals(0, eventMessage.getOdometer(), 0);
        //assertEquals(convertMetersToMiles(expectedOBDOdometer), eventMessage.getRawOdometer());
        //assertEquals(convertMetersToMiles(expectedOBDOdometer), eventMessage.getRawObdOdometer());
    }

    
    @Test
    public void testBeginSpeedingMessage()
    {
        long expectedOdometer = 1000l;
        EventCode code = EventCode.SPEED;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(code.ordinal())
                .setSequenceNumber(1)
                .setMobileIdType(MobileIdType.ESN)
                .setMobileId("234232323423")
                .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        //assertEquals(AbstractMessageType.SPEED.toString(), eventMessage.getAbstractMsgTypeCode());
        assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
        assertEquals(0, eventMessage.getOdometer(), 0);
        assertEquals(0, eventMessage.getRawObdOdometer(), 0);
        //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

//    @Test
    public void testEndSpeedingMessage()
    {
        long expectedOdometer = 1000l;
        long expectedIgonTime = 32;
        long expectedIgoffTime = 545;
        long expectedIdleTime = 23;
        long expectedStopThreshold = 643;
        long expectedStartThreshold = 2342;
        long expectedSpeedingTime = 234;
        long expectedMaxSpeed = 43;

        EventCode code = EventCode.SPEED;
        LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
        LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.ordinal())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(expectedOdometer);
        accumulators.add(expectedIgonTime);
        accumulators.add(expectedIgoffTime);
        accumulators.add(expectedIdleTime);
        accumulators.add(expectedStopThreshold);
        accumulators.add(expectedStartThreshold);
        accumulators.add(expectedSpeedingTime);
        accumulators.add(expectedMaxSpeed);
        ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
        ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


        Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
        assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
        Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getOdometer());
        assertEquals((Double)convertMetersToMiles(expectedOdometer), (Double)eventMessage.getRawOdometer());
        //what does this map to?
        assertEquals(expectedSpeedingTime, 0);
        assertEquals(expectedMaxSpeed, 0);
        assertEquals(expectedIdleTime, 0);
        assertEquals(expectedStopThreshold, 0);
        assertEquals(expectedStartThreshold, 0);
        assertEquals(expectedIgoffTime, 0);
        assertEquals(expectedIgonTime, 0);
    }

    @Test
    public void testGPSAcquiredMessage()
    {
       long expectedOdometer = 1000l;
       EventCode code = EventCode.GPSY;
       LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
       LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.ordinal())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
       List<Long> accumulators = new ArrayList<Long>();
       accumulators.add(expectedOdometer);
       ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
       ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


       Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
       assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
       Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
       //assertEquals(AbstractMessageType.GPSY.toString(), eventMessage.getAbstractMsgTypeCode());
       assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
       assertEquals(0, eventMessage.getOdometer(), 0);
       assertEquals(0, eventMessage.getRawObdOdometer(), 0);
       //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

    @Test
    public void testGPSLostMessage()
    {
       long expectedOdometer = 1000l;
       EventCode code = EventCode.GPSN;
       LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
       LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.ordinal())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
       List<Long> accumulators = new ArrayList<Long>();
       accumulators.add(expectedOdometer);
       ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
       ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


       Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
       assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
       Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
       //assertEquals(AbstractMessageType.GPSN.toString(), eventMessage.getAbstractMsgTypeCode());
       assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
       assertEquals(0, eventMessage.getOdometer(), 0);
       assertEquals(0, eventMessage.getRawObdOdometer(), 0);
       //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

    @Test
    public void testCommUpMessage()
    {
       long expectedOdometer = 1000l;
       EventCode code = EventCode.CGAIN;
       LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
       LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.ordinal())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
       List<Long> accumulators = new ArrayList<Long>();
       accumulators.add(expectedOdometer);
       ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
       ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


       Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
       assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
       Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
       //assertEquals(AbstractMessageType.CGAIN.toString(), eventMessage.getAbstractMsgTypeCode());
       assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
       assertEquals(0, eventMessage.getOdometer(), 0);
       assertEquals(0, eventMessage.getRawObdOdometer(), 0);
       //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

    @Test
    public void testCommDownMessage()
    {
       long expectedOdometer = 1000l;
       EventCode code = EventCode.CLOSS;
       LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault().build();
       LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.ordinal())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
       List<Long> accumulators = new ArrayList<Long>();
       accumulators.add(expectedOdometer);
       ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
       ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);


       Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
       assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
       Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
       //assertEquals(AbstractMessageType.CLOSS.toString(), eventMessage.getAbstractMsgTypeCode());
       assertEquals(code.ordinal(), eventMessage.getEventCode().intValue());
       assertEquals(0, eventMessage.getOdometer(), 0);
       assertEquals(0, eventMessage.getRawObdOdometer(), 0);
       //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

    
    @Test
    public void testInputTransitions()
    {
        //test that in1hi is triggered
        inputTransitionHelper(EventCode.INPUT1, AbstractMessageType.IN1HI, new Inputs(new boolean[]{false, false, false, false, false, false, true, false}));
        //test that in1lo is triggered
        inputTransitionHelper(EventCode.INPUT1, AbstractMessageType.IN1LO, new Inputs(new boolean[]{false, false, false, false, false, false, false, false}));
        //test that in2hi is triggered
        inputTransitionHelper(EventCode.INPUT2, AbstractMessageType.IN2HI, new Inputs(new boolean[]{false, false, false, false, false, true, false, false}));
        //test that in2lo is triggered
        inputTransitionHelper(EventCode.INPUT2, AbstractMessageType.IN2LO, new Inputs(new boolean[]{false, false, false, false, false, false, false, false}));
        //test that in3hi is triggered
        inputTransitionHelper(EventCode.INPUT3, AbstractMessageType.IN3HI, new Inputs(new boolean[]{false, false, false, false, true, false, false, false}));
        //test that in3lo is triggered
        inputTransitionHelper(EventCode.INPUT3, AbstractMessageType.IN3LO, new Inputs(new boolean[]{false, false, false, false, false, false, false, false}));
        //test that in4hi is triggered
        inputTransitionHelper(EventCode.INPUT4, AbstractMessageType.IN4HI, new Inputs(new boolean[]{false, false, false, true, false, false, false, false}));
        //test that in4lo is triggered
        inputTransitionHelper(EventCode.INPUT4, AbstractMessageType.IN4LO, new Inputs(new boolean[]{false, false, false, false, false, false, false, false}));
    }

    private void inputTransitionHelper(EventCode eventCode, AbstractMessageType expectedType, Inputs inputs)
    {
        long expectedOdometer = 1000l;
       EventCode code = eventCode;
       LocationStatusInfo info = LocationStatusInfoBuilder.getBuilderWithDefault()
               .setInputs(inputs).build();
       LMDirectMessage message = EventReportMessageBuilder.getBuilderWithDefault()
               .setEventCode(code.getEventCode())
               .setSequenceNumber(1)
               .setMobileIdType(MobileIdType.ESN)
               .setMobileId("234232323423")
               .toLMDirectMessage();
       List<Long> accumulators = new ArrayList<Long>();
       accumulators.add(expectedOdometer);
       ((EventReportMessageContent)message.getMessageContent()).setAccumulatorValues(accumulators);
       ((EventReportMessageContent)message.getMessageContent()).setLocationStatusInfo(info);

       Network.NetworkMessage convertedMessage = lmDirectToNetworkMesageConverter.convert(message);
       assertEquals(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE ,convertedMessage.getType());
       Network.MessageDetail eventMessage = convertedMessage.getMessageDetail();
       //assertEquals(expectedType.toString(), eventMessage.getAbstractMsgTypeCode());
       //assertEquals(expectedType.ordinal(), (expectedType.toString().contains("HI")?(eventMessage.getEventCode()+1) : eventMessage.getEventCode()+2));
       assertEquals(0, eventMessage.getOdometer(), 0);
       assertEquals(0, eventMessage.getRawObdOdometer(), 0);
       //assertEquals(convertMetersToMiles(expectedOdometer), eventMessage.getRawOdometer());
    }

    private static double convertMetersToMiles(long meters)
    {
        return new BigDecimal(meters * 0.00062137119).setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

}
