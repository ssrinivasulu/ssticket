package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.network.protocol.lmd.LmDirectSerializer;
import com.calamp.connect.network.protocol.lmd.converter.LMDirectToNetworkMessageConverter;
import com.calamp.connect.network.protocol.lmd.converter.NetworkAdapterConverterConfig;
import com.calamp.connect.network.protocol.lmd.domain.builders.IpUdpHeaderBuilder;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.serializers.MessageContentSerializer;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 18, 2010
 */
@SpringBootTest(classes = {NetworkAdapterConverterConfig.class})
@RunWith(SpringJUnit4ClassRunner.class)
public class EventReportMessageTest
{
	@Autowired
	private LMDirectToNetworkMessageConverter lmDirectToNetworkMesageConverter;
    /**
     * Verify that the speed duration and max speed are parsed from the message correctly.
     */
    @Test
    public void testSpeedEndMessage()
    {
        String incomingMessage = "830543310046770101010203ea4d2c70654d2c706517369219d1d9ffca00001861000005c8007d0c02019affc30f0a1d00320806" +
                "0000168dc6000009ec00000000000001b70000001e00000c0e";
        LMDirectMessage lmDirectMessage = LmDirectSerializer.decode(HexUtil.convertFromHexString(incomingMessage));
        lmDirectMessage.setIpUdpHeader(IpUdpHeaderBuilder.getBuilderWithDefault().build());
        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(lmDirectMessage);

        int expectedMaxSpeed =69;
        long expectedDuration =409;
        System.out.println(actualMessage.getMessageDetail().getOdometer());
        //assertEquals(expectedMaxSpeed, actualMessage.getMessageDetail().getMaxSpeed());
        //assertEquals(expectedDuration, actualMessage.getMessageDetail().getDuration());
    }

    @Test
    public void testUnitStatus()
    {
        UnitStatus unitStatus = new UnitStatus((byte)0x01);
        assertTrue(unitStatus.isMemoryTestOkay());
        unitStatus = new UnitStatus((byte)0x02);
        assertTrue(unitStatus.isGPSAntennaOkay());
        unitStatus = new UnitStatus((byte)0x04);
        assertTrue(unitStatus.isGPSReceiverSelfTestOkay());
        unitStatus = new UnitStatus((byte)0x08);
        assertTrue(unitStatus.isGPSReceiverTracking());
        unitStatus = new UnitStatus((byte)0x10);
        assertTrue(unitStatus.isModemMINTestOkay());
        unitStatus = new UnitStatus((byte)0x40);
        assertTrue(unitStatus.isGPSExceptionReported());

        unitStatus = new UnitStatus((byte)0xFF);
        assertTrue(unitStatus.isMemoryTestOkay());
        assertTrue(unitStatus.isGPSAntennaOkay());
        assertTrue(unitStatus.isGPSReceiverSelfTestOkay());
        assertTrue(unitStatus.isGPSReceiverTracking());
        assertTrue(unitStatus.isModemMINTestOkay());
        assertTrue(unitStatus.isGPSExceptionReported());

        unitStatus = new UnitStatus((byte)0xB5);
        assertTrue(unitStatus.isMemoryTestOkay());
        assertFalse(unitStatus.isGPSAntennaOkay());
        assertTrue(unitStatus.isGPSReceiverSelfTestOkay());
        assertFalse(unitStatus.isGPSReceiverTracking());
        assertTrue(unitStatus.isModemMINTestOkay());
        assertFalse(unitStatus.isGPSExceptionReported());

        unitStatus = new UnitStatus((byte)0x0A);
        assertFalse(unitStatus.isMemoryTestOkay());
        assertTrue(unitStatus.isGPSAntennaOkay());
        assertFalse(unitStatus.isGPSReceiverSelfTestOkay());
        assertTrue(unitStatus.isGPSReceiverTracking());
        assertFalse(unitStatus.isModemMINTestOkay());
        assertFalse(unitStatus.isGPSExceptionReported());
    }


    @Test
    public void testFixStatus()
    {
        FixStatus status = new FixStatus((byte)0x01);
        assertTrue(status.isPredicted());
        status = new FixStatus((byte)0x02);
        assertTrue(status.isDifferentiallyCorrected());
        status = new FixStatus((byte)0x04);
        assertTrue(status.isLastKnown());
        status = new FixStatus((byte)0x08);
        assertTrue(status.isInvalidFix());
        status = new FixStatus((byte)0x10);
        assertTrue(status.is2DFix());
        status = new FixStatus((byte)0x20);
        assertTrue(status.isHistoric());
        status = new FixStatus((byte)0x40);
        assertTrue(status.isInvalidTime());

        status = new FixStatus((byte)0xFF);
        assertTrue(status.isPredicted());
        assertTrue(status.isDifferentiallyCorrected());
        assertTrue(status.isLastKnown());
        assertTrue(status.isInvalidFix());
        assertTrue(status.is2DFix());
        assertTrue(status.isHistoric());
        assertTrue(status.isInvalidTime());

        status = new FixStatus((byte)0x3c);
        assertFalse(status.isPredicted());
        assertFalse(status.isDifferentiallyCorrected());
        assertTrue(status.isLastKnown());
        assertTrue(status.isInvalidFix());
        assertTrue(status.is2DFix());
        assertTrue(status.isHistoric());
        assertFalse(status.isInvalidTime());
    }
    @Test
    public void testInputs()
    {
        Inputs inputs = new Inputs((byte)0x01);
        assertTrue(inputs.isIgnitionOn());
        inputs = new Inputs((byte)0x02);
        assertTrue(inputs.isInput1On());
        inputs = new Inputs((byte)0x04);
        assertTrue(inputs.isInput2On());
        inputs = new Inputs((byte)0x08);
        assertTrue(inputs.isInput3On());
        inputs = new Inputs((byte)0x10);
        assertTrue(inputs.isInput4On());
        inputs = new Inputs((byte)0x20);
        assertTrue(inputs.isInput5On());

        inputs = new Inputs((byte)0xFF);
        assertTrue(inputs.isIgnitionOn());
        assertTrue(inputs.isInput1On());
        assertTrue(inputs.isInput2On());
        assertTrue(inputs.isInput3On());
        assertTrue(inputs.isInput4On());
        assertTrue(inputs.isInput5On());

        inputs = new Inputs((byte)0xBC);
        assertFalse(inputs.isIgnitionOn());
        assertFalse(inputs.isInput1On());
        assertTrue(inputs.isInput2On());
        assertTrue(inputs.isInput3On());
        assertTrue(inputs.isInput4On());
        assertTrue(inputs.isInput5On());
    }
    
    @Test
    public void testCommState()
    {
        CommState commState = new CommState((byte)0x01);
        assertTrue(commState.isAvailable());
        commState = new CommState((byte)0x02);
        assertTrue(commState.isNetworkService());
        commState = new CommState((byte)0x04);
        assertTrue(commState.isDataService());
        commState = new CommState((byte)0x08);
        assertTrue(commState.isConnected());
        commState = new CommState((byte)0x10);
        assertTrue(commState.isVoiceCallActive());
        commState = new CommState((byte)0x20);
        assertTrue(commState.isRoaming());

        commState = new CommState((byte)0xFF);
        assertTrue(commState.isAvailable());
        assertTrue(commState.isNetworkService());
        assertTrue(commState.isDataService());
        assertTrue(commState.isConnected());
        assertTrue(commState.isVoiceCallActive());
        assertTrue(commState.isRoaming());

        commState = new CommState((byte)0x2B);
        assertTrue(commState.isAvailable());
        assertTrue(commState.isNetworkService());
        assertFalse(commState.isDataService());
        assertTrue(commState.isConnected());
        assertFalse(commState.isVoiceCallActive());
        assertTrue(commState.isRoaming());
    }

    /**
     * A Test to make sure that the unsigned aspects of the code
     * are working correctly.
     * for example, speed is an unsigned 4 byte field, it should be able to handle something over Integer.MAX_VALUE;
     */
    @Test
    public void testHighValues()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("7fffffff"); //altitude
        builder.append("00000190"); //speed in cm
        builder.append("00D1"); //heading
        builder.append("FF");//satellites
        builder.append("00");//fix status
        builder.append("FFFF");//carrier
        builder.append("7FFF"); //rssi
        builder.append("0f");//comm state
        builder.append("FF");//hdop
        builder.append("07");//inputs
        builder.append("00");//unit status
        builder.append("FF");//event code
        builder.append("FF");//event Index
        builder.append("03");//3 accums
        builder.append("00");//spare
        builder.append("FFFFFFFF");
        builder.append("8000270F");
        builder.append("8131540F");

        EventReportMessageContent message = new EventReportMessageContent();
        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setTimeOfFix(new Date(1068845875000l));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(2147483647);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setUpdateTime(new Date(1068845875000l));
        locationStatusInfo.setSpeed(400);
        locationStatusInfo.setNumberOfSatellites(255);
        locationStatusInfo.setCarrier(65535);
        locationStatusInfo.setRssi(32767);
        locationStatusInfo.setHorizontalDilutionOfPrecision(255);
        message.setEventCode(255);
        message.setEventIndex(255);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false, false}));
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, false,false, false, false}));
        message.setLocationStatusInfo(locationStatusInfo);
        List<Long> accums = new ArrayList<Long>();
        accums.add(-1l);
        accums.add(2147493647l);
        accums.add(2167493647l);
        message.setAccumulatorValues(accums);
        eventReportMessageHelper(builder.toString(), message);
    }


    @Test
    public void testBasicsWithAccumulators()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("00000000"); //altitude
        builder.append("00000002"); //speed in cm
        builder.append("00D1"); //heading
        builder.append("04");//satellites
        builder.append("00");//fix status
        builder.append("0004");//carrier
        builder.append("FFBF"); //rssi
        builder.append("0f");//comm state
        builder.append("23");//hdop
        builder.append("07");//inputs
        builder.append("00");//unit status
        builder.append("02");//event Index
        builder.append("06");//event code
        builder.append("03");//3 accumulators
        builder.append("00");//spare
        builder.append("00000012");
        builder.append("00003e7c");
        builder.append("00000AD1");

        EventReportMessageContent message = new EventReportMessageContent();
        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setTimeOfFix(new Date(1068845875000l));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setUpdateTime(new Date(1068845875000l));
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setAltitude(0);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        message.setEventCode(6);
        message.setEventIndex(2);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false, false}));
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, false,false, false, false}));
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(18l);
        accumulators.add(15996l);
        accumulators.add(2769l);
        message.setLocationStatusInfo(locationStatusInfo);
        message.setAccumulatorValues(accumulators);
        eventReportMessageHelper(builder.toString(), message);

    }

    /**
     * note, the location & status info only comes from the LMU, for server to LMU messages,
     * it's not included
     */
    @Test
    public void testWithoutLocationStatusInfo()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("02");//event Index
        builder.append("01");//event code
        builder.append("00");//no accums
        builder.append("00");//spare

        EventReportMessageContent message = new EventReportMessageContent();
        message.setEventCode(1);
        message.setEventIndex(2);

        byte[] actualBytes = MessageContentSerializer.encodeEventReportMessageContent(message);
        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

    @Test
    public void testBasicsWithoutAccumulators()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("00000000"); //altitude
        builder.append("00000002"); //speed in cm
        builder.append("00D1"); //heading
        builder.append("04");//satellites
        builder.append("00");//fix status
        builder.append("0004");//carrier
        builder.append("FFBF"); //rssi
        builder.append("0f");//comm state
        builder.append("23");//hdop
        builder.append("07");//inputs
        builder.append("00");//unit status
        builder.append("02");//event Index
        builder.append("01");//event code
        builder.append("00");//no accums
        builder.append("00");//spare

        EventReportMessageContent message = new EventReportMessageContent();
        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setTimeOfFix(new Date(1068845875000l));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(0);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setUpdateTime(new Date(1068845875000l));
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        message.setEventCode(1);
        message.setEventIndex(2);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false, false}));
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, false,false, false, false}));
        message.setLocationStatusInfo(locationStatusInfo);
        eventReportMessageHelper(builder.toString(), message);
    }

    private void eventReportMessageHelper(String hexString, EventReportMessageContent eventReportMessageContent)
    {
        byte[] expectedBytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        EventReportMessageContent decodedHeader = MessageContentSerializer.decodeEventReportMessageContent(buffer);
        assertEquals(eventReportMessageContent, decodedHeader);

        byte[] actualBytes = MessageContentSerializer.encodeEventReportMessageContent(eventReportMessageContent);
        assertTrue(expectedBytes.length == actualBytes.length);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }
}
