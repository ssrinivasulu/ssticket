package com.calamp.connect.network.protocol.lmd.domain;


import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.ResourceRevision;

import static org.junit.Assert.assertEquals;

public class ResourceRevisionTest
{
    @Test
    public void resourceRevisionParseTest()
    {
        ResourceRevision resourceRevision = new ResourceRevision();
        resourceRevision.setFileType("0");
        resourceRevision.setAttachedDeviceAddress("");
        resourceRevision.setFilePath("CALAMP_FUSION-0399300003-PROD-V1.2.2-R201405081600.pak");
        resourceRevision.setFileVersion("CALAMP_FUSION-V1.2.2");
        resourceRevision.setAppliedTimestamp("");
        resourceRevision.setFutureFilePath("");
        resourceRevision.setFutureFileVersion("");
        resourceRevision.setFutureFileDownloadTimestamp("");
        resourceRevision.setFutureFileChecksumErrorCount("");
        resourceRevision.setFutureFilePathApplyTimestamp("");
        
        String rrev ="0,,CALAMP_FUSION-0399300003-PROD-V1.2.2-R201405081600.pak,CALAMP_FUSION-V1.2.2,,,,,,";
        
        ResourceRevision resourceRevisionParsed = ResourceRevision.parse(rrev);
        
        assertEquals(resourceRevision, resourceRevisionParsed);
    }
}
