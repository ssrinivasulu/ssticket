package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.nio.ByteBuffer;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.network.protocol.lmd.LmDirectSerializer;
import com.calamp.connect.network.protocol.lmd.converter.LMDirectToNetworkMessageConverter;
import com.calamp.connect.network.protocol.lmd.converter.NetworkAdapterConverterConfig;
import com.calamp.connect.network.protocol.lmd.domain.builders.IpUdpHeaderBuilder;
import com.calamp.connect.network.protocol.lmd.messageContent.IdReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.services.fmi.util.HexUtil;

@SpringBootTest(classes = {NetworkAdapterConverterConfig.class})
@RunWith(SpringJUnit4ClassRunner.class)
public class IdReportMessageTest
{
	@Autowired
	private LMDirectToNetworkMessageConverter lmDirectToNetworkMesageConverter;
	
    @Test
    public void idReportMessageDecodeTest()
    {
        String incomingMessage = "83037127520101000300BF0000000000000003000000000000FFFFFFFFFFFFFFFF9900005613058730311480105360953C1916203"
                + "44240FFFF89148000001034501766534B553A3134302D393332302D31303000534146453A3100465645523A43414C414D505F465553494F4E2030333"
                + "9393330303030332050524F442056312E322E33612D5232303134303633303134303000525245563A302C2C43414C414D505F465553494F4E2D30333"
                + "9393330303030332D50524F442D56312E322E33612D523230313430363330313430302E393330303130302E70616B2C50524F442D56312E322E33612"
                + "C2C2C2C2C2C7C312C2C49445265706F72745F32486F7572735F5F33643338333066656635366234663461613237303637306166336633643732332E7"
                + "86D6C2C49445265706F72745F32486F7572732C2C2C2C2C2C7C392C2C2C2C2C2C2C2C2C004C41544C4F4E3A33382E37353435372C2D3132312E33313"
                + "83638004F54413A317C303B30002357414E3A310057564952543A0057314D443A536965727261204D433737353000573148573A313000573146573A5"
                + "35749393630304D5F30332E30352E31302E30396170005731525353493A2D353464426D005731525352513A2D38644200573153494E523A306442005"
                + "7314C4E4B5459503A4E2F410057315246543A4E2F4100573150524C3A3000573143523A566572697A6F6E20576972656C65737300573150444E533A3"
                + "139382E3232342E3137332E31333500573153444E533A3139382E3232342E3137342E31333500573149503A3136362E3135342E3139302E313432005"
                + "7314E4D3A3235352E3235352E3235352E323532005731475749503A3136362E3135342E3139302E313431005731494D45493A3939303030303536313"
                + "330353837330057314D4549443A4131303030303344423041303543005731494D53493A33313134383031303533363039353300573149434349443A3"
                + "83931343830303030303130333435303137363600";
        
        LMDirectMessage lmDirectMessage = LmDirectSerializer.decode(HexUtil.convertFromHexString(incomingMessage));
        lmDirectMessage.setIpUdpHeader(IpUdpHeaderBuilder.getBuilderWithDefault().build());
        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(lmDirectMessage);

        String externalDeviceId = "712752";
        assertEquals(externalDeviceId, actualMessage.getExternalDeviceId());
    }

    @Test
    public void idReportMessageContentEncodeAndDecodeTest()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("01"); //scriptVersion 1
        builder.append("05"); //configVersion 5
        builder.append("000000"); //appVersion "
        builder.append("01"); //vehicleClass 1
        builder.append("00"); //unitStatus 0
        builder.append("03"); //modemSelection 3
        builder.append("01"); //applicationId 1
        builder.append("01"); //mobileIdType 1
        builder.append("00000000"); //queryId 0
        builder.append("ffffffffffffffff");
        builder.append("9900005613058730");
        builder.append("311480105360953c");
        builder.append("191620344240ffff");
        builder.append("89148000001034501766");
        
        IdReportMessageContent message = new IdReportMessageContent();
        message.setScriptVersion(1);
        message.setConfigVersion(5);
        message.setAppVersion("");
        message.setVehicleClass(1);
        message.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, false, false, false, false}));
        message.setModemSelection(3);
        message.setApplicationId(1);
        message.setMobileIdType(MobileIdType.ESN);
        message.setQueryId(0);
        message.setEsn("ffffffffffffffff");
        message.setImei("9900005613058730");
        message.setImsi("311480105360953c");
        message.setMin("191620344240ffff");
        message.setIccId("89148000001034501766");
        message.setExtension("");
        idReportMessageHelper(builder.toString(), message);
    }

    private void idReportMessageHelper( String hexString, IdReportMessageContent idReportMessageContent )
    {
        byte[] expectedBytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        IdReportMessageContent decodedMessage = IdReportMessageContent.decode(buffer);
        assertEquals(idReportMessageContent, decodedMessage);

        byte[] actualBytes = IdReportMessageContent.encode(idReportMessageContent);
        assertTrue(expectedBytes.length == actualBytes.length);
        for( int i=0;i<actualBytes.length;i++ )
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }
}
