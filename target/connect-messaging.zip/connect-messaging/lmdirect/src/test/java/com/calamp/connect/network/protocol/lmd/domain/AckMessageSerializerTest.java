package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;

import java.nio.ByteBuffer;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.serializers.MessageContentSerializer;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 18, 2010
 */
public class AckMessageSerializerTest
{
    @Test
    public void testAckMessageWithBlankAppVersion()
    {

        StringBuilder builder = new StringBuilder();
        builder.append("00"); //MessageType
        builder.append("00"); //AckType
        builder.append("00"); //spare
        builder.append("000000"); //AppVersion  of 61g


        AckMessageContent messageContent = new AckMessageContent();
        messageContent.setAckType(AckType.SUCCESS);
        messageContent.setMessageType(MessageType.NULL);
        messageContent.setAppVersion(null);
        ackMessageEncodingAndDecodingHelper(builder.toString(), messageContent);

    }

    @Test
    public void testAckMessageEncodeAndDecode()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("00"); //MessageType
        builder.append("00"); //AckType
        builder.append("00"); //spare
        builder.append("363147"); //AppVersion  of 61g

        AckMessageContent messageContent = new AckMessageContent();
        messageContent.setAckType(AckType.SUCCESS);
        messageContent.setMessageType(MessageType.NULL);
        messageContent.setAppVersion("61G");
        ackMessageEncodingAndDecodingHelper(builder.toString(), messageContent);

        builder = new StringBuilder();
        builder.append("09"); //MessageType
        builder.append("05"); //AckType
        builder.append("00"); //spare
        builder.append("4D4E4F"); //AppVersion

        messageContent = new AckMessageContent();
        messageContent.setAckType(AckType.FAILED_AUTHENTICATION_FAILURE);
        messageContent.setMessageType(MessageType.USER_DATA_WITH_ACCUMULATORS);
        messageContent.setAppVersion("MNO");
        ackMessageEncodingAndDecodingHelper(builder.toString(), messageContent);

        builder = new StringBuilder();
        builder.append("05"); //MessageType
        builder.append("03"); //AckType
        builder.append("00"); //spare
        builder.append("303030"); //AppVersion

        messageContent = new AckMessageContent();
        messageContent.setAckType(AckType.FAILED_UNSUPPORTED_OPERATION);
        messageContent.setMessageType(MessageType.APPLICATION_DATA);
        messageContent.setAppVersion("000");
        ackMessageEncodingAndDecodingHelper(builder.toString(), messageContent);

        builder = new StringBuilder();
        builder.append("05"); //MessageType
        builder.append("03"); //AckType
        builder.append("00"); //spare
        builder.append("303131"); //AppVersion

        messageContent = new AckMessageContent();
        messageContent.setAckType(AckType.FAILED_UNSUPPORTED_OPERATION);
        messageContent.setMessageType(MessageType.APPLICATION_DATA);
        messageContent.setAppVersion("011");
        ackMessageEncodingAndDecodingHelper(builder.toString(), messageContent);
    }

    private void ackMessageEncodingAndDecodingHelper(String hexString, AckMessageContent ackMessageContent)
    {
       byte[] expectedBytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        AckMessageContent decodedHeader = MessageContentSerializer.decodeAckMessage(buffer);
        assertEquals(ackMessageContent, decodedHeader);

        byte[] actualBytes = MessageContentSerializer.encodeAckMessageContent(ackMessageContent);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }
}
