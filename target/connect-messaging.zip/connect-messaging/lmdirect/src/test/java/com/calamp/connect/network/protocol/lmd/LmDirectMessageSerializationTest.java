package com.calamp.connect.network.protocol.lmd;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.CommGpsStatus;
import com.calamp.connect.network.protocol.lmd.domain.CommState;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.FixStatusAndSatellites;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.IpUdpHeader;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.network.protocol.lmd.domain.UnitStatus;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;
import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.LocateReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniEventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ParameterMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageWithAccumulatorsContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MessageStatisticsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterId;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterMessageAction;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterReadRequestMessage;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 19, 2010
 */
public class LmDirectMessageSerializationTest
{
    @Test
    public void testNullMessage()
    {
        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("07"); //mobile id length
        builder.append("63890070000000"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("02");//mobile id type
        builder.append("00"); //serviceType
        builder.append("00");//message Type
        builder.append("000F");//sequence Number

        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.IMEI);
        optionsHeader.setMobileId("63890070000000");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.NULL);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("8.12.2.32");
        ipUdpHeader.setDestinationAddress("99.12.43.77");
        ipUdpHeader.setSourcePort(8345);
        ipUdpHeader.setDestinationPort(8682);

        LMDirectMessage message = new LMDirectMessage();
        message.setIpUdpHeader(ipUdpHeader);
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        lmDirectMessageHelper(builder.toString(), message);
    }

    @Test
    public void testSampleAckMessage()
    {
        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("07"); //mobile id length
        builder.append("99999999999999"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("02");//mobile id type
        builder.append("00"); //serviceType
        builder.append("01");//message Type
        builder.append("000F");//sequence Number
        builder.append("04"); //MessageType
        builder.append("00"); //AckType
        builder.append("00"); //spare
        builder.append("363147"); //AppVersion  of 61G

        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.IMEI);
        optionsHeader.setMobileId("99999999999999");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.ACK_NAK);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);
        AckMessageContent content = new AckMessageContent();
        content.setAckType(AckType.SUCCESS);
        content.setMessageType(MessageType.USER_DATA);
        content.setAppVersion("61G");

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("87.162.72.32");
        ipUdpHeader.setDestinationAddress("113.91.57.19");
        ipUdpHeader.setSourcePort(14773);
        ipUdpHeader.setDestinationPort(23304);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(content);
        message.setIpUdpHeader(ipUdpHeader);
        lmDirectMessageHelper(builder.toString(), message);
    }

    @Test
    public void testMessageStatisticsReportApplicationMessage()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("83"); //options byte
        builder.append("07"); //mobile id length
        builder.append("99999999999999"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("02");//mobile id type
        builder.append("00"); //serviceType
        builder.append("05");//message Type
        builder.append("000F");//sequence Number
        builder.append("4CC04749"); //update time
        builder.append("4CC04749");//time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("000000FF"); //altitude
        builder.append("00000002"); //speed
        builder.append("00d1");//heading
        builder.append("04");//satellites
        builder.append("00");//fix status
        builder.append("0004");//carrier
        builder.append("FFBF");//RSSI
        builder.append("0f");//comm stat
        builder.append("23");//hdop
        builder.append("07"); //inputs
        builder.append("00");//unit status
        builder.append("0071"); //app message type
        builder.append("001E"); //app message payload size
        builder.append("000A"); //loca req count
        builder.append("0000"); //rec user msgs
        builder.append("0000"); //inbound reports
        builder.append("0000"); //sent user msgs
        builder.append("0000"); //spare
        builder.append("00000000"); //logged records
        builder.append("00000000000000000000000000000000"); //spare bits

        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.IMEI);
        optionsHeader.setMobileId("99999999999999");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.APPLICATION_DATA);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);

        ApplicationMessageContent content = new ApplicationMessageContent();
        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setUpdateTime(new Date(1287669577l*1000));
        locationStatusInfo.setTimeOfFix(new Date(1287669577l*1000));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(255);
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{ false, false, false, false, false, false, false, false}));
        locationStatusInfo.setFixStatus(new FixStatus(new boolean []{false, false,false, false, false, false, false, false}));
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));
        MessageStatisticsReport messageFormat = new MessageStatisticsReport();
        messageFormat.setLocationRequestsCount(10);
        content.setLocationStatusInfo(locationStatusInfo);
        content.setApplicationMessageType(ApplicationMessageType.MESSAGE_STATUS_REPORT);
        content.setApplicationMessageFormat(messageFormat);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(content);

        lmDirectMessageHelper(builder.toString(), message);
    }

    @Test
    public void testSampleIdReportMessage()
    {

    }

    @Test
    public void testSampleLocateReportMessage()
    {
        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("07"); //mobile id length
        builder.append("99999999999999"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("02");//mobile id type
        builder.append("02"); //serviceType
        builder.append("08");//message Type
        builder.append("000F");//sequence Number
        builder.append("4CC04749"); //update time
        builder.append("4CC04749");//time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("000000FF"); //altitude
        builder.append("00000002"); //speed
        builder.append("00d1");//heading
        builder.append("04");//satellites
        builder.append("00");//fix status
        builder.append("0004");//carrier
        builder.append("FFBF");//RSSI
        builder.append("0f");//comm stat
        builder.append("23");//hdop
        builder.append("07"); //inputs
        builder.append("00");//unit status
        builder.append("01"); //accumulator count
        builder.append("00");//spare
        builder.append("0000000c");//accumulator


        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.IMEI);
        optionsHeader.setMobileId("99999999999999");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.LOCATE_REPORT);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.RESPONSE_TO_ACKNOWLEDGED_REQUEST);

        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setUpdateTime(new Date(1287669577l*1000));
        locationStatusInfo.setTimeOfFix(new Date(1287669577l*1000));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(255);
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{ false, false, false, false, false, false, false, false}));
        locationStatusInfo.setFixStatus(new FixStatus(new boolean []{false, false,false, false, false, false, false, false}));
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));

        LocateReportMessageContent messageContent = new LocateReportMessageContent();
        messageContent.setLocationStatusInfo(locationStatusInfo);
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(12l);
        messageContent.setAccumulatorValues(accumulators);

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("87.162.72.32");
        ipUdpHeader.setDestinationAddress("113.91.57.19");
        ipUdpHeader.setSourcePort(14773);
        ipUdpHeader.setDestinationPort(23304);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(messageContent);
        message.setIpUdpHeader(ipUdpHeader);
        lmDirectMessageHelper(builder.toString(), message);
    }
    @Test
    public void testSampleMiniEventReportMessage()
    {
        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("05"); //mobile id length
        builder.append("0000000000"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("01");//mobile id type
        builder.append("00"); //serviceType
        builder.append("0a");//message Type
        builder.append("000F");//sequence Number
        builder.append("4CC04749"); //update time 
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("00d1");//heading
        builder.append("0F"); //speed
        builder.append("40");//fix stats & satellite count
        builder.append("0f");//comm stat
        builder.append("07"); //in puts
        builder.append("01");//event code
        builder.append("02");//accumulator count
        builder.append("0000007B");
        builder.append("0001E2E2");

        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.ESN);
        optionsHeader.setMobileId("0000000000");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.MINI_EVENT_REPORT);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);

        List<Long> accumulatorValues = new ArrayList<Long>();
        accumulatorValues.add(123l);
        accumulatorValues.add(123618l);

        MiniEventReportMessageContent messageContent = new MiniEventReportMessageContent();
        messageContent.setEventCode(1);
        messageContent.setAccumulatorValues(accumulatorValues);

        messageContent.setUpdateTime(new Date(1287669577l*1000));
        messageContent.setLongitude(-117.2771933);
        messageContent.setLatitude(33.0470716);
        messageContent.setHeading(209);
        messageContent.setSpeed(15);
        messageContent.setFixStatusAndSatellites(new FixStatusAndSatellites(new boolean[] { false, true, false, false, false, false, false, false}));
        messageContent.setCommGpsStatus(new CommGpsStatus(new boolean[] { false, false, false, false, true, true, true, true}));
        messageContent.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("87.162.72.32");
        ipUdpHeader.setDestinationAddress("113.91.57.19");
        ipUdpHeader.setSourcePort(14773);
        ipUdpHeader.setDestinationPort(23304);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(messageContent);
        message.setIpUdpHeader(ipUdpHeader);
        lmDirectMessageHelper(builder.toString(), message);
    }

    @Test
    public void testSampleParameterMessage()
    {

        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("05"); //mobile id length
        builder.append("1234567899"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("01");//mobile id type
        builder.append("00"); //serviceType
        builder.append("06");//message Type
        builder.append("000F");//sequence Number
        builder.append("00"); //Read Request
        builder.append("0910"); //parameterId
        builder.append("0001"); //length
        builder.append("00"); //index
        builder.append("00000000"); //footer

        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.ESN);
        optionsHeader.setMobileId("1234567899");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.CONFIGURATION_PARAMETER);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);

        ParameterMessageContent parameterMessageContent = new ParameterMessageContent();
        parameterMessageContent.setAction(ParameterMessageAction.READ_REQUEST);
        ParameterReadRequestMessage requestMessageBody = new ParameterReadRequestMessage();
        requestMessageBody.addParameterId(ParameterId.getParameterId(2320), 0);
        parameterMessageContent.setBody(requestMessageBody);

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("87.12.7.255");
        ipUdpHeader.setDestinationAddress("3.1.7.9");
        ipUdpHeader.setSourcePort(143);
        ipUdpHeader.setDestinationPort(204);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(parameterMessageContent);
        message.setIpUdpHeader(ipUdpHeader);
        lmDirectMessageHelper(builder.toString(), message);
    }

    @Test
    public void testSampleUserMessage()
    {
        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("05"); //mobile id length
        builder.append("1234567899"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("01");//mobile id type
        builder.append("00"); //serviceType
        builder.append("04");//message Type
        builder.append("000F");//sequence Number
        builder.append("4CC04749"); //update time
        builder.append("4CC04749");//time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("000000FF"); //altitude
        builder.append("00000002"); //speed
        builder.append("00d1");//heading
        builder.append("04");//satellites
        builder.append("00");//fix status
        builder.append("0004");//carrier
        builder.append("FFBF");//RSSI
        builder.append("0f");//comm stat
        builder.append("23");//hdop
        builder.append("07"); //inputs
        builder.append("00");//unit status
        builder.append("02"); //message route
        builder.append("17");//message id
        builder.append("000c");//message length
        builder.append("68656C6C6F20776F726C642E");//message
        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.ESN);
        optionsHeader.setMobileId("1234567899");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.USER_DATA);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);

        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setUpdateTime(new Date(1287669577l*1000));
        locationStatusInfo.setTimeOfFix(new Date(1287669577l*1000));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(255);
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{ false, false, false, false, false, false, false, false}));
        locationStatusInfo.setFixStatus(new FixStatus(new boolean []{false, false,false, false, false, false, false, false}));
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));

        UserMessageContent messageContent = new UserMessageContent();
        messageContent.setLocationStatusInfo(locationStatusInfo);
        messageContent.setUserMessage(HexUtil.convertFromHexString("68656C6C6F20776F726C642E"));
        messageContent.setUserMessageId(23);
        messageContent.setUserMessageRoute(UserMessageRoute.AUX_PORT);
        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("87.12.7.255");
        ipUdpHeader.setDestinationAddress("3.1.7.9");
        ipUdpHeader.setSourcePort(143);
        ipUdpHeader.setDestinationPort(204);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(messageContent);
        message.setIpUdpHeader(ipUdpHeader);
        lmDirectMessageHelper(builder.toString(), message);
    }

    @Test
    public void testSampleUserMessageWithAccumulators()
    {
        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("05"); //mobile id length
        builder.append("9876543210"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("04");//mobile id type
        builder.append("00"); //serviceType
        builder.append("09");//message Type
        builder.append("000F");//sequence Number
        builder.append("4CC04749"); //update time
        builder.append("4CC04749");//time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("000000FF"); //altitude
        builder.append("00000002"); //speed
        builder.append("00d1");//heading
        builder.append("04");//satellites
        builder.append("00");//fix status
        builder.append("0004");//carrier
        builder.append("FFBF");//RSSI
        builder.append("0f");//comm stat
        builder.append("23");//hdop
        builder.append("07"); //inputs
        builder.append("00");//unit status
        builder.append("00");//spare
        builder.append("00");//spare
        builder.append("02");//accumulator count
        builder.append("00");//spare
        builder.append("0000007B");
        builder.append("0001E2E2");
        builder.append("02"); //message route
        builder.append("17");//message id
        builder.append("000c");//message length
        builder.append("68656C6C6F20776F726C642E");//message
        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.USER_DEFINED);
        optionsHeader.setMobileId("9876543210");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.USER_DATA_WITH_ACCUMULATORS);
        messageHeader.setSequenceNumber(15);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);

        List<Long> accumulatorValues = new ArrayList<Long>();
        accumulatorValues.add(123l);
        accumulatorValues.add(123618l);

        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setUpdateTime(new Date(1287669577l*1000));
        locationStatusInfo.setTimeOfFix(new Date(1287669577l*1000));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(255);
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{ false, false, false, false, false, false, false, false}));
        locationStatusInfo.setFixStatus(new FixStatus(new boolean []{false, false,false, false, false, false, false, false}));
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));

        UserMessageWithAccumulatorsContent messageContent = new UserMessageWithAccumulatorsContent();
        messageContent.setAccumulatorValues(accumulatorValues);
        messageContent.setLocationStatusInfo(locationStatusInfo);
        messageContent.setUserMessage("hello world.");
        messageContent.setUserMessageId(23);
        messageContent.setUserMessageRoute(UserMessageRoute.AUX_PORT);

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("87.12.7.255");
        ipUdpHeader.setDestinationAddress("3.1.7.9");
        ipUdpHeader.setSourcePort(143);
        ipUdpHeader.setDestinationPort(204);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(messageContent);
        message.setIpUdpHeader(ipUdpHeader);
        lmDirectMessageHelper(builder.toString(), message);
    }


    @Test
    public void testSampleEventReport()
    {
        StringBuilder builder = new StringBuilder();

        builder.append("83"); //options byte
        builder.append("05"); //mobile id length
        builder.append("5555555555"); //mobile id
        builder.append("01");//mobile id length will always be 1
        builder.append("01");//mobile id type
        builder.append("01"); //serviceType
        builder.append("02");//message Type
        builder.append("000A");//sequence Number
        builder.append("3fb54b33"); //update time
        builder.append("3fb54b33");//time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("00000000"); //altitude
        builder.append("00000002"); //speed
        builder.append("00d1");//heading
        builder.append("04");//satellites
        builder.append("00");//fix status
        builder.append("0004");//carrier
        builder.append("FFBF");//RSSI
        builder.append("0f");//comm stat
        builder.append("23");//hdop
        builder.append("07"); //in puts
        builder.append("00");//unit status
        builder.append("01");//event index
        builder.append("01");//event code
        builder.append("02");//accumulator count
        builder.append("00");//spare
        builder.append("0000007B");
        builder.append("0001E2E2");

        OptionsHeader optionsHeader = new OptionsHeader();
        optionsHeader.setMobileIdType(MobileIdType.ESN);
        optionsHeader.setMobileId("5555555555");

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.EVENT_REPORT);
        messageHeader.setSequenceNumber(10);
        messageHeader.setServiceType(ServiceType.ACKNOWLEDGED_REQUEST);

        List<Long> accumulatorValues = new ArrayList<Long>();
        accumulatorValues.add(123l);
        accumulatorValues.add(123618l);

        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setUpdateTime(new Date(1068845875l*1000));
        locationStatusInfo.setTimeOfFix(new Date(1068845875l*1000));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(0);
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{ false, false, false, false, false, false, false, false}));
        locationStatusInfo.setFixStatus(new FixStatus(new boolean []{false, false,false, false, false, false, false, false}));
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));

        EventReportMessageContent messageContent = new EventReportMessageContent();
        messageContent.setEventCode(1);
        messageContent.setEventIndex(1);
        messageContent.setAccumulatorValues(accumulatorValues);
        messageContent.setLocationStatusInfo(locationStatusInfo);

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress("32.12.54.12");
        ipUdpHeader.setDestinationAddress("63.125.7.1");
        ipUdpHeader.setSourcePort(14324);
        ipUdpHeader.setDestinationPort(20514);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(messageContent);
        message.setIpUdpHeader(ipUdpHeader);
        lmDirectMessageHelper(builder.toString(), message);

    }
    @Test
    public void testDecodeSampleAppMessageWithAccumulators()
    {
    	byte[] expectedBytes = HexUtil.convertFromHexString("830546412235850101010E16E059357F7F5935302D173832D8D1DB41800000215D00000000000000040012FFA90F0A140000005200000000000000FFFF0003F8F70000000000000000000000000000000000000B8600000AE40007A120001E848094162F53000000000000000000000000000000000012EB870000583E0082000A95850000102700000064");
    	LMDirectMessage actualMessage = LmDirectSerializer.decode(expectedBytes);
    	
    	
    	assertEquals(actualMessage.getMessageType().getValue(),14);
    	
    }
    
    @Test
    public void testMiniUserMessageContentDecode()
    {
    	byte[] expectedBytes = HexUtil.convertFromHexString("830546410927980101010B00085993409C0200002710A12124009CF4F533DB000000546869732049732041204D696E69204D65737361676500201003");
        LMDirectMessage actualMessage = LmDirectSerializer.decode(expectedBytes);
        byte[] actualBytes = LmDirectSerializer.encode(actualMessage);
        assertArrayEquals(expectedBytes, actualBytes);
        assertEquals(actualMessage.getMessageType(),MessageType.MINI_USER_DATA);
    }
    @Test
    public void testMiniAppMessageContentDecode()
    {
    	byte[] expectedBytes = HexUtil.convertFromHexString("830546414022910101010C0004599353C90083005F56494E3A3147314A433534343452373235323336370050524F544F3A3600504152414D533A302C312C342C372C382C31312C31322C323000494E44435452533A3028303030303030303030303131292C312831313131313131313131312900");
        LMDirectMessage actualMessage = LmDirectSerializer.decode(expectedBytes);
        byte[] actualBytes = LmDirectSerializer.encode(actualMessage);
//        assertArrayEquals(expectedBytes, actualBytes);
        assertEquals(actualMessage.getMessageType(),MessageType.MINI_APPLICATION_DATA);
    }
    
    @Test
    public void testParameterMessageDecode()
    {
    	byte[] parameterMsgBytes = HexUtil.convertFromHexString("8305454220384001010206ea3c0300000000");
    	LMDirectMessage lmdirectMsg = LmDirectSerializer.decode(parameterMsgBytes);
    	assertEquals(MessageType.CONFIGURATION_PARAMETER, lmdirectMsg.getMessageType());
    	assertEquals(ParameterMessageAction.WRITE_REPORT, ((ParameterMessageContent)lmdirectMsg.getMessageContent()).getAction());
    	assertEquals(59964,  lmdirectMsg.getSequenceNumber());
    }
    
    @Test
    public void testJPOD2type138ContentDecode()
    {
    	//83054865001724010101050006584A0AA6584A0AA613C06D0FBA18D3EB000018B20000000000000802019AFFC74F0EFE00008A006810661400006E00000100640001050061000F09005E00020D00A8000111009D00041500AE00031900AF00021D006F000121002E0202250072020B290039040B2D00BE000231005B00043500BE000039007202023D00BE000A41002E0203450010000449007202084D
    	byte[] expectedBytes = HexUtil.convertFromHexString("83054865001724010101050006584A0AA6584A0AA613C06D0FBA18D3EB000018B20000000000000802019AFFC74F0EFE00008A006810661400006E00000100640001050061000F09005E00020D00A8000111009D00041500AE00031900AF00021D006F000121002E0202250072020B290039040B2D00BE000231005B00043500BE000039007202023D00BE000A41002E0203450010000449007202084D");
    	 LMDirectMessage actualMessage = LmDirectSerializer.decode(expectedBytes);
         byte[] actualBytes = LmDirectSerializer.encode(actualMessage);
         assertArrayEquals(expectedBytes, actualBytes);
         assertEquals(actualMessage.getMessageType(),MessageType.APPLICATION_DATA);
    }
    //
    @Test
    public void testJPOD2type142ContentDecode()
    {
    	//83054865001724010101050004584A0A24584A0A2413C06FF8BA18D88C00000A2A0000000200000800019AFFC74F0BFE00008E002A1F090000090901FFED0000000000001A02FFECFE0011008800314D3847444D3941584B50303432303133
    	byte[] expectedBytes = HexUtil.convertFromHexString("83054865001724010101050004584A0A24584A0A2413C06FF8BA18D88C00000A2A0000000200000800019AFFC74F0BFE00008E002A1F090000090901FFED0000000000001A02FFECFE0011008800314D3847444D3941584B50303432303133");
    	 LMDirectMessage actualMessage = LmDirectSerializer.decode(expectedBytes);
         byte[] actualBytes = LmDirectSerializer.encode(actualMessage);
         assertArrayEquals(expectedBytes, actualBytes);
         assertEquals(actualMessage.getMessageType(),MessageType.APPLICATION_DATA);
    }
    @Test
    public void testSethCreatedOptionsExtensionVINMessage()
    {
    	//c305456216505001010102112121212121212121212121212121212121010201A9596D3573596D35731A259D8CD0C7A2EC00003A31000000000150092202D0FF9B4F0B10002D030000
    	byte[] expectedBytes = HexUtil.convertFromHexString("C305456216505001010102112121212121212121212121212121212121010201A9596D3573596D35731A259D8CD0C7A2EC00003A31000000000150092202D0FF9B4F0B10002D030000");
    	LMDirectMessage actualMessage = LmDirectSerializer.decode(expectedBytes);
    	assert(actualMessage.getOptionsHeader().getOptionsExtension() != null);
    	assert(actualMessage.getOptionsHeader().getOptionsExtension().getVin() != null);
    }
    private void lmDirectMessageHelper(String expectedHexString, LMDirectMessage expectedMessage)
    {
        byte[] expectedBytes = HexUtil.convertFromHexString(expectedHexString);
        LMDirectMessage actualMessage = LmDirectSerializer.decode(expectedBytes);
        assertEquals(expectedMessage, actualMessage);

        byte[] actualBytes = LmDirectSerializer.encode(actualMessage);
        assertArrayEquals(expectedBytes, actualBytes);
    }
 
}

