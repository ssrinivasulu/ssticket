package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;

import java.nio.ByteBuffer;
import java.util.Date;

import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.CommState;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.OBDIIProtocol;
import com.calamp.connect.network.protocol.lmd.domain.UnitStatus;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.JbusReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MessageStatisticsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.junit.Test;



/**
 * User: ericw
 * Date: Oct 19, 2010
 */
public class ApplicationMessageSerializerTest {
    @Test
    public void testVehicleIdReportDecodeWithNoVin() {
        String builder = "4ddc34ab00000000000000000000000000000000000000000000002c019affab0f0000080083000c56494e3a0050524f544f3a3000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ApplicationMessageContent actualContent = ApplicationMessageContent.decode(byteBuffer);

        ApplicationMessageContent expectedContent = new ApplicationMessageContent();
        expectedContent.setApplicationMessageType(ApplicationMessageType.VEHICLE_REPORT_ID);

        VehicleIdReport vehicleIdReport = new VehicleIdReport("", OBDIIProtocol.NONE);
        expectedContent.setApplicationMessageFormat(vehicleIdReport);
        assertEquals(expectedContent.getApplicationMessageFormat(), actualContent.getApplicationMessageFormat());
        assertEquals(expectedContent.getApplicationMessageType(), actualContent.getApplicationMessageType());
    }
    
    @Test
    public void testVbusDataReportPassthrough(){
    	//8305484300251101010105f848 <- this part not part of testing, combine for dummy message
    	String builder = "5926d7e55926d7e518476183d3eff7f6000000000000000000c50a020016ffbd0f09f4000082001498e0290e073f4d157815ffa2154e15b115ff7515";
    	byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ApplicationMessageContent actualContent = ApplicationMessageContent.decode(byteBuffer);
        assert(actualContent.getApplicationMessageType() != null);
    }

    @Test
    public void testVehicleIdReportDecodeWithVin() {
        String builder = "00000034000000000000000000000000000000000000000000000064019affa30f00e10c0083005e56494e3a0050524f544f3a3600504152414d533a302c312c322c342c372c382c31312c313200494e44435452533a3028303030303030303030303131292c312831313131313131313131312900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ApplicationMessageContent actualContent = ApplicationMessageContent.decode(byteBuffer);

        ApplicationMessageContent expectedContent = new ApplicationMessageContent();
        expectedContent.setApplicationMessageType(ApplicationMessageType.VEHICLE_REPORT_ID);
        VehicleIdReport vehicleIdReport = new VehicleIdReport("", OBDIIProtocol.CAN29BIT);
        expectedContent.setApplicationMessageFormat(vehicleIdReport);

        assertEquals(expectedContent.getApplicationMessageFormat(), actualContent.getApplicationMessageFormat());
        assertEquals(expectedContent.getApplicationMessageType(), actualContent.getApplicationMessageType());
    }

    @Test
    public void testVehicleIdReportDecodeWithVinNewMessageFormat() {
        String builder = "00000034000000000000000000000000000000000000000000000064019affa30f00e10c0083005e56494e3a4a4d3354423338413438303135373034300050524f544f3a3700504152414d533a302c312c322c342c372c382c31312c313200494e44435452533a3028303030303030303030303131292c312831313131313131313131312900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ApplicationMessageContent actualContent = ApplicationMessageContent.decode(byteBuffer);

        ApplicationMessageContent expectedContent = new ApplicationMessageContent();
        expectedContent.setApplicationMessageType(ApplicationMessageType.VEHICLE_REPORT_ID);
        VehicleIdReport vehicleIdReport = new VehicleIdReport("JM3TB38A480157040", OBDIIProtocol.CAN11BIT_250);
        expectedContent.setApplicationMessageFormat(vehicleIdReport);

        assertEquals(expectedContent.getApplicationMessageFormat(), actualContent.getApplicationMessageFormat());
        assertEquals(expectedContent.getApplicationMessageType(), actualContent.getApplicationMessageType());
    }

    @Test
    public void testVehicleIdReportDecodeWithNoVinNewMessageFormat() {
        String builder = "00000034000000000000000000000000000000000000000000000064019affa30f00e10c0083005e56494e3a4a4d3354423338413438303135373034300050524f544f3a3700504152414d533a302c312c322c342c372c382c31312c313200494e44435452533a3028303030303030303030303131292c312831313131313131313131312900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ApplicationMessageContent actualContent = ApplicationMessageContent.decode(byteBuffer);

        ApplicationMessageContent expectedContent = new ApplicationMessageContent();
        expectedContent.setApplicationMessageType(ApplicationMessageType.VEHICLE_REPORT_ID);
        VehicleIdReport vehicleIdReport = new VehicleIdReport("JM3TB38A480157040", OBDIIProtocol.CAN11BIT_250);
        expectedContent.setApplicationMessageFormat(vehicleIdReport);

        assertEquals(expectedContent.getApplicationMessageFormat(), actualContent.getApplicationMessageFormat());
        assertEquals(expectedContent.getApplicationMessageType(), actualContent.getApplicationMessageType());
    }

    @Test
    public void testMessageReportStatisicsDecodeWithLocationInfo() {
        StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("00000000"); //altitude
        builder.append("00000000"); //speed in cm
        builder.append("0000"); //heading
        builder.append("0c");//satellites
        builder.append("6c");//fix status
        builder.append("3018");//carrier
        builder.append("0000"); //rssi
        builder.append("00");//comm state
        builder.append("00");//hdop
        builder.append("dd");//inputs
        builder.append("0a");//unit status
        builder.append("0071"); //application message type
        builder.append("001E"); //application message payload length
        builder.append("0000"); //location request count
        builder.append("0000"); //received user messages
        builder.append("000C");//inbound reports
        builder.append("00E8");//sent user msgs
        builder.append("0000"); //spare
        builder.append("0012C97F"); //logged records
        builder.append("00000000000000000000000000000000"); //spare bytes.
        byte[] bytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ApplicationMessageContent actualContent = ApplicationMessageContent.decode(byteBuffer);

        ApplicationMessageContent expectedContent = new ApplicationMessageContent();
        expectedContent.setApplicationMessageType(ApplicationMessageType.MESSAGE_STATUS_REPORT);

        MessageStatisticsReport report = new MessageStatisticsReport();
        report.setInboundReportCount(12);
        report.setLoggedMessages(1231231L);
        report.setSentUserMessages(232);
        expectedContent.setApplicationMessageFormat(report);

        LocationStatusInfo info = new LocationStatusInfo();
        info.setCarrier(12312);
        info.setTimeOfFix(new Date(1068845875000l));
        info.setUpdateTime(new Date(1068845875000l));
        info.setLongitude(-117.2771933);
        info.setLatitude(33.0470716);
        info.setNumberOfSatellites(12);
        info.setFixStatus(new FixStatus(new boolean[]{false, true, true, false, true, true, false, false}));
        info.setCommState(new CommState(new boolean[]{false, false, false, false, false, false, false, false}));
        info.setInputs(new Inputs(new boolean[]{true, true, false, true, true, true, false, true}));
        info.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, true, false, true, false}));
        expectedContent.setLocationStatusInfo(info);


        assertEquals(expectedContent, actualContent);
    }

    @Test
    public void testMessageReportStatisticsEncodeWithNoLocationInfo() {
        byte[] expectedBytes = HexUtil.convertFromHexString("0071001E00000000000C00E800000012C97F00000000000000000000000000000000");

        ApplicationMessageContent content = new ApplicationMessageContent();
        content.setApplicationMessageType(ApplicationMessageType.MESSAGE_STATUS_REPORT);

        MessageStatisticsReport report = new MessageStatisticsReport();
        report.setInboundReportCount(12);
        report.setLoggedMessages(1231231L);
        report.setSentUserMessages(232);
        content.setApplicationMessageFormat(report);

        byte[] actualBytes = ApplicationMessageContent.encode(content);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testMessageReportStatisticsEncodeWithLocationInfo() {
        StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("00000000"); //altitude
        builder.append("00000000"); //speed in cm
        builder.append("0000"); //heading
        builder.append("0c");//satellites
        builder.append("6c");//fix status
        builder.append("3018");//carrier
        builder.append("0000"); //rssi
        builder.append("00");//comm state
        builder.append("00");//hdop
        builder.append("dd");//inputs
        builder.append("0a");//unit status
        builder.append("0071"); //application message type
        builder.append("001E"); //application message payload length
        builder.append("0000"); //location request count
        builder.append("0000"); //received user messages
        builder.append("000C");//inbound reports
        builder.append("00E8");//sent user msgs
        builder.append("0000"); //spare
        builder.append("0012C97F"); //logged records
        builder.append("00000000000000000000000000000000"); //spare bytes.
        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());

        ApplicationMessageContent content = new ApplicationMessageContent();
        content.setApplicationMessageType(ApplicationMessageType.MESSAGE_STATUS_REPORT);

        MessageStatisticsReport report = new MessageStatisticsReport();
        report.setInboundReportCount(12);
        report.setLoggedMessages(1231231L);
        report.setSentUserMessages(232);
        content.setApplicationMessageFormat(report);

        LocationStatusInfo info = new LocationStatusInfo();
        info.setCarrier(12312);
        info.setTimeOfFix(new Date(1068845875000l));
        info.setUpdateTime(new Date(1068845875000l));
        info.setLongitude(-117.2771933);
        info.setLatitude(33.0470716);
        info.setNumberOfSatellites(12);
        info.setFixStatus(new FixStatus(new boolean[]{false, true, true, false, true, true, false, false}));
        info.setCommState(new CommState(new boolean[]{false, false, false, false, false, false, false, false}));
        info.setInputs(new Inputs(new boolean[]{true, true, false, true, true, true, false, true}));
        info.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, true, false, true, false}));
        content.setLocationStatusInfo(info);

        byte[] actualBytes = ApplicationMessageContent.encode(content);

        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testJbusReportEncodeWithNoLocationInformation() {
        byte[] expectedBytes = HexUtil.convertFromHexString("008200024869");

        ApplicationMessageContent content = new ApplicationMessageContent();
        content.setApplicationMessageType(ApplicationMessageType.JBUS_REPORT);

        JbusReport report = new JbusReport(HexUtil.convertFromHexString("4869"));
        content.setApplicationMessageFormat(report);

        byte[] actualBytes = ApplicationMessageContent.encode(content);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testJbusReportDecodeWithNoLocationInformation() {
        ApplicationMessageContent expectedContent = new ApplicationMessageContent();
        LocationStatusInfo info = new LocationStatusInfo();
        info.setCarrier(12312);
        info.setTimeOfFix(new Date(1068845875000l));
        info.setUpdateTime(new Date(1068845875000l));
        info.setLongitude(-117.2771933);
        info.setLatitude(33.0470716);
        info.setNumberOfSatellites(12);
        info.setFixStatus(new FixStatus(new boolean[]{false, true, true, false, true, true, false, false}));
        info.setCommState(new CommState(new boolean[]{false, false, false, false, false, false, false, false}));
        info.setInputs(new Inputs(new boolean[]{true, true, false, true, true, true, false, true}));
        info.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, true, false, true, false}));
        expectedContent.setLocationStatusInfo(info);
        expectedContent.setApplicationMessageType(ApplicationMessageType.JBUS_REPORT);
        JbusReport report = new JbusReport(HexUtil.convertFromHexString("4869"));
        expectedContent.setApplicationMessageFormat(report);

        //this info might not get sent. how do i tell the difference between the two?
        StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("00000000"); //altitude
        builder.append("00000000"); //speed in cm
        builder.append("0000"); //heading
        builder.append("0c");//satellites
        builder.append("6c");//fix status
        builder.append("3018");//carrier
        builder.append("0000"); //rssi
        builder.append("00");//comm state
        builder.append("00");//hdop
        builder.append("dd");//inputs
        builder.append("0a");//unit status
        builder.append("008200024869"); //(type, size, jbus message)
        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());

        ApplicationMessageContent actualContent = ApplicationMessageContent.decode(ByteBuffer.wrap(expectedBytes));
        assertEquals(expectedContent, actualContent);
    }

}
