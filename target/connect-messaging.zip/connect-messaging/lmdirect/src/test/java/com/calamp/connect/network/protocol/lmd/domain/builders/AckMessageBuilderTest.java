package com.calamp.connect.network.protocol.lmd.domain.builders;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 * User: ericw
 * Date: Oct 26, 2010
 */
public class AckMessageBuilderTest
{

    /**
     * Note, the options Header can't be null since that's what
     * creates the options byte
     */
    @Test
    public void testBuilderWithEmptyOptionsHeader()
    {
        LMDirectMessage expectedMessage = new LMDirectMessage();
        AckMessageContent messageContent = new AckMessageContent();
        messageContent.setAckType(AckType.SUCCESS);
        messageContent.setMessageType(MessageType.NULL);
        messageContent.setAppVersion("000");
        expectedMessage.setMessageContent(messageContent);

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setSequenceNumber(123);
        messageHeader.setServiceType(ServiceType.RESPONSE_TO_ACKNOWLEDGED_REQUEST);
        messageHeader.setMessageType(MessageType.EVENT_REPORT);
        expectedMessage.setMessageHeader(messageHeader);
        expectedMessage.setOptionsHeader(new OptionsHeader());

        LMDirectMessage actualMessage = AckMessageBuilder.getBuilder()
                .setAckType(AckType.SUCCESS)
                .setAppVersion("000")
                .setAckToMessageType(MessageType.NULL)
                .setServiceType(ServiceType.RESPONSE_TO_ACKNOWLEDGED_REQUEST)
                .setSequenceNumber(123)
                .setMessageType(MessageType.EVENT_REPORT)
                .toLMDirectMessage();

        assertEquals(expectedMessage, actualMessage);
    }

    /**
     * Note, the builder creates a message with the type of Ack_NAK
     */
    @Test
    public void testBuilderWithEmptyMessageHeader()
    {
        LMDirectMessage expectedMessage = new LMDirectMessage();
        AckMessageContent messageContent = new AckMessageContent();
        messageContent.setAckType(AckType.SUCCESS);
        messageContent.setMessageType(MessageType.NULL);
        messageContent.setAppVersion("000");
        expectedMessage.setMessageContent(messageContent);

        OptionsHeader header = new OptionsHeader();
        header.setMobileId("2342");
        header.setAuthentication("DOG");
        expectedMessage.setOptionsHeader(header);

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.ACK_NAK);
        expectedMessage.setMessageHeader(messageHeader);

        LMDirectMessage actualMessage = AckMessageBuilder.getBuilder()
            .setAckType(AckType.SUCCESS)
            .setAppVersion("000")
            .setAckToMessageType(MessageType.NULL)
            .setMobileId("2342")
            .setAuthentication("DOG")
            .toLMDirectMessage();
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void testBuilderWithNullMessageContents()
    {
        LMDirectMessage expectedMessage = new LMDirectMessage();

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setSequenceNumber(23523);
        messageHeader.setServiceType(ServiceType.ACKNOWLEDGED_REQUEST);
        messageHeader.setMessageType(MessageType.USER_DATA);
        expectedMessage.setMessageHeader(messageHeader);

        OptionsHeader header = new OptionsHeader();
        header.setMobileIdType(MobileIdType.CURRENT_IP);
        header.setRouting("BIT");
        expectedMessage.setOptionsHeader(header);
        LMDirectMessage actualMessage = AckMessageBuilder.getBuilder()
            .setServiceType(ServiceType.ACKNOWLEDGED_REQUEST)
            .setSequenceNumber(23523)
            .setMessageType(MessageType.USER_DATA)
            .setMobileIdType(MobileIdType.CURRENT_IP)
            .setRouting("BIT")
            .toLMDirectMessage();

         assertEquals(expectedMessage, actualMessage);

    }



}
