package com.calamp.connect.network.protocol.lmd.domain.applicationmessagetypes;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ObdSupportedParameters;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * User: ericw  Date: 3/7/13
 */
public class ObdSupportedParametersTest
{
    private ObdSupportedParameters parameters;

    @Test
    public void testSomeSupportedParameters()
    {
        String supportedParameters = "1,3,7,13,17,25,29";
        parameters = new ObdSupportedParameters(supportedParameters);
        assertTrue(parameters.isEngineSpeedSupported());
        assertTrue(parameters.isOdometerSupported());
        assertTrue(parameters.isEngineCoolantTempSupported());
        assertTrue(parameters.isCalculatedFuelUsageSupported());
        assertTrue(parameters.isServiceIntervalDaysRemainingSupported());
        assertTrue(parameters.isBarometricPressureSupported());
        assertTrue(parameters.isCanBusErrorTypeSupported());

        assertFalse(parameters.isVehicleSpeedSupported());
        assertFalse(parameters.isThrottlePositionSupported());
        assertFalse(parameters.isFuelLevelSupported());
        assertFalse(parameters.isFuelLevelRemainingSupported());
        assertFalse(parameters.isTransmissionGearSupported());
        assertFalse(parameters.isFuelRateSupported());
        assertFalse(parameters.isBatteryVoltageSupported());
        assertFalse(parameters.isTurnSignalStatusSupported());
        assertFalse(parameters.isTripOdometerSupported());
        assertFalse(parameters.isTripFuelConsumptionSupported());
        assertFalse(parameters.isEngineStateSupported());
        assertFalse(parameters.isServiceIntervalInspectionDistanceSupported());
        assertFalse(parameters.isFuelLevelRemaining3030Supported());
        assertFalse(parameters.isEngineOilTempSupported());
        assertFalse(parameters.isFuelEconomySupported());
        assertFalse(parameters.isDTCCountSupported());
        assertFalse(parameters.isServiceIntervalOilDistanceSupported());
        assertFalse(parameters.isServiceIntervalOilDaysSupported());
        assertFalse(parameters.isEngineRunTimeSupported());
        assertFalse(parameters.isAmbientAirTempSupported());
        assertFalse(parameters.isCanTecSupported());
        assertFalse(parameters.isCanRecSupported());
        assertFalse(parameters.isCanBusModeSupported());
        
    }

    @Test
    public void testAllSupportedParameters()
    {
        String supportedParameters = "0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29";
        parameters = new ObdSupportedParameters(supportedParameters);
        assertTrue(parameters.isEngineSpeedSupported());
        assertTrue(parameters.isOdometerSupported());
        assertTrue(parameters.isEngineCoolantTempSupported());
        assertTrue(parameters.isVehicleSpeedSupported());
        assertTrue(parameters.isThrottlePositionSupported());
        assertTrue(parameters.isFuelLevelSupported());
        assertTrue(parameters.isFuelLevelRemainingSupported());
        assertTrue(parameters.isTransmissionGearSupported());
        assertTrue(parameters.isFuelRateSupported());
        assertTrue(parameters.isBatteryVoltageSupported());
        assertTrue(parameters.isTurnSignalStatusSupported());
        assertTrue(parameters.isTripOdometerSupported());
        assertTrue(parameters.isTripFuelConsumptionSupported());
        assertTrue(parameters.isCalculatedFuelUsageSupported());
        assertTrue(parameters.isEngineStateSupported());
        assertTrue(parameters.isServiceIntervalInspectionDistanceSupported());
        assertTrue(parameters.isFuelLevelRemaining3030Supported());
        assertTrue(parameters.isServiceIntervalDaysRemainingSupported());
        assertTrue(parameters.isEngineOilTempSupported());
        assertTrue(parameters.isFuelEconomySupported());
        assertTrue(parameters.isDTCCountSupported());
        assertTrue(parameters.isServiceIntervalOilDistanceSupported());
        assertTrue(parameters.isServiceIntervalOilDaysSupported());
        assertTrue(parameters.isEngineRunTimeSupported());
        assertTrue(parameters.isAmbientAirTempSupported());
        assertTrue(parameters.isBarometricPressureSupported());
        assertTrue(parameters.isCanTecSupported());
        assertTrue(parameters.isCanRecSupported());
        assertTrue(parameters.isCanBusModeSupported());
        assertTrue(parameters.isCanBusErrorTypeSupported());
        
    }

    @Test
    public void testNoSupportedParameters()
    {
        String supportedParameters = "";
        parameters = new ObdSupportedParameters(supportedParameters);
        assertFalse(parameters.isEngineSpeedSupported());
        assertFalse(parameters.isEngineCoolantTempSupported());
        assertFalse(parameters.isVehicleSpeedSupported());
        assertFalse(parameters.isThrottlePositionSupported());
        assertFalse(parameters.isOdometerSupported());
        assertFalse(parameters.isFuelLevelSupported());
        assertFalse(parameters.isFuelLevelRemainingSupported());
        assertFalse(parameters.isTransmissionGearSupported());
        assertFalse(parameters.isFuelRateSupported());
        assertFalse(parameters.isBatteryVoltageSupported());
        assertFalse(parameters.isTurnSignalStatusSupported());
        assertFalse(parameters.isTripOdometerSupported());
        assertFalse(parameters.isTripFuelConsumptionSupported());
        assertFalse(parameters.isCalculatedFuelUsageSupported());
        assertFalse(parameters.isEngineStateSupported());
        assertFalse(parameters.isServiceIntervalInspectionDistanceSupported());
        assertFalse(parameters.isFuelLevelRemaining3030Supported());
        assertFalse(parameters.isServiceIntervalDaysRemainingSupported());
        assertFalse(parameters.isEngineOilTempSupported());
        assertFalse(parameters.isFuelEconomySupported());
        assertFalse(parameters.isDTCCountSupported());
        assertFalse(parameters.isServiceIntervalOilDistanceSupported());
        assertFalse(parameters.isServiceIntervalOilDaysSupported());
        assertFalse(parameters.isEngineRunTimeSupported());
        assertFalse(parameters.isAmbientAirTempSupported());
        assertFalse(parameters.isBarometricPressureSupported());
        assertFalse(parameters.isCanTecSupported());
        assertFalse(parameters.isCanRecSupported());
        assertFalse(parameters.isCanBusModeSupported());
        assertFalse(parameters.isCanBusErrorTypeSupported());
    }

    @Test
    public void testOneSupportedParameters()
    {
        String supportedParameters = "8";
        parameters = new ObdSupportedParameters(supportedParameters);
        assertTrue(parameters.isFuelRateSupported());

        assertFalse(parameters.isEngineSpeedSupported());
        assertFalse(parameters.isEngineCoolantTempSupported());
        assertFalse(parameters.isVehicleSpeedSupported());
        assertFalse(parameters.isThrottlePositionSupported());
        assertFalse(parameters.isOdometerSupported());
        assertFalse(parameters.isFuelLevelSupported());
        assertFalse(parameters.isFuelLevelRemainingSupported());
        assertFalse(parameters.isTransmissionGearSupported());
        assertFalse(parameters.isBatteryVoltageSupported());
        assertFalse(parameters.isTurnSignalStatusSupported());
        assertFalse(parameters.isTripOdometerSupported());
        assertFalse(parameters.isTripFuelConsumptionSupported());
        assertFalse(parameters.isCalculatedFuelUsageSupported());
        assertFalse(parameters.isEngineStateSupported());
        assertFalse(parameters.isServiceIntervalInspectionDistanceSupported());
        assertFalse(parameters.isFuelLevelRemaining3030Supported());
        assertFalse(parameters.isServiceIntervalDaysRemainingSupported());
        assertFalse(parameters.isEngineOilTempSupported());
        assertFalse(parameters.isFuelEconomySupported());
        assertFalse(parameters.isDTCCountSupported());
        assertFalse(parameters.isServiceIntervalOilDistanceSupported());
        assertFalse(parameters.isServiceIntervalOilDaysSupported());
        assertFalse(parameters.isEngineRunTimeSupported());
        assertFalse(parameters.isAmbientAirTempSupported());
        assertFalse(parameters.isBarometricPressureSupported());
        assertFalse(parameters.isCanTecSupported());
        assertFalse(parameters.isCanRecSupported());
        assertFalse(parameters.isCanBusModeSupported());
        assertFalse(parameters.isCanBusErrorTypeSupported());
    }
}
