package com.calamp.connect.network.protocol.lmd.domain.applicationmessagetypes;

import java.nio.ByteBuffer;

import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.OtaDownload;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class OtaDownloadTest
{
    @Test
    public void otaDownloadEncodeAndDecodeTest()
    {
        OtaDownload originalOtaDownload = new OtaDownload();
        originalOtaDownload.setDeviceType("1000");
        originalOtaDownload.setFileType("1");
        originalOtaDownload.setFileLength("157767");
        originalOtaDownload.setFileVersion("MVFusionDev");
        originalOtaDownload.setDownloadProtocol("1");
        originalOtaDownload.setServerName("dev.calamp-ts.com");
        originalOtaDownload.setFilePath("downloads/devicefiles/FusionDev__da39fdb909724bf1b685ed4b55a781ac.xml");
        originalOtaDownload.setApplyDate("1413000000000");
        originalOtaDownload.setChecksum("761d39d625feaaf8d9869ef79538cdbd");
        
        byte[] originalReportBytes = originalOtaDownload.encode();
        ByteBuffer byteBuffer = ByteBuffer.wrap(originalReportBytes);
        OtaDownload newOtaDownload = OtaDownload.decode(byteBuffer);
        
        assertEquals(originalOtaDownload, newOtaDownload);
    }

    @Test
    public void otaDownloadEncodeTest()
    {
        String expectedHexString = "4445563a313030300046494c453a3100464c454e3a313537373637005645523a4d56467573696f6e4465760050524f543a31005"
                + "35256523a6465762e63616c616d702d74732e636f6d00504154483a646f776e6c6f6164732f64657669636566696c65732f467573696f6e4465765f5"
                + "f64613339666462393039373234626631623638356564346235356137383161632e786d6c004150504c59444154453a3134313330303030303030303"
                + "00043484b53554d3a37363164333964363235666561616638643938363965663739353338636462640041444556414444523a6e756c6c";
        byte[] expectedBytes = HexUtil.convertFromHexString(expectedHexString);

        OtaDownload otaDownload = new OtaDownload();
        otaDownload.setDeviceType("1000");
        otaDownload.setFileType("1");
        otaDownload.setFileLength("157767");
        otaDownload.setFileVersion("MVFusionDev");
        otaDownload.setDownloadProtocol("1");
        otaDownload.setServerName("dev.calamp-ts.com");
        otaDownload.setFilePath("downloads/devicefiles/FusionDev__da39fdb909724bf1b685ed4b55a781ac.xml");
        otaDownload.setApplyDate("1413000000000");
        otaDownload.setChecksum("761d39d625feaaf8d9869ef79538cdbd");

        byte[] actualBytes = otaDownload.encode();
        
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void otaDownloadDecodeTest()
    {
        String hexString = "4445563a313030300046494c453a3100464c454e3a313537373637005645523a4d56467573696f6e4465760050524f543a31005"
                + "35256523a6465762e63616c616d702d74732e636f6d00504154483a646f776e6c6f6164732f64657669636566696c65732f467573696f6e4465765f5"
                + "f64613339666462393039373234626631623638356564346235356137383161632e786d6c004150504c59444154453a3134313330303030303030303"
                + "00043484b53554d3a37363164333964363235666561616638643938363965663739353338636462640041444556414444523a6e756c6c";
        byte[] bytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);

        OtaDownload otaDownloadExpected = new OtaDownload();
        otaDownloadExpected.setDeviceType("1000");
        otaDownloadExpected.setFileType("1");
        otaDownloadExpected.setFileLength("157767");
        otaDownloadExpected.setFileVersion("MVFusionDev");
        otaDownloadExpected.setDownloadProtocol("1");
        otaDownloadExpected.setServerName("dev.calamp-ts.com");
        otaDownloadExpected.setFilePath("downloads/devicefiles/FusionDev__da39fdb909724bf1b685ed4b55a781ac.xml");
        otaDownloadExpected.setApplyDate("1413000000000");
        otaDownloadExpected.setChecksum("761d39d625feaaf8d9869ef79538cdbd");

        OtaDownload actualOtaDownload = OtaDownload.decode(byteBuffer);
        assertEquals(otaDownloadExpected,  actualOtaDownload);
    }
}
