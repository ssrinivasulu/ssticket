/*
 *
 */
package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.nio.ByteBuffer;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.calamp.connect.services.fmi.util.HexUtil;

public class OtaDownload extends ApplicationMessageFormat
{
    private String deviceType;
    private String fileType;
    private String fileLength;
    private String fileVersion;
    private String downloadProtocol;
    private String serverName;
    private String filePath;
    private String username;
    private String password;
    private String applyDate;
    private String checksum;
    private String attachedDeviceAddress;
    
    private static final String OTA_SEPARATOR = "\0";
    private static final String OTA_TUPLE_SEPARATOR = ":";
    private static final String NULL_VALUE_STRING = "null";
    private static final String DEVICE_TYPE = "DEV";
    private static final String FILE_TYPE = "FILE";
    private static final String FILE_LENGTH = "FLEN";
    private static final String FILE_VERSION = "VER";
    private static final String DOWNLOAD_PROTOCOL = "PROT";
    private static final String SERVER_NAME = "SRVR";
    private static final String FILE_PATH = "PATH";
    private static final String USERNAME = "UNAM";
    private static final String PASSWORD = "PWD";
    private static final String APPLY_DATE = "APPLYDATE";
    private static final String CHECKSUM = "CHKSUM";
    private static final String ATTACHED_DEVICE_ADDRESS = "ADEVADDR";

    /**
     * @return the deviceType
     */
    public String getDeviceType()
    {
        return deviceType;
    }

    /**
     * @param deviceType the deviceType to set
     */
    public void setDeviceType(String deviceType)
    {
        this.deviceType = deviceType;
    }

    /**
     * @return the fileType
     */
    public String getFileType()
    {
        return fileType;
    }

    /**
     * @param fileType the fileType to set
     */
    public void setFileType(String fileType)
    {
        this.fileType = fileType;
    }

    /**
     * @return the fileLength
     */
    public String getFileLength()
    {
        return fileLength;
    }

    /**
     * @param fileLength the fileLength to set
     */
    public void setFileLength(String fileLength)
    {
        this.fileLength = fileLength;
    }

    /**
     * @return the fileVersion
     */
    public String getFileVersion()
    {
        return fileVersion;
    }

    /**
     * @param fileVersion the fileVersion to set
     */
    public void setFileVersion(String fileVersion)
    {
        this.fileVersion = fileVersion;
    }

    /**
     * @return the downloadProtocol
     */
    public String getDownloadProtocol()
    {
        return downloadProtocol;
    }

    /**
     * @param downloadProtocol the downloadProtocol to set
     */
    public void setDownloadProtocol(String downloadProtocol)
    {
        this.downloadProtocol = downloadProtocol;
    }

    /**
     * @return the serverName
     */
    public String getServerName()
    {
        return serverName;
    }

    /**
     * @param serverName the serverName to set
     */
    public void setServerName(String serverName)
    {
        this.serverName = serverName;
    }

    /**
     * @return the filePath
     */
    public String getFilePath()
    {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath)
    {
        this.filePath = filePath;
    }

    /**
     * @return the username
     */
    public String getUsername()
    {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword()
    {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * @return the applyDate
     */
    public String getApplyDate()
    {
        return applyDate;
    }

    /**
     * @param applyDate the applyDate to set
     */
    public void setApplyDate(String applyDate)
    {
        this.applyDate = applyDate;
    }

    /**
     * @return the checksum
     */
    public String getChecksum()
    {
        return checksum;
    }

    /**
     * @param checksum the checksum to set
     */
    public void setChecksum(String checksum)
    {
        this.checksum = checksum;
    }

    /**
     * @return the attachedDeviceAddress
     */
    public String getAttachedDeviceAddress()
    {
        return attachedDeviceAddress;
    }

    /**
     * @param attachedDeviceAddress the attachedDeviceAddress to set
     */
    public void setAttachedDeviceAddress(String attachedDeviceAddress)
    {
        this.attachedDeviceAddress = attachedDeviceAddress;
    }
    
    @Override
    public byte[] encode()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(DEVICE_TYPE).append(OTA_TUPLE_SEPARATOR).append(this.deviceType).append(OTA_SEPARATOR);
        sb.append(FILE_TYPE).append(OTA_TUPLE_SEPARATOR).append(this.fileType).append(OTA_SEPARATOR);
        sb.append(FILE_LENGTH).append(OTA_TUPLE_SEPARATOR).append(this.fileLength).append(OTA_SEPARATOR);
        sb.append(FILE_VERSION).append(OTA_TUPLE_SEPARATOR).append(this.fileVersion).append(OTA_SEPARATOR);
        sb.append(DOWNLOAD_PROTOCOL).append(OTA_TUPLE_SEPARATOR).append(this.downloadProtocol).append(OTA_SEPARATOR);
        sb.append(SERVER_NAME).append(OTA_TUPLE_SEPARATOR).append(this.serverName).append(OTA_SEPARATOR);
        sb.append(FILE_PATH).append(OTA_TUPLE_SEPARATOR).append(this.filePath).append(OTA_SEPARATOR);
        
        if ( StringUtils.isNotBlank(this.username) )
            sb.append(USERNAME).append(OTA_TUPLE_SEPARATOR).append(this.username).append(OTA_SEPARATOR);
        
        if ( StringUtils.isNotBlank(this.password) )
            sb.append(PASSWORD).append(OTA_TUPLE_SEPARATOR).append(this.password).append(OTA_SEPARATOR);
        
        sb.append(APPLY_DATE).append(OTA_TUPLE_SEPARATOR).append(this.applyDate).append(OTA_SEPARATOR);
        
        if ( StringUtils.isNotBlank(this.checksum) )
            sb.append(CHECKSUM).append(OTA_TUPLE_SEPARATOR).append(this.checksum).append(OTA_SEPARATOR);
        
        sb.append(ATTACHED_DEVICE_ADDRESS).append(OTA_TUPLE_SEPARATOR).append(this.attachedDeviceAddress);
        
        return HexUtil.getHexByteArray(sb.toString());
    }

    public static OtaDownload decode(ByteBuffer byteBuffer)
    {
        OtaDownload otaDownload = new OtaDownload();
        
        String ota = decodeValue(byteBuffer, byteBuffer.remaining());
        if ( ota == null )
            return otaDownload;
        
        Map<String, String> otaMap = parseOtaString(ota);
        
        otaDownload.setDeviceType(otaMap.get(DEVICE_TYPE));
        otaDownload.setFileType(otaMap.get(FILE_TYPE));
        otaDownload.setFileLength(otaMap.get(FILE_LENGTH));
        otaDownload.setFileVersion(otaMap.get(FILE_VERSION));
        otaDownload.setDownloadProtocol(otaMap.get(DOWNLOAD_PROTOCOL));
        otaDownload.setServerName(otaMap.get(SERVER_NAME));
        otaDownload.setFilePath(otaMap.get(FILE_PATH));
        otaDownload.setUsername(otaMap.get(USERNAME));
        otaDownload.setPassword(otaMap.get(PASSWORD));
        otaDownload.setApplyDate(otaMap.get(APPLY_DATE));
        otaDownload.setChecksum(otaMap.get(CHECKSUM));
        otaDownload.setAttachedDeviceAddress(otaMap.get(ATTACHED_DEVICE_ADDRESS));
        
        return otaDownload;
    }
    
    private static String decodeValue( ByteBuffer byteBuffer, int length )
    {
        byte[] values = new byte[length];
        byteBuffer.get(values, 0, length);
        String valueString = null;
        
        for( byte data : values )
        {
            if( data != 0 )
            {
                valueString = HexUtil.getStringFromHexByteArray(values);
                break;
            }
        }
        
        return valueString;
    }
    
    private static Map<String, String> parseOtaString( String otaString )
    {
        Map<String, String> otaMap = new LinkedHashMap<>();
        
        String[] otaTuples = otaString.split(OTA_SEPARATOR);
        for ( String tupleString : otaTuples )
        {
            String[] tuple = StringUtils.splitPreserveAllTokens(tupleString, OTA_TUPLE_SEPARATOR);
            
            if ( !tuple[1].equalsIgnoreCase(NULL_VALUE_STRING) )
                otaMap.put(tuple[0], tuple[1]);
            else
                otaMap.put(tuple[0], null);
        }
        
        return otaMap;
    }
    
    @Override
    public String toString()
    {
        return "OtaDownload{" +
                "deviceType=" + deviceType +
                ", fileType=" + fileType +
                ", fileLength=" + fileLength +
                ", fileVersion=" + fileVersion +
                ", downloadProtocol=" + downloadProtocol +
                ", serverName=" + serverName +
                ", filePath=" + filePath +
                ", username=" + username +
                ", password=" + password +
                ", applyDate=" + applyDate +
                ", checksum=" + checksum +
                ", attachedDeviceAddress=" + attachedDeviceAddress +
                "}";
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OtaDownload that = (OtaDownload) o;

        if (deviceType != null ? !deviceType.equals(that.deviceType) : that.deviceType != null) return false;
        if (fileType != null ? !fileType.equals(that.fileType) : that.fileType != null) return false;
        if (fileLength != null ? !fileLength.equals(that.fileLength) : that.fileLength != null) return false;
        if (fileVersion != null ? !fileVersion.equals(that.fileVersion) : that.fileVersion != null) return false;
        if (downloadProtocol != null ? !downloadProtocol.equals(that.downloadProtocol) : that.downloadProtocol != null) return false;
        if (serverName != null ? !serverName.equals(that.serverName) : that.serverName != null) return false;
        if (filePath != null ? !filePath.equals(that.filePath) : that.filePath != null) return false;
        if (username != null ? !username.equals(that.username) : that.username != null) return false;
        if (password != null ? !password.equals(that.password) : that.password != null) return false;
        if (applyDate != null ? !applyDate.equals(that.applyDate) : that.applyDate != null) return false;
        if (checksum != null ? !checksum.equals(that.checksum) : that.checksum != null) return false;
        if (attachedDeviceAddress != null ? !attachedDeviceAddress.equals(that.attachedDeviceAddress) : that.attachedDeviceAddress != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (deviceType != null ? deviceType.hashCode() : 0);
        result = 31 * result + (fileType != null ? fileType.hashCode() : 0);
        result = 31 * result + (fileLength != null ? fileLength.hashCode() : 0);
        result = 31 * result + (fileVersion != null ? fileVersion.hashCode() : 0);
        result = 31 * result + (downloadProtocol != null ? downloadProtocol.hashCode() : 0);
        result = 31 * result + (serverName != null ? serverName.hashCode() : 0);
        result = 31 * result + (filePath != null ? filePath.hashCode() : 0);
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (password != null ? password.hashCode() : 0);
        result = 31 * result + (applyDate != null ? applyDate.hashCode() : 0);
        result = 31 * result + (checksum != null ? checksum.hashCode() : 0);
        result = 31 * result + (attachedDeviceAddress != null ? attachedDeviceAddress.hashCode() : 0);
        
        return result;
    }
}
