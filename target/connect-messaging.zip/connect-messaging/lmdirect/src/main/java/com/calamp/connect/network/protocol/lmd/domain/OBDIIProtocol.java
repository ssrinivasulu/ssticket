package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: 5/24/11
 */
public enum OBDIIProtocol
{
    NONE(0), J1850VPW(1), J1850PWM(2), ISO9141_2(3), KWP2000(4), CAN11BIT(5), CAN29BIT(6), CAN11BIT_250(7), CAN29BIT_250(8), KWP2000_5(9);

    private int index;
    OBDIIProtocol(int index)
    {
        this.index = index;
    }

    public int getIndex()
    {
        return index;
    }

    public static OBDIIProtocol getValue(int protocol)
    {
        for(OBDIIProtocol obdiiProtocol : OBDIIProtocol.values())
        {
            if(obdiiProtocol.getIndex() == protocol)
                return obdiiProtocol;
        }
        return null;
    }
}
