package com.calamp.connect.network.protocol.lmd.domain.builders;

import java.util.Date;

import com.calamp.connect.network.protocol.lmd.domain.CommState;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.UnitStatus;

/**
 * User: ericw
 * Date: Oct 27, 2010
 */
public class LocationStatusInfoBuilder
{
    private LocationStatusInfo locationStatusInfo;

    private LocationStatusInfoBuilder( LocationStatusInfo locationStatusInfo )
    {
        this.locationStatusInfo = locationStatusInfo;
    }

    public static LocationStatusInfoBuilder buildFrom(LocationStatusInfo info)
    {
        return new LocationStatusInfoBuilder(LocationStatusInfoBuilder.copyMessage(info));
    }

    public static LocationStatusInfoBuilder getBuilder()
    {
        return new LocationStatusInfoBuilder(new LocationStatusInfo());
    }
    
    public static LocationStatusInfoBuilder getBuilderWithDefault()
    {
        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        Date defaultDate = new Date(1288199000); //  In seconds!
        locationStatusInfo.setUpdateTime(defaultDate );
        locationStatusInfo.setTimeOfFix(defaultDate );
        locationStatusInfo.setLatitude(38.9698323);
        locationStatusInfo.setLongitude(-77.3860975);
        locationStatusInfo.setAltitude(361);
        locationStatusInfo.setSpeed(3576);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{true, true, true, true, true, true, true, true}));
        locationStatusInfo.setCarrier(234);
        locationStatusInfo.setRssi(23);
        locationStatusInfo.setCommState(new CommState(new boolean[]{true, true, true, true, true, true, true, true}));
        locationStatusInfo.setHorizontalDilutionOfPrecision(234);
        locationStatusInfo.setInputs(new Inputs(new boolean[]{true, true, true, true, true, true, true, true}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{true, true, true, true, true, true, true, true}));
        return new LocationStatusInfoBuilder(locationStatusInfo);
    }

    public LocationStatusInfoBuilder setUpdateTime(Date updateTime)
    {
        locationStatusInfo.setUpdateTime(updateTime);
        return this;
    }


    public LocationStatusInfoBuilder setTimeOfFix(Date timeOfFix)
    {
        locationStatusInfo.setTimeOfFix(timeOfFix);
        return this;
    }

    public LocationStatusInfoBuilder setLongitude(Double longitude)
    {
        locationStatusInfo.setLongitude(longitude);
        return this;
    }

    public LocationStatusInfoBuilder setLatitude(Double latitude)
    {
        locationStatusInfo.setLatitude(latitude);
        return this;
    }

    public LocationStatusInfoBuilder setAltitude(Integer altitude)
    {
        locationStatusInfo.setAltitude(altitude);
        return this;
    }

    public LocationStatusInfoBuilder setSpeed(long speed)
    {
        locationStatusInfo.setSpeed(speed);
        return this;
    }

    public LocationStatusInfoBuilder setHeading(int heading)
    {
        locationStatusInfo.setHeading(heading);
        return this;
    }

    public LocationStatusInfoBuilder setNumberOfSatellites(int satelliteCount)
    {
        locationStatusInfo.setNumberOfSatellites(satelliteCount);
        return this;
    }

    public LocationStatusInfoBuilder setFixStatus(FixStatus fixStatus)
    {
        locationStatusInfo.setFixStatus(fixStatus);
        return this;
    }

    public LocationStatusInfoBuilder setCarrier(Integer carrier)
    {
        locationStatusInfo.setCarrier(carrier);
        return this;
    }

    public LocationStatusInfoBuilder setCommState(CommState commState)
    {
        locationStatusInfo.setCommState(commState);
        return this;
    }

    public LocationStatusInfoBuilder setHorizontalDilutionOfPrecision(Integer hdop)
    {
        locationStatusInfo.setHorizontalDilutionOfPrecision(hdop);
        return this;
    }

    public LocationStatusInfoBuilder setInputs(Inputs inputs)
    {
        locationStatusInfo.setInputs(inputs);
        return this;
    }

    public LocationStatusInfoBuilder setUnitStatus(UnitStatus unitStatus)
    {
        locationStatusInfo.setUnitStatus(unitStatus);
        return this;
    }

    public LocationStatusInfoBuilder setRssi(Integer rssi)
    {
        locationStatusInfo.setRssi(rssi);
        return this;
    }

    private static LocationStatusInfo copyMessage(LocationStatusInfo messageToCopy)
    {
        return new LocationStatusInfo(messageToCopy);
    }

    public LocationStatusInfo build()
    {
        LocationStatusInfo returnMessage = locationStatusInfo;
        locationStatusInfo = null;
        return returnMessage;
    }

    public void clear()
    {
        locationStatusInfo=null;
    }
}
