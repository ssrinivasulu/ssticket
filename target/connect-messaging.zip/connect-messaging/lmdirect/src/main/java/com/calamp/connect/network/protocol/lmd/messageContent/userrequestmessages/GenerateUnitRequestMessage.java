package com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages;

import java.nio.ByteBuffer;

import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * @author Sidlingappa
 *
 */
public class GenerateUnitRequestMessage implements UnitRequestMessageBody
{
    private String data8bit;
    private String data16bit;
    private String data32bit;

    public GenerateUnitRequestMessage(String data8bit, String data16bit, String data32bit)
    {
        this.data8bit = data8bit;
        this.data16bit = data16bit;
        this.data32bit = data32bit;
    }

    public static GenerateUnitRequestMessage decode(ByteBuffer byteBuffer)
    {
        String data8bit = String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        String data16bit = String.valueOf(byteBuffer.getShort());
        String data32bit = String.valueOf(byteBuffer.getInt());

        GenerateUnitRequestMessage message = new GenerateUnitRequestMessage(data8bit, data16bit, data32bit);

        return message;
    }

    @Override
    public byte[] encode()
    {
        byte[] byteArray = new byte[7];

        if (data8bit.length() == 2)
        {
            int val = Integer.parseInt(data8bit, 16);
            byteArray[0] = (byte) ((val >>> 0) & 0xff);
        }
        else
        {
            byteArray[0] = 0;
        }
        if (data16bit.length() == 4)
        {
            long val = Long.parseLong(data16bit, 16);
            byteArray[1] = (byte) ((val >>> 8) & 0xff);
            byteArray[2] = (byte) ((val >>> 0) & 0xff);
        }
        else
        {
            byteArray[1] = 0;
            byteArray[2] = 0;
        }
        if (data32bit.length() == 8)
        {
            long val = Long.parseLong(data32bit, 16);
            byteArray[3] = (byte) ((val >>> 24) & 0xff);
            byteArray[4] = (byte) ((val >>> 16) & 0xff);
            byteArray[5] = (byte) ((val >>> 8) & 0xff);
            byteArray[6] = (byte) ((val >>> 0) & 0xff);
        }
        else
        {
            byteArray[3] = 0;
            byteArray[4] = 0;
            byteArray[5] = 0;
            byteArray[6] = 0;
        }

        return byteArray;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        GenerateUnitRequestMessage that = (GenerateUnitRequestMessage) o;

        if (!data8bit.equals(that.data8bit))
            return false;
        if (!data16bit.equals(that.data16bit))
            return false;
        if (!data32bit.equals(that.data32bit))
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = ((data8bit != null) ? data8bit.hashCode() : 0);
        result = 31 * result + ((data16bit != null) ? data16bit.hashCode() : 0);
        result = 31 * result + ((data32bit != null) ? data32bit.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "GenerateUnitRequestMessage{" + "data8bit=" + data8bit + " data16bit=" + data16bit + " data32bit=" + data32bit + '}';
    }

    public String getData8bit()
    {
        return data8bit;
    }

    public void setData8bit(String data8bit)
    {
        this.data8bit = data8bit;
    }

    public String getData16bit()
    {
        return data16bit;
    }

    public void setData16bit(String data16bit)
    {
        this.data16bit = data16bit;
    }

    public String getData32bit()
    {
        return data32bit;
    }

    public void setData32bit(String data32bit)
    {
        this.data32bit = data32bit;
    }

}
