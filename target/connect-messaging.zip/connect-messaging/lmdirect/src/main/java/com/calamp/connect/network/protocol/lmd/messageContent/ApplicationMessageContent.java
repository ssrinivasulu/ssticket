package com.calamp.connect.network.protocol.lmd.messageContent;

import java.nio.ByteBuffer;

import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ApplicationMessageFormat;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.DtcReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.JbusReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MessageStatisticsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MotionLogsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.OtaDownload;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.UnknownReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class ApplicationMessageContent  extends MessageContent
{
    private LocationStatusInfo locationStatusInfo;
    private ApplicationMessageType applicationMessageType;
    private ApplicationMessageFormat applicationMessageFormat;

    public LocationStatusInfo getLocationStatusInfo()
    {
        return locationStatusInfo;
    }

    public void setLocationStatusInfo(LocationStatusInfo locationStatusInfo)
    {
        this.locationStatusInfo = locationStatusInfo;
    }

    public ApplicationMessageType getApplicationMessageType()
    {
        return applicationMessageType;
    }

    public void setApplicationMessageType(ApplicationMessageType applicationMessageType)
    {
        this.applicationMessageType = applicationMessageType;
    }

    public ApplicationMessageFormat getApplicationMessageFormat()
    {
        return applicationMessageFormat;
    }

    public void setApplicationMessageFormat(ApplicationMessageFormat applicationMessageFormat)
    {
        this.applicationMessageFormat = applicationMessageFormat;
    }

    public static ApplicationMessageContent decode(ByteBuffer byteBuffer) {
    	return decode(byteBuffer, true);
    }
    
    public static ApplicationMessageContent decode(ByteBuffer byteBuffer, boolean isUpLink)
    {
        LocationStatusInfo locationInfo = null;
        if(isUpLink)
        	locationInfo = LocationStatusInfo.decode(byteBuffer);
        int messageTypeValue = ByteUtil.getUnsignedShort(byteBuffer);
        ApplicationMessageType applicationMessageType = ApplicationMessageType.getApplicationMessageType(messageTypeValue);
        int messageFormatSize = ByteUtil.getUnsignedShort(byteBuffer);//the size isn't used, but we need to advance the byteBuffer
        ApplicationMessageFormat  format = null;
        switch (applicationMessageType)
        {
            case MESSAGE_STATUS_REPORT:
            {
                format = MessageStatisticsReport.decode(byteBuffer);
                break;
            }
            case VEHICLE_REPORT_ID:
            {
                format = VehicleIdReport.decode(byteBuffer);
                break;
            }
            case DTC_REPORT:
            {
                format = DtcReport.decode(byteBuffer);
                break;
            }
            case JBUS_REPORT:
            {
                format =  JbusReport.decode(byteBuffer);
                break;
            }
            case OTA_DOWNLOAD:
            {
                format = OtaDownload.decode(byteBuffer);
                break;
            }
            case MOTION_LOGS:
            {
                format = MotionLogsReport.decode(byteBuffer);
                break;
            }
			default:
			{
				applicationMessageType = ApplicationMessageType.UNKNOWN;
				byte [] rest = new byte[byteBuffer.remaining()];
				for (int i = 0; i < rest.length; i++) {
		            rest[i] = byteBuffer.get();
		        }
				
				format = UnknownReport.decode(rest, messageFormatSize, messageTypeValue);
				break;
			}
        }

        ApplicationMessageContent content = new ApplicationMessageContent();
        content.setLocationStatusInfo(locationInfo);
        content.setApplicationMessageType(applicationMessageType);
        content.setApplicationMessageFormat(format);
        return content;
    }

    public static byte[] encode(ApplicationMessageContent applicationMessageContent)
    {
        byte[] locationStatusBytes = new byte[0];
        if(applicationMessageContent.getLocationStatusInfo()!=null)
        {
            locationStatusBytes = LocationStatusInfo.encode(applicationMessageContent.getLocationStatusInfo());
        }
        byte[] applicationMessageTypeBytes = new byte[0];
        if(applicationMessageContent.getApplicationMessageType() != ApplicationMessageType.UNKNOWN){
        	applicationMessageTypeBytes = applicationMessageContent.getApplicationMessageType().toBytes();
        }
        else
        {
        	ByteBuffer typeByteBuffer = ByteBuffer.allocate(2);
        	typeByteBuffer.putShort((short)((UnknownReport)applicationMessageContent.getApplicationMessageFormat()).getMessageTypeValue());
        	applicationMessageTypeBytes = typeByteBuffer.array();
        	
        }
        byte[] applicationMessageFormatBytes = new byte[0];
        if(applicationMessageContent.getApplicationMessageFormat()!=null)
        {
            applicationMessageFormatBytes = applicationMessageContent.getApplicationMessageFormat().encode();
        }

        ByteBuffer byteBuffer = ByteBuffer.allocate(locationStatusBytes.length
                + applicationMessageFormatBytes.length + applicationMessageTypeBytes.length+2); //+2 for msg size
        byteBuffer.put(locationStatusBytes);
        byteBuffer.put(applicationMessageTypeBytes);
        byteBuffer.putShort((short)applicationMessageFormatBytes.length);
        byteBuffer.put(applicationMessageFormatBytes);
        return byteBuffer.array();
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ApplicationMessageContent that = (ApplicationMessageContent) o;

        if (applicationMessageFormat != null ? !applicationMessageFormat.equals(that.applicationMessageFormat) : that.applicationMessageFormat != null)
            return false;
        if (applicationMessageType != that.applicationMessageType) return false;
        if (locationStatusInfo != null ? !locationStatusInfo.equals(that.locationStatusInfo) : that.locationStatusInfo != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = locationStatusInfo != null ? locationStatusInfo.hashCode() : 0;
        result = 31 * result + (applicationMessageType != null ? applicationMessageType.hashCode() : 0);
        result = 31 * result + (applicationMessageFormat != null ? applicationMessageFormat.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "ApplicationMessageContent{" +
                "locationStatusInfo=" + locationStatusInfo +
                ", applicationMessageType=" + applicationMessageType +
                ", applicationMessageFormat=" + applicationMessageFormat +
                '}';
    }
}
