package com.calamp.connect.network.protocol.lmd.springintegration;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.models.network.Network.MessageDetail;
import com.calamp.connect.models.network.Network.NetworkMessage;

/**
 * User: ericw
 * Date: 2/24/11
 */
public class EventMessageDataTransformer
{
    private static Logger logger = LogManager.getLogger(EventMessageDataTransformer.class);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss:SSS a");

    private static Calendar EPOCH =null;

    public static void initalize()
    {
        EPOCH = Calendar.getInstance();
        EPOCH.set(1980, 0, 1, 1, 1, 1); //this will drift a bit. setting it to 1980 just to cover all bases
    }
    /*
    //when the device doesn't have a gps fix after a cold boot it sends
        //a timestamp of 1000, if we detect that we need to stamp it with the current time
        //note, this is a temp fix!!!  imagine a driver powers his device on at 8:00 and doesn't have a gps fix
        //at 8:05 he gets a gps fix and the location time is correct.
        //meanwhile the servers are down until 9:00. When we get the power on message, we'll time stamp it at 9:00
        //but it really should have a time before the 8:05 message
    */
    public static NetworkMessage handleEpochLocationTime(NetworkMessage networkMessage)
    {
    	if(EPOCH ==null)
    		initalize();
        //should always be true otherwise it doesn't make sense to use this method!
        if((networkMessage.getType() == Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE) || 
        		(networkMessage.getType() == NetworkMessage.NetworkMessageType.JBUS_MESSAGE))
        {
        	long locationTime;
        	if(networkMessage.getType() == NetworkMessage.NetworkMessageType.JBUS_MESSAGE)
            {
            	Network.RawJbusMessage eventMessage = networkMessage.getRawJbusMessage();
            	locationTime = eventMessage.getLocationTime();
            }
        	else
        	{
        		MessageDetail eventMessage = networkMessage.getMessageDetail();
        		locationTime = eventMessage.getLocationTime();
        	}
            	
            if(locationTime < EPOCH.getTimeInMillis())
            {
                logger.warn("Got an invalid location time for the following message "+networkMessage);

                MessageDetail newMessageDetail = networkMessage.getMessageDetail();
                if (newMessageDetail == null)
                    newMessageDetail = new MessageDetail();
                newMessageDetail.setLocationTime(new Date().getTime());
                Network.NetworkMessage newMessage = networkMessage;
                newMessage.setMessageDetail(newMessageDetail);
                return newMessage;
            }
        }
        return networkMessage;
    }
    
    
}
