package com.calamp.connect.network.protocol.lmd.serializers;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.List;

import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.CommGpsStatus;
import com.calamp.connect.network.protocol.lmd.domain.FixStatusAndSatellites;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;
import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageWithAccumulatorsContent;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.IdReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LocateReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniEventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniUserMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ParameterMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UnitRequestMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageWithAccumulatorsContent;
import com.calamp.connect.services.fmi.util.ByteUtil;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 21, 2010
 */
public class MessageContentSerializer
{
    private static final int ACK_MESSAGE_LENGTH = 6;
    private static final int EVENT_REPORT_WITHOUT_ACCUMULATOR_BYTE_LENGTH = 2;
    private static final int MINI_EVENT_REPORT_WITHOUT_ACCUMULATOR_BYTE_LENGTH = 19;
    private static final int USER_MESSAGE_WITHOUT_MESSAGE_OR_ACCUMULATORS_BYTE_LENGTH = 6;
    private static final int USER_MESSAGE_WITHOUT_MESSAGE_BYTE_LENGTH = 4;

    private static final int MAX_MESSAGE_BYTE_SIZE = 843; //this number is 848 (max of full message) minus the 4 bytes needed to create it
    private static final int APP_VERSION_LENGTH = 3;

    public static byte[] encode(MessageContent content, MessageType messageType)
    {
        byte[] bytes = new byte[0];
        switch (messageType)
        {
            case NULL:
                //no message contents, don't set anything
                break;
            case ACK_NAK:
                AckMessageContent ackMessageContent = (AckMessageContent)content;
                bytes = encodeAckMessageContent(ackMessageContent);
                break;
            case EVENT_REPORT:
                EventReportMessageContent eventReportMessageContent = (EventReportMessageContent)content;
                bytes = encodeEventReportMessageContent(eventReportMessageContent);
                break;
            case ID_REPORT:
            case EXTENDED_ID_REPORT:
                IdReportMessageContent idReportMessageContent = (IdReportMessageContent) content;
                bytes = IdReportMessageContent.encode(idReportMessageContent);
                break;
            case USER_DATA:
                UserMessageContent userMessageContent = (UserMessageContent)content;
                bytes = encodeUserMessageContent(userMessageContent);
                break;
            case MINI_APPLICATION_DATA:
            	MiniApplicationMessageContent miniApplicationMessageContent = (MiniApplicationMessageContent)content;
            	bytes = MiniApplicationMessageContent.encode(miniApplicationMessageContent);
            	break;
            case APPLICATION_DATA:
                ApplicationMessageContent applicationMessageContent = (ApplicationMessageContent)content;
                bytes = ApplicationMessageContent.encode(applicationMessageContent);
                break;
            case APPLICATION_DATA_WITH_ACCUMULATORS:
            	ApplicationMessageWithAccumulatorsContent appContent = (ApplicationMessageWithAccumulatorsContent) content;
            	bytes = ApplicationMessageWithAccumulatorsContent.encode(appContent);
            	break;
            case CONFIGURATION_PARAMETER:
                ParameterMessageContent parameterMessageContent = (ParameterMessageContent)content;
                bytes = ParameterMessageContent.encode(parameterMessageContent);
                break;
            case UNIT_REQUEST:
                UnitRequestMessageContent unitRequestMessageContent = (UnitRequestMessageContent)content;
                bytes = UnitRequestMessageContent.encode(unitRequestMessageContent);
                break;
            case LOCATE_REPORT:
                LocateReportMessageContent locateReportMessageContent = (LocateReportMessageContent)content;
                bytes = encodeLocateReportMessageContent(locateReportMessageContent);
                break;
            case USER_DATA_WITH_ACCUMULATORS:
                UserMessageWithAccumulatorsContent userMessageWithAccumulatorsContent = (UserMessageWithAccumulatorsContent)content;
                bytes = encodeUserMessageWithAccumulatorsContent(userMessageWithAccumulatorsContent);
                break;
            case MINI_EVENT_REPORT:
                MiniEventReportMessageContent miniEventReportMessageContent = (MiniEventReportMessageContent)content;
                bytes = encodeMiniEventReportMessageContent(miniEventReportMessageContent);
                break;
            case MINI_USER_DATA:
            	MiniUserMessageContent miniUserMessageContent = (MiniUserMessageContent)content;
            	bytes = MiniUserMessageContent.encode(miniUserMessageContent);
            	break;
            default:
                throw new IllegalArgumentException("Message Type was unrecognized");
        }
        return bytes;
    }

    public static MessageContent decode(ByteBuffer byteBuffer, MessageType messageType)
    {
        return decode(byteBuffer, messageType, true);
    }
    
    public static MessageContent decode(ByteBuffer byteBuffer, MessageType messageType, boolean isUplink )
    {
        MessageContent content = null;
        switch (messageType)
        {
            case NULL:
                return null;//nothing to decode
            case ACK_NAK:
                content = decodeAckMessage(byteBuffer);
                break;
            case EVENT_REPORT:
                content = decodeEventReportMessageContent(byteBuffer);
                break;
            case ID_REPORT:
            case EXTENDED_ID_REPORT:
                content = IdReportMessageContent.decode(byteBuffer);
                break;
            case USER_DATA:
                content = decodeUserMessageContent(byteBuffer, isUplink);
                break;
            case APPLICATION_DATA:
                content = ApplicationMessageContent.decode(byteBuffer, isUplink);
                break;
            case MINI_APPLICATION_DATA:
            	content = MiniApplicationMessageContent.decode(byteBuffer,isUplink);
            	break;
            case CONFIGURATION_PARAMETER:
                content = ParameterMessageContent.decode(byteBuffer);
                break;
            case UNIT_REQUEST:
                content = UnitRequestMessageContent.decode(byteBuffer);
                break;
            case LOCATE_REPORT:
                content = decodeLocateReportMessageContent(byteBuffer);
                break;
            case USER_DATA_WITH_ACCUMULATORS:
                content = decodeUserMessageWithAccumulatorsContent(byteBuffer, isUplink);
                break;
            case MINI_EVENT_REPORT:
                content = decodeMiniEventReportMessageContent(byteBuffer);
                break;
            case APPLICATION_DATA_WITH_ACCUMULATORS:
            	content = ApplicationMessageWithAccumulatorsContent.decode(byteBuffer, isUplink);
            	break;
            case MINI_USER_DATA:
            	content = MiniUserMessageContent.decode(byteBuffer, isUplink);
            	break;
            default:
                throw new IllegalArgumentException("Message Type was unrecognized");
        }

        return content;
    }

    public static byte[] encodeAckMessageContent(AckMessageContent ackMessageContent)
    {
        ByteBuffer byteBuffer = ByteBuffer.allocate(ACK_MESSAGE_LENGTH);
        byteBuffer.put((byte) ackMessageContent.getMessageType().getValue());
        byteBuffer.put((byte) ackMessageContent.getAckType().ordinal());
        byteBuffer.put((byte)0);
        String appVersion = ackMessageContent.getAppVersion();
        if(appVersion == null)
        {
            byteBuffer.put(new byte[]{0,0,0});
        }
        else
        {
            byteBuffer.put(HexUtil.getHexByteArray(appVersion));
        }
        return byteBuffer.array();
    }

    public static AckMessageContent decodeAckMessage(ByteBuffer byteBuffer)
    {
        AckMessageContent ackMessageContent = new AckMessageContent();
        byte messageTypeByte = byteBuffer.get();
        MessageType messageType = MessageType.getMessageType(messageTypeByte);
        byte ackTypeByte = byteBuffer.get();
        AckType ackType = AckType.getAckType(ackTypeByte);
        byteBuffer.get();//spare byte
        byte[] appVersion = new byte[APP_VERSION_LENGTH];
        byteBuffer.get(appVersion, 0, APP_VERSION_LENGTH);
        ackMessageContent.setAckType(ackType);
        ackMessageContent.setMessageType(messageType);
        String appVersionByteString = null;
        for(byte data : appVersion)
        {
            if(data!=0)
            {
                appVersionByteString = HexUtil.getStringFromHexByteArray(appVersion);
                break;
            }
        }
        ackMessageContent.setAppVersion(appVersionByteString);
        return ackMessageContent;
    }


    public static byte[] encodeEventReportMessageContent(EventReportMessageContent messageContent)
    {
        byte[] accumulatorBytes = AccumulatorSerializer.encode(messageContent.getAccumulatorValues());

        int totalNumberOfBytes = accumulatorBytes.length + EVENT_REPORT_WITHOUT_ACCUMULATOR_BYTE_LENGTH;
        ByteBuffer byteBuffer = ByteBuffer.allocate(totalNumberOfBytes);

        if(messageContent.getLocationStatusInfo()!=null)
        {
            byteBuffer = ByteBuffer.allocate(totalNumberOfBytes + LocationStatusInfo.LMU_STATUS_AND_LOCATION_BYTE_LENGTH);
            byteBuffer.put(LocationStatusInfo.encode(messageContent.getLocationStatusInfo()));
        }

        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getEventIndex()));
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getEventCode()));
        byteBuffer.put(accumulatorBytes);

        return byteBuffer.array();
    }


    public static EventReportMessageContent decodeEventReportMessageContent(ByteBuffer byteBuffer)
    {
        EventReportMessageContent reportMessageContent = new EventReportMessageContent();
        LocationStatusInfo locationStatusInfo = LocationStatusInfo.decode(byteBuffer);
        reportMessageContent.setLocationStatusInfo(locationStatusInfo);
        reportMessageContent.setEventIndex(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        reportMessageContent.setEventCode(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));

        List<Long> accumulators = AccumulatorSerializer.decode(byteBuffer);
        reportMessageContent.setAccumulatorValues(accumulators);

        return reportMessageContent;
    }


    public static byte[] encodeLocateReportMessageContent(LocateReportMessageContent messageContent)
    {
        byte[] accumulatorBytes = AccumulatorSerializer.encode(messageContent.getAccumulatorValues());

        int totalNumberOfBytes = accumulatorBytes.length;
        ByteBuffer byteBuffer = ByteBuffer.allocate(totalNumberOfBytes + LocationStatusInfo.LMU_STATUS_AND_LOCATION_BYTE_LENGTH);
        byteBuffer.put(LocationStatusInfo.encode(messageContent.getLocationStatusInfo()));
        byteBuffer.put(accumulatorBytes);

        return byteBuffer.array();
    }

    public static LocateReportMessageContent decodeLocateReportMessageContent(ByteBuffer byteBuffer)
    {
        LocateReportMessageContent reportMessageContents = new LocateReportMessageContent();
        LocationStatusInfo locationStatusInfo = LocationStatusInfo.decode(byteBuffer);
        reportMessageContents.setLocationStatusInfo(locationStatusInfo);
        List<Long> accumulators = AccumulatorSerializer.decode(byteBuffer);
        reportMessageContents.setAccumulatorValues(accumulators);

        return reportMessageContents;
    }

    public static byte[] encodeMiniEventReportMessageContent(MiniEventReportMessageContent messageContents)
    {

        byte[] accumulatorBytes = AccumulatorSerializer.encode(messageContents.getAccumulatorValues(), false); //skip the spare bit
        int totalNumberOfBytes = accumulatorBytes.length + MINI_EVENT_REPORT_WITHOUT_ACCUMULATOR_BYTE_LENGTH;
        ByteBuffer byteBuffer = ByteBuffer.allocate(totalNumberOfBytes);

        long updateTimeInMilli = messageContents.getUpdateTime().getTime();
        byteBuffer.put(ByteUtil.unsignedIntegerToBytes(updateTimeInMilli/1000));
        byteBuffer.putInt((int)(messageContents.getLatitude() / LocationStatusInfo.LAT_LONG_FACTOR));
        byteBuffer.putInt((int)(messageContents.getLongitude() / LocationStatusInfo.LAT_LONG_FACTOR));
        byteBuffer.put(ByteUtil.unsignedShortToBytes(messageContents.getHeading()));
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContents.getSpeed())); //this is in KM/hour
        byteBuffer.put(messageContents.getFixStatusAndSatellites().getByte());
        byteBuffer.put(messageContents.getCommGpsStatus().getByte());
        byteBuffer.put(messageContents.getInputs().getByte());
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContents.getEventCode()));
        byteBuffer.put(accumulatorBytes);
        return byteBuffer.array();
    }

    public static MiniEventReportMessageContent decodeMiniEventReportMessageContent(ByteBuffer byteBuffer)
    {
        MiniEventReportMessageContent reportMessageContents = new MiniEventReportMessageContent();

        long updateTimeSeconds  = ByteUtil.getUnsignedInteger(byteBuffer);
        reportMessageContents.setUpdateTime(new Date(updateTimeSeconds*1000));

        int latitudeInt = byteBuffer.getInt();
        BigDecimal originalLat = new BigDecimal(latitudeInt);
        BigDecimal latitude = originalLat.scaleByPowerOfTen(-7);
        reportMessageContents.setLatitude( latitude.doubleValue());

        int longitudeInt = byteBuffer.getInt();
        BigDecimal originalLong = new BigDecimal(longitudeInt);
        BigDecimal longitude = originalLong.scaleByPowerOfTen(-7);
        reportMessageContents.setLongitude( longitude.doubleValue());
        reportMessageContents.setHeading(ByteUtil.getUnsignedShort(byteBuffer));

        int speedInKm = ByteUtil.signedByteToUnsignedByte(byteBuffer.get());
        reportMessageContents.setSpeed(speedInKm);

        reportMessageContents.setFixStatusAndSatellites(new FixStatusAndSatellites(byteBuffer.get()));
        reportMessageContents.setCommGpsStatus(new CommGpsStatus(byteBuffer.get()));
        reportMessageContents.setInputs(new Inputs(byteBuffer.get()));
        reportMessageContents.setEventCode(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));

        List<Long> accumulators = AccumulatorSerializer.decode(byteBuffer, false);
        reportMessageContents.setAccumulatorValues(accumulators);

        return reportMessageContents;
    }

    public static byte[] encodeUserMessageContent(UserMessageContent messageContent)
    {
        int userMessageByteLength = messageContent.getUserMessage() != null ? messageContent.getUserMessage().length : 0;
        if (userMessageByteLength > MAX_MESSAGE_BYTE_SIZE)
        {
            throw new IllegalArgumentException("user messageContents " + messageContent.getUserMessage() + " can not exceed " + MAX_MESSAGE_BYTE_SIZE);
        }

        int totalByteLength = USER_MESSAGE_WITHOUT_MESSAGE_BYTE_LENGTH + userMessageByteLength;
        ByteBuffer byteBuffer = ByteBuffer.allocate(totalByteLength);
        if (messageContent.getLocationStatusInfo() != null)
        {
            byteBuffer = ByteBuffer.allocate(LocationStatusInfo.LMU_STATUS_AND_LOCATION_BYTE_LENGTH +
                    totalByteLength);
            byteBuffer.put(LocationStatusInfo.encode(messageContent.getLocationStatusInfo()));
        }


        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getUserMessageRoute().getValue()));
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getUserMessageId()));
        byteBuffer.put(ByteUtil.unsignedShortToBytes(userMessageByteLength));
        if (userMessageByteLength > 0)
        {
            byteBuffer.put(messageContent.getUserMessage());
        }

        return byteBuffer.array();
    }

    public static UserMessageContent decodeUserMessageContent(ByteBuffer byteBuffer)
    {
        return decodeUserMessageContent(byteBuffer, true);
    }
    
    public static UserMessageContent decodeUserMessageContent(ByteBuffer byteBuffer, boolean isUplink )
    {
        UserMessageContent userMessageContents = new UserMessageContent();

        if ( isUplink )
        {
            LocationStatusInfo locationStatusInfo = LocationStatusInfo.decode(byteBuffer);
            userMessageContents.setLocationStatusInfo(locationStatusInfo);
        }
        UserMessageRoute route = UserMessageRoute.getUserMessageRoute(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        userMessageContents.setUserMessageRoute(route);
        userMessageContents.setUserMessageId(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        int messageLength = ByteUtil.getUnsignedShort(byteBuffer);
        if(messageLength>0)
        {
            byte[] messageBytes = new byte[messageLength];
            byteBuffer.get(messageBytes, 0, messageLength);
            userMessageContents.setUserMessage(messageBytes);
        }
        return userMessageContents;
    }

    public static byte[] encodeUserMessageWithAccumulatorsContent(UserMessageWithAccumulatorsContent messageContents)
    {
    	byte[] locationStatusBytes = new byte[0];
        if(messageContents.getLocationStatusInfo()!=null)
        {
            locationStatusBytes = LocationStatusInfo.encode(messageContents.getLocationStatusInfo());
        }
        byte[] spareBytes = {(byte)0,(byte)0};
        byte[] accumulatorBytes = AccumulatorSerializer.encode(messageContents.getAccumulatorValues());
        byte[] userMessageRouterBytes = {(byte)messageContents.getUserMessageRoute().getValue()};
        byte[] userMessageIDBytes = {(byte)messageContents.getUserMessageId()};
        byte[] userMessagePayloadBytes = new byte[0];
        if(messageContents.getUserMessage().length() != 0){
        	userMessagePayloadBytes = HexUtil.getHexByteArray(messageContents.getUserMessage());
        }
        

        ByteBuffer byteBuffer = ByteBuffer.allocate(locationStatusBytes.length
                + userMessageRouterBytes.length + userMessageIDBytes.length+ 4 + accumulatorBytes.length + userMessagePayloadBytes.length); //+2 for msg size, +2 for spare bytes
        byteBuffer.put(locationStatusBytes);
        byteBuffer.put(spareBytes);
        byteBuffer.put(accumulatorBytes);

        byteBuffer.put(userMessageRouterBytes);
        byteBuffer.put(userMessageIDBytes);
        byteBuffer.putShort((short)userMessagePayloadBytes.length);
        byteBuffer.put(userMessagePayloadBytes);
        return byteBuffer.array();
    }

    public static UserMessageWithAccumulatorsContent decodeUserMessageWithAccumulatorsContent(ByteBuffer byteBuffer)
    {
        return decodeUserMessageWithAccumulatorsContent(byteBuffer, true);
    }
        
    public static UserMessageWithAccumulatorsContent decodeUserMessageWithAccumulatorsContent(ByteBuffer byteBuffer, boolean isUplink )
    {
        UserMessageWithAccumulatorsContent userMessageContents = new UserMessageWithAccumulatorsContent();
        if ( isUplink )
        {
            LocationStatusInfo locationStatusInfo = LocationStatusInfo.decode(byteBuffer);
            userMessageContents.setLocationStatusInfo(locationStatusInfo);
        }
        byteBuffer.get(); //skip spare
        byteBuffer.get(); //skip spare
        List<Long> accumulatorValues = AccumulatorSerializer.decode(byteBuffer);
        userMessageContents.setAccumulatorValues(accumulatorValues);

        UserMessageRoute route = UserMessageRoute.getUserMessageRoute(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        userMessageContents.setUserMessageRoute(route);
        userMessageContents.setUserMessageId(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        int messageLength = ByteUtil.getUnsignedShort(byteBuffer);
        byte[] messageBytes = new byte[messageLength];
        byteBuffer.get(messageBytes, 0, messageLength);
        userMessageContents.setUserMessage(HexUtil.getStringFromHexByteArray(messageBytes));

        return userMessageContents;
    }
}
