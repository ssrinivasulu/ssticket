package com.calamp.connect.network.protocol.lmd.messageContent.parametermessages;

import java.util.Arrays;

/**
 * User: ericw
 * Date: 4/23/14
 */
public class ParameterInfo {

    private ParameterId parameterId;
    private Integer parameterIndex;
    private byte[] parameterData;

    public ParameterInfo(ParameterId parameterId, Integer parameterIndex, byte[] parameterData) {
        this.parameterId = parameterId;
        this.parameterIndex = parameterIndex;
        this.parameterData = parameterData;
    }

    public ParameterId getParameterId() {
        return parameterId;
    }

    public Integer getParameterIndex() {
        return parameterIndex;
    }

    public byte[] getParameterData() {
        return parameterData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ParameterInfo that = (ParameterInfo) o;

        if (parameterId != null ? !parameterId.equals(that.parameterId) : that.parameterId != null) return false;
        if (parameterIndex != null ? !parameterIndex.equals(that.parameterIndex) : that.parameterIndex != null)
            return false;
        if (!Arrays.equals(parameterData, that.parameterData)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = parameterId != null ? parameterId.hashCode() : 0;
        result = 31 * result + (parameterIndex != null ? parameterIndex.hashCode() : 0);
        result = 31 * result + (parameterData != null ? Arrays.hashCode(parameterData) : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ParameterInfo{" +
                "parameterId=" + parameterId +
                ", parameterIndex=" + parameterIndex +
                ", parameterData=" + Arrays.toString(parameterData) +
                '}';
    }
}
