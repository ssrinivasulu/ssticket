package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.IpUdpHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 *
 * Generic Builder for the messages.  Note, it's not using Generic methods so these calls will
 * have to come after all the subclass setters due to the return types.
 *
 * User: ericw
 * Date: Oct 27, 2010
 */
public class LMDirectMessageBuilder
{
    private LMDirectMessage message;

    private OptionsHeaderBuilder optionsBuilder;
    private MessageHeaderBuilder headerBuilder;
    private IpUdpHeaderBuilder ipUdpHeaderBuilder;

    protected LMDirectMessageBuilder(LMDirectMessageBuilder builder)
    {
        this(builder!=null?builder.toLMDirectMessage():null);
    }

    private LMDirectMessageBuilder(LMDirectMessage message)
    {
        if(message == null)
        {
            ipUdpHeaderBuilder = IpUdpHeaderBuilder.getBuilder();
            optionsBuilder = OptionsHeaderBuilder.getBuilder();
            headerBuilder = MessageHeaderBuilder.getBuilder();
        }

        if(message.getIpUdpHeader()!=null)
        {
            ipUdpHeaderBuilder = IpUdpHeaderBuilder.buildFrom(message.getIpUdpHeader());
        }
        else
        {
            ipUdpHeaderBuilder = IpUdpHeaderBuilder.getBuilder();
        }
        if(message.getOptionsHeader()!=null)
        {
            optionsBuilder = OptionsHeaderBuilder.buildFrom(message.getOptionsHeader());
        }
        else
        {
            optionsBuilder = OptionsHeaderBuilder.getBuilder();
        }
        if(message.getMessageHeader()!=null)
        {
            headerBuilder = MessageHeaderBuilder.buildFrom(message.getMessageHeader());
        }
        else
        {
            headerBuilder = MessageHeaderBuilder.getBuilder();
        }
        this.message = message;
    }

    public static LMDirectMessageBuilder getBuilder()
    {
        LMDirectMessage message = new LMDirectMessage();
        return new LMDirectMessageBuilder(message);
    }

    public LMDirectMessageBuilder setSequenceNumber(int sequenceNumber)
    {
        headerBuilder.setSequenceNumber(sequenceNumber);
        return this;
    }


    public LMDirectMessageBuilder setServiceType(ServiceType serviceType)
    {
        headerBuilder.setServiceType(serviceType);
        return this;
    }

    public LMDirectMessageBuilder setMessageType(MessageType messageType)
    {
        headerBuilder.setMessageType(messageType);
        return this;
    }

    public LMDirectMessageBuilder setAuthentication(String authentication)
    {
        optionsBuilder.setAuthentication(authentication);
        return this;
    }

    public LMDirectMessageBuilder setMobileId(String mobileId)
    {
        optionsBuilder.setMobileId(mobileId);
        return this;
    }

    public LMDirectMessageBuilder setMobileIdType(MobileIdType mobileIdType)
    {
        optionsBuilder.setMobileIdType(mobileIdType);
        return this;
    }

    public LMDirectMessageBuilder setRouting(String routing)
    {
        optionsBuilder.setRouting(routing);
        return this;
    }

    public LMDirectMessageBuilder setSourceAddress(String sourceAddress)
    {
        ipUdpHeaderBuilder.setSourceAddress(sourceAddress);
        return this;
    }
    
    public LMDirectMessageBuilder setDestinationAddress(String destinationAddress)
     {
         ipUdpHeaderBuilder.setDestinationAddress(destinationAddress);
         return this;
     }

     public LMDirectMessageBuilder setSourcePort(Integer sourcePort)
     {
         ipUdpHeaderBuilder.setSourcePort(sourcePort);
         return this;
     }

     public LMDirectMessageBuilder setDestinationPort(Integer destinationPort)
     {
         ipUdpHeaderBuilder.setDestinationPort(destinationPort);
         return this;
     }


    public LMDirectMessage toLMDirectMessage()
    {
        MessageHeader builtMessageHeader = headerBuilder.build();
        OptionsHeader builtOptionsHeader = optionsBuilder.build();
        IpUdpHeader builtIpUdpHeader = ipUdpHeaderBuilder.build();

        message.setIpUdpHeader(builtIpUdpHeader);
        message.setMessageHeader(builtMessageHeader);
        message.setOptionsHeader(builtOptionsHeader);

        LMDirectMessage returnMessage = message;
        message = null;
        return returnMessage;
    }
 
    public static LMDirectMessageBuilder getBuilderWithDefault()
    {
        LMDirectMessage message = new LMDirectMessage();
        MessageHeader messageHeader = MessageHeaderBuilder
            .getBuilderWithDefault()
            .setMessageType(MessageType.ACK_NAK)
            .build();

        OptionsHeader optionsHeader = OptionsHeaderBuilder.getBuilderWithDefault().build();
        IpUdpHeader ipUdpHeader = IpUdpHeaderBuilder.getBuilderWithDefault().build();

        message.setOptionsHeader(optionsHeader);
        message.setMessageHeader(messageHeader);
        message.setIpUdpHeader(ipUdpHeader);

        return new LMDirectMessageBuilder(message);
    }

    public void clear()
    {
        ipUdpHeaderBuilder.clear();
        optionsBuilder.clear();
        headerBuilder.clear();
    }

    public LMDirectMessageBuilder clearIdUdpHeader()
    {
        ipUdpHeaderBuilder = IpUdpHeaderBuilder.getBuilder();
        return this;
    }
}
