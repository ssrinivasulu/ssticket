package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * @author ssrinivasulu
 *
 */
public class DiscoveryReportMap implements JbusMap {

	private MachineState machineState;
	private Double mapRevision;
    private Boolean vehicleSpeedFound;
    private Boolean odometerFound;
    private Boolean totalFuelFound;
    private Boolean vinFound;
    private Boolean batteryVoltageSourcesFound;
    private Boolean discoveryReportSourcesFound1, discoveryReportSourcesFound2, discoveryReportSourcesFound3, discoveryReportSourcesFound4;
    private Boolean fuelTankSourcesFound, averageFuelTankSourcesFound, ptoSourcesFound, ptoSourcesActive, engineTorqueSourcesFound, engineThrottleSourcesFound;
    
    private static Logger logger = LogManager.getLogger(DiscoveryReportMap.class); 

   

	public byte[] encode() {
        ByteBuffer encodedBytes = ByteBuffer.allocate(15);
        encodedBytes.put(JbusMapType.DISCOVERY_REPORT.toBytes());
        
        if(machineState!=null) {
        	boolean[] bits = new boolean[8];
        	bits[7] = machineState.isEngineStatus();
        	bits[6] = machineState.isPtoStatus();
        	bits[5] = machineState.isMoving();
        	bits[1] = machineState.isJ1708MsgRecvd();
        	bits[0] = machineState.isJ1939MsgRecvd();	
        	encodedBytes.put(BitUtil.getByte(bits));
        }
        else
            encodedBytes.put(new byte[2]);
       if(mapRevision!=null)
            encodedBytes.put(ByteUtil.unsignedByteToSignedByte((int)round(mapRevision,0)));
        else
            encodedBytes.put(new byte[1]);
      
            encodedBytes.put(new byte[1]);
            encodedBytes.put(new byte[1]);
            encodedBytes.put(new byte[1]);
            encodedBytes.put(new byte[1]);
            byte b0=0;
            byte b1=1;
            
            encodedBytes.put(new byte[1]);
            encodedBytes.put(new byte[1]);
            
            if(vehicleSpeedFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
          
            encodedBytes.put(new byte[1]);
           
            if(odometerFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            encodedBytes.put(new byte[1]);
            
            if(totalFuelFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            encodedBytes.put(new byte[1]);
            
            if(vinFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            encodedBytes.put(new byte[1]);
            
            if(batteryVoltageSourcesFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            encodedBytes.put(new byte[1]);
            
            if(discoveryReportSourcesFound1){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            if(discoveryReportSourcesFound2){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            if(fuelTankSourcesFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            if(averageFuelTankSourcesFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            if(discoveryReportSourcesFound3){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            if(ptoSourcesFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            if(ptoSourcesActive){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            encodedBytes.put(new byte[1]);
            encodedBytes.put(new byte[1]);
            encodedBytes.put(new byte[1]);
            encodedBytes.put(new byte[1]);
            
            if(engineTorqueSourcesFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
            encodedBytes.put(new byte[1]);
            
            if(engineThrottleSourcesFound){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
             
            encodedBytes.put(new byte[1]);
            
            if(discoveryReportSourcesFound4){
            	encodedBytes.put(b1);
            }else{
            	encodedBytes.put(b0);
            }
            
        return encodedBytes.array();
    }

    public JbusMap decode(ByteBuffer byteBuffer) {
        DiscoveryReportMap map = new DiscoveryReportMap();
        /*   Machine state is a 16 bit number sent LSB first.  The current bit usage is as follows.
         *   Bit:    Meaning:    
         *    0   Engine Status (0=Off, 1=On (RPM > 300)) 
         *    1   PTO Status (0=Off, 1 =On)   0
         *    2   Moving (0=Stopped, 1=Moving (>5 MPH))   0
         *    3   Unused (Defaulted to 0) 0
         *    4   Unused (Defaulted to 0) 0
         *    5   Unused (Defaulted to 0) 0
         *    6   J1708 Messages Received 0
         *    7   J1939 Messages Received 0
         *    8   Unused (Defaulted to 0)   0
         *    9   Unused (Defaulted to 0)   0
         *    10  Unused (Defaulted to 0)   0
         *    11  Unused (Defaulted to 0)   0
         *    12  Unused (Defaulted to 0)   0
         *    13  Unused (Defaulted to 0)   0
         *    14  Unused (Defaulted to 0)   0
         *    15  Unused (Defaulted to 0)   0
         *    values are coming MSB first i am reversing the index
         *    Engine Status bit index is 7
         *    PTO Status bit index is 6
         *    Moving bit index is 5
         *    J1708 Messages Received bit index is 1
         *    J1939 Messages Received bit index is 0
         */
        boolean[] bits = BitUtil.getBits(byteBuffer.get());//MachineState
        boolean engineStatus = bits[7];
        boolean ptoStatus = bits[6];
        boolean moving= bits[5];
        boolean j1708MsgRecvd  = bits[1];
        boolean j1939MsgRecvd = bits[0];
        
        machineState = new MachineState();
        machineState.setEngineStatus(engineStatus);
        machineState.setPtoStatus(ptoStatus);
        machineState.setMoving(moving);
        machineState.setJ1708MsgRecvd(j1708MsgRecvd);
        machineState.setJ1939MsgRecvd(j1939MsgRecvd);
        
        map.setMachineState(machineState);
        map.setMapRevision(round(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()),2)); //Map Revision
        
        byteBuffer.get(); //CAN Baud Rate  4
        byteBuffer.get(); //CAN Baud Rate  5
        byteBuffer.get(); //J1939 Only Parameters Found 1   6
        byteBuffer.get(); //J1939 Only Parameters Found 2   7
       
   
        byteBuffer.get(); // Engine Speed Found            8
        byteBuffer.get(); //Engine Speed ECU Address Used  9 

        boolean isVehicleSpeedFound=byteBuffer.get()>0;              //10  Road Speed = Vehicle Speed
        map.setVehicleSpeedFound(isVehicleSpeedFound); 
        
        byteBuffer.get(); //Road Speed ECU Address Used    11
        
    
		boolean isOdometerFound = byteBuffer.get()>0;                //12
        map.setOdometerFound(isOdometerFound);
        
        byteBuffer.get(); //Odometer ECU Address Used  13

      
		boolean totalFuelFound =byteBuffer.get()>0;                  //14
        map.setTotalFuelFound(totalFuelFound);
        
        byteBuffer.get(); //Total Fuel ECU Address Used 15
        
        boolean vinFound =byteBuffer.get()>0;                  //16
        map.setVinFound(vinFound);
        
        byteBuffer.get(); //Vehicle Identification Number (VIN) ECU Address Used 	//17
        
        boolean batteryVoltageSourcesFound =byteBuffer.get()>0;                  //18
        map.setBatteryVoltageSourcesFound(batteryVoltageSourcesFound);
        
        byteBuffer.get(); //Battery Voltage ECU Address Used 	//19
        
        boolean discoveryReportSourcesFound1 =byteBuffer.get()>0;                //20
        map.setDiscoveryReportSourcesFound1(discoveryReportSourcesFound1);
        
        boolean discoveryReportSourcesFound2 =byteBuffer.get()>0;                //21
        map.setDiscoveryReportSourcesFound2(discoveryReportSourcesFound2);
        
        boolean fuelTankSourcesFound =byteBuffer.get()>0;                  		 //22 
        map.setFuelTankSourcesFound(fuelTankSourcesFound);
        
        boolean averageFuelTankSourcesFound =byteBuffer.get()>0;                 //23
        map.setAverageFuelTankSourcesFound(averageFuelTankSourcesFound);

        boolean discoveryReportSourcesFound3 =byteBuffer.get()>0;                //24
        map.setDiscoveryReportSourcesFound3(discoveryReportSourcesFound3);
        
        boolean ptoSourcesFound =byteBuffer.get()>0;                			//25
        map.setPtoSourcesFound(ptoSourcesFound);
        
        boolean ptoSourcesActive =byteBuffer.get()>0;                			//26
        map.setPtoSourcesActive(ptoSourcesActive);
        
        byteBuffer.get(); 	//Last J1708 PID 89 Value 	//27
        
        byteBuffer.get(); 	//Last J1708 PID 979 Value  //28
        
        byteBuffer.get(); 	//Last J1708 PID 976 Value  //29
        
        //END OF MAP REV 0 REPORT
        
        byteBuffer.get(); 	//Max Diagnostic Trouble Codes (DM1) Per Minute  	//30
        
        boolean engineTorqueSourcesFound =byteBuffer.get()>0;                	//31
        map.setEngineTorqueSourcesFound(engineTorqueSourcesFound);
        
        byteBuffer.get(); 	//Engine Torque ECU Address Used  //32
        
        boolean engineThrottleSourcesFound =byteBuffer.get()>0;                	//33
        map.setEngineThrottleSourcesFound(engineThrottleSourcesFound);
        
        byteBuffer.get(); 	//Engine Throttle ECU Address Used 		//34
        
        boolean discoveryReportSourcesFound4 =byteBuffer.get()>0;                //35
        map.setDiscoveryReportSourcesFound4(discoveryReportSourcesFound4);
        
        logger.debug("discovery map:: "+map);

        return map;
    }

    public static double round(double unrounded, int precision) {
        BigDecimal bd = new BigDecimal(unrounded);
        BigDecimal rounded = bd.setScale(precision, RoundingMode.HALF_UP);
        return rounded.doubleValue();
    }

    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setMachineState(machineState);
        jbusMessage.setVehicleSpeedFound(vehicleSpeedFound);
        jbusMessage.setOdometerFound(odometerFound);
        jbusMessage.setTotalFuelFound(totalFuelFound);
        jbusMessage.setVinFound(vinFound);
        jbusMessage.setBatteryVoltageSourcesFound(batteryVoltageSourcesFound);
        jbusMessage.setDiscoveryReportSourcesFound1(discoveryReportSourcesFound1);
        jbusMessage.setDiscoveryReportSourcesFound2(discoveryReportSourcesFound2);
        jbusMessage.setDiscoveryReportSourcesFound3(discoveryReportSourcesFound3);
        jbusMessage.setDiscoveryReportSourcesFound4(discoveryReportSourcesFound4);
        jbusMessage.setFuelTankSourcesFound(fuelTankSourcesFound);
        jbusMessage.setAverageFuelTankSourcesFound(averageFuelTankSourcesFound);
        jbusMessage.setPtoSourcesFound(ptoSourcesFound);
        jbusMessage.setPtoSourcesActive(ptoSourcesActive);
        jbusMessage.setEngineTorqueSourcesFound(engineTorqueSourcesFound);
        jbusMessage.setEngineThrottleSourcesFound(engineThrottleSourcesFound);
     
        return jbusMessage;
    } 
    
    public MachineState getMachineState() {
		return machineState;
	}

	public void setMachineState(MachineState machineState) {
		this.machineState = machineState;
	}

	public Double getMapRevision() {
		return mapRevision;
	}

	public void setMapRevision(Double mapRevision) {
		this.mapRevision = mapRevision;
	}


	public Boolean getOdometerFound() {
		return odometerFound;
	}

	public void setOdometerFound(Boolean odometerFound) {
		this.odometerFound = odometerFound;
	}

	public Boolean getTotalFuelFound() {
		return totalFuelFound;
	}

	public void setTotalFuelFound(Boolean totalFuelFound) {
		this.totalFuelFound = totalFuelFound;
	}

	public Boolean getVehicleSpeedFound() {
		return vehicleSpeedFound;
	}

	public void setVehicleSpeedFound(Boolean vehicleSpeedFound) {
		this.vehicleSpeedFound = vehicleSpeedFound;
	}

	public Boolean getVinFound() {
		return vinFound;
	}

	public void setVinFound(Boolean vinFound) {
		this.vinFound = vinFound;
	}

	public Boolean getBatteryVoltageSourcesFound() {
		return batteryVoltageSourcesFound;
	}

	public void setBatteryVoltageSourcesFound(Boolean batteryVoltageSourcesFound) {
		this.batteryVoltageSourcesFound = batteryVoltageSourcesFound;
	}

	public Boolean getDiscoveryReportSourcesFound1() {
		return discoveryReportSourcesFound1;
	}

	public void setDiscoveryReportSourcesFound1(Boolean discoveryReportSourcesFound1) {
		this.discoveryReportSourcesFound1 = discoveryReportSourcesFound1;
	}

	public Boolean getDiscoveryReportSourcesFound2() {
		return discoveryReportSourcesFound2;
	}

	public void setDiscoveryReportSourcesFound2(Boolean discoveryReportSourcesFound2) {
		this.discoveryReportSourcesFound2 = discoveryReportSourcesFound2;
	}

	public Boolean getDiscoveryReportSourcesFound3() {
		return discoveryReportSourcesFound3;
	}

	public void setDiscoveryReportSourcesFound3(Boolean discoveryReportSourcesFound3) {
		this.discoveryReportSourcesFound3 = discoveryReportSourcesFound3;
	}

	public Boolean getDiscoveryReportSourcesFound4() {
		return discoveryReportSourcesFound4;
	}

	public void setDiscoveryReportSourcesFound4(Boolean discoveryReportSourcesFound4) {
		this.discoveryReportSourcesFound4 = discoveryReportSourcesFound4;
	}

	public Boolean getFuelTankSourcesFound() {
		return fuelTankSourcesFound;
	}

	public void setFuelTankSourcesFound(Boolean fuelTankSourcesFound) {
		this.fuelTankSourcesFound = fuelTankSourcesFound;
	}

	public Boolean getAverageFuelTankSourcesFound() {
		return averageFuelTankSourcesFound;
	}

	public void setAverageFuelTankSourcesFound(Boolean averageFuelTankSourcesFound) {
		this.averageFuelTankSourcesFound = averageFuelTankSourcesFound;
	}

	public Boolean getPtoSourcesFound() {
		return ptoSourcesFound;
	}

	public void setPtoSourcesFound(Boolean ptoSourcesFound) {
		this.ptoSourcesFound = ptoSourcesFound;
	}

	public Boolean getPtoSourcesActive() {
		return ptoSourcesActive;
	}

	public void setPtoSourcesActive(Boolean ptoSourcesActive) {
		this.ptoSourcesActive = ptoSourcesActive;
	}

	public Boolean getEngineTorqueSourcesFound() {
		return engineTorqueSourcesFound;
	}

	public void setEngineTorqueSourcesFound(Boolean engineTorqueSourcesFound) {
		this.engineTorqueSourcesFound = engineTorqueSourcesFound;
	}

	public Boolean getEngineThrottleSourcesFound() {
		return engineThrottleSourcesFound;
	}

	public void setEngineThrottleSourcesFound(Boolean engineThrottleSourcesFound) {
		this.engineThrottleSourcesFound = engineThrottleSourcesFound;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((averageFuelTankSourcesFound == null) ? 0 : averageFuelTankSourcesFound.hashCode());
		result = prime * result + ((batteryVoltageSourcesFound == null) ? 0 : batteryVoltageSourcesFound.hashCode());
		result = prime * result
				+ ((discoveryReportSourcesFound1 == null) ? 0 : discoveryReportSourcesFound1.hashCode());
		result = prime * result
				+ ((discoveryReportSourcesFound2 == null) ? 0 : discoveryReportSourcesFound2.hashCode());
		result = prime * result
				+ ((discoveryReportSourcesFound3 == null) ? 0 : discoveryReportSourcesFound3.hashCode());
		result = prime * result
				+ ((discoveryReportSourcesFound4 == null) ? 0 : discoveryReportSourcesFound4.hashCode());
		result = prime * result + ((engineThrottleSourcesFound == null) ? 0 : engineThrottleSourcesFound.hashCode());
		result = prime * result + ((engineTorqueSourcesFound == null) ? 0 : engineTorqueSourcesFound.hashCode());
		result = prime * result + ((fuelTankSourcesFound == null) ? 0 : fuelTankSourcesFound.hashCode());
		result = prime * result + ((machineState == null) ? 0 : machineState.hashCode());
		result = prime * result + ((mapRevision == null) ? 0 : mapRevision.hashCode());
		result = prime * result + ((odometerFound == null) ? 0 : odometerFound.hashCode());
		result = prime * result + ((ptoSourcesActive == null) ? 0 : ptoSourcesActive.hashCode());
		result = prime * result + ((ptoSourcesFound == null) ? 0 : ptoSourcesFound.hashCode());
		result = prime * result + ((totalFuelFound == null) ? 0 : totalFuelFound.hashCode());
		result = prime * result + ((vehicleSpeedFound == null) ? 0 : vehicleSpeedFound.hashCode());
		result = prime * result + ((vinFound == null) ? 0 : vinFound.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DiscoveryReportMap other = (DiscoveryReportMap) obj;
		if (averageFuelTankSourcesFound == null) {
			if (other.averageFuelTankSourcesFound != null)
				return false;
		} else if (!averageFuelTankSourcesFound.equals(other.averageFuelTankSourcesFound))
			return false;
		if (batteryVoltageSourcesFound == null) {
			if (other.batteryVoltageSourcesFound != null)
				return false;
		} else if (!batteryVoltageSourcesFound.equals(other.batteryVoltageSourcesFound))
			return false;
		if (discoveryReportSourcesFound1 == null) {
			if (other.discoveryReportSourcesFound1 != null)
				return false;
		} else if (!discoveryReportSourcesFound1.equals(other.discoveryReportSourcesFound1))
			return false;
		if (discoveryReportSourcesFound2 == null) {
			if (other.discoveryReportSourcesFound2 != null)
				return false;
		} else if (!discoveryReportSourcesFound2.equals(other.discoveryReportSourcesFound2))
			return false;
		if (discoveryReportSourcesFound3 == null) {
			if (other.discoveryReportSourcesFound3 != null)
				return false;
		} else if (!discoveryReportSourcesFound3.equals(other.discoveryReportSourcesFound3))
			return false;
		if (discoveryReportSourcesFound4 == null) {
			if (other.discoveryReportSourcesFound4 != null)
				return false;
		} else if (!discoveryReportSourcesFound4.equals(other.discoveryReportSourcesFound4))
			return false;
		if (engineThrottleSourcesFound == null) {
			if (other.engineThrottleSourcesFound != null)
				return false;
		} else if (!engineThrottleSourcesFound.equals(other.engineThrottleSourcesFound))
			return false;
		if (engineTorqueSourcesFound == null) {
			if (other.engineTorqueSourcesFound != null)
				return false;
		} else if (!engineTorqueSourcesFound.equals(other.engineTorqueSourcesFound))
			return false;
		if (fuelTankSourcesFound == null) {
			if (other.fuelTankSourcesFound != null)
				return false;
		} else if (!fuelTankSourcesFound.equals(other.fuelTankSourcesFound))
			return false;
		if (machineState == null) {
			if (other.machineState != null)
				return false;
		} else if (!machineState.equals(other.machineState))
			return false;
		if (mapRevision == null) {
			if (other.mapRevision != null)
				return false;
		} else if (!mapRevision.equals(other.mapRevision))
			return false;
		if (odometerFound == null) {
			if (other.odometerFound != null)
				return false;
		} else if (!odometerFound.equals(other.odometerFound))
			return false;
		if (ptoSourcesActive == null) {
			if (other.ptoSourcesActive != null)
				return false;
		} else if (!ptoSourcesActive.equals(other.ptoSourcesActive))
			return false;
		if (ptoSourcesFound == null) {
			if (other.ptoSourcesFound != null)
				return false;
		} else if (!ptoSourcesFound.equals(other.ptoSourcesFound))
			return false;
		if (totalFuelFound == null) {
			if (other.totalFuelFound != null)
				return false;
		} else if (!totalFuelFound.equals(other.totalFuelFound))
			return false;
		if (vehicleSpeedFound == null) {
			if (other.vehicleSpeedFound != null)
				return false;
		} else if (!vehicleSpeedFound.equals(other.vehicleSpeedFound))
			return false;
		if (vinFound == null) {
			if (other.vinFound != null)
				return false;
		} else if (!vinFound.equals(other.vinFound))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DiscoveryReportMap [machineState=" + machineState + ", mapRevision=" + mapRevision
				+ ", vehicleSpeedFound=" + vehicleSpeedFound + ", odometerFound=" + odometerFound + ", totalFuelFound="
				+ totalFuelFound + ", vinFound=" + vinFound + ", batteryVoltageSourcesFound="
				+ batteryVoltageSourcesFound + ", discoveryReportSourcesFound1=" + discoveryReportSourcesFound1
				+ ", discoveryReportSourcesFound2=" + discoveryReportSourcesFound2 + ", discoveryReportSourcesFound3="
				+ discoveryReportSourcesFound3 + ", discoveryReportSourcesFound4=" + discoveryReportSourcesFound4
				+ ", fuelTankSourcesFound=" + fuelTankSourcesFound + ", averageFuelTankSourcesFound="
				+ averageFuelTankSourcesFound + ", ptoSourcesFound=" + ptoSourcesFound + ", ptoSourcesActive="
				+ ptoSourcesActive + ", engineTorqueSourcesFound=" + engineTorqueSourcesFound
				+ ", engineThrottleSourcesFound=" + engineThrottleSourcesFound + "]";
	}

}
