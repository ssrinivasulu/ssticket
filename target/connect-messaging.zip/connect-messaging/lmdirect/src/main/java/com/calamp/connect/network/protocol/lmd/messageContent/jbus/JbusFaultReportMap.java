package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;

import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

public class JbusFaultReportMap implements JbusMap {

    private MachineState machineState;
    private Integer sourceAddress;
    private Integer device;
    private Integer function;
    private Integer failure;

    @Override
    public byte[] encode()
    {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer)
    {
        JbusFaultReportMap map = new JbusFaultReportMap();

        /*   Machine state is a 16 bit number sent LSB first.  The current bit usage is as follows.
         *   Bit:    Meaning:    
         *    0   Engine Status (0=Off, 1=On (RPM > 300)) 
         *    1   PTO Status (0=Off, 1 =On)   0
         *    2   Moving (0=Stopped, 1=Moving (>5 MPH))   0
         *    3   Unused (Defaulted to 0) 0
         *    4   Unused (Defaulted to 0) 0
         *    5   Unused (Defaulted to 0) 0
         *    6   J1708 Messages Received 0
         *    7   J1939 Messages Received 0
         *    8   Unused (Defaulted to 0)   0
         *    9   Unused (Defaulted to 0)   0
         *    10  Unused (Defaulted to 0)   0
         *    11  Unused (Defaulted to 0)   0
         *    12  Unused (Defaulted to 0)   0
         *    13  Unused (Defaulted to 0)   0
         *    14  Unused (Defaulted to 0)   0
         *    15  Unused (Defaulted to 0)   0
         *    values are coming MSB first i am reversing the index
         *    Engine Status bit index is 7
         *    PTO Status bit index is 6
         *    Moving bit index is 5
         *    J1708 Messages Received bit index is 1
         *    J1939 Messages Received bit index is 0
         */
        boolean[] bits = BitUtil.getBits(byteBuffer.get());//MachineState
        boolean engineStatus = bits[7];
        boolean ptoStatus = bits[6];
        boolean moving= bits[5];
        boolean j1708MsgRecvd  = bits[1];
        boolean j1939MsgRecvd = bits[0];
        
        machineState = new MachineState();
        machineState.setEngineStatus(engineStatus);
        machineState.setPtoStatus(ptoStatus);
        machineState.setMoving(moving);
        machineState.setJ1708MsgRecvd(j1708MsgRecvd);
        machineState.setJ1939MsgRecvd(j1939MsgRecvd);
        
        map.setMachineState(machineState);
        byteBuffer.get();//MachineState this byte is ignored because they are unused bits
        byteBuffer.get(); // Map Revision

        map.setSourceAddress(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        map.setDevice(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        map.setFunction(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        map.setFailure(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));

        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage()
    {
        RawJbusMessage rawJbusMessage = new RawJbusMessage();

        rawJbusMessage.setMachineState(machineState);
        rawJbusMessage.setSourceAddress(sourceAddress);
        rawJbusMessage.setDevice(device);
        rawJbusMessage.setFunction(function);
        rawJbusMessage.setFailure(failure);

        return rawJbusMessage;
    }

    public MachineState getMachineState() {
        return machineState;
    }

    public void setMachineState(MachineState machineState) {
        this.machineState = machineState;
    }

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }

    public Integer getDevice()
    {
        return device;
    }

    public void setDevice(Integer device)
    {
        this.device = device;
    }

    public Integer getFunction()
    {
        return function;
    }

    public void setFunction(Integer function)
    {
        this.function = function;
    }

    public Integer getFailure()
    {
        return failure;
    }

    public void setFailure(Integer failure)
    {
        this.failure = failure;
    }

}
