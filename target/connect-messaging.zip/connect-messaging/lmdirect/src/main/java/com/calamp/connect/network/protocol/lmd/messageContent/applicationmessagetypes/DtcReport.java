package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: 8/25/11
 */
public class DtcReport extends ApplicationMessageFormat
{
    public enum DtcReportType { ALL, UNREPORTED }

    private DtcReportType reportType;
    List<String> dtcCodes = new ArrayList<String>();
    private static int DTC_BYTE_LENGTH = 5;

    private static final Log logger = LogFactory.getLog(VehicleIdReport.class);

    public DtcReport(){}
    public DtcReport(DtcReportType reportType, List<String> dtcCodes)
    {
        this.reportType = reportType;
        this.dtcCodes = dtcCodes;
    }

    @Override
    public byte[] encode()
    {
        int spaceNeededForDtcCodes = dtcCodes.size() * DTC_BYTE_LENGTH;
        byte[] byteArray = new byte[spaceNeededForDtcCodes + 2];
        byteArray[0] = (byte)reportType.ordinal();
        byteArray[1] = (byte)dtcCodes.size();
        int offset = 2;
        for(String dtcCode : dtcCodes)
        {
            char[] chars = dtcCode.toCharArray();
            for(char character : chars)
            {
                byteArray[offset] = (byte)character;
                offset++;
            }
        }
        return byteArray;
    }

    public static DtcReport decode(ByteBuffer byteBuffer)
    {
        if(logger.isDebugEnabled())
        {
            logger.debug(HexUtil.convertToHexString(byteBuffer.array()));
        }

        int reportTypeByte = byteBuffer.get();
        int dtcCodeCount = byteBuffer.get();
        List<String> dtcCodes = new ArrayList<String>();
        for(int i=0;i<dtcCodeCount;i++)
        {
            byte[] dtcByteArray = new byte[DTC_BYTE_LENGTH];
            byteBuffer.get(dtcByteArray);
            StringBuilder builder = new StringBuilder(DTC_BYTE_LENGTH);
            for(int j=0;j<DTC_BYTE_LENGTH;j++)
            {
                builder.append((char)dtcByteArray[j]);
            }
            dtcCodes.add(builder.toString());
        }

        DtcReportType reportType = DtcReportType.values()[reportTypeByte];
        return new DtcReport(reportType, dtcCodes);
    }

    public List<String> getDtcCodes()
    {
        return dtcCodes;
    }

    public void addDtcCode(String dtcCode)
    {
        dtcCodes.add(dtcCode);
    }
    public void setDtcCodes(List<String> dtcCodes)
    {
        this.dtcCodes = dtcCodes;
    }

    public DtcReportType getReportType()
    {
        return reportType;
    }

    public void setReportType(DtcReportType reportType)
    {
        this.reportType = reportType;
    }

    @Override
    public String toString()
    {
        return "DtcReport{" +
                "reportType=" + reportType +
                ", dtcCodes=" + dtcCodes +
                '}';
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DtcReport dtcReport = (DtcReport) o;

        if (dtcCodes != null ? !dtcCodes.equals(dtcReport.dtcCodes) : dtcReport.dtcCodes != null) return false;
        if (reportType != dtcReport.reportType) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = reportType != null ? reportType.hashCode() : 0;
        result = 31 * result + (dtcCodes != null ? dtcCodes.hashCode() : 0);
        return result;
    }
}
