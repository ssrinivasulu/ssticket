package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw  Date: 7/31/13
 */
public class FuelIdleMap implements JbusMap {
    private Double totalFuel1708;
    private Double totalFuel1939;
    private Double totalIdleFuel1708;
    private Double totalIdleFuel1939;
    private Double totalIdleHours1708;
    private Double totalIdleHours1939;

    @Override
    public byte[] encode() {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        encodedBytes.put(JbusMapType.FUEL_IDLE_MAP.toBytes());
        if(totalFuel1708!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundLong((totalFuel1708 / .125), 0)));
        else
            encodedBytes.put(new byte[4]);
        if(totalFuel1939!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundLong((totalFuel1939 / .5), 0)));
        else
            encodedBytes.put(new byte[4]);
        if(totalIdleFuel1708!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundLong((totalIdleFuel1708 / .125), 0)));
        else
            encodedBytes.put(new byte[4]);
        if(totalIdleFuel1939!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundInt((totalIdleFuel1939 / .5), 0)));
        else
            encodedBytes.put(new byte[4]);
        if(totalIdleHours1708!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundInt((totalIdleHours1708 / .05), 0)));
        else
            encodedBytes.put(new byte[4]);
        if(totalIdleHours1939!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundInt((totalIdleHours1939 / .05), 0)));
        else
            encodedBytes.put(new byte[4]);

        encodedBytes.put(new byte[3]); //padded bytes on the end
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
        FuelIdleMap map = new FuelIdleMap();
        map.setTotalFuel1708( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .125), 1)); //only have 4 bytes
        map.setTotalFuel1939( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .5), 1)); //only have 4 bytes
        map.setTotalIdleFuel1708( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .125), 1)); //only have 4 bytes
        map.setTotalIdleFuel1939( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .5), 1)); //only have 4 bytes
        map.setTotalIdleHours1708( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2)); //only have 4 bytes
        map.setTotalIdleHours1939( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2));
        //the remaining 3 bytes are blank
        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setTotalFuel1708(totalFuel1708);
        jbusMessage.setTotalFuel1939(totalFuel1939);
        jbusMessage.setTotalIdleFuel1708(totalIdleFuel1708);
        jbusMessage.setTotalIdleFuel1939(totalIdleFuel1939);
        jbusMessage.setTotalIdleHours1708(totalIdleHours1708);
        jbusMessage.setTotalIdleHours1939(totalIdleHours1939);
        return jbusMessage;
    }

    public Double getTotalFuel1708() {
        return totalFuel1708;
    }

    public void setTotalFuel1708(Double totalFuel1708) {
        this.totalFuel1708 = totalFuel1708;
    }

    public Double getTotalFuel1939() {
        return totalFuel1939;
    }

    public void setTotalFuel1939(Double totalFuel1939) {
        this.totalFuel1939 = totalFuel1939;
    }

    public Double getTotalIdleFuel1708() {
        return totalIdleFuel1708;
    }

    public void setTotalIdleFuel1708(Double totalIdleFuel1708) {
        this.totalIdleFuel1708 = totalIdleFuel1708;
    }

    public Double getTotalIdleFuel1939() {
        return totalIdleFuel1939;
    }

    public void setTotalIdleFuel1939(Double totalIdleFuel1939) {
        this.totalIdleFuel1939 = totalIdleFuel1939;
    }

    public Double getTotalIdleHours1708() {
        return totalIdleHours1708;
    }

    public void setTotalIdleHours1708(Double totalIdleHours1708) {
        this.totalIdleHours1708 = totalIdleHours1708;
    }

    public Double getTotalIdleHours1939() {
        return totalIdleHours1939;
    }

    public void setTotalIdleHours1939(Double totalIdleHours1939) {
        this.totalIdleHours1939 = totalIdleHours1939;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FuelIdleMap that = (FuelIdleMap) o;

        if (totalFuel1708 != null ? !totalFuel1708.equals(that.totalFuel1708) : that.totalFuel1708 != null)
            return false;
        if (totalFuel1939 != null ? !totalFuel1939.equals(that.totalFuel1939) : that.totalFuel1939 != null)
            return false;
        if (totalIdleFuel1708 != null ? !totalIdleFuel1708.equals(that.totalIdleFuel1708) : that.totalIdleFuel1708 != null)
            return false;
        if (totalIdleFuel1939 != null ? !totalIdleFuel1939.equals(that.totalIdleFuel1939) : that.totalIdleFuel1939 != null)
            return false;
        if (totalIdleHours1708 != null ? !totalIdleHours1708.equals(that.totalIdleHours1708) : that.totalIdleHours1708 != null)
            return false;
        if (totalIdleHours1939 != null ? !totalIdleHours1939.equals(that.totalIdleHours1939) : that.totalIdleHours1939 != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = totalFuel1708 != null ? totalFuel1708.hashCode() : 0;
        result = 31 * result + (totalFuel1939 != null ? totalFuel1939.hashCode() : 0);
        result = 31 * result + (totalIdleFuel1708 != null ? totalIdleFuel1708.hashCode() : 0);
        result = 31 * result + (totalIdleFuel1939 != null ? totalIdleFuel1939.hashCode() : 0);
        result = 31 * result + (totalIdleHours1708 != null ? totalIdleHours1708.hashCode() : 0);
        result = 31 * result + (totalIdleHours1939 != null ? totalIdleHours1939.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "FuelIdleMap{" +
                "totalFuel1708=" + totalFuel1708 +
                ", totalFuel1939=" + totalFuel1939 +
                ", totalIdleFuel1708=" + totalIdleFuel1708 +
                ", totalIdleFuel1939=" + totalIdleFuel1939 +
                ", totalIdleHours1708=" + totalIdleHours1708 +
                ", totalIdleHours1939=" + totalIdleHours1939 +
                '}';
    }

    public static double round(double unrounded, int precision) {
        BigDecimal bd = new BigDecimal(unrounded);
        BigDecimal rounded = bd.setScale(precision, RoundingMode.HALF_UP);
        return rounded.doubleValue();
    }
}
