package com.calamp.connect.network.protocol.lmd.messageContent.jbus;
 

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.services.fmi.util.ByteUtil;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw  Date: 7/29/13
 */
public class BasicParametersMap implements JbusMap {

    private Double odometer1708;
    private Double odometer1939;
    private Double highResolution1939;
    private Double batteryVoltage1708;
    private Double batteryVoltage1939;
    private Double switchedBatteryVoltage1708;
    private Double switchedBatteryVoltage1939;
    private Double engineSpeed1708;
    private Double engineSpeed1939;

    @Override
    public byte[] encode() {

        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        encodedBytes.put(JbusMapType.BASIC_MAP.toBytes());
        if(odometer1708!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian((long) round(odometer1708 / .1, 0)));
        else
            encodedBytes.put(new byte[4]);
        if(odometer1939!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian( (long) round(odometer1939 / .125, 0)));
        else
            encodedBytes.put(new byte[4]);
        if(highResolution1939!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian( (long) round(highResolution1939 / .005, 0)));
        else
            encodedBytes.put(new byte[4]);
        if(batteryVoltage1708!=null)
            encodedBytes.put(ByteUtil.unsignedShortToBytesLittleEndian( (int) round(batteryVoltage1708 / .05, 0)));
        else
            encodedBytes.put(new byte[2]);
        if(batteryVoltage1939!=null)
            encodedBytes.put(ByteUtil.unsignedShortToBytesLittleEndian( (int) round(batteryVoltage1939 / .05, 0)));
        else
            encodedBytes.put(new byte[2]);
        if(switchedBatteryVoltage1708!=null)
            encodedBytes.put(ByteUtil.unsignedShortToBytesLittleEndian( (int) round(switchedBatteryVoltage1708 / .05, 0)));
        else
            encodedBytes.put(new byte[2]);
        if(switchedBatteryVoltage1939!=null)
            encodedBytes.put(ByteUtil.unsignedShortToBytesLittleEndian( (int) round(switchedBatteryVoltage1939 / .05, 0)));
        else
            encodedBytes.put(new byte[2]);
        if(engineSpeed1708!=null)
            encodedBytes.put(  ByteUtil.unsignedShortToBytesLittleEndian( (int) round(engineSpeed1708 / .25, 0)));
        else
            encodedBytes.put(new byte[2]);
        if(engineSpeed1939!=null)
            encodedBytes.put(   ByteUtil.unsignedShortToBytesLittleEndian( (int) round(engineSpeed1939 / .125, 0)));
        else
            encodedBytes.put(new byte[2]);

        encodedBytes.put(new byte[2]); //padded bytes on the end
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
        BasicParametersMap map = new BasicParametersMap();

        map.setOdometer1708( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 3)); //only have 4 bytes
        map.setOdometer1939( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .125), 3)); //only have 4 bytes
        map.setHighResolution1939( round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .005), 3)); //only have 4 bytes
        map.setBatteryVoltage1708( round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2)); //only have 2 bytes
        map.setBatteryVoltage1939( round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2)); //only have 2 bytes
        map.setSwitchedBatteryVoltage1708( round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2));
        map.setSwitchedBatteryVoltage1939( round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2)); //only have 2 bytes
        map.setEngineSpeed1708( round(ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .25, 2)); //only have 2 bytes
        map.setEngineSpeed1939( round(ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .125, 3)); //only have 2 bytes
        //the remaining 2 bytes are blank
        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setOdometer1708(odometer1708);
        jbusMessage.setOdometer1939(odometer1939);
        jbusMessage.setHighResolution1939(highResolution1939);
        jbusMessage.setBatteryVoltage1708(batteryVoltage1708);
        jbusMessage.setBatteryVoltage1939(batteryVoltage1939);
        jbusMessage.setSwitchedBatteryVoltage1708(switchedBatteryVoltage1708);
        jbusMessage.setSwitchedBatteryVoltage1939(switchedBatteryVoltage1939);
        jbusMessage.setEngineSpeed1708(engineSpeed1708);
        jbusMessage.setEngineSpeed1939(engineSpeed1939);
        return jbusMessage;
    }

    public Double getOdometer1708() {
        return odometer1708;
    }

    public void setOdometer1708(Double odometer1708) {
        this.odometer1708 = odometer1708;
    }

    public Double getOdometer1939() {
        return odometer1939;
    }

    public void setOdometer1939(Double odometer1939) {
        this.odometer1939 = odometer1939;
    }

    public Double getHighResolution1939() {
        return highResolution1939;
    }

    public void setHighResolution1939(Double highResolution1939) {
        this.highResolution1939 = highResolution1939;
    }

    public Double getBatteryVoltage1708() {
        return batteryVoltage1708;
    }

    public void setBatteryVoltage1708(Double batteryVoltage1708) {
        this.batteryVoltage1708 = batteryVoltage1708;
    }

    public Double getBatteryVoltage1939() {
        return batteryVoltage1939;
    }

    public void setBatteryVoltage1939(Double batteryVoltage1939) {
        this.batteryVoltage1939 = batteryVoltage1939;
    }

    public Double getSwitchedBatteryVoltage1708() {
        return switchedBatteryVoltage1708;
    }

    public void setSwitchedBatteryVoltage1708(Double switchedBatteryVoltage1708) {
        this.switchedBatteryVoltage1708 = switchedBatteryVoltage1708;
    }

    public Double getSwitchedBatteryVoltage1939() {
        return switchedBatteryVoltage1939;
    }

    public void setSwitchedBatteryVoltage1939(Double switchedBatteryVoltage1939) {
        this.switchedBatteryVoltage1939 = switchedBatteryVoltage1939;
    }

    public Double getEngineSpeed1708() {
        return engineSpeed1708;
    }

    public void setEngineSpeed1708(Double engineSpeed1708) {
        this.engineSpeed1708 = engineSpeed1708;
    }

    public Double getEngineSpeed1939() {
        return engineSpeed1939;
    }

    public void setEngineSpeed1939(Double engineSpeed1939) {
        this.engineSpeed1939 = engineSpeed1939;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BasicParametersMap that = (BasicParametersMap) o;

        if (batteryVoltage1708 != null ? !batteryVoltage1708.equals(that.batteryVoltage1708) : that.batteryVoltage1708 != null)
            return false;
        if (batteryVoltage1939 != null ? !batteryVoltage1939.equals(that.batteryVoltage1939) : that.batteryVoltage1939 != null)
            return false;
        if (engineSpeed1708 != null ? !engineSpeed1708.equals(that.engineSpeed1708) : that.engineSpeed1708 != null)
            return false;
        if (engineSpeed1939 != null ? !engineSpeed1939.equals(that.engineSpeed1939) : that.engineSpeed1939 != null)
            return false;
        if (highResolution1939 != null ? !highResolution1939.equals(that.highResolution1939) : that.highResolution1939 != null)
            return false;
        if (odometer1708 != null ? !odometer1708.equals(that.odometer1708) : that.odometer1708 != null) return false;
        if (odometer1939 != null ? !odometer1939.equals(that.odometer1939) : that.odometer1939 != null) return false;
        if (switchedBatteryVoltage1708 != null ? !switchedBatteryVoltage1708.equals(that.switchedBatteryVoltage1708) : that.switchedBatteryVoltage1708 != null)
            return false;
        if (switchedBatteryVoltage1939 != null ? !switchedBatteryVoltage1939.equals(that.switchedBatteryVoltage1939) : that.switchedBatteryVoltage1939 != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = odometer1708 != null ? odometer1708.hashCode() : 0;
        result = 31 * result + (odometer1939 != null ? odometer1939.hashCode() : 0);
        result = 31 * result + (highResolution1939 != null ? highResolution1939.hashCode() : 0);
        result = 31 * result + (batteryVoltage1708 != null ? batteryVoltage1708.hashCode() : 0);
        result = 31 * result + (batteryVoltage1939 != null ? batteryVoltage1939.hashCode() : 0);
        result = 31 * result + (switchedBatteryVoltage1708 != null ? switchedBatteryVoltage1708.hashCode() : 0);
        result = 31 * result + (switchedBatteryVoltage1939 != null ? switchedBatteryVoltage1939.hashCode() : 0);
        result = 31 * result + (engineSpeed1708 != null ? engineSpeed1708.hashCode() : 0);
        result = 31 * result + (engineSpeed1939 != null ? engineSpeed1939.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "BasicParametersMap{" +
                "odometer1708=" + odometer1708 +
                ", odometer1939=" + odometer1939 +
                ", highResolution1939=" + highResolution1939 +
                ", batteryVoltage1708=" + batteryVoltage1708 +
                ", batteryVoltage1939=" + batteryVoltage1939 +
                ", switchedBatteryVoltage1708=" + switchedBatteryVoltage1708 +
                ", switchedBatteryVoltage1939=" + switchedBatteryVoltage1939 +
                ", engineSpeed1708=" + engineSpeed1708 +
                ", engineSpeed1939=" + engineSpeed1939 +
                '}';
    }

    public static double round(double unrounded, int precision) {
        BigDecimal bd = new BigDecimal(unrounded);
        BigDecimal rounded = bd.setScale(precision, RoundingMode.HALF_UP);
        return rounded.doubleValue();
    }
}
