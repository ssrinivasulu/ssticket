/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network.RawJbusMessage;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class RawJbusToNetworkRawJbusMessageConverter extends GenericNetworkMessageConverter<com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage, RawJbusMessage> {

	@Override
	public RawJbusMessage convert(com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage applRawJbusMessage) {
		RawJbusMessage rawJbusMessage = super.convert(applRawJbusMessage, RawJbusMessage.class);

        return rawJbusMessage;
	}

	@Override
	public com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage convert(RawJbusMessage rawJbusMessage) {
		com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage applicationMessageContent = super.convert(rawJbusMessage, com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage.class);
	        return applicationMessageContent;
	}

	@Override
	protected RawJbusMessage customConvert(com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage applRawJbusMessage, RawJbusMessage rawJbusMessage) {
		return rawJbusMessage;
	}

	@Override
	protected com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage customConvert(RawJbusMessage applRawJbusMessage, com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage rawJbusMessage) {
		return rawJbusMessage;
	}

}
