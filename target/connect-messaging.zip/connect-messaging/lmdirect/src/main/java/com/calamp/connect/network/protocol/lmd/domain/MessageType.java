package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: Oct 13, 2010
 */
public enum MessageType
{
	UNKNOWN(-1),
    NULL(0), 
    ACK_NAK(1), 
    EVENT_REPORT(2), 
    ID_REPORT(3), 
    USER_DATA(4), 
    APPLICATION_DATA(5), 
    CONFIGURATION_PARAMETER(6), 
    UNIT_REQUEST(7),
    LOCATE_REPORT(8), 
    USER_DATA_WITH_ACCUMULATORS(9), 
    MINI_EVENT_REPORT(10),
    MINI_USER_DATA(11),
    MINI_APPLICATION_DATA(12),
    APPLICATION_DATA_WITH_ACCUMULATORS(14),
    EXTENDED_ID_REPORT(100);
	
	private final int value;
	
	private MessageType(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}
	
    public static MessageType getMessageType(int value)
    {
        for(MessageType type : values())
        {
            if(type.getValue() == value)
            {
                return type;
            }
        }
        return MessageType.UNKNOWN;
    }
    
    public static void main(String[] args) {
    	System.out.println("the message type for type value 3 is: " + MessageType.getMessageType(3));
    }
}
