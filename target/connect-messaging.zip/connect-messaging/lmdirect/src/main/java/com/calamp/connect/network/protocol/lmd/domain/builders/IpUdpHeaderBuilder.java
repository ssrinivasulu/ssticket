package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.IpUdpHeader;

/**
 * User: ericw
 * Date: Oct 28, 2010
 */
public class IpUdpHeaderBuilder
{
    private IpUdpHeader ipUdpHeader;

    private IpUdpHeaderBuilder(IpUdpHeader header)
    {
        this.ipUdpHeader = header;
    }

    public static IpUdpHeaderBuilder buildFrom(IpUdpHeader ipUdpHeader)
    {
          return new IpUdpHeaderBuilder(IpUdpHeaderBuilder.copyMessage(ipUdpHeader));
    }

    public static IpUdpHeaderBuilder getBuilder()
    {
        return new IpUdpHeaderBuilder(null);
    }

    public static IpUdpHeaderBuilder getBuilderWithDefault()
    {
        IpUdpHeader header = new IpUdpHeader();
        header.setSourceAddress("10.115.130.180");
        header.setDestinationAddress("172.25.0.122");
        header.setSourcePort(20500);
        header.setDestinationPort(20510);
        return new IpUdpHeaderBuilder(header);
    }
    
    private static IpUdpHeader copyMessage(IpUdpHeader messageToCopy)
    {
        if(messageToCopy==null)
            return null;

        IpUdpHeader newIpUdpHeader = new IpUdpHeader();

        newIpUdpHeader.setDestinationAddress(messageToCopy.getDestinationAddress());
        newIpUdpHeader.setSourceAddress(messageToCopy.getSourceAddress());
        newIpUdpHeader.setSourcePort(messageToCopy.getSourcePort());
        newIpUdpHeader.setDestinationPort(messageToCopy.getDestinationPort());

        return newIpUdpHeader;
    }

    public IpUdpHeader build()
    {
        if(ipUdpHeader==null)
        {
            return null;
        }
        IpUdpHeader returnedHeader = ipUdpHeader;
        ipUdpHeader = null;

        return returnedHeader;
    }

    public IpUdpHeaderBuilder setSourceAddress(String sourceAddress)
    {
        if(ipUdpHeader==null)
        {
            ipUdpHeader = new IpUdpHeader();
        }
        ipUdpHeader.setSourceAddress(sourceAddress);
        return this;
    }

    public IpUdpHeaderBuilder setDestinationAddress(String destinationAddress)
    {
        if(ipUdpHeader==null)
        {
            ipUdpHeader = new IpUdpHeader();
        }
        ipUdpHeader.setDestinationAddress(destinationAddress);
        return this;
    }

    public IpUdpHeaderBuilder setSourcePort(Integer sourcePort)
    {
        if(ipUdpHeader==null)
        {
            ipUdpHeader = new IpUdpHeader();
        }
        ipUdpHeader.setSourcePort(sourcePort);
        return this;
    }

    public IpUdpHeaderBuilder setDestinationPort(Integer destinationPort)
    {
        if(ipUdpHeader==null)
        {
            ipUdpHeader = new IpUdpHeader();
        }
        ipUdpHeader.setDestinationPort(destinationPort);
        return this;
    }

    public void clear()
    {
        ipUdpHeader = null;
    }
}
