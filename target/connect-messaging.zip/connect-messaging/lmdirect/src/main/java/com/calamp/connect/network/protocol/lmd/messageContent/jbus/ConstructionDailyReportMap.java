package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

public class ConstructionDailyReportMap implements JbusMap
{

    private MachineState machineState;
    private String       engineTotalFuelUsed;
    private String       avgEngineFuelRate;
    private String       avgActualEngineTorque;
    private String       minEngineSpeed;
    private String       maxEngineSpeed;
    private String       avgEngineSpeed;
    private String       minDEFConcentration;
    private String       maxDEFConcentration;
    private String       avgDEFConcentration;
    private String       minDEFTempr;
    private String       maxDEFTempr;
    private String       avgDEFTempr;
    private String       minEngineOilPressure;
    private String       maxEngineOilPressure;
    private String       avgEngineOilPressure;
    private String       minEngineOilTempr;
    private String       maxEngineOilTempr;
    private String       avgEngineOilTempr;
    private String       minEngineCoolantTempr;
    private String       maxEngineCoolantTempr;
    private String       avgEngineCoolantTempr;
    private String       minEngineFuelTempr1;
    private String       maxEngineFuelTempr1;
    private String       avgEngineFuelTempr1;
    private String       minAmbientAirTempr;
    private String       maxAmbientAirTempr;
    private String       avgAmbientAirTempr;
    private String       minAuxiliaryTempr1;
    private String       maxAuxiliaryTempr1;
    private String       avgAuxiliaryTempr1;

    @Override
    public byte[] encode()
    {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer)
    {
        ConstructionDailyReportMap map = new ConstructionDailyReportMap();
        /*
         * Machine state is a 16 bit number sent LSB first. The current bit usage is as follows. Bit: Meaning: 0 Engine Status (0=Off, 1=On (RPM >
         * 300)) 1 PTO Status (0=Off, 1 =On) 0 2 Moving (0=Stopped, 1=Moving (>5 MPH)) 0 3 Unused (Defaulted to 0) 0 4 Unused (Defaulted to 0) 0 5
         * Unused (Defaulted to 0) 0 6 J1708 Messages Received 0 7 J1939 Messages Received 0 8 Unused (Defaulted to 0) 0 9 Unused (Defaulted to 0) 0
         * 10 Unused (Defaulted to 0) 0 11 Unused (Defaulted to 0) 0 12 Unused (Defaulted to 0) 0 13 Unused (Defaulted to 0) 0 14 Unused (Defaulted to
         * 0) 0 15 Unused (Defaulted to 0) 0 values are coming MSB first i am reversing the index Engine Status bit index is 7 PTO Status bit index is
         * 6 Moving bit index is 5 J1708 Messages Received bit index is 1 J1939 Messages Received bit index is 0
         */

        boolean[] bits = BitUtil.getBits(byteBuffer.get());// MachineState
        boolean engineStatus = bits[7];
        boolean ptoStatus = bits[6];
        boolean moving = bits[5];
        boolean j1708MsgRecvd = bits[1];
        boolean j1939MsgRecvd = bits[0];

        machineState = new MachineState();
        machineState.setEngineStatus(engineStatus);
        machineState.setPtoStatus(ptoStatus);
        machineState.setMoving(moving);
        machineState.setJ1708MsgRecvd(j1708MsgRecvd);
        machineState.setJ1939MsgRecvd(j1939MsgRecvd);

        map.setMachineState(machineState);
        byteBuffer.get();// MachineState this byte is ignored because they are unused bits
        byteBuffer.get(); // Map Revision

        map.setEngineTotalFuelUsed(NetworkUtil.round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .5), 2));
        map.setAvgEngineFuelRate(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2));
        map.setAvgActualEngineTorque(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 125));
        map.setMinEngineSpeed(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .125), 3));
        map.setMaxEngineSpeed(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .125), 3));
        map.setAvgEngineSpeed(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .125), 3));
        map.setMinDEFConcentration(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * .25));
        map.setMaxDEFConcentration(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * .25));
        map.setAvgDEFConcentration(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * .25));
        map.setMinDEFTempr(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMaxDEFTempr(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setAvgDEFTempr(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMinEngineOilPressure(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 4));
        map.setMaxEngineOilPressure(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 4));
        map.setAvgEngineOilPressure(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 4));
        map.setMinEngineOilTempr(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5));
        map.setMaxEngineOilTempr(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5));
        map.setAvgEngineOilTempr(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5));
        map.setMinEngineCoolantTempr(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMaxEngineCoolantTempr(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setAvgEngineCoolantTempr(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMinEngineFuelTempr1(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMaxEngineFuelTempr1(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setAvgEngineFuelTempr1(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMinAmbientAirTempr(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5));
        map.setMaxAmbientAirTempr(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5));
        map.setAvgAmbientAirTempr(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5));
        map.setMinAuxiliaryTempr1(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMaxAuxiliaryTempr1(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setAvgAuxiliaryTempr1(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));

        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage()
    {
        RawJbusMessage jbusMessage = new RawJbusMessage();

        jbusMessage.setMachineState(machineState);
        jbusMessage.setEngineTotalFuelUsed(engineTotalFuelUsed);
        jbusMessage.setAvgEngineFuelRate(avgEngineFuelRate);
        jbusMessage.setAvgActualEngineTorque(avgActualEngineTorque);
        jbusMessage.setMinEngineSpeed(minEngineSpeed);
        jbusMessage.setMaxEngineSpeed(maxEngineSpeed);
        jbusMessage.setAvgEngineSpeed(avgEngineSpeed);
        jbusMessage.setMinDEFConcentration(minDEFConcentration);
        jbusMessage.setMaxDEFConcentration(maxDEFConcentration);
        jbusMessage.setAvgDEFConcentration(avgDEFConcentration);
        jbusMessage.setMinDEFTempr(minDEFTempr);
        jbusMessage.setMaxDEFTempr(maxDEFTempr);
        jbusMessage.setAvgDEFTempr(avgDEFTempr);
        jbusMessage.setMinEngineOilPressure(minEngineOilPressure);
        jbusMessage.setMaxEngineOilPressure(maxEngineOilPressure);
        jbusMessage.setAvgEngineOilPressure(avgEngineOilPressure);
        jbusMessage.setMinEngineOilTempr(minEngineOilTempr);
        jbusMessage.setMaxEngineOilTempr(maxEngineOilTempr);
        jbusMessage.setAvgEngineOilTempr(avgEngineOilTempr);
        jbusMessage.setMinEngineCoolantTempr(minEngineCoolantTempr);
        jbusMessage.setMaxEngineCoolantTempr(maxEngineCoolantTempr);
        jbusMessage.setAvgEngineCoolantTempr(avgEngineCoolantTempr);
        jbusMessage.setMinEngineFuelTempr1(minEngineFuelTempr1);
        jbusMessage.setMaxEngineFuelTempr1(maxEngineFuelTempr1);
        jbusMessage.setAvgEngineFuelTempr1(avgEngineFuelTempr1);
        jbusMessage.setMinAmbientAirTempr(minAmbientAirTempr);
        jbusMessage.setMaxAmbientAirTempr(maxAmbientAirTempr);
        jbusMessage.setAvgAmbientAirTempr(avgAmbientAirTempr);
        jbusMessage.setMinAuxiliaryTempr1(minAuxiliaryTempr1);
        jbusMessage.setMaxAuxiliaryTempr1(maxAuxiliaryTempr1);
        jbusMessage.setAvgAuxiliaryTempr1(avgAuxiliaryTempr1);

        return jbusMessage;
    }

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    public String getEngineTotalFuelUsed()
    {
        return engineTotalFuelUsed;
    }

    public void setEngineTotalFuelUsed(String engineTotalFuelUsed)
    {
        this.engineTotalFuelUsed = engineTotalFuelUsed;
    }

    public String getAvgEngineFuelRate()
    {
        return avgEngineFuelRate;
    }

    public void setAvgEngineFuelRate(String avgEngineFuelRate)
    {
        this.avgEngineFuelRate = avgEngineFuelRate;
    }

    public String getAvgActualEngineTorque()
    {
        return avgActualEngineTorque;
    }

    public void setAvgActualEngineTorque(String avgActualEngineTorque)
    {
        this.avgActualEngineTorque = avgActualEngineTorque;
    }

    public String getMinEngineSpeed()
    {
        return minEngineSpeed;
    }

    public void setMinEngineSpeed(String minEngineSpeed)
    {
        this.minEngineSpeed = minEngineSpeed;
    }

    public String getMaxEngineSpeed()
    {
        return maxEngineSpeed;
    }

    public void setMaxEngineSpeed(String maxEngineSpeed)
    {
        this.maxEngineSpeed = maxEngineSpeed;
    }

    public String getAvgEngineSpeed()
    {
        return avgEngineSpeed;
    }

    public void setAvgEngineSpeed(String avgEngineSpeed)
    {
        this.avgEngineSpeed = avgEngineSpeed;
    }

    public String getMinDEFConcentration()
    {
        return minDEFConcentration;
    }

    public void setMinDEFConcentration(String minDEFConcentration)
    {
        this.minDEFConcentration = minDEFConcentration;
    }

    public String getMaxDEFConcentration()
    {
        return maxDEFConcentration;
    }

    public void setMaxDEFConcentration(String maxDEFConcentration)
    {
        this.maxDEFConcentration = maxDEFConcentration;
    }

    public String getAvgDEFConcentration()
    {
        return avgDEFConcentration;
    }

    public void setAvgDEFConcentration(String avgDEFConcentration)
    {
        this.avgDEFConcentration = avgDEFConcentration;
    }

    public String getMinDEFTempr()
    {
        return minDEFTempr;
    }

    public void setMinDEFTempr(String minDEFTempr)
    {
        this.minDEFTempr = minDEFTempr;
    }

    public String getMaxDEFTempr()
    {
        return maxDEFTempr;
    }

    public void setMaxDEFTempr(String maxDEFTempr)
    {
        this.maxDEFTempr = maxDEFTempr;
    }

    public String getAvgDEFTempr()
    {
        return avgDEFTempr;
    }

    public void setAvgDEFTempr(String avgDEFTempr)
    {
        this.avgDEFTempr = avgDEFTempr;
    }

    public String getMinEngineOilPressure()
    {
        return minEngineOilPressure;
    }

    public void setMinEngineOilPressure(String minEngineOilPressure)
    {
        this.minEngineOilPressure = minEngineOilPressure;
    }

    public String getMaxEngineOilPressure()
    {
        return maxEngineOilPressure;
    }

    public void setMaxEngineOilPressure(String maxEngineOilPressure)
    {
        this.maxEngineOilPressure = maxEngineOilPressure;
    }

    public String getAvgEngineOilPressure()
    {
        return avgEngineOilPressure;
    }

    public void setAvgEngineOilPressure(String avgEngineOilPressure)
    {
        this.avgEngineOilPressure = avgEngineOilPressure;
    }

    public String getMinEngineOilTempr()
    {
        return minEngineOilTempr;
    }

    public void setMinEngineOilTempr(String minEngineOilTempr)
    {
        this.minEngineOilTempr = minEngineOilTempr;
    }

    public String getMaxEngineOilTempr()
    {
        return maxEngineOilTempr;
    }

    public void setMaxEngineOilTempr(String maxEngineOilTempr)
    {
        this.maxEngineOilTempr = maxEngineOilTempr;
    }

    public String getAvgEngineOilTempr()
    {
        return avgEngineOilTempr;
    }

    public void setAvgEngineOilTempr(String avgEngineOilTempr)
    {
        this.avgEngineOilTempr = avgEngineOilTempr;
    }

    public String getMinEngineCoolantTempr()
    {
        return minEngineCoolantTempr;
    }

    public void setMinEngineCoolantTempr(String minEngineCoolantTempr)
    {
        this.minEngineCoolantTempr = minEngineCoolantTempr;
    }

    public String getMaxEngineCoolantTempr()
    {
        return maxEngineCoolantTempr;
    }

    public void setMaxEngineCoolantTempr(String maxEngineCoolantTempr)
    {
        this.maxEngineCoolantTempr = maxEngineCoolantTempr;
    }

    public String getAvgEngineCoolantTempr()
    {
        return avgEngineCoolantTempr;
    }

    public void setAvgEngineCoolantTempr(String avgEngineCoolantTempr)
    {
        this.avgEngineCoolantTempr = avgEngineCoolantTempr;
    }

    public String getMinEngineFuelTempr1()
    {
        return minEngineFuelTempr1;
    }

    public void setMinEngineFuelTempr1(String minEngineFuelTempr1)
    {
        this.minEngineFuelTempr1 = minEngineFuelTempr1;
    }

    public String getMaxEngineFuelTempr1()
    {
        return maxEngineFuelTempr1;
    }

    public void setMaxEngineFuelTempr1(String maxEngineFuelTempr1)
    {
        this.maxEngineFuelTempr1 = maxEngineFuelTempr1;
    }

    public String getAvgEngineFuelTempr1()
    {
        return avgEngineFuelTempr1;
    }

    public void setAvgEngineFuelTempr1(String avgEngineFuelTempr1)
    {
        this.avgEngineFuelTempr1 = avgEngineFuelTempr1;
    }

    public String getMinAmbientAirTempr()
    {
        return minAmbientAirTempr;
    }

    public void setMinAmbientAirTempr(String minAmbientAirTempr)
    {
        this.minAmbientAirTempr = minAmbientAirTempr;
    }

    public String getMaxAmbientAirTempr()
    {
        return maxAmbientAirTempr;
    }

    public void setMaxAmbientAirTempr(String maxAmbientAirTempr)
    {
        this.maxAmbientAirTempr = maxAmbientAirTempr;
    }

    public String getAvgAmbientAirTempr()
    {
        return avgAmbientAirTempr;
    }

    public void setAvgAmbientAirTempr(String avgAmbientAirTempr)
    {
        this.avgAmbientAirTempr = avgAmbientAirTempr;
    }

    public String getMinAuxiliaryTempr1()
    {
        return minAuxiliaryTempr1;
    }

    public void setMinAuxiliaryTempr1(String minAuxiliaryTempr1)
    {
        this.minAuxiliaryTempr1 = minAuxiliaryTempr1;
    }

    public String getMaxAuxiliaryTempr1()
    {
        return maxAuxiliaryTempr1;
    }

    public void setMaxAuxiliaryTempr1(String maxAuxiliaryTempr1)
    {
        this.maxAuxiliaryTempr1 = maxAuxiliaryTempr1;
    }

    public String getAvgAuxiliaryTempr1()
    {
        return avgAuxiliaryTempr1;
    }

    public void setAvgAuxiliaryTempr1(String avgAuxiliaryTempr1)
    {
        this.avgAuxiliaryTempr1 = avgAuxiliaryTempr1;
    }

}
