/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Event.FixStatus;
import com.calamp.connect.models.network.Network.CommState;
import com.calamp.connect.models.network.Network.Inputs;
import com.calamp.connect.models.network.Network.MessageDetail;
import com.calamp.connect.models.network.Network.UnitStatus;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class EventReportToMessageDetailConverter extends GenericNetworkMessageConverter<EventReportMessageContent, MessageDetail>
{
    private static Logger logger = LogManager.getLogger(EventReportToMessageDetailConverter.class);

    @Override
    public MessageDetail convert(EventReportMessageContent eventReportMessageContent)
    {
        MessageDetail messageDetail = super.convert(eventReportMessageContent, MessageDetail.class);

        return messageDetail;
    }

    @Override
    public EventReportMessageContent convert(MessageDetail messageDetail)
    {
        EventReportMessageContent eventReportMessageContent = super.convert(messageDetail, EventReportMessageContent.class);

        return eventReportMessageContent;
    }

    @Override
    protected MessageDetail customConvert(EventReportMessageContent eventReportMessageContent, MessageDetail messageDetail)
    {
        messageDetail.setEventCode(eventReportMessageContent.getEventCode());
        if (eventReportMessageContent.getLocationStatusInfo() != null)
        {
            messageDetail.setHdop(translateHdop(eventReportMessageContent.getLocationStatusInfo().getHorizontalDilutionOfPrecision()));
            messageDetail.setSpeed(eventReportMessageContent.getLocationStatusInfo().getSpeed());

            boolean hasCurrentFix = ConverterUtil.hasCurrentFix(eventReportMessageContent.getLocationStatusInfo().getFixStatus(), messageDetail.getHdop(), messageDetail.getSatelliteCount());
            messageDetail.setFixStatus(hasCurrentFix);
            messageDetail.setTimeOfFix(eventReportMessageContent.getLocationStatusInfo().getTimeOfFix());
            
            if (eventReportMessageContent.getLocationStatusInfo().getCommState() != null)
            {
                com.calamp.connect.network.protocol.lmd.domain.CommState netCommState = eventReportMessageContent.getLocationStatusInfo()
                        .getCommState();
                CommState commState = new CommState();
                commState.setAvailable(netCommState.isAvailable());
                commState.setConnected(netCommState.isConnected());
                commState.setDataService(netCommState.isDataService());
                commState.setNetworkService(netCommState.isNetworkService());
                commState.setRoaming(netCommState.isRoaming());
                commState.setThreeGNetwork(netCommState.isThreeGNetwork());
                commState.setVoiceCallIsActive(netCommState.isVoiceCallActive());
                messageDetail.setCommState(commState);
            }
            if (eventReportMessageContent.getLocationStatusInfo().getFixStatus() != null)
            {
                com.calamp.connect.network.protocol.lmd.domain.FixStatus netFixStatus = eventReportMessageContent.getLocationStatusInfo()
                        .getFixStatus();
                FixStatus fixStatus = new FixStatus();
                fixStatus.setDifferentiallyCorrected(netFixStatus.isDifferentiallyCorrected());
                fixStatus.setHistoric(netFixStatus.isHistoric());
                fixStatus.setInvalidFix(netFixStatus.isInvalidFix());
                fixStatus.setInvalidTime(netFixStatus.isInvalidTime());
                fixStatus.setLastKnown(netFixStatus.isLastKnown());
                fixStatus.setPredicted(netFixStatus.isPredicted());
                fixStatus.setTwoDFix(netFixStatus.is2DFix());
                messageDetail.setGpsFixStatus(fixStatus);
            }
            if (eventReportMessageContent.getLocationStatusInfo().getUnitStatus() != null)
            {
                UnitStatus unitStatus = new UnitStatus();
                com.calamp.connect.network.protocol.lmd.domain.UnitStatus netUnitStatus = eventReportMessageContent.getLocationStatusInfo()
                        .getUnitStatus();
                unitStatus.setGpsAntennaStatus(netUnitStatus.isGPSAntennaOkay());
                unitStatus.setGpsExceptionReported(netUnitStatus.isGPSExceptionReported());
                unitStatus.setGpsReceiverSelfTest(netUnitStatus.isGPSReceiverSelfTestOkay());
                unitStatus.setGpsReceiverTracking(netUnitStatus.isGPSReceiverTracking());
                unitStatus.setMemoryTest(netUnitStatus.isMemoryTestOkay());
                unitStatus.setModemMinTest(netUnitStatus.isModemMINTestOkay());
                messageDetail.setUnitStatus(unitStatus);
            }
            if (eventReportMessageContent.getLocationStatusInfo().getInputs() != null)
            {
                Inputs inputs = new Inputs();
                com.calamp.connect.network.protocol.lmd.domain.Inputs netInputs = eventReportMessageContent.getLocationStatusInfo().getInputs();
                inputs.setIgnition(netInputs.isIgnitionOn());
                inputs.setInput1(netInputs.isInput1On());
                inputs.setInput2(netInputs.isInput2On());
                inputs.setInput3(netInputs.isInput3On());
                inputs.setInput4(netInputs.isInput4On());
                inputs.setInput5(netInputs.isInput5On());
                inputs.setInput6(netInputs.isInput6On());
                inputs.setInput7(netInputs.isInput7On());

                String binaryInputString = Integer.toBinaryString(eventReportMessageContent.getLocationStatusInfo().getInputs().getByte() & 0xFF);
                StringBuilder binaryInputStringBuilder = new StringBuilder(binaryInputString);
                while (binaryInputStringBuilder.length() < 8)
                {
                    binaryInputStringBuilder.insert(0, "0");
                }
                inputs.setValue(binaryInputStringBuilder.reverse().toString());

                messageDetail.setInputs(inputs);
            }
        }
        messageDetail.setRssi(eventReportMessageContent.getLocationStatusInfo().getRssi());// The backing bits in Inputs are in reverse order;

        return messageDetail;
    }

    @Override
    protected EventReportMessageContent customConvert(MessageDetail messageDetail, EventReportMessageContent eventReportMessageContent)
    {

        return eventReportMessageContent;
    }

 

    public static double translateHdop(int original)
    {
        Double hdop = Double.valueOf(original);
        hdop = hdop / 10.0d;
        return hdop.doubleValue();
    }
}
