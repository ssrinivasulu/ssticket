package com.calamp.connect.network.protocol.lmd.domain;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.Date;

import com.calamp.connect.services.fmi.util.ByteUtil;


public class LocationStatusInfo {
	private Date updateTime;
	private Date timeOfFix;
	private double latitude;
	private double longitude;
	private int altitude;
	private long speed; // cm/second
	private int heading;
	private int numberOfSatellites;
	private FixStatus fixStatus;
	private int carrier;
	private int rssi;
	private CommState commState;
	private int horizontalDilutionOfPrecision;
	private Inputs inputs;
	private UnitStatus unitStatus;

	public static final double LAT_LONG_FACTOR = 0.0000001;
	public static int LMU_STATUS_AND_LOCATION_BYTE_LENGTH = 36;

	public LocationStatusInfo() {
	}

	public LocationStatusInfo(LocationStatusInfo info) {
		setAltitude(info.getAltitude());
		setCarrier(info.getCarrier());
		if (info.getCommState() != null) {
			setCommState(new CommState(info.getCommState()));
		}
		if (info.getFixStatus() != null) {
			setFixStatus(new FixStatus(info.getFixStatus()));
		}
		setHeading(info.getHeading());
		setHorizontalDilutionOfPrecision(info
				.getHorizontalDilutionOfPrecision());
		if (info.getInputs() != null) {
			setInputs(new Inputs(info.getInputs()));
		}
		setLatitude(info.getLatitude());
		setLongitude(info.getLongitude());
		setNumberOfSatellites(info.getNumberOfSatellites());
		setRssi(info.getRssi());
		setSpeed(info.getSpeed());
		setTimeOfFix(info.getTimeOfFix());
		if (info.getUnitStatus() != null) {
			setUnitStatus(new UnitStatus(info.getUnitStatus()));
		}
		setUpdateTime(info.getUpdateTime());
	}

	public static byte[] encode(LocationStatusInfo statusInfo) {
		ByteBuffer byteBuffer = ByteBuffer
				.allocate(LMU_STATUS_AND_LOCATION_BYTE_LENGTH);
		long updateTimeInMilli = statusInfo.getUpdateTime().getTime();
		byteBuffer.put(ByteUtil
				.unsignedIntegerToBytes(updateTimeInMilli / 1000));
		long timeOfFixInMilli = statusInfo.getTimeOfFix().getTime();
		byteBuffer
				.put(ByteUtil.unsignedIntegerToBytes(timeOfFixInMilli / 1000));
		byteBuffer
				.putInt((int) (statusInfo.getLatitude() / LocationStatusInfo.LAT_LONG_FACTOR));
		byteBuffer
				.putInt((int) (statusInfo.getLongitude() / LocationStatusInfo.LAT_LONG_FACTOR));
		byteBuffer.putInt(statusInfo.getAltitude());
		byteBuffer.put(ByteUtil.unsignedIntegerToBytes(statusInfo.getSpeed()));
		byteBuffer.put(ByteUtil.unsignedShortToBytes(statusInfo.getHeading()));
		byteBuffer.put(ByteUtil.unsignedByteToSignedByte(statusInfo
				.getNumberOfSatellites()));
		byteBuffer.put(statusInfo.getFixStatus().getByte());
		byteBuffer.put(ByteUtil.unsignedShortToBytes(statusInfo.getCarrier()));
		byteBuffer.putShort((short) statusInfo.getRssi());
		byteBuffer.put(statusInfo.getCommState().getByte());
		byteBuffer.put(ByteUtil.unsignedByteToSignedByte(statusInfo
				.getHorizontalDilutionOfPrecision()));
		byteBuffer.put(statusInfo.getInputs().getByte());
		byteBuffer.put(statusInfo.getUnitStatus().getByte());

		return byteBuffer.array();
	}

	public static LocationStatusInfo decode(ByteBuffer byteBuffer) {
		LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
		long updateTimeSeconds = ByteUtil.getUnsignedInteger(byteBuffer);
		locationStatusInfo.setUpdateTime(new Date(updateTimeSeconds * 1000));

		long timeOfFixSeconds = ByteUtil.getUnsignedInteger(byteBuffer);
		locationStatusInfo.setTimeOfFix(new Date(timeOfFixSeconds * 1000));

		int latitudeInt = byteBuffer.getInt();
		BigDecimal originalLat = new BigDecimal(latitudeInt);
		BigDecimal latitude = originalLat.scaleByPowerOfTen(-7);
		locationStatusInfo.setLatitude(latitude.doubleValue());

		int longitudeInt = byteBuffer.getInt();
		BigDecimal originalLong = new BigDecimal(longitudeInt);
		BigDecimal longitude = originalLong.scaleByPowerOfTen(-7);
		locationStatusInfo.setLongitude(longitude.doubleValue());

		locationStatusInfo.setAltitude(byteBuffer.getInt());
		long speedInCm = ByteUtil.getUnsignedInteger(byteBuffer);
		locationStatusInfo.setSpeed(speedInCm);

		locationStatusInfo.setHeading(ByteUtil.getUnsignedShort(byteBuffer));
		locationStatusInfo.setNumberOfSatellites(ByteUtil
				.signedByteToUnsignedByte(byteBuffer.get()));
		locationStatusInfo.setFixStatus(new FixStatus(byteBuffer.get()));
		locationStatusInfo.setCarrier(ByteUtil.getUnsignedShort(byteBuffer));
		locationStatusInfo.setRssi(byteBuffer.getShort());
		locationStatusInfo.setCommState(new CommState(byteBuffer.get()));
		locationStatusInfo.setHorizontalDilutionOfPrecision(ByteUtil
				.signedByteToUnsignedByte(byteBuffer.get()));
		locationStatusInfo.setInputs(new Inputs(byteBuffer.get()));
		locationStatusInfo.setUnitStatus(new UnitStatus(byteBuffer.get()));

		return locationStatusInfo;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getUpdateTime()
     */
	public java.util.Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getTimeOfFix()
     */
	public Date getTimeOfFix() {
		return timeOfFix;
	}

	public void setTimeOfFix(Date timeOfFix) {
		this.timeOfFix = timeOfFix;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getLatitude()
     */
	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getLongitude()
     */
	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getAltitude()
     */
	public int getAltitude() {
		return altitude;
	}

	public void setAltitude(int altitude) {
		this.altitude = altitude;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getSpeed()
     */
	public long getSpeed() {
		return speed;
	}

	public void setSpeed(long speed) {
		this.speed = speed;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getHeading()
     */
	public int getHeading() {
		return heading;
	}

	public void setHeading(int heading) {
		this.heading = heading;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getNumberOfSatellites()
     */
	public int getNumberOfSatellites() {
		return numberOfSatellites;
	}

	public void setNumberOfSatellites(int numberOfSatellites) {
		this.numberOfSatellites = numberOfSatellites;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getFixStatus()
     */
	public FixStatus getFixStatus() {
		return fixStatus;
	}

	public void setFixStatus(FixStatus fixStatus) {
		this.fixStatus = fixStatus;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getCarrier()
     */
	public int getCarrier() {
		return carrier;
	}

	public void setCarrier(int carrier) {
		this.carrier = carrier;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getRssi()
     */
	public int getRssi() {
		return rssi;
	}

	public void setRssi(int rssi) {
		this.rssi = rssi;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getCommState()
     */
	public CommState getCommState() {
		return commState;
	}

	public void setCommState(CommState commState) {
		this.commState = commState;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getHorizontalDilutionOfPrecision()
     */
	public int getHorizontalDilutionOfPrecision() {
		return horizontalDilutionOfPrecision;
	}

	public void setHorizontalDilutionOfPrecision(
			int horizontalDilutionOfPrecision) {
		this.horizontalDilutionOfPrecision = horizontalDilutionOfPrecision;
	}

	public void setInputs(Inputs inputs) {
		this.inputs = inputs;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getInputs()
     */
	public Inputs getInputs() {
		return inputs;
	}

	/* (non-Javadoc)
     * @see com.wrx.platform.services.network.calamp.domain.LocationStatusInfo#getUnitStatus()
     */
	public UnitStatus getUnitStatus() {
		return unitStatus;
	}

	public void setUnitStatus(UnitStatus unitStatus) {
		this.unitStatus = unitStatus;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		LocationStatusInfo that = (LocationStatusInfo) o;

		if (altitude != that.altitude)
			return false;
		if (carrier != that.carrier)
			return false;
		if (heading != that.heading)
			return false;
		if (horizontalDilutionOfPrecision != that.horizontalDilutionOfPrecision)
			return false;
		if (Double.compare(that.latitude, latitude) != 0)
			return false;
		if (Double.compare(that.longitude, longitude) != 0)
			return false;
		if (numberOfSatellites != that.numberOfSatellites)
			return false;
		if (rssi != that.rssi)
			return false;
		if (speed != that.speed)
			return false;
		if (commState != null ? !commState.equals(that.commState)
				: that.commState != null)
			return false;
		if (fixStatus != null ? !fixStatus.equals(that.fixStatus)
				: that.fixStatus != null)
			return false;
		if (inputs != null ? !inputs.equals(that.inputs) : that.inputs != null)
			return false;
		if (timeOfFix != null ? !timeOfFix.equals(that.timeOfFix)
				: that.timeOfFix != null)
			return false;
		if (unitStatus != null ? !unitStatus.equals(that.unitStatus)
				: that.unitStatus != null)
			return false;
		if (updateTime != null ? !updateTime.equals(that.updateTime)
				: that.updateTime != null)
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result;
		long temp;
		result = updateTime != null ? updateTime.hashCode() : 0;
		result = 31 * result + (timeOfFix != null ? timeOfFix.hashCode() : 0);
		temp = latitude != +0.0d ? Double.doubleToLongBits(latitude) : 0L;
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		temp = longitude != +0.0d ? Double.doubleToLongBits(longitude) : 0L;
		result = 31 * result + (int) (temp ^ (temp >>> 32));
		result = 31 * result + altitude;
		result = 31 * result + (int) (speed ^ (speed >>> 32));
		result = 31 * result + heading;
		result = 31 * result + numberOfSatellites;
		result = 31 * result + (fixStatus != null ? fixStatus.hashCode() : 0);
		result = 31 * result + carrier;
		result = 31 * result + rssi;
		result = 31 * result + (commState != null ? commState.hashCode() : 0);
		result = 31 * result + horizontalDilutionOfPrecision;
		result = 31 * result + (inputs != null ? inputs.hashCode() : 0);
		result = 31 * result + (unitStatus != null ? unitStatus.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return "LocationStatusInfo{" + "updateTime=" + updateTime
				+ ", timeOfFix=" + timeOfFix + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", altitude=" + altitude
				+ ", speed=" + speed + ", heading=" + heading
				+ ", numberOfSatellites=" + numberOfSatellites + ", fixStatus="
				+ fixStatus + ", carrier=" + carrier + ", rssi=" + rssi
				+ ", commState=" + commState
				+ ", horizontalDilutionOfPrecision="
				+ horizontalDilutionOfPrecision + ", inputs=" + inputs
				+ ", unitStatus=" + unitStatus + '}';
	}
}