package com.calamp.connect.network.protocol.lmd.serializers;

import java.nio.ByteBuffer;

import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw
 * Date: Oct 14, 2010
 */
public class MessageHeaderSerializer
{
    private static final int SEQUENCE_NUMBER_BYTE_LENGTH = 2;
    private static final int MESSAGE_HEADER_BYTE_LENGTH = 4;
    public byte[] encode(MessageHeader header)
    {
        ByteBuffer buffer = ByteBuffer.allocate(MESSAGE_HEADER_BYTE_LENGTH);
        buffer.put((byte)header.getServiceType().ordinal());
        buffer.put((byte)header.getMessageType().getValue());
        buffer.put(ByteUtil.unsignedShortToBytes(header.getSequenceNumber()));
        return buffer.array();
    }

    public MessageHeader decode(ByteBuffer byteBuffer)
    {
        MessageHeader header = new MessageHeader();
        byte serviceType = byteBuffer.get();
        byte messageType = byteBuffer.get();
        byte[] sequenceNumberBytes = new byte[SEQUENCE_NUMBER_BYTE_LENGTH];
        byteBuffer.get(sequenceNumberBytes, 0, SEQUENCE_NUMBER_BYTE_LENGTH);
        int sequenceNumber = ByteUtil.bytesToUnsignedShort(sequenceNumberBytes);
        header.setServiceType(ServiceType.getServiceType(serviceType));
        header.setMessageType(MessageType.getMessageType(messageType));
        header.setSequenceNumber(sequenceNumber);
        return header;
    }
}
