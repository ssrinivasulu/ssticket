package com.calamp.connect.network.protocol.lmd.messageContent;

import java.util.ArrayList;
import java.util.List;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;

/**
 *
 * A type of user message with accumulators
 * note, the max message size is still 848, if the message
 * approaches that size limit, accumulators may be dropped
 * 
 * User: ericw
 * Date: Oct 15, 2010
 */
public class UserMessageWithAccumulatorsContent extends MessageContent
{
    private LocationStatusInfo locationStatusInfo;
    private List<Long> accumulatorValues = new ArrayList<Long>();
    private UserMessageRoute userMessageRoute;
    private int userMessageId;
    private String userMessage;
    
    public LocationStatusInfo getLocationStatusInfo()
    {
        return locationStatusInfo;
    }

    public void setLocationStatusInfo(LocationStatusInfo locationStatusInfo)
    {
        this.locationStatusInfo = locationStatusInfo;
    }

    public List<Long> getAccumulatorValues()
    {
        return accumulatorValues;
    }

    public void setAccumulatorValues(List<Long> accumulatorValues)
    {
        this.accumulatorValues = accumulatorValues;
    }

    public UserMessageRoute getUserMessageRoute()
    {
        return userMessageRoute;
    }

    public void setUserMessageRoute(UserMessageRoute userMessageRoute)
    {
        this.userMessageRoute = userMessageRoute;
    }

    public int getUserMessageId()
    {
        return userMessageId;
    }

    public void setUserMessageId(int userMessageId)
    {
        this.userMessageId = userMessageId;
    }

    public String getUserMessage()
    {
        return userMessage;
    }

    public void setUserMessage(String userMessage)
    {
        this.userMessage = userMessage;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserMessageWithAccumulatorsContent that = (UserMessageWithAccumulatorsContent) o;

        if (userMessageId != that.userMessageId) return false;
        if (accumulatorValues != null ? !accumulatorValues.equals(that.accumulatorValues) : that.accumulatorValues != null)
            return false;
        if (locationStatusInfo != null ? !locationStatusInfo.equals(that.locationStatusInfo) : that.locationStatusInfo != null)
            return false;
        if (userMessage != null ? !userMessage.equals(that.userMessage) : that.userMessage != null) return false;
        if (userMessageRoute != that.userMessageRoute) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = locationStatusInfo != null ? locationStatusInfo.hashCode() : 0;
        result = 31 * result + (accumulatorValues != null ? accumulatorValues.hashCode() : 0);
        result = 31 * result + (userMessageRoute != null ? userMessageRoute.hashCode() : 0);
        result = 31 * result + userMessageId;
        result = 31 * result + (userMessage != null ? userMessage.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "UserMessageWithAccumulatorsContent{" +
                "locationStatusInfo=" + locationStatusInfo +
                ", accumulatorValues=" + accumulatorValues +
                ", userMessageRoute=" + userMessageRoute +
                ", userMessageId=" + userMessageId +
                ", userMessage='" + userMessage + '\'' +
                '}';
    }
}
