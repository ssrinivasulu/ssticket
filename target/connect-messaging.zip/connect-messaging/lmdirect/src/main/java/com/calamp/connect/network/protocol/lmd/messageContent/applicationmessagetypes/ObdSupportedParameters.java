package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.util.Arrays;

import org.apache.log4j.Logger;
/**
 * User: ericw  Date: 3/7/13
 */
public class ObdSupportedParameters
{
	Logger logger = Logger.getLogger(ObdSupportedParameters.class); 
    private static int SUPPORTED_PARAMETER_COUNT = 30;
    boolean[] supportedParameters = new boolean[SUPPORTED_PARAMETER_COUNT];

    public ObdSupportedParameters(String supportedParameterString)
    {
        if(supportedParameterString == null || supportedParameterString.equals(""))
            return;

        String[] parameterStrings = supportedParameterString.split(",");
        for(String parameterString : parameterStrings)
        {
            int index = Integer.valueOf(parameterString);
			if(index >= 0 && index < SUPPORTED_PARAMETER_COUNT)
			{
            	supportedParameters[index] = true;
            } 
			else
			{
            	logger.warn("supportedParameters index OUT OF RANGE : "+index);
            }
        }
    }

    public boolean isVehicleSpeedSupported()
    {
        return supportedParameters[0];
    }

    public boolean isEngineSpeedSupported()
    {
        return supportedParameters[1];
    }

    public boolean isThrottlePositionSupported()
    {
        return supportedParameters[2];
    }

    public boolean isOdometerSupported()
    {
        return supportedParameters[3];
    }

    public boolean isFuelLevelSupported()
    {
        return supportedParameters[4];
    }

    public boolean isFuelLevelRemainingSupported()
    {
        return supportedParameters[5];
    }

    public boolean isTransmissionGearSupported()
    {
        return supportedParameters[6];
    }

    public boolean isEngineCoolantTempSupported()
    {
        return supportedParameters[7];
    }

    public boolean isFuelRateSupported()
    {
        return supportedParameters[8];
    }

    public boolean isBatteryVoltageSupported()
    {
        return supportedParameters[9];
    }

    public boolean isTurnSignalStatusSupported()
    {
        return supportedParameters[10];
    }

    public boolean isTripOdometerSupported()
    {
        return supportedParameters[11];
    }

    public boolean isTripFuelConsumptionSupported()
    {
        return supportedParameters[12];
    }
    
    public boolean isCalculatedFuelUsageSupported()
    {
        return supportedParameters[13];
    }
    
    public boolean isEngineStateSupported()
    {
        return supportedParameters[14];
    }
    
    public boolean isServiceIntervalInspectionDistanceSupported()
    {
        return supportedParameters[15];
    }
    
    public boolean isFuelLevelRemaining3030Supported()
    {
        return supportedParameters[16];
    }
    
    public boolean isServiceIntervalDaysRemainingSupported()
    {
        return supportedParameters[17];
    }
    
    public boolean isEngineOilTempSupported()
    {
        return supportedParameters[18];
    }
    
    public boolean isFuelEconomySupported()
    {
        return supportedParameters[19];
    }
    
    public boolean isDTCCountSupported()
    {
        return supportedParameters[20];
    }
    
    public boolean isServiceIntervalOilDistanceSupported()
    {
        return supportedParameters[21];
    }
    
    public boolean isServiceIntervalOilDaysSupported()
    {
        return supportedParameters[22];
    }
    
    public boolean isEngineRunTimeSupported()
    {
        return supportedParameters[23];
    }
    
    public boolean isAmbientAirTempSupported()
    {
        return supportedParameters[24];
    }
    
    public boolean isBarometricPressureSupported()
    {
        return supportedParameters[25];
    }
    
    public boolean isCanTecSupported()
    {
        return supportedParameters[26];
    }
    
    public boolean isCanRecSupported()
    {
        return supportedParameters[27];
    }
    
    public boolean isCanBusModeSupported()
    {
        return supportedParameters[28];
    }
    
    public boolean isCanBusErrorTypeSupported()
    {
        return supportedParameters[29];
    }

    @Override
    public String toString()
    {
        return "ObdSupportedParameters{" +
                "supportedParameters=" + supportedParameters +
                '}';
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ObdSupportedParameters that = (ObdSupportedParameters) o;

        if (!Arrays.equals(supportedParameters, that.supportedParameters)) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        return supportedParameters != null ? Arrays.hashCode(supportedParameters) : 0;
    }
}
