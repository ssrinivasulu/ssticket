package com.calamp.connect.network.protocol.lmd.domain;

import java.util.Arrays;

import com.calamp.connect.services.fmi.util.BitUtil;



/**
 * 
 * The current State of the wireless modem
 * 
 * User: ericw Date: Oct 18, 2010
 */
public class CommState {
    //NOTE!!!! position 0 of the backing bits is *not* bit 0, it's bit 7. element 0 is actually bit 7
	private boolean[] backingBits;
	private static final int AVAILABLE_BIT = 7;
	private static final int NETWORK_SERVICE_BIT = 6;
	private static final int DATA_SERVICE_BIT = 5;
	private static final int CONNECTED_BIT = 4;
	private static final int VOICE_CALL_IS_ACTIVE_BIT = 3;
	private static final int ROAMING_BIT = 2;
    private static final int THREE_G_NETWORK = 1;

	public CommState(byte commStateInfo) {
		this(BitUtil.getBits(commStateInfo));
	}

	public CommState(boolean[] commStateInfo) {
		backingBits = commStateInfo;
	}

	public CommState(CommState commState) {
		this(commState.backingBits);
	}

	public byte getByte() {
		return BitUtil.getByte(backingBits);
	}

	public boolean isAvailable() {
		return backingBits[AVAILABLE_BIT];
	}

	public boolean isNetworkService() {
		return backingBits[NETWORK_SERVICE_BIT];
	}

	public boolean isDataService() {
		return backingBits[DATA_SERVICE_BIT];
	}

	public boolean isConnected() {
		return backingBits[CONNECTED_BIT];
	}

	public boolean isVoiceCallActive() {
		return backingBits[VOICE_CALL_IS_ACTIVE_BIT];
	}

	public boolean isRoaming() {
		return backingBits[ROAMING_BIT];
	}
    public boolean isThreeGNetwork() {
        return backingBits[THREE_G_NETWORK];
    }

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		CommState commState = (CommState) o;

		if (!Arrays.equals(backingBits, commState.backingBits))
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		return backingBits != null ? Arrays.hashCode(backingBits) : 0;
	}

	@Override
	public String toString() {
		return "CommState{" + "backingBits=" + Arrays.toString(backingBits)
				+ '}';
	}
}
