package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw  Date: 7/31/13
 */
public class TimeTemperatureMap implements JbusMap {
    private Double totalEngineHours1708;
    private Double totalEngineHours1939;
    private Integer engineCoolantTemperature1708;
    private Integer engineCoolantTemperature1939;
    private Double engineOilTemperature1708;
    private Double engineOilTemperature1939;
    private Boolean seatBeltUsed;

    @Override
    public byte[] encode() {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        encodedBytes.put(JbusMapType.TIME_TEMPERATURE_MAP.toBytes());
        if(totalEngineHours1708!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundLong((totalEngineHours1708 / .05), 0)));
        else
            encodedBytes.put(new byte[4]);
        if(totalEngineHours1939!=null)
            encodedBytes.put(ByteUtil.unsignedIntegerToBytesLittleEndian(NetworkUtil.roundLong((totalEngineHours1939 / .05), 0)));
        else
            encodedBytes.put(new byte[4]);
        if(engineCoolantTemperature1708!=null)
            encodedBytes.put(ByteUtil.unsignedByteToSignedByte( engineCoolantTemperature1708));
        else
            encodedBytes.put(new byte[1]);
        if(engineCoolantTemperature1939!=null)
            encodedBytes.put(ByteUtil.unsignedByteToSignedByte( engineCoolantTemperature1939 + 40));
        else
            encodedBytes.put(new byte[1]);
        if(engineOilTemperature1708!=null)
           encodedBytes.put(ByteUtil.unsignedShortToBytesLittleEndian(NetworkUtil.roundInt(((engineOilTemperature1708 / .25) + 32), 0) ));
        else
            encodedBytes.put(new byte[2]);
        if(engineOilTemperature1939!=null)
            encodedBytes.put(ByteUtil.unsignedShortToBytesLittleEndian(NetworkUtil.roundInt(((engineOilTemperature1939 + 273 ) * 32), 0) ));
        else
            encodedBytes.put(new byte[2]);
        if(seatBeltUsed!=null && seatBeltUsed)
            encodedBytes.put(new byte[]{1});
        else
            encodedBytes.put(new byte[1]);

        encodedBytes.put(new byte[9]); //padded bytes on the end
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
        TimeTemperatureMap map = new TimeTemperatureMap();
        map.setTotalEngineHours1708( round(ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05, 2)); //only have 4 bytes
        map.setTotalEngineHours1939( round(ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05, 2)); //only have 4 bytes
        map.setEngineCoolantTemperature1708( ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) ); //only have 1 bytes
        map.setEngineCoolantTemperature1939( ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) - 40); //only have 1 bytes
        map.setEngineOilTemperature1708((round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN)-32) * .25, 5)) ); //only have 2 bytes
        map.setEngineOilTemperature1939((round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) -273, 5)) ); //only have 2 bytes
        byte seatBelt = byteBuffer.get();
        if(seatBelt == 0)
            map.setSeatBeltUsed(Boolean.FALSE);
        else if(seatBelt == 1)
            map.setSeatBeltUsed(Boolean.TRUE);
        else
            map.setSeatBeltUsed(null);
        //the remaining 9 bytes are blank
        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setTotalEngineHours1708(totalEngineHours1708);
        jbusMessage.setTotalEngineHours1939(totalEngineHours1939);
        jbusMessage.setEngineCoolantTemperature1708(engineCoolantTemperature1708);
        jbusMessage.setEngineCoolantTemperature1939(engineCoolantTemperature1939);
        jbusMessage.setEngineOilTemperature1708(engineOilTemperature1708);
        jbusMessage.setEngineOilTemperature1939(engineOilTemperature1939);
        jbusMessage.setSeatBeltUsed(seatBeltUsed);
        return jbusMessage;
    }

    public Double getTotalEngineHours1708() {
        return totalEngineHours1708;
    }

    public void setTotalEngineHours1708(Double totalEngineHours1708) {
        this.totalEngineHours1708 = totalEngineHours1708;
    }

    public Double getTotalEngineHours1939() {
        return totalEngineHours1939;
    }

    public void setTotalEngineHours1939(Double totalEngineHours1939) {
        this.totalEngineHours1939 = totalEngineHours1939;
    }

    public Integer getEngineCoolantTemperature1708() {
        return engineCoolantTemperature1708;
    }

    public void setEngineCoolantTemperature1708(Integer engineCoolantTemperature1708) {
        this.engineCoolantTemperature1708 = engineCoolantTemperature1708;
    }

    public Integer getEngineCoolantTemperature1939() {
        return engineCoolantTemperature1939;
    }

    public void setEngineCoolantTemperature1939(Integer engineCoolantTemperature1939) {
        this.engineCoolantTemperature1939 = engineCoolantTemperature1939;
    }

    public Double getEngineOilTemperature1708() {
        return engineOilTemperature1708;
    }

    public void setEngineOilTemperature1708(Double engineOilTemperature1708) {
        this.engineOilTemperature1708 = engineOilTemperature1708;
    }

    public Double getEngineOilTemperature1939() {
        return engineOilTemperature1939;
    }

    public void setEngineOilTemperature1939(Double engineOilTemperature1939) {
        this.engineOilTemperature1939 = engineOilTemperature1939;
    }

    public Boolean getSeatBeltUsed() {
        return seatBeltUsed;
    }

    public void setSeatBeltUsed(Boolean seatBeltUsed) {
        this.seatBeltUsed = seatBeltUsed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TimeTemperatureMap that = (TimeTemperatureMap) o;

        if (engineCoolantTemperature1708 != null ? !engineCoolantTemperature1708.equals(that.engineCoolantTemperature1708) : that.engineCoolantTemperature1708 != null)
            return false;
        if (engineCoolantTemperature1939 != null ? !engineCoolantTemperature1939.equals(that.engineCoolantTemperature1939) : that.engineCoolantTemperature1939 != null)
            return false;
        if (engineOilTemperature1708 != null ? !engineOilTemperature1708.equals(that.engineOilTemperature1708) : that.engineOilTemperature1708 != null)
            return false;
        if (engineOilTemperature1939 != null ? !engineOilTemperature1939.equals(that.engineOilTemperature1939) : that.engineOilTemperature1939 != null)
            return false;
        if (seatBeltUsed != null ? !seatBeltUsed.equals(that.seatBeltUsed) : that.seatBeltUsed != null) return false;
        if (totalEngineHours1708 != null ? !totalEngineHours1708.equals(that.totalEngineHours1708) : that.totalEngineHours1708 != null)
            return false;
        if (totalEngineHours1939 != null ? !totalEngineHours1939.equals(that.totalEngineHours1939) : that.totalEngineHours1939 != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = totalEngineHours1708 != null ? totalEngineHours1708.hashCode() : 0;
        result = 31 * result + (totalEngineHours1939 != null ? totalEngineHours1939.hashCode() : 0);
        result = 31 * result + (engineCoolantTemperature1708 != null ? engineCoolantTemperature1708.hashCode() : 0);
        result = 31 * result + (engineCoolantTemperature1939 != null ? engineCoolantTemperature1939.hashCode() : 0);
        result = 31 * result + (engineOilTemperature1708 != null ? engineOilTemperature1708.hashCode() : 0);
        result = 31 * result + (engineOilTemperature1939 != null ? engineOilTemperature1939.hashCode() : 0);
        result = 31 * result + (seatBeltUsed != null ? seatBeltUsed.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "TimeTemperatureMap{" +
                "totalEngineHours1708=" + totalEngineHours1708 +
                ", totalEngineHours1939=" + totalEngineHours1939 +
                ", engineCoolantTemperature1708=" + engineCoolantTemperature1708 +
                ", engineCoolantTemperature1939=" + engineCoolantTemperature1939 +
                ", engineOilTemperature1708=" + engineOilTemperature1708 +
                ", engineOilTemperature1939=" + engineOilTemperature1939 +
                ", seatBeltUsed=" + seatBeltUsed +
                '}';
    }

    public static double round(double unrounded, int precision) {
        BigDecimal bd = new BigDecimal(unrounded);
        BigDecimal rounded = bd.setScale(precision, RoundingMode.HALF_UP);
        return rounded.doubleValue();
    }
}
