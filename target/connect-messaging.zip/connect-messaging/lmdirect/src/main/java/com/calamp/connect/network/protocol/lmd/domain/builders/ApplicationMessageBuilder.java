package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ApplicationMessageFormat;

/**
 * User: ericw
 * Date: Oct 26, 2010
 */
public class ApplicationMessageBuilder extends LocationBasedMessageBuilder
{
    private ApplicationMessageContent messageContent;

    private ApplicationMessageBuilder( ApplicationMessageContent messageContent, LocationBasedMessageBuilder builder )
    {
        super(builder);
        this.messageContent = messageContent;
    }

    /**
    * Builds a Default Ack_Nak message
    * @return Message Builder
    */
    public static ApplicationMessageBuilder getBuilderWithDefault()
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilderWithDefault();
        msgBldr.setMessageType(MessageType.APPLICATION_DATA);
        ApplicationMessageContent content = new ApplicationMessageContent();
        return new ApplicationMessageBuilder(content, msgBldr);
    }

    public static ApplicationMessageBuilder getBuilderWithDefault( LocationStatusInfo locInfo )
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilderWithDefault(locInfo);
        msgBldr.setMessageType(MessageType.APPLICATION_DATA);
        ApplicationMessageContent content = new ApplicationMessageContent();
        return new ApplicationMessageBuilder(content, msgBldr);
    }

    public static ApplicationMessageBuilder getBuilder()
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilder();
        msgBldr.setMessageType(MessageType.APPLICATION_DATA);
        return new ApplicationMessageBuilder(null,msgBldr);
    }

    public static ApplicationMessageBuilder getBuilder( LocationStatusInfo locInfo )
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilder(locInfo);
        msgBldr.setMessageType(MessageType.APPLICATION_DATA);
        return new ApplicationMessageBuilder(null, msgBldr);
    }
    
    public ApplicationMessageBuilder setAppMsgType(ApplicationMessageType applicationMessageType)
    {
        if(messageContent!=null)
        {
            messageContent.setApplicationMessageType(applicationMessageType);
        }
        else
        {
            messageContent = new ApplicationMessageContent();
            messageContent.setApplicationMessageType(applicationMessageType);
        }
        return this;
    }
    
    public ApplicationMessageBuilder setAppMsgFormat(ApplicationMessageFormat applicationMessageFormat)
    {
    	if(messageContent!=null)
        {
            messageContent.setApplicationMessageFormat(applicationMessageFormat);
        }
        else
        {
            messageContent = new ApplicationMessageContent();
            messageContent.setApplicationMessageFormat(applicationMessageFormat);
        }
        return this;
    }
   
    public LMDirectMessage toLMDirectMessage()
    {
        messageContent.setLocationStatusInfo(getLocationStatusInfo());
        LMDirectMessage partialMessage = super.toLMDirectMessage();
        partialMessage.setMessageContent(messageContent);
        messageContent = null;
        super.clear();
        return partialMessage;
    }

}
