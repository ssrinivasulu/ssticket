package com.calamp.connect.network.protocol.lmd.messageContent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class EventReportMessageContent extends MessageContent
{
    private LocationStatusInfo locationStatusInfo;
    private int eventIndex;
    private int eventCode;
    private List<Long> accumulatorValues = new ArrayList<Long>();

    public EventReportMessageContent(){}

    public EventReportMessageContent(EventReportMessageContent content)
    {
        setEventCode(content.getEventCode());
        setEventIndex(content.getEventIndex());
        if(content.getLocationStatusInfo()!=null)
        {
            setLocationStatusInfo(new LocationStatusInfo(content.getLocationStatusInfo()));
        }
        setAccumulatorValues( new ArrayList<Long>(content.getAccumulatorValues()));
    }

    public int getEventIndex()
    {
        return eventIndex;
    }

    public void setEventIndex(int eventIndex)
    {
        this.eventIndex = eventIndex;
    }

    public int getEventCode()
    {
        return eventCode;
    }

    public void setEventCode(int eventCode)
    {
        this.eventCode = eventCode;
    }

    public List<Long> getAccumulatorValues()
    {
        return Collections.unmodifiableList(accumulatorValues);
    }

    public void setAccumulatorValues(List<Long> accumulatorValues)
    {
        if ( accumulatorValues != null )
            this.accumulatorValues = accumulatorValues;
    }

    public Long getAccumulatorValue( int index )
    {
        if ( index >= accumulatorValues.size() || index < 0 )
            throw new IllegalArgumentException("Invalid accumulator requested: " + index);
        
        return accumulatorValues.get(index);
    }

    public void setAccumulatorValue( int index, Long value )
    {
        if ( index < accumulatorValues.size() ) 
            accumulatorValues.set(index, value); 
        else
        {
            //We need to pad the accumulators list with nulls till the 
            //new accumulator index is reached. This is so that the new
            //accumulator is added at the right index in the list.
            for ( int i = accumulatorValues.size(); i < index; i++ )
                accumulatorValues.add(null);
            
            accumulatorValues.add(value);
        }
    }

//    public void setAccumulatorValue( int index, long value )
//    {
//        this.accumulatorValues.set(index, value);
//    }

    public LocationStatusInfo getLocationStatusInfo()
    {
        return locationStatusInfo;
    }

    public void setLocationStatusInfo(LocationStatusInfo locationStatusInfo)
    {
        this.locationStatusInfo = locationStatusInfo;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EventReportMessageContent that = (EventReportMessageContent) o;

        if (eventCode != that.eventCode) return false;
        if (eventIndex != that.eventIndex) return false;
        if (accumulatorValues != null ? !accumulatorValues.equals(that.accumulatorValues) : that.accumulatorValues != null)
            return false;
        if (locationStatusInfo != null ? !locationStatusInfo.equals(that.locationStatusInfo) : that.locationStatusInfo != null)
            return false;


        return true;
    }

    @Override
    public int hashCode()
    {
        int result = locationStatusInfo != null ? locationStatusInfo.hashCode() : 0;
        result = 31 * result + eventIndex;
        result = 31 * result + eventCode;
        result = 31 * result + (accumulatorValues != null ? accumulatorValues.hashCode() : 0);
        result = 31 * result + (locationStatusInfo != null ? locationStatusInfo.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "EventReportMessageContent{" +
                "locationStatusInfo=" + locationStatusInfo +
                ", eventIndex=" + eventIndex +
                ", eventCode=" + eventCode +
                ", accumulatorValues=" + accumulatorValues +
                '}';
    }
}
