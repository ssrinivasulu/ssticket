package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

public class JbusHydraulicReportMap implements JbusMap
{

    private MachineState machineState;
    private String       minHydraulicChargePressure;
    private String       maxHydraulicChargePressure;
    private String       avgHydraulicChargePressure;
    private String       minHydraulicOilTemperature;
    private String       maxHydraulicOilTemperature;
    private String       avgHydraulicOilTemperature;

    @Override
    public byte[] encode()
    {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer)
    {
        JbusHydraulicReportMap map = new JbusHydraulicReportMap();

        /*
         * Machine state is a 16 bit number sent LSB first. The current bit usage is as follows. Bit: Meaning: 0 Engine Status (0=Off, 1=On (RPM >
         * 300)) 1 PTO Status (0=Off, 1 =On) 0 2 Moving (0=Stopped, 1=Moving (>5 MPH)) 0 3 Unused (Defaulted to 0) 0 4 Unused (Defaulted to 0) 0 5
         * Unused (Defaulted to 0) 0 6 J1708 Messages Received 0 7 J1939 Messages Received 0 8 Unused (Defaulted to 0) 0 9 Unused (Defaulted to 0) 0
         * 10 Unused (Defaulted to 0) 0 11 Unused (Defaulted to 0) 0 12 Unused (Defaulted to 0) 0 13 Unused (Defaulted to 0) 0 14 Unused (Defaulted to
         * 0) 0 15 Unused (Defaulted to 0) 0 values are coming MSB first i am reversing the index Engine Status bit index is 7 PTO Status bit index is
         * 6 Moving bit index is 5 J1708 Messages Received bit index is 1 J1939 Messages Received bit index is 0
         */
        boolean[] bits = BitUtil.getBits(byteBuffer.get());// MachineState
        boolean engineStatus = bits[7];
        boolean ptoStatus = bits[6];
        boolean moving = bits[5];
        boolean j1708MsgRecvd = bits[1];
        boolean j1939MsgRecvd = bits[0];

        machineState = new MachineState();
        machineState.setEngineStatus(engineStatus);
        machineState.setPtoStatus(ptoStatus);
        machineState.setMoving(moving);
        machineState.setJ1708MsgRecvd(j1708MsgRecvd);
        machineState.setJ1939MsgRecvd(j1939MsgRecvd);

        map.setMachineState(machineState);
        byteBuffer.get();// MachineState this byte is ignored because they are unused bits
        byteBuffer.get(); // Map Revision

        map.setMinHydraulicChargePressure(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN)), 2));
        map.setMaxHydraulicChargePressure(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN)), 2));
        map.setAvgHydraulicChargePressure(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN)), 2));
        map.setMinHydraulicOilTemperature(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setMaxHydraulicOilTemperature(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setAvgHydraulicOilTemperature(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));

        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage()
    {
        RawJbusMessage rawJbusMessage = new RawJbusMessage();

        rawJbusMessage.setMachineState(machineState);
        rawJbusMessage.setMinHydraulicChargePressure(minHydraulicChargePressure);
        rawJbusMessage.setMaxHydraulicChargePressure(maxHydraulicChargePressure);
        rawJbusMessage.setAvgHydraulicChargePressure(avgHydraulicChargePressure);
        rawJbusMessage.setMinHydraulicOilTemperature(minHydraulicOilTemperature);
        rawJbusMessage.setMaxHydraulicOilTemperature(maxHydraulicOilTemperature);
        rawJbusMessage.setAvgHydraulicOilTemperature(avgHydraulicOilTemperature);

        return rawJbusMessage;
    }

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    public String getMinHydraulicChargePressure()
    {
        return minHydraulicChargePressure;
    }

    public void setMinHydraulicChargePressure(String minHydraulicChargePressure)
    {
        this.minHydraulicChargePressure = minHydraulicChargePressure;
    }

    public String getMaxHydraulicChargePressure()
    {
        return maxHydraulicChargePressure;
    }

    public void setMaxHydraulicChargePressure(String maxHydraulicChargePressure)
    {
        this.maxHydraulicChargePressure = maxHydraulicChargePressure;
    }

    public String getAvgHydraulicChargePressure()
    {
        return avgHydraulicChargePressure;
    }

    public void setAvgHydraulicChargePressure(String avgHydraulicChargePressure)
    {
        this.avgHydraulicChargePressure = avgHydraulicChargePressure;
    }

    public String getMinHydraulicOilTemperature()
    {
        return minHydraulicOilTemperature;
    }

    public void setMinHydraulicOilTemperature(String minHydraulicOilTemperature)
    {
        this.minHydraulicOilTemperature = minHydraulicOilTemperature;
    }

    public String getMaxHydraulicOilTemperature()
    {
        return maxHydraulicOilTemperature;
    }

    public void setMaxHydraulicOilTemperature(String maxHydraulicOilTemperature)
    {
        this.maxHydraulicOilTemperature = maxHydraulicOilTemperature;
    }

    public String getAvgHydraulicOilTemperature()
    {
        return avgHydraulicOilTemperature;
    }

    public void setAvgHydraulicOilTemperature(String avgHydraulicOilTemperature)
    {
        this.avgHydraulicOilTemperature = avgHydraulicOilTemperature;
    }

}
