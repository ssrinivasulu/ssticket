package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw Date: Oct 13, 2010
 */
public class OptionsHeader {
	private MobileIdType mobileIdType;
	private String mobileId;
	private String authentication;
	private String routing;
	private Forwarding forwarding;
	private ResponseRedirection responseRedirection;
	private OptionsExtension optionsExtension;

	public OptionsHeader() {
	}

	public OptionsExtension getOptionsExtension() {
		return optionsExtension;
	}

	public void setOptionsExtension(OptionsExtension optionsExtension) {
		this.optionsExtension = optionsExtension;
	}

	/**
	 * Copy constructor mainly used in the builders
	 * 
	 * @param header header
	 */
	public OptionsHeader(OptionsHeader header) {
		setMobileId(header.getMobileId());
		setAuthentication(header.getAuthentication());
		setRouting(header.getRouting());
		if (header.getResponseRedirection() != null) {
			setResponseRedirection(new ResponseRedirection(
					header.getResponseRedirection()));
		}
		if (header.getForwarding() != null) {
			setForwarding(new Forwarding(header.getForwarding()));
		}
		setMobileIdType(header.getMobileIdType());
	}

	public MobileIdType getMobileIdType() {
		return mobileIdType;
	}

	public void setMobileIdType(MobileIdType mobileIdType) {
		this.mobileIdType = mobileIdType;
	}

	public String getMobileId() {
		return mobileId;
	}

    public void setMobileId(String mobileId) {
        this.mobileId = mobileId;
    }

	public String getAuthentication() {
		return authentication;
	}

	public void setAuthentication(String authentication) {
		this.authentication = authentication;
	}

	public String getRouting() {
		return routing;
	}

	public void setRouting(String routing) {
		this.routing = routing;
	}

	public Forwarding getForwarding() {
		return forwarding;
	}

	public void setForwarding(Forwarding forwarding) {
		this.forwarding = forwarding;
	}

	public ResponseRedirection getResponseRedirection() {
		return responseRedirection;
	}

	public void setResponseRedirection(ResponseRedirection responseRedirection) {
		this.responseRedirection = responseRedirection;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		OptionsHeader that = (OptionsHeader) o;

		if (authentication != null ? !authentication
				.equals(that.authentication) : that.authentication != null)
			return false;
		if (forwarding != null ? !forwarding.equals(that.forwarding)
				: that.forwarding != null)
			return false;
		if (mobileId != null ? !mobileId.equals(that.mobileId)
				: that.mobileId != null)
			return false;
		if (mobileIdType != that.mobileIdType)
			return false;
		if (responseRedirection != null ? !responseRedirection
				.equals(that.responseRedirection)
				: that.responseRedirection != null)
			return false;
		if (routing != null ? !routing.equals(that.routing)
				: that.routing != null)
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = mobileIdType != null ? mobileIdType.hashCode() : 0;
		result = 31 * result + (mobileId != null ? mobileId.hashCode() : 0);
		result = 31 * result
				+ (authentication != null ? authentication.hashCode() : 0);
		result = 31 * result + (routing != null ? routing.hashCode() : 0);
		result = 31 * result + (forwarding != null ? forwarding.hashCode() : 0);
		result = 31
				* result
				+ (responseRedirection != null ? responseRedirection.hashCode()
						: 0);
		return result;
	}

	@Override
	public String toString() {
		return "OptionsHeader{" + "mobileIdType=" + mobileIdType
				+ ", mobileId='" + mobileId + '\'' + ", authentication='"
				+ authentication + '\'' + ", routing='" + routing + '\''
				+ ", forwarding=" + forwarding + ", responseRedirection="
				+ responseRedirection + '}';
	}
}
