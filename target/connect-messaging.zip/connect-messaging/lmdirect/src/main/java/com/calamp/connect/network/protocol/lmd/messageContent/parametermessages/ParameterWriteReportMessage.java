package com.calamp.connect.network.protocol.lmd.messageContent.parametermessages;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw
 * Date: 4/25/14
 *
 * IMPORTANT:  The write report is buggy. I've tried putting in a couple of invalid parameter ids (1 and 0)
 * If you send a write request with the bad parameter everything works. If you send an invalid parameter with a valid parameter
 * write request, or you send an invalid parameter with an invalid parameter index, then you get a bunch of junk back.
 * It looks like some sort of overflow error.
 */
public class ParameterWriteReportMessage implements ParameterMessageBody {

    private List<Integer> invalidParameterIds = new ArrayList<>();
    private List<ParameterInfo> invalidParameterIndexes = new ArrayList<>();

    public static ParameterWriteReportMessage decode(ByteBuffer byteBuffer) {
        ParameterWriteReportMessage message = new ParameterWriteReportMessage();
//
        while (true) //scary, but no concern for an infinite loop. If the message is malformed, we'll get
        //an exception when we try to read from the end of a bytebuffer
        {

            int parameterIdInt = ByteUtil.getUnsignedShort(byteBuffer);
            int length = ByteUtil.getUnsignedShort(byteBuffer);
            if (parameterIdInt == 0 && length == 0)
                break;

            if(length > 0) { //valid parameterId and invalid index
                ParameterId parameterId = ParameterId.getParameterId(parameterIdInt);
                int index = byteBuffer.get();
                message.invalidParameterIndexes.add(new ParameterInfo(parameterId, index, null));
            }
            else { //just an invalid parameterId
                message.invalidParameterIds.add(parameterIdInt);
            }
       }
        if (message.invalidParameterIds.isEmpty() && message.invalidParameterIndexes.isEmpty())
            return null;
        return message;
    }


    @Override
    public byte[] encode() {

        int sizeInBytes = invalidParameterIds.size() * 4; //2 for id and 2 for length
        sizeInBytes += (invalidParameterIndexes.size() * 4) + invalidParameterIndexes.size(); //an extra byte for the index

        ByteBuffer buffer = ByteBuffer.allocate(sizeInBytes);

        for(Integer parameterId : invalidParameterIds) {
            buffer.putShort((short)parameterId.intValue());
            buffer.putShort((short)0); //length is always 0
        }
        for(ParameterInfo info : invalidParameterIndexes) {
            buffer.putShort((short)info.getParameterId().getValue());
            buffer.putShort((short)1); //length is always 1
            buffer.put((byte)info.getParameterIndex().intValue());
        }
        return buffer.array();
    }

    public List<Integer> getInvalidParameterIds() {
        return invalidParameterIds;
    }

    public void setInvalidParameterIds(List<Integer> invalidParameterIds) {
        this.invalidParameterIds = invalidParameterIds;
    }

    public List<ParameterInfo> getInvalidParameterIndexes() {
        return invalidParameterIndexes;
    }

    public void setInvalidParameterIndexes(List<ParameterInfo> invalidParameterIndexes) {
        this.invalidParameterIndexes = invalidParameterIndexes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ParameterWriteReportMessage that = (ParameterWriteReportMessage) o;

        if (invalidParameterIds != null ? !invalidParameterIds.equals(that.invalidParameterIds) : that.invalidParameterIds != null)
            return false;
        if (invalidParameterIndexes != null ? !invalidParameterIndexes.equals(that.invalidParameterIndexes) : that.invalidParameterIndexes != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = invalidParameterIds != null ? invalidParameterIds.hashCode() : 0;
        result = 31 * result + (invalidParameterIndexes != null ? invalidParameterIndexes.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ParameterWriteReportMessage{" +
                "invalidParameterIds=" + invalidParameterIds +
                ", invalidParameterIndexes=" + invalidParameterIndexes +
                '}';
    }
}
