package com.calamp.connect.network.protocol.lmd.serializers;

import java.nio.ByteBuffer;

import com.calamp.connect.network.protocol.lmd.domain.Forwarding;
import com.calamp.connect.network.protocol.lmd.domain.ForwardingOperationType;
import com.calamp.connect.network.protocol.lmd.domain.ForwardingProtocol;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsExtension;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.domain.ResponseRedirection;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw
 * Date: Oct 13, 2010
 */
public class OptionsHeaderSerializer
{
    public static final int MOBILE_ID_OPTION_BIT = 7;
    public static final int MOBILE_ID_TYPE_OPTION_BIT = 6;
    public static final int AUTHENTICATION_WORD_OPTION_BIT = 5;
    public static final int ROUTING_OPTION_BIT = 4;
    public static final int FORWARDING_OPTION_BIT = 3;
    public static final int RESPONSE_REDIRECTION_OPTION_BIT = 2;
    public static final int OPTIONS_EXTENSION_BIT = 1;
    public static final int OPTIONAL_HEADER_BIT = 0;


    private static final int ADDRESS_LENGTH = 4;
    private static final int PORT_LENGTH = 2;
    private static final int FORWARDING_BYTE_LENGTH = 8;
    private static final int RESPONSE_REDIRECTION_BYTE_LENGTH = 6;

    /**
     * Takes an OptionsHeader and converts it into a byte[]
     *
     * @param header The OptionsHeader to decode
     * @return a byte[] representing the header
     */
    public byte[] encode(OptionsHeader header)
    {
        if(header==null)
        	return null;
        
        //optional bits, set position 0 = true because if there was no header we wouldn't be here.
        //this bit is a little confusing but the MSB is in the zero position of the array
        boolean[] optionBits = new boolean[]{false, false, false, false, false, false, false, false};
        optionBits[OPTIONAL_HEADER_BIT] = true;
        ByteBuffer headerBuffer = ByteBuffer.allocate(0);
        if(header.getMobileId()!=null)
        {
            optionBits[MOBILE_ID_OPTION_BIT] = true;
            ByteBuffer mobileIdBuffer;


            byte[] mobileIdBytes = ByteUtil.convertToBcd(header.getMobileId());

            mobileIdBuffer = ByteBuffer.allocate(mobileIdBytes.length + 1); //+1 for size
            mobileIdBuffer.put((byte)mobileIdBytes.length);
            mobileIdBuffer.put(mobileIdBytes);


            headerBuffer = joinBuffer(headerBuffer, mobileIdBuffer);
        }
        if(header.getMobileIdType()!=null)
        {
            optionBits[MOBILE_ID_TYPE_OPTION_BIT] = true;
            int idOrdinal = header.getMobileIdType().ordinal();
            ByteBuffer mobileIdTypeBuffer = ByteBuffer.allocate(2);
            mobileIdTypeBuffer.put((byte)1);  //size of MobileId Type is always one
            mobileIdTypeBuffer.put((byte)idOrdinal);
            headerBuffer = joinBuffer(headerBuffer, mobileIdTypeBuffer);
        }
        if(header.getAuthentication()!=null)
        {
            optionBits[AUTHENTICATION_WORD_OPTION_BIT] =true;
            byte[] authenticationBytes = header.getAuthentication().getBytes();
            ByteBuffer authenticationBuffer = ByteBuffer.wrap(authenticationBytes);
            headerBuffer = joinBuffer(headerBuffer, authenticationBuffer);
        }
        if(header.getRouting()!=null)
        {
            optionBits[ROUTING_OPTION_BIT] = true;
            byte[] routingBytes = header.getRouting().getBytes();
            ByteBuffer routingByteBuffer = ByteBuffer.wrap(routingBytes);
            headerBuffer = joinBuffer(headerBuffer, routingByteBuffer);
        }
        if(header.getForwarding()!=null)
        {
            optionBits[FORWARDING_OPTION_BIT] = true;
            ByteBuffer forwardingByteBuffer = ByteBuffer.allocate(FORWARDING_BYTE_LENGTH+1); //+1 for the length byte
            forwardingByteBuffer.put((byte) FORWARDING_BYTE_LENGTH);
            forwardingByteBuffer.put(ByteUtil.convertIpAddressToBytes(header.getForwarding().getAddress()));
            byte[] portBytes = ByteUtil.unsignedShortToBytes(header.getForwarding().getPort());
            forwardingByteBuffer.put(portBytes);
            forwardingByteBuffer.put(header.getForwarding().getProtocol().getValue());
            forwardingByteBuffer.put((byte)header.getForwarding().getOperation().ordinal());
            headerBuffer = joinBuffer(headerBuffer, forwardingByteBuffer);
        }
        if(header.getResponseRedirection()!=null)
        {
            optionBits[RESPONSE_REDIRECTION_OPTION_BIT] = true;
            ByteBuffer responseRedirectionByteBuffer = ByteBuffer.allocate(RESPONSE_REDIRECTION_BYTE_LENGTH+1); //+1 for length byte
            responseRedirectionByteBuffer.put((byte) RESPONSE_REDIRECTION_BYTE_LENGTH);
            responseRedirectionByteBuffer.put(ByteUtil.convertIpAddressToBytes(header.getResponseRedirection().getAddress()));
            byte[] portBytes = ByteUtil.unsignedShortToBytes(header.getResponseRedirection().getPort());
            responseRedirectionByteBuffer.put(portBytes);
            headerBuffer = joinBuffer(headerBuffer, responseRedirectionByteBuffer);
        }

        byte optionByte = BitUtil.getByte(optionBits);

        ByteBuffer withOptionBuffer = ByteBuffer.allocate(1+headerBuffer.capacity());
        withOptionBuffer.put(optionByte);
        headerBuffer.position(0);
        withOptionBuffer.put(headerBuffer);
        return withOptionBuffer.array();
    }

    private ByteBuffer joinBuffer(ByteBuffer firstBuffer, ByteBuffer secondBuffer)
    {
        ByteBuffer tempFirstBuffer = firstBuffer.duplicate();
        ByteBuffer tempSecondBuffer = secondBuffer.duplicate();
        ByteBuffer newBuffer = ByteBuffer.allocate(tempFirstBuffer.capacity()+tempSecondBuffer.capacity());
        tempFirstBuffer.position(0);
        tempSecondBuffer.position(0);
        newBuffer.put(tempFirstBuffer);
        newBuffer.put(tempSecondBuffer);
        return newBuffer;
    }

    /**
     *
     * Encodes a byte array into an OptionsHeader. The format of an Options Header is :
     *
     *   Options Byte (MSBit always set)
     *   Mobile ID Length
     *   Mobile ID Byte 0
     *   ...
     *   Mobile ID Byte n
     *   Mobile ID Type Length
     *   Mobile ID Type Byte
     *   Authentication Length (=4)
     *   Authentication Byte 0
     *   ...
     *   Authentication Byte 3
     *   Routing Length (=8)
     *   Routing Byte 0
     *   ...
     *   Routing, up to Byte 7
     *   Forwarding Length (= 8)
     *   Forwarding Address (4 Bytes)
     *   Forwarding Port (2 Bytes)
     *   Forwarding Protocol (1 Byte)
     *   Forwarding Operation (1 Byte)
     *   Resp. Redirection Length (= 6)
     *   Resp. Redirection Address (4 bytes)
     *   Resp. Redirection Port (2 bytes)
     *
     * @param byteBuffer  a Big Endian ordered byteBuffer
     * @return an OptionsHeader
     */
    public OptionsHeader decode(ByteBuffer byteBuffer)
    {
        OptionsHeader header = new OptionsHeader();
 
        int pos = byteBuffer.position();
        boolean[] optionalBits = BitUtil.getBits(byteBuffer.get());

        if(!optionalBits[OPTIONAL_HEADER_BIT])
        {
            //no optional header
        	byteBuffer.position(pos);
            return null;
        }

        if(optionalBits[MOBILE_ID_OPTION_BIT])
        {
            //next byte is the length of the MobileId
            byte mobileIdLength = byteBuffer.get();
            if(mobileIdLength>0)
            {
                byte[] mobileIdBytes = new byte[mobileIdLength];
                byteBuffer.get(mobileIdBytes, 0, mobileIdLength);
                String mobileId = ByteUtil.convertFromBcDToString(mobileIdBytes);
                header.setMobileId( mobileId );
            }
        }
        if(optionalBits[MOBILE_ID_TYPE_OPTION_BIT])
        {
            byteBuffer.get(); //mobileItTypeLength isn't used
            byte mobileIdType = byteBuffer.get();
            header.setMobileIdType(MobileIdType.getMobileIdType(mobileIdType));
        }
        if(optionalBits[AUTHENTICATION_WORD_OPTION_BIT])
        {
            byte authenticationWordLength = byteBuffer.get();  //should be 4 per the spec
            byte[] authenticationWord = new byte[authenticationWordLength];
            byteBuffer.get(authenticationWord, 0, authenticationWordLength);
            header.setAuthentication(new String(authenticationWord));
        }
        if(optionalBits[ROUTING_OPTION_BIT])
        {
            byte routingLength = byteBuffer.get();     //can be up to 8 per the spec
            byte[] routingWord = new byte[routingLength];
            byteBuffer.get(routingWord, 0, routingLength);
            header.setRouting(new String(routingWord));
        }
        if(optionalBits[FORWARDING_OPTION_BIT])
        {
            //The forwarding address should always be 8bytes (if present) per the spec so we're going to skip getting the length
            byteBuffer.get(); //skip the forwarding length
            byte[] addressBytes = new byte[ADDRESS_LENGTH];
            byte[] portBytes = new byte[PORT_LENGTH];
            byteBuffer.get(addressBytes, 0, ADDRESS_LENGTH);
            byteBuffer.get(portBytes, 0, PORT_LENGTH);
            byte protocol = byteBuffer.get();
            byte operation = byteBuffer.get();
            int port = ByteUtil.bytesToUnsignedShort(portBytes);

            Forwarding forwarding = new Forwarding(ByteUtil.convertBytesToIpAddress(addressBytes), port,
                    ForwardingProtocol.getForwardingProtocol(protocol), ForwardingOperationType.getForwardingOperationType(operation) );
            header.setForwarding(forwarding);
        }
        if(optionalBits[RESPONSE_REDIRECTION_OPTION_BIT])
        {
            //The response redirection should always be 6bytes (if present) per the spec so we're going to skip getting the length
            byteBuffer.get(); //skip the responseRedirection length;
            byte[] addressBytes = new byte[ADDRESS_LENGTH];
            byte[] portBytes = new byte[PORT_LENGTH];
            byteBuffer.get(addressBytes, 0, ADDRESS_LENGTH);
            byteBuffer.get(portBytes, 0, PORT_LENGTH);
            int port = ByteUtil.bytesToUnsignedShort(portBytes);
            ResponseRedirection redirection = new ResponseRedirection(ByteUtil.convertBytesToIpAddress(addressBytes), port);
            header.setResponseRedirection(redirection);
        }
        if(optionalBits[OPTIONS_EXTENSION_BIT])
        {
        	OptionsExtension optionsExtension = new OptionsExtension();
        	int length = Byte.toUnsignedInt(byteBuffer.get());
        	if(length != 1)
        		return null;//this extension bitmap supported is 1 byte
        	boolean[] extensionBits = BitUtil.getBits(byteBuffer.get());
        	for ( OptionsExtension.TYPES type : OptionsExtension.TYPES.values() ) {
        		if(extensionBits[type.ordinal()]){
        			switch (type){
        				case VIN:
        					length =  Byte.toUnsignedInt(byteBuffer.get());
        					byte[] vinBytes = new byte[length];
                            for(int i = 0;i<length;i++)
                            	vinBytes[i] = byteBuffer.get();
        					optionsExtension.setVin(new String(vinBytes));
        					break;
        				default:
                            length =  Byte.toUnsignedInt(byteBuffer.get());
                            byte[] throwThisAway = new byte[length];
                            for(int i = 0;i<length;i++)
                            	throwThisAway[i] = byteBuffer.get();
                            break;
        			}
        		}
        		
        	}
        	
        	header.setOptionsExtension(optionsExtension);
        }
        return header;
    }



}
