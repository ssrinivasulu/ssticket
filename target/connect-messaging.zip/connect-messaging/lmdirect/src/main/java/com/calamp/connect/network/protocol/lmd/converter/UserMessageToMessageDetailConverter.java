/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Event.FixStatus;
import com.calamp.connect.models.network.Network.CommState;
import com.calamp.connect.models.network.Network.Inputs;
import com.calamp.connect.models.network.Network.MessageDetail;
import com.calamp.connect.models.network.Network.UnitStatus;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;

/**
 * @author sphillips
 *
 */
@Component
public class UserMessageToMessageDetailConverter extends GenericNetworkMessageConverter<UserMessageContent, MessageDetail>
{
    private static Logger logger = LogManager.getLogger(EventReportToMessageDetailConverter.class);

    @Override
    public MessageDetail convert(UserMessageContent userMessageContent)
    {
        MessageDetail messageDetail = super.convert(userMessageContent, MessageDetail.class);

        return messageDetail;
    }

    @Override
    public UserMessageContent convert(MessageDetail messageDetail)
    {
        UserMessageContent userMessageContent = super.convert(messageDetail, UserMessageContent.class);

        return userMessageContent;
    }

    @Override
    protected MessageDetail customConvert(UserMessageContent userMessageContent, MessageDetail messageDetail)
    {
    
        if (userMessageContent.getLocationStatusInfo() != null)
        {
            messageDetail.setHdop(translateHdop(userMessageContent.getLocationStatusInfo().getHorizontalDilutionOfPrecision()));
            messageDetail.setSpeed(userMessageContent.getLocationStatusInfo().getSpeed());

            boolean hasCurrentFix = ConverterUtil.hasCurrentFix(userMessageContent.getLocationStatusInfo().getFixStatus(), messageDetail.getHdop(), messageDetail.getSatelliteCount());
            messageDetail.setFixStatus(hasCurrentFix);
            messageDetail.setTimeOfFix(userMessageContent.getLocationStatusInfo().getTimeOfFix());
            
            if (userMessageContent.getLocationStatusInfo().getCommState() != null)
            {
                com.calamp.connect.network.protocol.lmd.domain.CommState netCommState = userMessageContent.getLocationStatusInfo()
                        .getCommState();
                CommState commState = new CommState();
                commState.setAvailable(netCommState.isAvailable());
                commState.setConnected(netCommState.isConnected());
                commState.setDataService(netCommState.isDataService());
                commState.setNetworkService(netCommState.isNetworkService());
                commState.setRoaming(netCommState.isRoaming());
                commState.setThreeGNetwork(netCommState.isThreeGNetwork());
                commState.setVoiceCallIsActive(netCommState.isVoiceCallActive());
                messageDetail.setCommState(commState);
            }
            if (userMessageContent.getLocationStatusInfo().getFixStatus() != null)
            {
                com.calamp.connect.network.protocol.lmd.domain.FixStatus netFixStatus = userMessageContent.getLocationStatusInfo()
                        .getFixStatus();
                FixStatus fixStatus = new FixStatus();
                fixStatus.setDifferentiallyCorrected(netFixStatus.isDifferentiallyCorrected());
                fixStatus.setHistoric(netFixStatus.isHistoric());
                fixStatus.setInvalidFix(netFixStatus.isInvalidFix());
                fixStatus.setInvalidTime(netFixStatus.isInvalidTime());
                fixStatus.setLastKnown(netFixStatus.isLastKnown());
                fixStatus.setPredicted(netFixStatus.isPredicted());
                fixStatus.setTwoDFix(netFixStatus.is2DFix());
                messageDetail.setGpsFixStatus(fixStatus);
            }
            if (userMessageContent.getLocationStatusInfo().getUnitStatus() != null)
            {
                UnitStatus unitStatus = new UnitStatus();
                com.calamp.connect.network.protocol.lmd.domain.UnitStatus netUnitStatus = userMessageContent.getLocationStatusInfo()
                        .getUnitStatus();
                unitStatus.setGpsAntennaStatus(netUnitStatus.isGPSAntennaOkay());
                unitStatus.setGpsExceptionReported(netUnitStatus.isGPSExceptionReported());
                unitStatus.setGpsReceiverSelfTest(netUnitStatus.isGPSReceiverSelfTestOkay());
                unitStatus.setGpsReceiverTracking(netUnitStatus.isGPSReceiverTracking());
                unitStatus.setMemoryTest(netUnitStatus.isMemoryTestOkay());
                unitStatus.setModemMinTest(netUnitStatus.isModemMINTestOkay());
                messageDetail.setUnitStatus(unitStatus);
            }
            if (userMessageContent.getLocationStatusInfo().getInputs() != null)
            {
                Inputs inputs = new Inputs();
                com.calamp.connect.network.protocol.lmd.domain.Inputs netInputs = userMessageContent.getLocationStatusInfo().getInputs();
                inputs.setIgnition(netInputs.isIgnitionOn());
                inputs.setInput1(netInputs.isInput1On());
                inputs.setInput2(netInputs.isInput2On());
                inputs.setInput3(netInputs.isInput3On());
                inputs.setInput4(netInputs.isInput4On());
                inputs.setInput5(netInputs.isInput5On());
                inputs.setInput6(netInputs.isInput6On());
                inputs.setInput7(netInputs.isInput7On());

                String binaryInputString = Integer.toBinaryString(Byte.toUnsignedInt(userMessageContent.getLocationStatusInfo().getInputs().getByte()));
                StringBuilder binaryInputStringBuilder = new StringBuilder(binaryInputString);
                while (binaryInputStringBuilder.length() < 8)
                {
                    binaryInputStringBuilder.insert(0, "0");
                }
                inputs.setValue(binaryInputStringBuilder.reverse().toString());

                messageDetail.setInputs(inputs);
            }
            messageDetail.setRssi(userMessageContent.getLocationStatusInfo().getRssi());// The backing bits in Inputs are in reverse order;
        }
        

        return messageDetail;
    }

    @Override
    protected UserMessageContent customConvert(MessageDetail messageDetail, UserMessageContent userMessageContent)
    {

        return userMessageContent;
    }

 

    public static double translateHdop(int original)
    {
        Double hdop = Double.valueOf(original);
        hdop = hdop / 10.0d;
        return hdop.doubleValue();
    }
}


