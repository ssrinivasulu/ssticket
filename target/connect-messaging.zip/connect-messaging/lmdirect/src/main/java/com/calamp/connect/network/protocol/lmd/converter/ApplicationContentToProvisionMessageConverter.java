/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network.ProvisionMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;

import ma.glasnost.orika.MapperFacade;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class ApplicationContentToProvisionMessageConverter extends GenericNetworkMessageConverter<ApplicationMessageContent, ProvisionMessage> {

	private static Logger logger = LogManager.getLogger(ApplicationContentToProvisionMessageConverter.class);
	
	@Autowired
    private VehicleIdReportToProvisionMessageConverter vehicleIdReportMessageConverter;
	
	@Override
	public ProvisionMessage convert(ApplicationMessageContent applicationMessageContent) {
		ProvisionMessage provisionMessage = super.convert(applicationMessageContent, ProvisionMessage.class);

        return provisionMessage;
	}

	@Override
	public ApplicationMessageContent convert(ProvisionMessage provisionMessage) {
		ApplicationMessageContent applicationMessageContent = super.convert(provisionMessage, ApplicationMessageContent.class);
	    return applicationMessageContent;
	}

	@Override
	protected ProvisionMessage customConvert(ApplicationMessageContent applicationMessageContent, ProvisionMessage provisionMessage) {
		if(applicationMessageContent.getLocationStatusInfo() != null )
		{
			provisionMessage.setSpeed(ConverterUtil.convertCmPerSToMph(applicationMessageContent.getLocationStatusInfo().getSpeed()));
		}
		VehicleIdReport vehicleIdReport = (VehicleIdReport)applicationMessageContent.getApplicationMessageFormat();
		String vin = vehicleIdReport.getVin();
		int obdiiProtocol = (vehicleIdReport.getObdIIProtocol() != null)?vehicleIdReport.getObdIIProtocol().getIndex():vehicleIdReport.getProtocolIndex();
		provisionMessage.setVin(vin);
		provisionMessage.setObiiProtocol(obdiiProtocol);
		MapperFacade mapper = mapperFactory.getMapperFacade();
		ProvisionMessage obdprovisionMessage  = mapper.map(vehicleIdReport, ProvisionMessage.class);
		provisionMessage.setObdSupportedIndicators(obdprovisionMessage.getObdSupportedIndicators());
		provisionMessage.setObdSupportedParameters(obdprovisionMessage.getObdSupportedParameters());
		//vehicleIdReportMessageConverter.convert(vehicleIdReport);
		return provisionMessage;
	}

	@Override
	protected ApplicationMessageContent customConvert(ProvisionMessage provisionMessage, ApplicationMessageContent applicationMessageContent) {
		
		return applicationMessageContent;
	}

}
