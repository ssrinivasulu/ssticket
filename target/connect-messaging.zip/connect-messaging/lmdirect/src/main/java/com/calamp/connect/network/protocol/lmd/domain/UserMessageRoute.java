package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: Oct 19, 2010
 */
public enum UserMessageRoute
{
    HOST_PORT(0), AUX_PORT(2);
    private int value;
    private UserMessageRoute(int value)
    {
        this.value = value;
    }

    public static UserMessageRoute getUserMessageRoute(int value)
    {
        for(UserMessageRoute type : values())
        {
            if(type.value == value)
            {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown UserMessageRoute "+value);
    }
    public int getValue()
    {
        return value;
    }
}
