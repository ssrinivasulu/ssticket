package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * Created by agamulo on 5/26/15.
 */
public class DailyReportMap implements JbusMap
{

    private String dailyEngineTotalHours;
    private String dailyEngineIdleHours;
    private String dailyEngineIdleFuel;
    private String dailyEngineOilLevel;
    private String dailyEngineCoolantLevel;
    private String dailyNoxTankLevel;

    @Override
    public byte[] encode()
    {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer)
    {
        DailyReportMap map = new DailyReportMap();

        byteBuffer.get(); // Machine state
        byteBuffer.get(); // Machine state
        byteBuffer.get(); // Map Revision

        // only have 4 bytes
        map.setDailyEngineTotalHours(NetworkUtil.round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2));
        map.setDailyEngineIdleHours(NetworkUtil.round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2));
        map.setDailyEngineIdleFuel(NetworkUtil.round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .5), 1));
        map.setDailyEngineOilLevel(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * .4));
        map.setDailyEngineCoolantLevel(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * .4));
        map.setDailyNoxTankLevel(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * .4));

        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage()
    {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setDailyEngineTotalHours(dailyEngineTotalHours);
        jbusMessage.setDailyEngineIdleHours(dailyEngineIdleHours);
        jbusMessage.setDailyEngineIdleFuel(dailyEngineIdleFuel);
        jbusMessage.setDailyEngineOilLevel(dailyEngineOilLevel);
        jbusMessage.setDailyEngineCoolantLevel(dailyEngineCoolantLevel);
        jbusMessage.setDailyNoxTankLevel(dailyNoxTankLevel);
        return jbusMessage;
    }

    public String getDailyEngineTotalHours()
    {
        return dailyEngineTotalHours;
    }

    public void setDailyEngineTotalHours(String dailyEngineTotalHours)
    {
        this.dailyEngineTotalHours = dailyEngineTotalHours;
    }

    public String getDailyEngineIdleHours()
    {
        return dailyEngineIdleHours;
    }

    public void setDailyEngineIdleHours(String dailyEngineIdleHours)
    {
        this.dailyEngineIdleHours = dailyEngineIdleHours;
    }

    public String getDailyEngineIdleFuel()
    {
        return dailyEngineIdleFuel;
    }

    public void setDailyEngineIdleFuel(String dailyEngineIdleFuel)
    {
        this.dailyEngineIdleFuel = dailyEngineIdleFuel;
    }

    public String getDailyEngineOilLevel()
    {
        return dailyEngineOilLevel;
    }

    public void setDailyEngineOilLevel(String dailyEngineOilLevel)
    {
        this.dailyEngineOilLevel = dailyEngineOilLevel;
    }

    public String getDailyEngineCoolantLevel()
    {
        return dailyEngineCoolantLevel;
    }

    public void setDailyEngineCoolantLevel(String dailyEngineCoolantLevel)
    {
        this.dailyEngineCoolantLevel = dailyEngineCoolantLevel;
    }

    public String getDailyNoxTankLevel()
    {
        return dailyNoxTankLevel;
    }

    public void setDailyNoxTankLevel(String dailyNoxTankLevel)
    {
        this.dailyNoxTankLevel = dailyNoxTankLevel;
    }

}
