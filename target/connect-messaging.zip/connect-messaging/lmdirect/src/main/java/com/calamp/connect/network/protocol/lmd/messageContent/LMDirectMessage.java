package com.calamp.connect.network.protocol.lmd.messageContent;

import com.calamp.connect.network.protocol.lmd.domain.IpUdpHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;

/**
 * User: ericw
 * Date: Oct 13, 2010
 */
public class LMDirectMessage  extends MessageContent
{
    private IpUdpHeader ipUdpHeader;
    private OptionsHeader optionsHeader;
    private MessageHeader messageHeader;
    private MessageContent messageContent;
    
	private String rawDeviceHexMessage;

    public LMDirectMessage() {}
    public LMDirectMessage(LMDirectMessage messageToCopy)
    {
        IpUdpHeader newIpUdpHeader = null;
        if(messageToCopy.getIpUdpHeader()!=null)
        {
            newIpUdpHeader = new IpUdpHeader(messageToCopy.getIpUdpHeader().toByteArray());
        }

        OptionsHeader newOptions = null;
        if(messageToCopy.getOptionsHeader()!=null)
        {
            newOptions = new OptionsHeader(messageToCopy.getOptionsHeader());
        }

        MessageHeader newMessageHeader = null;
        if(messageToCopy.getMessageHeader()!=null)
        {
            newMessageHeader = new MessageHeader(messageToCopy.getMessageHeader());
        }

        setIpUdpHeader(newIpUdpHeader);
        setMessageHeader(newMessageHeader);
        setOptionsHeader(newOptions);
    }

    public OptionsHeader getOptionsHeader()
    {
        return optionsHeader;
    }

    public void setOptionsHeader(OptionsHeader optionsHeader)
    {
        this.optionsHeader = optionsHeader;
    }

    public MessageHeader getMessageHeader()
    {
        return messageHeader;
    }

    public void setMessageHeader(MessageHeader messageHeader)
    {
        this.messageHeader = messageHeader;
    }

    public MessageContent getMessageContent()
    {
        return messageContent;
    }

    public void setMessageContent(MessageContent messageContent)
    {
        this.messageContent = messageContent;
    }

    public MessageType getMessageType()
    {
        if(messageHeader!=null)
        {
            return messageHeader.getMessageType();
        }

        return null;
    }

    public int getSequenceNumber()
    {
        if(messageHeader!=null)
        {
            return messageHeader.getSequenceNumber();
        }
        return -1;
    }

    public ServiceType getServiceType()
    {
        if(messageHeader!=null)
        {
            return messageHeader.getServiceType();
        }
        return null;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LMDirectMessage that = (LMDirectMessage) o;

//        if (ipUdpHeader != null ? !ipUdpHeader.equals(that.ipUdpHeader) : that.ipUdpHeader != null) return false;
        if (messageContent != null ? !messageContent.equals(that.messageContent) : that.messageContent != null)
            return false;
        if (messageHeader != null ? !messageHeader.equals(that.messageHeader) : that.messageHeader != null)
            return false;
        if (optionsHeader != null ? !optionsHeader.equals(that.optionsHeader) : that.optionsHeader != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = ipUdpHeader != null ? ipUdpHeader.hashCode() : 0;
        result = 31 * result + (optionsHeader != null ? optionsHeader.hashCode() : 0);
        result = 31 * result + (messageHeader != null ? messageHeader.hashCode() : 0);
        result = 31 * result + (messageContent != null ? messageContent.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "LMDirectMessage{" +
                "ipUdpHeader=" + ipUdpHeader +
                ", optionsHeader=" + optionsHeader +
                ", messageHeader=" + messageHeader +
                ", messageContent=" + messageContent +
                '}';
    }

    public IpUdpHeader getIpUdpHeader()
    {
        return ipUdpHeader;
    }

    public void setIpUdpHeader(IpUdpHeader ipUdpHeader)
    {
        this.ipUdpHeader = ipUdpHeader;
    }
	
    public String getRawDeviceHexMessage() {
		return rawDeviceHexMessage;
	}
	
    public void setRawDeviceHexMessage(String rawDeviceHexMessage) {
		this.rawDeviceHexMessage = rawDeviceHexMessage;
	}
    
}
