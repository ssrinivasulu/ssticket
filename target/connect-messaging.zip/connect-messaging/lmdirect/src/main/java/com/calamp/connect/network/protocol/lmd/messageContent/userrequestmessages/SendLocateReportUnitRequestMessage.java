package com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages;

import java.nio.ByteBuffer;

/**
 * User: ericw
 * Date: 4/28/14
 */
public class SendLocateReportUnitRequestMessage implements UnitRequestMessageBody {

    private int numberOfAccumulators;

    public SendLocateReportUnitRequestMessage(int numberOfAccumulators) {
        this.numberOfAccumulators = numberOfAccumulators;
    }

    public static SendLocateReportUnitRequestMessage decode(ByteBuffer byteBuffer) {
        byte numberOfAccumulators = byteBuffer.get();
        return new SendLocateReportUnitRequestMessage(numberOfAccumulators);
    }

    @Override
    public byte[] encode() {
        return new byte[]{(byte)numberOfAccumulators,0,0,0,0,0,0};
    }

    public int getNumberOfAccumulators() {
        return numberOfAccumulators;
    }

    @Override
    public String toString() {
        return "SendLocateReportUnitRequestMessage{" +
                "numberOfAccumulators=" + numberOfAccumulators +
                '}';
    }

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SendLocateReportUnitRequestMessage that = (SendLocateReportUnitRequestMessage) o;

        if (numberOfAccumulators != that.numberOfAccumulators) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return numberOfAccumulators;
    }
}
