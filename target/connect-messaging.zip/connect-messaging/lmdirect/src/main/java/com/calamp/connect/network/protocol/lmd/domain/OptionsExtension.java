package com.calamp.connect.network.protocol.lmd.domain;

public class OptionsExtension {
	public enum TYPES {
    
    	
    	UNKNOWN7,
    	UNKNOWN6,
    	MAC,
    	LMDirectRouting,
    	LMDirectCompression,
    	EncryptionService,
    	VIN,
    	ESN
    }
	private String vin;
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	
	
}
