package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;

/**
 * User: ericw
 * Date: Oct 27, 2010
 */
public class OptionsHeaderBuilder
{
    private OptionsHeader optionsHeader;

    private OptionsHeaderBuilder(OptionsHeader optionsHeader)
    {
        this.optionsHeader = optionsHeader;
    }

    public static OptionsHeaderBuilder buildFrom(OptionsHeader header)
    {
        return new OptionsHeaderBuilder(OptionsHeaderBuilder.copyMessage(header));
    }
    public static OptionsHeaderBuilder getBuilder()
    {
        return new OptionsHeaderBuilder(new OptionsHeader());
    }

    public static OptionsHeaderBuilder getBuilderWithDefault()
    {
        OptionsHeader header = new OptionsHeader();
        header.setMobileIdType(MobileIdType.USER_DEFINED);
        header.setMobileId(1234000000l+"");
        return new OptionsHeaderBuilder(header);
    }

    public OptionsHeaderBuilder setAuthentication(String authentication)
    {
        optionsHeader.setAuthentication(authentication);
        return this;
    }

    public OptionsHeaderBuilder setMobileId(String mobileId)
    {
        optionsHeader.setMobileId(mobileId);
        return this;
    }

    public OptionsHeaderBuilder setMobileIdType(MobileIdType mobileIdType)
    {
        optionsHeader.setMobileIdType(mobileIdType);
        return this;
    }

    public OptionsHeaderBuilder setRouting(String routing)
    {
        optionsHeader.setRouting(routing);
        return this;
    }


    private static OptionsHeader copyMessage(OptionsHeader messageToCopy)
    {
        return new OptionsHeader(messageToCopy);
    }

    public OptionsHeader build()
    {
        OptionsHeader returnMessage = optionsHeader;
        optionsHeader = null;
        return returnMessage;
    }

    public void clear()
    {
        optionsHeader = null;
    }
}
