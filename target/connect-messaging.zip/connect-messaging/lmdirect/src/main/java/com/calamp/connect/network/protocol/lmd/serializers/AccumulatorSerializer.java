package com.calamp.connect.network.protocol.lmd.serializers;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.calamp.connect.services.fmi.util.ByteUtil;


/**
 * User: ericw
 * Date: Oct 19, 2010
 */
public class AccumulatorSerializer
{
    private static Logger logger = LogManager.getLogger(AccumulatorSerializer.class);
    private static final int ACCUMULATOR_BYTE_LENGTH = 4;
    private static final int ENHANCED_ACCUMULATOR_OVERHEAD = 2;
    private static final int MAXIMUM_NUMBER_OF_ACCUMULATORS = 32;

    /*
     * byte array contains the accumulator length as well as the spare byte
     */
    public static byte[] encode(List<Long> accumulators)
    {
       return encode(accumulators, true);
    }

    public static byte[] encode(List<Long> accumulators, boolean useSpareBit)
    {
        byte numberOfAccumulators = (byte)accumulators.size();
        int totalNumberOfBytes = (numberOfAccumulators *ACCUMULATOR_BYTE_LENGTH + 1); //+1 for the length
        if(useSpareBit) //add one if we're using the spare
        {
            totalNumberOfBytes += 1;
        }
        ByteBuffer byteBuffer = ByteBuffer.allocate(totalNumberOfBytes);
        byteBuffer.put(numberOfAccumulators);
        if(useSpareBit)
        {
            byteBuffer.put((byte)0); //spare byte, always 0
        }

        if(!accumulators.isEmpty())
        {
            for(Long accumulatorValue : accumulators)
            {
                byteBuffer.put( ByteUtil.unsignedIntegerToBytes(accumulatorValue));
            }
        }

        return byteBuffer.array();
    }


    /**
     * reads the length of the accumulators as well as a spare bit
     */
    public static List<Long> decode(ByteBuffer byteBuffer)
    {
         return decode(byteBuffer, true);
    }

    public static List<Long> decode(ByteBuffer byteBuffer, boolean useSpareBit)
    {

        ByteBuffer totalByteBuffer = byteBuffer;
        long invalidValue = -1L;
    	int numberOfAccumulators = byteBuffer.get();
    	if (numberOfAccumulators >= 64) {
    		numberOfAccumulators = numberOfAccumulators & 63;
    		numberOfAccumulators -= ENHANCED_ACCUMULATOR_OVERHEAD; 
    		if (useSpareBit) byteBuffer.get();
    		long accumulatorsAboveThreshold = ByteUtil.getUnsignedInteger(byteBuffer);    		
    		String binaryString = Long.toBinaryString(accumulatorsAboveThreshold);
    	    //make sure there are enough zeros;
    	    StringBuilder builder = new StringBuilder(binaryString);
    	    	while(builder.length() < 32) {
    	    		builder.insert(0, "0");
    	    }
    		
    		long accumulatorsReporting = ByteUtil.getUnsignedInteger(byteBuffer);
    		binaryString = Long.toBinaryString(accumulatorsReporting);
    		builder = new StringBuilder(binaryString);
	    	while(builder.length() < 32) {
	    		builder.insert(0, "0");
	    	}
            String accumulatorsReportingString = builder.toString();

            int lastAccumulatorReporting = MAXIMUM_NUMBER_OF_ACCUMULATORS - accumulatorsReportingString.indexOf('1');
            logger.debug(" - (" + lastAccumulatorReporting + ") Accumulators reported: " + accumulatorsReportingString);

            // TODO: only populate reported accumulators
            List<Long> accumulators = new ArrayList<Long>(lastAccumulatorReporting);

            for (int i = 0; i < lastAccumulatorReporting; i++)
            {
                // LSB
                if (accumulatorsReportingString.charAt((MAXIMUM_NUMBER_OF_ACCUMULATORS - 1) - i) == '1')
                {
                    long accumulatorValue = ByteUtil.getUnsignedInteger(byteBuffer);
                    logger.debug("ACC[" + i + "] = " + accumulatorValue);
                    accumulators.add(accumulatorValue);
                }
                else
                {
                    accumulators.add(invalidValue);
                    logger.debug("ACC[" + i + "] = null");
                }
            }
    		
    		return accumulators;
    		
    	} else {   	    	
	        if(useSpareBit)
	        {
	            byteBuffer.get();//advance past the spare bit
	        }
	        if(numberOfAccumulators<1)
	        {
	            return new ArrayList<Long>();
	        }
	
	        List<Long> accumulators = new ArrayList<Long>(numberOfAccumulators);
	        for(int i=0;i<numberOfAccumulators;i++)
	        {
	            if(byteBuffer.remaining() < 4)
	            {
	                logger.debug("Accumulator with less than 4 bytes. Total byteBuffer :"+totalByteBuffer.toString());
	                continue;
	            }
	            
                long accumulatorValue = ByteUtil.getUnsignedInteger(byteBuffer);
                if(accumulatorValue != 4294967295l)
                    accumulators.add(accumulatorValue);
                else
                    accumulators.add(invalidValue);
            }
	
	        return accumulators;
    	}
    	
    }
}
