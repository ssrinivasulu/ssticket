package com.calamp.connect.network.util;

/**
 * User: ericw Date: Nov 9, 2010
 */
public final class HeaderConstants
{
    public static final String SOURCE_ADDRESS = "SOURCE_ADDRESS";
    public static final String SOURCE_PORT = "SOURCE_PORT";
    public static final String SMART_SERVER = "SMART_SERVER";
    public static final String GATEWAY_ID = "GATEWAY_ID";
    public static final String DEVICE_URN = "DEVICE_URN";
    public static final String NULL = "Null";
    public static final String IS_ACK_NEEDED = "IS_ACK_NEEDED";
    public static final String DATA_LENGTH = "DATA_LENGTH";

    public static final String PROTOCOL = "PROTOCOL";
    public static final String CALAMP = "CALAMP";
    public static final String AVL = "AVL";
    public static final String WTPP = "WTPP";
    public static final String GVT = "GVT";
    public static final String ENFO = "ENFO";
    public static final String XIRGO = "XIRGO";
    public static final String ALL_PROTOCOLS = "ALL_PROTOCOLS";
    public static final String TRANSACTION_ID = "TXN_ID";
    public static final String UUID = "UUID";
    
    public static final String ANDROID = "ANDROID";
    public static final String IOS = "IOS";
    
    public static final String RESPONSE_PROCESSED = "RESPONSE_PROCESSED";
    public static final String TRANSPORT_MECHANISM = "TRANSPORT_MECHANISM";
}
