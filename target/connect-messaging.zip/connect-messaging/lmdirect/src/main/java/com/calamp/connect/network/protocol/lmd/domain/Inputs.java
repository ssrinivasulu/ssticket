package com.calamp.connect.network.protocol.lmd.domain;

import java.util.Arrays;

import com.calamp.connect.services.fmi.util.BitUtil;

/**
 * User: ericw Date: Oct 18, 2010
 */
public class Inputs {
	//NOTE!!!! position 0 of the backing bits is *not* bit 0, it's bit 7. element 0 is actually bit 7
    boolean[] backingBits;
	private static final int IGNITION_BIT = 7;
	private static final int INPUT_1_BIT = 6;
	private static final int INPUT_2_BIT = 5;
	private static final int INPUT_3_BIT = 4;
	private static final int INPUT_4_BIT = 3;
	private static final int INPUT_5_BIT = 2;
    private static final int INPUT_6_BIT = 1;
    private static final int INPUT_7_BIT = 0;

	public Inputs(byte inputInformation) {
		this(BitUtil.getBits(inputInformation));
	}

	public Inputs(boolean[] inputInformation) {
		backingBits = inputInformation;
	}

	public Inputs(Inputs inputs) {
		this(inputs.backingBits);
	}

	public byte getByte() {
		return BitUtil.getByte(backingBits);
	}

	public boolean isIgnitionOn() {
		return backingBits[IGNITION_BIT];
	}

	public boolean isInput1On() {
		return backingBits[INPUT_1_BIT];
	}

	public boolean isInput2On() {
		return backingBits[INPUT_2_BIT];
	}

	public boolean isInput3On() {
		return backingBits[INPUT_3_BIT];
	}

	public boolean isInput4On() {
		return backingBits[INPUT_4_BIT];
	}

	public boolean isInput5On() {
		return backingBits[INPUT_5_BIT];
	}

    public boolean isInput6On() {
        return backingBits[INPUT_6_BIT];
    }

    public boolean isInput7On() {
        return backingBits[INPUT_7_BIT];
    }

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		Inputs inputs = (Inputs) o;

		if (!Arrays.equals(backingBits, inputs.backingBits))
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		return backingBits != null ? Arrays.hashCode(backingBits) : 0;
	}

	@Override
	public String toString() {
		return "Inputs{" + "backingBits=" + Arrays.toString(backingBits) + '}';
	}
}
