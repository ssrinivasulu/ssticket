package com.calamp.connect.network.protocol.lmd.domain;


import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * ApplicationMessage Types are represented in the LMD Spec as an ushort
 *
 * User: ericw
 * Date: 4/26/11
 */
public enum ApplicationMessageType
{
    MESSAGE_STATUS_REPORT(113), VEHICLE_REPORT_ID(131), DTC_REPORT(132), JBUS_REPORT(130), OTA_DOWNLOAD(107), MOTION_LOGS(122), UNKNOWN(0);

    private int value;

    private ApplicationMessageType(int value)
    {
        this.value = value;
    }

    public byte[] toBytes()
    {
        return ByteUtil.unsignedShortToBytes(value);
    }

    public int getValue()
    {
        return value;
    }

    public static ApplicationMessageType getApplicationMessageType(int value)
    {
        for(ApplicationMessageType type : values())
        {
            if(type.value==value)
            {
                return type;
            }
        }
        return ApplicationMessageType.UNKNOWN;
        //throw new IllegalArgumentException("Unknown ApplicationMessageType "+value);
    }
}
