package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Nov 8, 2010
 */
public class UserDataMessageBuilder  extends LMDirectMessageBuilder
{

    private UserMessageContent messageContent;
    private LocationStatusInfoBuilder locationStatusInfoBuilder;

    private UserDataMessageBuilder(UserMessageContent messageContent, LMDirectMessageBuilder builder, LocationStatusInfoBuilder infoBuilder)
    {
        super(builder);
        locationStatusInfoBuilder = infoBuilder;
        this.messageContent = messageContent;
    }

    /**
     * Builds a Default Ack_Nak message
     * @return Message Builder
     */
    public static UserDataMessageBuilder getBuilderWithDefault()
    {
        LMDirectMessageBuilder lmDirectMessageBuilder = LMDirectMessageBuilder.getBuilderWithDefault()
                    .setMessageType(MessageType.USER_DATA)
                    .setServiceType(ServiceType.RESPONSE_TO_ACKNOWLEDGED_REQUEST);
        UserMessageContent content = new UserMessageContent();
        content.setUserMessage(HexUtil.getHexByteArray("hello world"));
        content.setUserMessageId(1);
        content.setUserMessageRoute(UserMessageRoute.AUX_PORT);

        LocationStatusInfoBuilder infoBuilder = LocationStatusInfoBuilder.getBuilderWithDefault();

        return new UserDataMessageBuilder(content, lmDirectMessageBuilder, infoBuilder);
    }

    public UserDataMessageBuilder setUserMessageId(int id)
    {
        messageContent.setUserMessageId(id);
        return this;
    }
    public UserDataMessageBuilder setUserMessageRoute(UserMessageRoute route)
    {
        messageContent.setUserMessageRoute(route);
        return this;
    }
    public UserDataMessageBuilder setUserMessage(byte[] userMessage)
    {
        messageContent.setUserMessage(userMessage);
        return this;
    }
    public UserDataMessageBuilder setLocationStatusInfoBuilder(LocationStatusInfoBuilder infoBuilder)
    {
        this.locationStatusInfoBuilder = infoBuilder;
        return this;
    }

    public static UserDataMessageBuilder getBuilder()
    {
        LMDirectMessageBuilder lmDirectMessageBuilder = LMDirectMessageBuilder.getBuilder();
        lmDirectMessageBuilder.setMessageType(MessageType.USER_DATA);
        LocationStatusInfoBuilder infoBuilder = LocationStatusInfoBuilder.getBuilder();

        return new UserDataMessageBuilder(new UserMessageContent(),lmDirectMessageBuilder, infoBuilder);
    }

      public LMDirectMessage toLMDirectMessage()
    {

        LocationStatusInfo builtLocationStatusInfo = null;
        if(locationStatusInfoBuilder!=null)
             builtLocationStatusInfo = locationStatusInfoBuilder.build();

        messageContent.setLocationStatusInfo(builtLocationStatusInfo);

        LMDirectMessage partialMessage = super.toLMDirectMessage();
        partialMessage.setMessageContent(messageContent);

        messageContent = null;
        super.clear();
        if(locationStatusInfoBuilder!=null)
            locationStatusInfoBuilder.clear();
        return partialMessage;
    }
}
