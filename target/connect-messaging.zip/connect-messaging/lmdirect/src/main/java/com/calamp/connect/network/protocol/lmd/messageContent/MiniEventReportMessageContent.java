package com.calamp.connect.network.protocol.lmd.messageContent;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.calamp.connect.network.protocol.lmd.domain.CommGpsStatus;
import com.calamp.connect.network.protocol.lmd.domain.FixStatusAndSatellites;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class MiniEventReportMessageContent extends MessageContent
{
    private Date updateTime;
    private double latitude;
    private double longitude;
    private int heading;
    private int speed;//in km/hour
    private FixStatusAndSatellites fixStatusAndSatellites;
    private CommGpsStatus commGpsStatus;
    private Inputs inputs;
    private int eventCode;
    private List<Long> accumulatorValues = new ArrayList<Long>();
 
    public Date getUpdateTime()
    {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime)
    {
        this.updateTime = updateTime;
    }

    public double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(double latitude)
    {
        this.latitude = latitude;
    }

    public double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(double longitude)
    {
        this.longitude = longitude;
    }

    public int getHeading()
    {
        return heading;
    }

    public void setHeading(int heading)
    {
        this.heading = heading;
    }

    public int getSpeed()
    {
        return speed;
    }

    public void setSpeed(int speed)
    {
        this.speed = speed;
    }

    public FixStatusAndSatellites getFixStatusAndSatellites()
    {
        return fixStatusAndSatellites;
    }

    public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites)
    {
        this.fixStatusAndSatellites = fixStatusAndSatellites;
    }

    public CommGpsStatus getCommGpsStatus()
    {
        return commGpsStatus;
    }

    public void setCommGpsStatus(CommGpsStatus commGpsStatus)
    {
        this.commGpsStatus = commGpsStatus;
    }

    public Inputs getInputs()
    {
        return inputs;
    }

    public void setInputs(Inputs inputs)
    {
        this.inputs = inputs;
    }

    public int getEventCode()
    {
        return eventCode;
    }

    public void setEventCode(int eventCode)
    {
        this.eventCode = eventCode;
    }

    public List<Long> getAccumulatorValues()
    {
        return accumulatorValues;
    }

    public void setAccumulatorValues(List<Long> accumulatorValues)
    {
        this.accumulatorValues = accumulatorValues;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MiniEventReportMessageContent that = (MiniEventReportMessageContent) o;

        if (eventCode != that.eventCode) return false;
        if (heading != that.heading) return false;
        if (Double.compare(that.latitude, latitude) != 0) return false;
        if (Double.compare(that.longitude, longitude) != 0) return false;
        if (speed != that.speed) return false;
        if (accumulatorValues != null ? !accumulatorValues.equals(that.accumulatorValues) : that.accumulatorValues != null)
            return false;
        if (commGpsStatus != null ? !commGpsStatus.equals(that.commGpsStatus) : that.commGpsStatus != null)
            return false;
        if (fixStatusAndSatellites != null ? !fixStatusAndSatellites.equals(that.fixStatusAndSatellites) : that.fixStatusAndSatellites != null) return false;
        if (inputs != null ? !inputs.equals(that.inputs) : that.inputs != null) return false;
        if (updateTime != null ? !updateTime.equals(that.updateTime) : that.updateTime != null) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result;
        long temp;
        result = updateTime != null ? updateTime.hashCode() : 0;
        temp = latitude != +0.0d ? Double.doubleToLongBits(latitude) : 0L;
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        temp = longitude != +0.0d ? Double.doubleToLongBits(longitude) : 0L;
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + heading;
        result = 31 * result + speed;
        result = 31 * result + (fixStatusAndSatellites != null ? fixStatusAndSatellites.hashCode() : 0);
        result = 31 * result + (commGpsStatus != null ? commGpsStatus.hashCode() : 0);
        result = 31 * result + (inputs != null ? inputs.hashCode() : 0);
        result = 31 * result + eventCode;
        result = 31 * result + (accumulatorValues != null ? accumulatorValues.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "MiniEventReportMessageContent{" +
                "updateTime=" + updateTime +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", heading=" + heading +
                ", speed=" + speed +
                ", fixStatusAndSatellites=" + fixStatusAndSatellites +
                ", commGpsStatus=" + commGpsStatus +
                ", inputs=" + inputs +
                ", eventCode=" + eventCode +
                ", accumulatorValues=" + accumulatorValues +
                '}';
    }
}
