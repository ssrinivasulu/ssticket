package com.calamp.connect.network.protocol.lmd.serializers;

import java.math.BigDecimal;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.network.protocol.lmd.converter.LMDirectToNetworkMessageConverter;
import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.network.protocol.lmd.domain.builders.AckMessageBuilder;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 * User: ericw
 * Date: Oct 25, 2010
 */
@Component
public class MessageDetailSerializer
{
    private static Logger logger = LogManager.getLogger(MessageDetailSerializer.class);
    private static final String APP_VERSION = "000"; //TODO put this into a property field

    @Autowired
    private static LMDirectToNetworkMessageConverter lmDirectToNetworkMesageConverter;
    
    
    public static LMDirectMessage createLMDirectAckUsingMessageHeaders(Message<Network.NetworkMessage> message)
    {
        Network.NetworkMessage ackMessage = message.getPayload();
        MessageHeaders headers = message.getHeaders();
        MessageType messageType = (MessageType)headers.get("ORIGINAL_MESSAGE_TYPE");
        if(messageType==null)
        {
            throw new IllegalArgumentException("The header needs to have a value for ORIGINAL_MESSAGE_TYPE");
        }
        if(ackMessage.getType()!=Network.NetworkMessage.NetworkMessageType.ACK_MESSAGE)
        {
            throw new IllegalArgumentException("This method needs to have an Ack Message");
        }

        return createLMDirectAckMessage(ackMessage, messageType);
    }

    public static LMDirectMessage createLMDirectAckMessage(Network.NetworkMessage ackMessage, MessageType originalMessageType)
    {
        Network.AckMessage ackMessageContent = ackMessage.getAckMessage();

        LMDirectMessage lmDirectMessage = AckMessageBuilder.getBuilder()
                .setAckToMessageType(originalMessageType)
                .setAckType( AckType.getAckType(ackMessageContent.getAckTypeCode()) )
                .setAppVersion(APP_VERSION)
                .setMessageType(MessageType.ACK_NAK)
                .setServiceType(ServiceType.RESPONSE_TO_ACKNOWLEDGED_REQUEST)
                .setMobileId(ackMessage.getExternalDeviceId())
                //TODO This is wrong, don't hardcode this to the ESN
                .setMobileIdType(MobileIdType.ESN)
                .setSequenceNumber(ackMessage.getSequenceId())
                .toLMDirectMessage();

        return lmDirectMessage;
    }
    /*
    public static LMDirectMessage encode(Network.NetworkMessage networkMessage)
    {
        LMDirectMessage lmDirectMessage = null;
        if(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE == networkMessage.getType())
        {
            lmDirectMessage = EventReportMessageBuilder.getBuilder()
                    .setEventCode(networkMessage.getMessageDetail().getEventCode())
                    .setMessageType(MessageType.EVENT_REPORT)
                    .setMobileId(networkMessage.hasExternalDeviceId() ? networkMessage.getExternalDeviceId() : networkMessage.getDeviceId()+"")
                    .setSequenceNumber(networkMessage.getSequenceId())
                    //TODO this is wrong, don't hardcode this to ESN
                    .setMobileIdType(MobileIdType.ESN)
                    .toLMDirectMessage();
        }
        else if(Network.NetworkMessage.NetworkMessageType.PND_MESSAGE == networkMessage.getType())
        {
            lmDirectMessage = LMDirectMessageBuilder.getBuilder()
                    .setMessageType(MessageType.USER_DATA)
                    .setMobileId(networkMessage.hasExternalDeviceId() ? networkMessage.getExternalDeviceId() : networkMessage.getDeviceId()+"")
                    .setSequenceNumber(networkMessage.getSequenceId())
                    //TODO this is wrong, don't hardcode this to ESN
                    .setMobileIdType(MobileIdType.ESN)
                    .toLMDirectMessage();
        }
        else if(Network.NetworkMessage.NetworkMessageType.PROVISION_MESSAGE == networkMessage.getType())
        {
        	lmDirectMessage = ApplicationMessageBuilder.getBuilder()
                    .setMessageType(MessageType.APPLICATION_DATA)
                    //TODO this is wrong, don't hardcode this to ESN
                    .toLMDirectMessage();
        }
        else if(Network.NetworkMessage.NetworkMessageType.ACK_MESSAGE == networkMessage.getType())
        {
            createLMDirectAckMessage(networkMessage, null);
        }
        else if(Network.NetworkMessage.NetworkMessageType.UNKNOWN_MESSAGE == networkMessage.getType())
        {
            //TODO how do we handle these?  we don't, just for testing reasons
        }

        return lmDirectMessage;

    }*/

    @Transformer
    public static Network.NetworkMessage decode(LMDirectMessage message)
    {
        logger.debug("In the MessageDetailSerializer:decode ");
        return lmDirectToNetworkMesageConverter.convert(message);
        //return networkMessage.build();
    }
    
    public static int convertCmPerSToMph(long cmPerS)
    {
        return new BigDecimal(cmPerS * 0.02237).setScale(0, BigDecimal.ROUND_HALF_UP).intValue();
    }
    
    public static double translateHdop(int original) {
        Double hdop = Double.valueOf(original);
        hdop = hdop / 10.0d;
        return hdop.doubleValue();
    }
 
}
