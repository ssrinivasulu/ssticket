package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import com.calamp.connect.network.protocol.lmd.domain.OBDIIProtocol;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.nio.ByteBuffer;

/**
 * User: ericw
 * Date: 5/24/11
 */
public class VehicleIdReport extends ApplicationMessageFormat
{
    private String vin;
    private OBDIIProtocol obdIIProtocol;
    private ObdSupportedParameters supportedParameters;
    private ObdSupportedIndicators supportedIndicators;
    private static final Log logger = LogFactory.getLog(VehicleIdReport.class);
    private static final int VIN_TERMINATION_BYTE= 0;
    private int protocolIndex;

    public VehicleIdReport(String vin, OBDIIProtocol protocol)
    {
        this.vin = vin;
        this.obdIIProtocol = protocol;
    }

    @Override
    public byte[] encode()
    {
        //throw new NotImplementedException();
    	ByteBuffer byteBuffer;
    	
    	StringBuffer buffer = new StringBuffer();
    	buffer.append("VIN:");
    	
    	if ( vin != null ) {
    		//byteBuffer = ByteBuffer.allocate(4+vin.length());
    		buffer = buffer.append(vin);
    	}
    	
    	buffer.append(',');
    	
    	buffer.append("PROTO:"+obdIIProtocol.ordinal());
    	
        return buffer.toString().getBytes();
       
    }

    public static ApplicationMessageFormat decode(ByteBuffer byteBuffer)
    {
        if(logger.isDebugEnabled())
        {
            logger.debug(HexUtil.convertToHexString(byteBuffer.array()));
        }
        //the format of this is pretty wonky, the 17 digit VIN will only be in the message if it exists,
        //otherwise you'll see something like VIN:,PROTO:0
        byteBuffer.position(byteBuffer.position()+4); //skip the VIN: part of the message
        StringBuilder vinBuilder = new StringBuilder();
        byte msgChar = 0;
        while((msgChar = byteBuffer.get()) != VIN_TERMINATION_BYTE) //0 = null
        {
            vinBuilder.append((char)msgChar);
        }
        String vinMessage = vinBuilder.toString();
        byteBuffer.position(byteBuffer.position()+6); //skip PROTO: part of the message
        String rawProtocol = new String(new byte[] {byteBuffer.get()});
        int protocol = (rawProtocol!=null && !(rawProtocol.equals("")))?Integer.parseInt(rawProtocol):0; //need to convert from ascii to integers
        byteBuffer.position(byteBuffer.position()+8); //skip null terminator for proto + "PARAMS:" part of message
        StringBuilder paramBuilder = new StringBuilder();
        while((msgChar = byteBuffer.get()) != VIN_TERMINATION_BYTE) //0 = null
        {
            paramBuilder.append((char)msgChar);
        }
        byteBuffer.position(byteBuffer.position()+8); //"INDCTRS:" part of message

        StringBuilder builder = new StringBuilder();
        while((msgChar = byteBuffer.get()) != VIN_TERMINATION_BYTE) //0 = null, also skip indicators index
        {
//            msgChar = byteBuffer.get();//skip indicator index
            msgChar = byteBuffer.get();//skip '('
            while((msgChar = byteBuffer.get()) != 41) //41 = ')'
            {
                builder.append((char)msgChar);
            }
            msgChar = byteBuffer.get(); //skip the ',' after the ')'
            if(msgChar == VIN_TERMINATION_BYTE)
                break;
        }
        VehicleIdReport report = new VehicleIdReport(vinMessage, OBDIIProtocol.getValue(protocol));
        report.setSupportedParameters(paramBuilder.toString());
        report.setSupportedIndicators(builder.toString());
        report.setProtocolIndex(protocol);
        return report;
    }

    public void setSupportedParameters(String parametersString)
    {
        supportedParameters = new ObdSupportedParameters(parametersString);
    }

    public void setSupportedIndicators(String indicatorsString)
    {
        this.supportedIndicators = new ObdSupportedIndicators(indicatorsString);
    }

    public String getVin() {
		return vin;
	}

	public void setVin(String vin) {
		this.vin = vin;
	}

    public int getProtocolIndex()
    {
        return protocolIndex;
    }

    public void setProtocolIndex(int protocolIndex)
    {
        this.protocolIndex = protocolIndex;
    }

    public OBDIIProtocol getObdIIProtocol() {
		return obdIIProtocol;
	}

	public void setObdIIProtocol(OBDIIProtocol obdIIProtocol) {
		this.obdIIProtocol = obdIIProtocol;
	}

    public ObdSupportedIndicators getSupportedIndicators()
    {
        return supportedIndicators;
    }

    public ObdSupportedParameters getSupportedParameters()
    {
        return supportedParameters;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VehicleIdReport that = (VehicleIdReport) o;

        if (obdIIProtocol != that.obdIIProtocol) return false;
        if (vin != null ? !vin.equals(that.vin) : that.vin != null) return false;

        return true;
    }

	@Override
    public int hashCode()
    {
        int result = vin != null ? vin.hashCode() : 0;
        result = 31 * result + (obdIIProtocol != null ? obdIIProtocol.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "VehicleIdReport{" +
                "vin='" + vin + '\'' +
                ", obdIIProtocol=" + obdIIProtocol +
                ", supportedParameters=" + supportedParameters +
                '}';
    }
}
