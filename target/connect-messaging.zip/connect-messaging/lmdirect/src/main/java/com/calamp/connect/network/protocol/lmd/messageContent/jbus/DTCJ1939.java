package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * Created by agamulo on 12/2/14.
 */
public class DTCJ1939 implements JbusMap {

    public enum DTCJ1939Fields{SPN, FMI, OC};

    private List<HashMap> DTCCodes = new ArrayList<HashMap>();

    @Override
    public byte[] encode() {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
        DTCJ1939 map = new DTCJ1939();
        byteBuffer.get(); //Protocol
        byteBuffer.get(); //Source Address
        byteBuffer.get(); //Lamp Status
        short dtcCount = (short) (byteBuffer.get() & 0xff); // Number of DTCs in message
        byteBuffer.get(); //Modified Count?

        //Loop through to collect DTCs
        while (dtcCount-- > 0){
            /**
             * The next 3 bytes contain spn, fmi and OC values, but
             * out of the 24 bits(3 bytes) 19 bits is the SPN, 5bits FMI
             * 1bit CM should be 0 in order to carry out the SPN conversion
             * rest 7 bits is the OC
             */
            boolean[] spn = BitUtil.getBits(byteBuffer.get());
            spn = concat(BitUtil.getBits(byteBuffer.get()), spn);
            boolean[] spn_fmi = BitUtil.getBits(byteBuffer.get());
            spn = concat(Arrays.copyOfRange(spn_fmi, 0, 3), spn); //19 bits of spn in to boolean array
            boolean[] fmi = Arrays.copyOfRange(spn_fmi, 3, 8); // 5 bits of fmi
            int ocValue = ByteUtil.signedByteToUnsignedByte(byteBuffer.get()); //if CM is 1 the min is 128 for the next 8 bits
            if (ocValue < 128) {
                HashMap<DTCJ1939Fields,Object> DTCCode = new HashMap();
                DTCCode.put(DTCJ1939Fields.OC, ocValue);
                DTCCode.put(DTCJ1939Fields.SPN, BitUtil.bin2Dec(spn));
                DTCCode.put(DTCJ1939Fields.FMI, BitUtil.bin2Dec(fmi));
                map.addDtcCode(DTCCode);
            }
        }

        return map;
    }

    public void addDtcCode(HashMap dtcCode)
    {
        DTCCodes.add(dtcCode);
    }

    public List<HashMap> getDTCCodes() {
        return DTCCodes;
    }

    public void setDTCCodes(List<HashMap> DTCCodes) {
        this.DTCCodes = DTCCodes;
    }


    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setJ1939DTCCodes(getDTCCodes());
        return jbusMessage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DTCJ1939 that = (DTCJ1939) o;

        if (DTCCodes != null ? !DTCCodes.equals(that.DTCCodes) : that.DTCCodes != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = DTCCodes != null ? DTCCodes.hashCode() : 0;
        return result;
    }

    @Override
    public String toString() {
        return "DTCJ1939{" +
                "DTCCodes=" + DTCCodes +
                '}';
    }

    public static boolean[] concat(boolean[] a, boolean[] b){
        int length = a.length + b.length;
        boolean[] result = new boolean[length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }
}
