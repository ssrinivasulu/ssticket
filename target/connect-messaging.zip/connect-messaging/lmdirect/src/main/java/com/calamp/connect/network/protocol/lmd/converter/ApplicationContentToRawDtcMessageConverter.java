/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network.CommState;
import com.calamp.connect.models.network.Network.Inputs;
import com.calamp.connect.models.network.Network.LocationInformation;
import com.calamp.connect.models.network.Network.RawDtcMessage;
import com.calamp.connect.models.network.Network.UnitStatus;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.DtcReport;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class ApplicationContentToRawDtcMessageConverter extends GenericNetworkMessageConverter<ApplicationMessageContent, RawDtcMessage>
{

    @Override
    public RawDtcMessage convert(ApplicationMessageContent applicationMessageContent)
    {
        RawDtcMessage rawDtcMessage = super.convert(applicationMessageContent, RawDtcMessage.class);

        return rawDtcMessage;
    }

    @Override
    public ApplicationMessageContent convert(RawDtcMessage rawDtcMessage)
    {
        ApplicationMessageContent applicationMessageContent = super.convert(rawDtcMessage, ApplicationMessageContent.class);
        return applicationMessageContent;
    }

    @Override
    protected RawDtcMessage customConvert(ApplicationMessageContent applicationMessageContent, RawDtcMessage rawDtcMessage)
    {

        DtcReport dtcReport = (DtcReport) applicationMessageContent.getApplicationMessageFormat();
        rawDtcMessage.setDtcCodes(dtcReport.getDtcCodes());
        LocationStatusInfo locationStatusInfo = applicationMessageContent.getLocationStatusInfo();
        if (locationStatusInfo != null)
        {
            LocationInformation locationInformation = new LocationInformation();
            locationInformation.setAltitude(locationStatusInfo.getAltitude());
            locationInformation.setCarrier(locationStatusInfo.getCarrier());

            boolean hasCurrentFix = hasCurrentFix(locationStatusInfo.getFixStatus(), locationStatusInfo.getLatitude(),
                    locationStatusInfo.getLongitude());

//            locationInformation.setFixStatus(hasCurrentFix);
            locationInformation.setHdop(locationStatusInfo.getHorizontalDilutionOfPrecision());
            locationInformation.setHeading(locationStatusInfo.getHeading());
            locationInformation.setLatitude(locationStatusInfo.getLatitude());
            locationInformation.setLongitude(locationStatusInfo.getLongitude());
            locationInformation.setRssi(locationStatusInfo.getRssi());
            locationInformation.setSatelliteCount(locationStatusInfo.getNumberOfSatellites());
            locationInformation.setSpeed(locationStatusInfo.getSpeed());
            if (locationStatusInfo.getCommState() != null)
            {
                CommState commState = new CommState();
                commState.setAvailable(locationStatusInfo.getCommState().isAvailable());
                commState.setConnected(locationStatusInfo.getCommState().isConnected());
                commState.setDataService(locationStatusInfo.getCommState().isDataService());
                commState.setNetworkService(locationStatusInfo.getCommState().isNetworkService());
                commState.setRoaming(locationStatusInfo.getCommState().isRoaming());
                commState.setThreeGNetwork(locationStatusInfo.getCommState().isThreeGNetwork());
                commState.setVoiceCallIsActive(locationStatusInfo.getCommState().isVoiceCallActive());
                locationInformation.setCommState(commState);
            }
            if (locationStatusInfo.getFixStatus() != null)
            {
                com.calamp.connect.models.network.Event.FixStatus fixStatus = new com.calamp.connect.models.network.Event.FixStatus();
                fixStatus.setDifferentiallyCorrected(locationStatusInfo.getFixStatus().isDifferentiallyCorrected());
                fixStatus.setHistoric(locationStatusInfo.getFixStatus().isHistoric());
                fixStatus.setInvalidFix(locationStatusInfo.getFixStatus().isInvalidFix());
                fixStatus.setInvalidTime(locationStatusInfo.getFixStatus().isInvalidTime());
                fixStatus.setLastKnown(locationStatusInfo.getFixStatus().isLastKnown());
                fixStatus.setPredicted(locationStatusInfo.getFixStatus().isPredicted());
                fixStatus.setTwoDFix(locationStatusInfo.getFixStatus().is2DFix());
                locationInformation.setFixStatus(fixStatus);
            }
            if (locationStatusInfo.getUnitStatus() != null)
            {
                UnitStatus unitStatus = new UnitStatus();

                unitStatus.setGpsAntennaStatus(locationStatusInfo.getUnitStatus().isGPSAntennaOkay());
                unitStatus.setGpsExceptionReported(locationStatusInfo.getUnitStatus().isGPSExceptionReported());
                unitStatus.setGpsReceiverSelfTest(locationStatusInfo.getUnitStatus().isGPSReceiverSelfTestOkay());
                unitStatus.setGpsReceiverTracking(locationStatusInfo.getUnitStatus().isGPSReceiverTracking());
                unitStatus.setMemoryTest(locationStatusInfo.getUnitStatus().isMemoryTestOkay());
                unitStatus.setModemMinTest(locationStatusInfo.getUnitStatus().isModemMINTestOkay());
                locationInformation.setUnitStatus(unitStatus);
            }
            if (locationStatusInfo.getInputs() != null)
            {
                Inputs inputs = new Inputs();
                inputs.setIgnition(locationStatusInfo.getInputs().isIgnitionOn());
                inputs.setInput1(locationStatusInfo.getInputs().isInput1On());
                inputs.setInput2(locationStatusInfo.getInputs().isInput2On());
                inputs.setInput3(locationStatusInfo.getInputs().isInput3On());
                inputs.setInput4(locationStatusInfo.getInputs().isInput4On());
                inputs.setInput5(locationStatusInfo.getInputs().isInput5On());
                inputs.setInput6(locationStatusInfo.getInputs().isInput6On());
                inputs.setInput7(locationStatusInfo.getInputs().isInput7On());

                String binaryInputString = Integer.toBinaryString(locationStatusInfo.getInputs().getByte());
                StringBuilder binaryInputStringBuilder = new StringBuilder(binaryInputString);
                while (binaryInputStringBuilder.length() < 8)
                {
                    binaryInputStringBuilder.insert(0, "0");
                }
                inputs.setValue(binaryInputStringBuilder.reverse().toString());
                locationInformation.setInputs(inputs);
            }

            rawDtcMessage.setLocationInformation(locationInformation);
            rawDtcMessage.setLocationTime(locationStatusInfo.getUpdateTime().getTime());
        }
        return rawDtcMessage;
    }

    @Override
    protected ApplicationMessageContent customConvert(RawDtcMessage rawDtcMessage, ApplicationMessageContent applicationMessageContent)
    {

        return applicationMessageContent;
    }

    private static boolean hasCurrentFix(FixStatus fixStatus, double latitude, double longitude)
    {
        // if the invalidFix or the predicted bits are set, no current Fix is set.
        return !(fixStatus.isInvalidFix() || fixStatus.isPredicted());
    }

}
