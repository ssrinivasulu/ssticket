package com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages;

import java.nio.ByteBuffer;

/**
 * User: ericw
 * Date: 4/28/14
 */
public class SetZoneToCurrentLocationUnitRequestMessage implements UnitRequestMessageBody {

    private static final int MAX_ZONE_SIZE = 429000;
    private int zoneNumber;
    private int zoneHysteresis;
    private int zoneSize;

    public static SetZoneToCurrentLocationUnitRequestMessage decode(ByteBuffer byteBuffer) {

        byte zoneNumber = byteBuffer.get();
        short zoneHysteresis = byteBuffer.getShort();
        int zoneSize = byteBuffer.getInt();

        SetZoneToCurrentLocationUnitRequestMessage message = new SetZoneToCurrentLocationUnitRequestMessage();
        message.setZoneNumber(zoneNumber);
        message.setZoneHysteresis(zoneHysteresis);
        message.setZoneSize(zoneSize);
        return message;
    }

    @Override
    public byte[] encode() {

        ByteBuffer byteBuffer = ByteBuffer.allocate(7);
        byteBuffer.put((byte)zoneNumber);
        byteBuffer.putShort((short) zoneHysteresis);
        byteBuffer.putInt(zoneSize);
        return byteBuffer.array();
    }

    public int getZoneNumber() {
        return zoneNumber;
    }

    public void setZoneNumber(int zoneNumber) {
        this.zoneNumber = zoneNumber;
    }

    public int getZoneHysteresis() {
        return zoneHysteresis;
    }

    public void setZoneHysteresis(int zoneHysteresis) {
        if(zoneHysteresis > Short.MAX_VALUE)
            zoneHysteresis = Short.MAX_VALUE;
        this.zoneHysteresis = zoneHysteresis;
    }

    public int getZoneSize() {
        return zoneSize;
    }

    public void setZoneSize(int zoneSize) {
        if(zoneSize > MAX_ZONE_SIZE)
            zoneSize = MAX_ZONE_SIZE;
        this.zoneSize = zoneSize;
    }

    @Override
    public boolean equals(Object o) {

        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SetZoneToCurrentLocationUnitRequestMessage that = (SetZoneToCurrentLocationUnitRequestMessage) o;

        if (zoneHysteresis != that.zoneHysteresis) return false;
        if (zoneNumber != that.zoneNumber) return false;
        if (zoneSize != that.zoneSize) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) zoneNumber;
        result = 31 * result + zoneHysteresis;
        result = 31 * result + zoneSize;
        return result;
    }

    @Override
    public String toString() {
        return "SetZoneToCurrentLocationUnitRequestMessage{" +
                "zoneNumber=" + zoneNumber +
                ", zoneHysteresis=" + zoneHysteresis +
                ", zoneSize=" + zoneSize +
                '}';
    }
}
