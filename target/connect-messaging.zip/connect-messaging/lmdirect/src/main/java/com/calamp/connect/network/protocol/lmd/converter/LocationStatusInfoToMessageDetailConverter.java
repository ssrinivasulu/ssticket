package com.calamp.connect.network.protocol.lmd.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Event.FixStatus;
import com.calamp.connect.models.network.Network.CommState;
import com.calamp.connect.models.network.Network.Inputs;
import com.calamp.connect.models.network.Network.MessageDetail;
import com.calamp.connect.models.network.Network.UnitStatus;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;

@Component
public class LocationStatusInfoToMessageDetailConverter  {
	@Autowired
    @Qualifier("lmdirectToNetworkMapperFactory")
    protected MapperFactory mapperFactory;
	
	public MessageDetail convert(LocationStatusInfo protocol) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		MessageDetail messageDetail = mapper.map(protocol, MessageDetail.class);
		if (protocol != null)
        {
            messageDetail.setHdop(translateHdop(protocol.getHorizontalDilutionOfPrecision()));
            messageDetail.setSpeed(protocol.getSpeed());

            boolean hasCurrentFix = ConverterUtil.hasCurrentFix(protocol.getFixStatus(), messageDetail.getHdop(), messageDetail.getSatelliteCount());
            messageDetail.setFixStatus(hasCurrentFix);
            messageDetail.setTimeOfFix(protocol.getTimeOfFix());
            
            if (protocol.getCommState() != null)
            {
                com.calamp.connect.network.protocol.lmd.domain.CommState netCommState = protocol
                        .getCommState();
                CommState commState = new CommState();
                commState.setAvailable(netCommState.isAvailable());
                commState.setConnected(netCommState.isConnected());
                commState.setDataService(netCommState.isDataService());
                commState.setNetworkService(netCommState.isNetworkService());
                commState.setRoaming(netCommState.isRoaming());
                commState.setThreeGNetwork(netCommState.isThreeGNetwork());
                commState.setVoiceCallIsActive(netCommState.isVoiceCallActive());
                messageDetail.setCommState(commState);
            }
            if (protocol.getFixStatus() != null)
            {
                com.calamp.connect.network.protocol.lmd.domain.FixStatus netFixStatus = protocol
                        .getFixStatus();
                FixStatus fixStatus = new FixStatus();
                fixStatus.setDifferentiallyCorrected(netFixStatus.isDifferentiallyCorrected());
                fixStatus.setHistoric(netFixStatus.isHistoric());
                fixStatus.setInvalidFix(netFixStatus.isInvalidFix());
                fixStatus.setInvalidTime(netFixStatus.isInvalidTime());
                fixStatus.setLastKnown(netFixStatus.isLastKnown());
                fixStatus.setPredicted(netFixStatus.isPredicted());
                fixStatus.setTwoDFix(netFixStatus.is2DFix());
                messageDetail.setGpsFixStatus(fixStatus);
            }
            if (protocol.getUnitStatus() != null)
            {
                UnitStatus unitStatus = new UnitStatus();
                com.calamp.connect.network.protocol.lmd.domain.UnitStatus netUnitStatus = protocol
                        .getUnitStatus();
                unitStatus.setGpsAntennaStatus(netUnitStatus.isGPSAntennaOkay());
                unitStatus.setGpsExceptionReported(netUnitStatus.isGPSExceptionReported());
                unitStatus.setGpsReceiverSelfTest(netUnitStatus.isGPSReceiverSelfTestOkay());
                unitStatus.setGpsReceiverTracking(netUnitStatus.isGPSReceiverTracking());
                unitStatus.setMemoryTest(netUnitStatus.isMemoryTestOkay());
                unitStatus.setModemMinTest(netUnitStatus.isModemMINTestOkay());
                messageDetail.setUnitStatus(unitStatus);
            }
            if (protocol.getInputs() != null)
            {
                Inputs inputs = new Inputs();
                com.calamp.connect.network.protocol.lmd.domain.Inputs netInputs = protocol.getInputs();
                inputs.setIgnition(netInputs.isIgnitionOn());
                inputs.setInput1(netInputs.isInput1On());
                inputs.setInput2(netInputs.isInput2On());
                inputs.setInput3(netInputs.isInput3On());
                inputs.setInput4(netInputs.isInput4On());
                inputs.setInput5(netInputs.isInput5On());
                inputs.setInput6(netInputs.isInput6On());
                inputs.setInput7(netInputs.isInput7On());

                String binaryInputString = Integer.toBinaryString(Byte.toUnsignedInt(protocol.getInputs().getByte()));
                StringBuilder binaryInputStringBuilder = new StringBuilder(binaryInputString);
                while (binaryInputStringBuilder.length() < 8)
                {
                    binaryInputStringBuilder.insert(0, "0");
                }
                inputs.setValue(binaryInputStringBuilder.reverse().toString());

                messageDetail.setInputs(inputs);
            }
            messageDetail.setRssi(protocol.getRssi());// The backing bits in Inputs are in reverse order;
        }
		return messageDetail;
	}

	public static double translateHdop(int original)
    {
        Double hdop = Double.valueOf(original);
        hdop = hdop / 10.0d;
        return hdop.doubleValue();
    }



}
