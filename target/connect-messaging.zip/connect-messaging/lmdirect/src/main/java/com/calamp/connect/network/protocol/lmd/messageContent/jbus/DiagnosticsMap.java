package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.util.Arrays;

import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

public class DiagnosticsMap implements JbusMap {
	
	private Integer SPNValue;
    private Integer FMIValue;
    private Integer OCValue;
    
    @Override
    public byte[] encode() {
    	ByteBuffer encodedBytes = ByteBuffer.allocate(28);
    	return encodedBytes.array();
    }
    
    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
    	DiagnosticsMap map = new DiagnosticsMap();
    	byteBuffer.get(); //ignore first byte
    	byteBuffer.get(); //ignore second byte
    	
    	/**
    	* The next 3 bytes contain spn, fmi and OC values, but 
    	* out of the 24 bits(3 bytes) 19 bits is the SPN, 5bits FMI
    	* 1bit CM should be 0 in order to carry out the SPN conversion 
    	* rest 7 bits is the OC 
    	*/
    	boolean[] spn = BitUtil.getBits(byteBuffer.get());
    	spn = concat(BitUtil.getBits(byteBuffer.get()), spn);
    	boolean[] spn_fmi = BitUtil.getBits(byteBuffer.get());
    	spn = concat(Arrays.copyOfRange(spn_fmi, 0, 3), spn); //19 bits of spn in to boolean array
    	boolean[] fmi = Arrays.copyOfRange(spn_fmi, 3, 8); // 5 bits of fmi
        int ocValue = ByteUtil.signedByteToUnsignedByte(byteBuffer.get()); //if CM is 1 the min is 128 for the next 8 bits 
        if (ocValue < 128) {
        	map.setOCValue(ocValue);
        	map.setSPNValue(BitUtil.bin2Dec(spn));
        	map.setFMIValue(BitUtil.bin2Dec(fmi));        	
        }
        //the remaining 20 bytes are blank
        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setSPNValue(SPNValue);
        jbusMessage.setFMIValue(FMIValue);
        jbusMessage.setOCValue(OCValue);
        return jbusMessage;
    }


    public Integer getSPNValue() {
		return SPNValue;
	}

	public void setSPNValue(Integer sPNValue) {
		SPNValue = sPNValue;
	}

	public Integer getFMIValue() {
		return FMIValue;
	}

	public void setFMIValue(Integer fMIValue) {
		FMIValue = fMIValue;
	}

	public Integer getOCValue() {
		return OCValue;
	}

	public void setOCValue(Integer oCValue) {
		OCValue = oCValue;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DiagnosticsMap that = (DiagnosticsMap) o;

        if (SPNValue != null ? !SPNValue.equals(that.SPNValue) : that.SPNValue != null)
            return false;
        if (FMIValue != null ? !FMIValue.equals(that.FMIValue) : that.FMIValue != null)
            return false;
        if (OCValue != null ? !OCValue.equals(that.OCValue) : that.OCValue != null)
            return false;
     
        return true;
    }

    @Override
    public int hashCode() {
        int result = SPNValue != null ? SPNValue.hashCode() : 0;
        result = 31 * result + (FMIValue != null ? FMIValue.hashCode() : 0);
        result = 31 * result + (OCValue != null ? OCValue.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "DiagnosticsMap{" +
                "SPNValue=" + SPNValue +
                ", FMIValue=" + FMIValue +
                ", OCValue=" + OCValue +
                '}';
    }
    
    public static boolean[] concat(boolean[] a, boolean[] b){
        int length = a.length + b.length;
        boolean[] result = new boolean[length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }    

}