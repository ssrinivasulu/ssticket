package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * User: ericw  Date: 7/29/13
 */
public class JbusMessageSerializer {

    private static Logger                                 logger = LogManager.getLogger(JbusMessageSerializer.class);

    public static JbusMap decode(ByteBuffer byteBuffer) {
    	try{
//        byte mapId = byteBuffer.get();
        short mapId = (short) (byteBuffer.get() & 0xff);
        JbusMapType type = JbusMapType.getApplicationMessageType(mapId);
        if(type == null)
            return null;
        switch(type) {
            case BASIC_MAP: {
                return new BasicParametersMap().decode(byteBuffer);
            }
            case FUEL_IDLE_MAP: {
                return new FuelIdleMap().decode(byteBuffer);
            }
            case TIME_TEMPERATURE_MAP: {
                return new TimeTemperatureMap().decode(byteBuffer);
            }
            case J1708_VIN: {
                //return new Vin1708Map().decode(byteBuffer);
            	//this is deprecated
            }
            case VIN_MAP: {
                return new VinMap().decode(byteBuffer);
            }
            case DIAGNOSTICS_MAP: {
                return new DiagnosticsMap().decode(byteBuffer);
            }
            case J1939_DTC: {
                return new DTCJ1939().decode(byteBuffer);
            }
            case J1708_DTC: {
                return new DTCJ1708().decode(byteBuffer);
            }
            case DAILY_REPORT: {
                return new DailyReportMap().decode(byteBuffer);
            }
            case HOURLY_REPORT: {
                return new HourlyReportMap().decode(byteBuffer);
            }
            case CONSTR_DAILY_REPORT: {
                return new ConstructionDailyReportMap().decode(byteBuffer);
            }
            case CONSTR_DAILY_USAGE_REPORT: {
                return new ConstructionDailyUsageReportMap().decode(byteBuffer);
            }
            case CONSTR_HOURLY_REPORT: {
                return new ConstructionHourlyReportMap().decode(byteBuffer);
            }
            case JHYDRAULIC_REPORT: {
                return new JbusHydraulicReportMap().decode(byteBuffer);
            }
            case JFAULT_REPORT: {
                return new JbusFaultReportMap().decode(byteBuffer);
            }
            case DISCOVERY_REPORT: {
                return new DiscoveryReportMap().decode(byteBuffer);
            }
            
    	}
	}
    	catch(Exception e) {
    		logger.error("Exception occured when decoding Jbus message"+ExceptionUtils.getMessage(e));
    	}
        return null;
    }

    public static byte[] encode(JbusMap jbusMap) {
        return jbusMap.encode();
    }

}
