package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * User: ericw  Date: 7/29/13
 */
public class JbusReport extends ApplicationMessageFormat {

    private byte[] rawJbusReport;

    public JbusReport(byte[] jbusMessage) {
        this.rawJbusReport = jbusMessage;
    }

    @Override
    public byte[] encode() {
        return rawJbusReport;
    }

    public static JbusReport decode(ByteBuffer byteBuffer) {
        List<Byte> bytes = new ArrayList<Byte>();
        while (byteBuffer.hasRemaining()) {
            bytes.add(byteBuffer.get());
        }
        byte[] byteArray = new byte[bytes.size()];
        for (int i = 0; i < byteArray.length; i++) {
            byteArray[i] = bytes.get(i);
        }
        JbusReport jbusReport = new JbusReport(byteArray);
        return jbusReport;
    }

    public byte[] getRawJbusReport() {
        return rawJbusReport;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        JbusReport that = (JbusReport) o;

        if (!Arrays.equals(rawJbusReport, that.rawJbusReport)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return rawJbusReport != null ? Arrays.hashCode(rawJbusReport) : 0;
    }
}
