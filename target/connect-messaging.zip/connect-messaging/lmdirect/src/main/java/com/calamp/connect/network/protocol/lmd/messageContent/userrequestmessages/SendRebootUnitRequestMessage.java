package com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages;

public class SendRebootUnitRequestMessage implements UnitRequestMessageBody
{
    @Override
    public byte[] encode()
    {
        return new byte[]{0, 0 , 0, 0, 0, 0, 0};
    }
}
