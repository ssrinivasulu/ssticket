package com.calamp.connect.network.protocol.lmd.domain;

import com.calamp.connect.services.fmi.util.ByteUtil;

public enum ShortMotionLogsRecordType
{
    RECORD_TYPE_TWO(2), RECORD_TYPE_FOUR(4), RECORD_TYPE_SIX(6), RECORD_TYPE_EIGHT(8), RECORD_TYPE_TEN(10), RECORD_TYPE_TWELVE(
            12), RECORD_TYPE_FOURTEEN(14), RECORD_TYPE_SIXTEEN(16), UNKNOWN(0);

    private int value;

    private ShortMotionLogsRecordType(int value)
    {
        this.value = value;
    }

    public byte[] toBytes()
    {
        return ByteUtil.unsignedShortToBytes(value);
    }

    public int getValue()
    {
        return value;
    }

    public static ShortMotionLogsRecordType getShortMotionLogsRecordType(int value)
    {
        for (ShortMotionLogsRecordType type : values())
        {
            if (type.value == value)
            {
                return type;
            }
        }
        return ShortMotionLogsRecordType.UNKNOWN;
    }
}
