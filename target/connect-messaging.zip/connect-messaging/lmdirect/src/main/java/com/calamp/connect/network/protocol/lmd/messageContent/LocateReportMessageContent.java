package com.calamp.connect.network.protocol.lmd.messageContent;

import java.util.ArrayList;
import java.util.List;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;

/**
 * This type of message is sent by the LMU is response to a request by
 * the application made with a Unit Request Message.   The server does not send this to the device.
 *
 * User: ericw
 * Date: Oct 19, 2010
 */
public class LocateReportMessageContent  extends MessageContent
{
    private LocationStatusInfo locationStatusInfo;
    private List<Long> accumulatorValues = new ArrayList<Long>();

    public LocationStatusInfo getLocationStatusInfo()
    {
        return locationStatusInfo;
    }

    public void setLocationStatusInfo(LocationStatusInfo locationStatusInfo)
    {
        this.locationStatusInfo = locationStatusInfo;
    }

    public List<Long> getAccumulatorValues()
    {
        return accumulatorValues;
    }

    public void setAccumulatorValues(List<Long> accumulatorValues)
    {
        this.accumulatorValues = accumulatorValues;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LocateReportMessageContent that = (LocateReportMessageContent) o;

        if (accumulatorValues != null ? !accumulatorValues.equals(that.accumulatorValues) : that.accumulatorValues != null) return false;
        if (locationStatusInfo != null ? !locationStatusInfo.equals(that.locationStatusInfo) : that.locationStatusInfo != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = locationStatusInfo != null ? locationStatusInfo.hashCode() : 0;
        result = 31 * result + (accumulatorValues != null ? accumulatorValues.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "LocateReportMessageContent{" +
                "locationStatusInfo=" + locationStatusInfo +
                ", accumulatorValues=" + accumulatorValues +
                '}';
    }
}
