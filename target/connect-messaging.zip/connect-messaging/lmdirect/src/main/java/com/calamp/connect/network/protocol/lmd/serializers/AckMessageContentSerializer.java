package com.calamp.connect.network.protocol.lmd.serializers;

/**
 * User: ericw
 * Date: Oct 21, 2010
 */
public class AckMessageContentSerializer
{
}
