package com.calamp.connect.network.protocol.lmd.springintegration;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.integration.annotation.Transformer;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import com.calamp.connect.network.util.HeaderConstants;
import com.calamp.connect.services.fmi.util.HexUtil;
import com.calamp.connect.network.protocol.lmd.LmDirectSerializer;
import com.calamp.connect.network.protocol.lmd.domain.IpUdpHeader;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 *
 * Creates an LMDirectMessage
 * as well as pulls the Source address/port from the header
 *
 * User: ericw
 * Date: Oct 29, 2010
 */

public class LMDirectMessageTransformer
{
    private static Logger logger = LogManager.getLogger(LMDirectMessageTransformer.class);
 
    @Transformer
    public static Message<byte[]> toByteStream(Message<LMDirectMessage> message)
    {
        logger.debug("entering the LMDirectMessageTransformer:toByteStream");
        LMDirectMessage payload = message.getPayload();

        //TODO should we populate the IPUdpHeader here?
        byte[] lmDirectMessageBytes = LmDirectSerializer.encode(payload);
        Message<byte[]> newMessage = MessageBuilder.withPayload(lmDirectMessageBytes)
                .copyHeaders(message.getHeaders()).build();
        logger.debug("leaving the LMDirectMessageTransformer:toByteStream");
        return newMessage;
    }

    @Transformer
    public static Message<LMDirectMessage> fromByteStream(Message<byte[]> message)
    {
        byte[] payload =  message.getPayload();
        String sourceAddress = (String)message.getHeaders().get(HeaderConstants.SOURCE_ADDRESS);
        Integer sourcePort = (Integer)message.getHeaders().get(HeaderConstants.SOURCE_PORT);

        IpUdpHeader ipUdpHeader = new IpUdpHeader();
        ipUdpHeader.setSourceAddress(sourceAddress);
        ipUdpHeader.setSourcePort(sourcePort);

        LMDirectMessage lmDirectMessage = LmDirectSerializer.decode(payload);
        lmDirectMessage.setRawDeviceHexMessage(HexUtil.convertToHexString(payload));
        lmDirectMessage.setIpUdpHeader(ipUdpHeader);
        Message<LMDirectMessage> newMessage = MessageBuilder.withPayload(lmDirectMessage)
                .copyHeaders(message.getHeaders())
                .setHeader(HeaderConstants.PROTOCOL, HeaderConstants.CALAMP).build();

        return newMessage;
    }
}
