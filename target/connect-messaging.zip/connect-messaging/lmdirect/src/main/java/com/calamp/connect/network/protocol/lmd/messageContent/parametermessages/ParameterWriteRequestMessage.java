package com.calamp.connect.network.protocol.lmd.messageContent.parametermessages;

import java.util.List;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw
 * Date: 4/25/14
 */
public class ParameterWriteRequestMessage implements ParameterMessageBody {

    private Map<ParameterId, List<ParameterInfo>> parameterIdIndexMap = new LinkedHashMap<>();
    private Set<ParameterInfo> parameterInfoList = new LinkedHashSet<>();

    public static ParameterWriteRequestMessage decode(ByteBuffer byteBuffer)
    {
        ParameterWriteRequestMessage message = new ParameterWriteRequestMessage();

        while(true) //scary, but no concern for an infinite loop. If the message is malformed, we'll get
        //an exception when we try to read from the end of a bytebuffer
        {
            ParameterId parameterId = ParameterId.getParameterId(ByteUtil.getUnsignedShort(byteBuffer));
            int length = ByteUtil.getUnsignedShort(byteBuffer);
            if(parameterId==ParameterId.NULL_PARAMETER && length==0)
                break;

            int dataLength = parameterId.getDataLength();
            int indexCount = length / (dataLength+1); //this minus one is for the one byte for the index
            for(int i=0;i<indexCount;i++)
            {
                int index = byteBuffer.get();
                byte[] dataBytes = new byte[dataLength];
                byteBuffer.get(dataBytes);
                message.addParameterIdInformation(parameterId, index, dataBytes);
            }
        }
        if(message.parameterInfoList.isEmpty())
            return null;
        return message;
    }

    @Override
    public byte[] encode() {
        //I'm not a big fan of how this turned out.
        int sizeInBytes =0;
        for(ParameterId parameterId : parameterIdIndexMap.keySet())
        {
            List<ParameterInfo> indexes = parameterIdIndexMap.get(parameterId);
            //each parameter id needs 4 bytes for the id and the length
            sizeInBytes+= 4+  (indexes.size()*parameterId.getDataLength()+indexes.size());
        }
        ByteBuffer buffer = ByteBuffer.allocate(sizeInBytes);

        for(ParameterId parameterId : parameterIdIndexMap.keySet())
        {
            List<ParameterInfo> indexes = parameterIdIndexMap.get(parameterId);
            buffer.putShort((short)parameterId.getValue());
            buffer.putShort((short)(indexes.size() * parameterId.getDataLength()+indexes.size()));
            for(ParameterInfo info : indexes)
            {
                buffer.put((byte)info.getParameterIndex().intValue());
                buffer.put(info.getParameterData());
            }
        }
        return buffer.array();
    }

    public void addParameterIdInformation(ParameterId parameterId, Integer index, byte[] data)
    {
        ParameterInfo info = new ParameterInfo(parameterId, index, data);
        parameterInfoList.add(info);

        List<ParameterInfo> infoList = parameterIdIndexMap.get(parameterId);
        if(infoList == null)
        {
            infoList = new ArrayList<>();
            parameterIdIndexMap.put(parameterId, infoList);
        }
        infoList.add(info);

    }

    public Map<ParameterId, List<ParameterInfo>> getParameterInfoByParameterId()
    {
        return new LinkedHashMap<>(parameterIdIndexMap);
    }

    public List<ParameterInfo> getParameterInfoList() {
        return new ArrayList<>(parameterInfoList);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ParameterWriteRequestMessage that = (ParameterWriteRequestMessage) o;

        if (parameterIdIndexMap != null ? !parameterIdIndexMap.equals(that.parameterIdIndexMap) : that.parameterIdIndexMap != null)
            return false;
        if (parameterInfoList != null ? !parameterInfoList.equals(that.parameterInfoList) : that.parameterInfoList != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = parameterIdIndexMap != null ? parameterIdIndexMap.hashCode() : 0;
        result = 31 * result + (parameterInfoList != null ? parameterInfoList.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ParameterWriteRequestMessage{" +
                "parameterIdIndexMap=" + parameterIdIndexMap +
                ", parameterInfoList=" + parameterInfoList +
                '}';
    }
}
