package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.util.List;

import com.calamp.connect.network.protocol.lmd.messageContent.MessageContent;

/**
 * User: ericw Date: 7/29/13
 */
@SuppressWarnings("serial")
public class RawJbusMessage extends MessageContent
{

    private Double       odometer1708;
    private Double       odometer1939;
    private Double       highResolution1939;
    private Double       batteryVoltage1708;
    private Double       batteryVoltage1939;
    private Double       switchedBatteryVoltage1708;
    private Double       switchedBatteryVoltage1939;
    private Double       engineSpeed1708;
    private Double       engineSpeed1939;
    private Double       totalFuel1708;
    private Double       totalFuel1939;
    private Double       totalIdleFuel1708;
    private Double       totalIdleFuel1939;
    private Double       totalIdleHours1708;
    private Double       totalIdleHours1939;
    private Double       totalEngineHours1708;
    private Double       totalEngineHours1939;
    private Integer      engineCoolantTemperature1708;
    private Integer      engineCoolantTemperature1939;
    private Double       engineOilTemperature1708;
    private Double       engineOilTemperature1939;
    private Boolean      seatBeltUsed;
    private String       vin1708;
    private String       vin1939;
    private Integer      SPNValue;
    private Integer      FMIValue;
    private Integer      OCValue;
    private List         J1939DTCCodes;
    private List         J1708DTCCodes;
    private String       dailyEngineTotalHours;
    private String       dailyEngineIdleHours;
    private String       dailyEngineIdleFuel;
    private String       dailyEngineOilLevel;
    private String       dailyEngineCoolantLevel;
    private String       dailyNoxTankLevel;
    private String       hourlyEngineCoolantTemperature;
    private String       hourlyEngineOilTemperature;
    private String       hourlyEngineOilPressure;
    private String       hourlyEngineCrankcasePressure;
    private String       hourlyEngineCoolantPressure;
    private String       hourlyEngineBatteryVoltage;
    private String       hourlyEngineFuelTankLevel1;
    private String       hourlyEngineFuelTankLevel2;
    private String       hourlyTransmissionOilTemperature;
    private String       hourlyAverageFuelEconomy;
    private Integer      sourceAddress;
    private String       engineTotalFuelUsed;
    private String       avgEngineFuelRate;
    private String       avgActualEngineTorque;
    private String       minEngineSpeed;
    private String       maxEngineSpeed;
    private String       avgEngineSpeed;
    private String       minDEFConcentration;
    private String       maxDEFConcentration;
    private String       avgDEFConcentration;
    private String       minDEFTempr;
    private String       maxDEFTempr;
    private String       avgDEFTempr;
    private String       minEngineOilPressure;
    private String       maxEngineOilPressure;
    private String       avgEngineOilPressure;
    private String       minEngineOilTempr;
    private String       maxEngineOilTempr;
    private String       avgEngineOilTempr;
    private String       minEngineCoolantTempr;
    private String       maxEngineCoolantTempr;
    private String       avgEngineCoolantTempr;
    private String       minEngineFuelTempr1;
    private String       maxEngineFuelTempr1;
    private String       avgEngineFuelTempr1;
    private String       minAmbientAirTempr;
    private String       maxAmbientAirTempr;
    private String       avgAmbientAirTempr;
    private String       minAuxiliaryTempr1;
    private String       maxAuxiliaryTempr1;
    private String       avgAuxiliaryTempr1;
    private String       engineTorque0To10PercentUsage;
    private String       engineTorque10To20PercentUsage;
    private String       engineTorque20To30PercentUsage;
    private String       engineTorque30To40PercentUsage;
    private String       engineTorque40To50PercentUsage;
    private String       engineTorque50To60PercentUsage;
    private String       engineTorque60To70PercentUsage;
    private String       engineTorque70To80PercentUsage;
    private String       engineTorque80To90PercentUsage;
    private String       engineTorqueOver90PercentUsage;
    private String       positionTorque0To10PercentUsage;
    private String       positionTorque10To20PercentUsage;
    private String       positionTorque20To30PercentUsage;
    private String       positionTorque30To40PercentUsage;
    private String       positionTorque40To50PercentUsage;
    private String       positionTorque50To60PercentUsage;
    private String       positionTorque60To70PercentUsage;
    private String       positionTorque70To80PercentUsage;
    private String       positionTorque80To90PercentUsage;
    private String       positionTorqueOver90PercentUsage;
    private String       totalEngineHours;
    private String       defOrNoxTankLevel;
    private String       fuelTankLevel1;
    private String       minHydraulicChargePressure;
    private String       maxHydraulicChargePressure;
    private String       avgHydraulicChargePressure;
    private String       minHydraulicOilTemperature;
    private String       maxHydraulicOilTemperature;
    private String       avgHydraulicOilTemperature;
    private Integer      device;
    private Integer      function;
    private Integer      failure;
    private MachineState machineState;
    
	//Discovery Report
	private Boolean vehicleSpeedFound;
	private Boolean odometerFound;
	private Boolean totalFuelFound;
	private Boolean vinFound;
    private Boolean batteryVoltageSourcesFound;
    private Boolean discoveryReportSourcesFound1;
    private Boolean discoveryReportSourcesFound2;
    private Boolean discoveryReportSourcesFound3;
    private Boolean discoveryReportSourcesFound4;
    private Boolean fuelTankSourcesFound;
    private Boolean averageFuelTankSourcesFound;
    private Boolean ptoSourcesFound; 
    private Boolean ptoSourcesActive; 
    private Boolean engineTorqueSourcesFound; 
    private Boolean engineThrottleSourcesFound;

    public RawJbusMessage()
    {
    }

    public Double getOdometer1708()
    {
        return odometer1708;
    }

    public void setOdometer1708(Double odometer1708)
    {
        this.odometer1708 = odometer1708;
    }

    public Double getOdometer1939()
    {
        return odometer1939;
    }

    public void setOdometer1939(Double odometer1939)
    {
        this.odometer1939 = odometer1939;
    }

    public Double getHighResolution1939()
    {
        return highResolution1939;
    }

    public void setHighResolution1939(Double highResolution1939)
    {
        this.highResolution1939 = highResolution1939;
    }

    public Double getBatteryVoltage1708()
    {
        return batteryVoltage1708;
    }

    public void setBatteryVoltage1708(Double batteryVoltage1708)
    {
        this.batteryVoltage1708 = batteryVoltage1708;
    }

    public Double getBatteryVoltage1939()
    {
        return batteryVoltage1939;
    }

    public void setBatteryVoltage1939(Double batteryVoltage1939)
    {
        this.batteryVoltage1939 = batteryVoltage1939;
    }

    public Double getSwitchedBatteryVoltage1708()
    {
        return switchedBatteryVoltage1708;
    }

    public void setSwitchedBatteryVoltage1708(Double switchedBatteryVoltage1708)
    {
        this.switchedBatteryVoltage1708 = switchedBatteryVoltage1708;
    }

    public Double getSwitchedBatteryVoltage1939()
    {
        return switchedBatteryVoltage1939;
    }

    public void setSwitchedBatteryVoltage1939(Double switchedBatteryVoltage1939)
    {
        this.switchedBatteryVoltage1939 = switchedBatteryVoltage1939;
    }

    public Double getEngineSpeed1708()
    {
        return engineSpeed1708;
    }

    public void setEngineSpeed1708(Double engineSpeed1708)
    {
        this.engineSpeed1708 = engineSpeed1708;
    }

    public Double getEngineSpeed1939()
    {
        return engineSpeed1939;
    }

    public void setEngineSpeed1939(Double engineSpeed1939)
    {
        this.engineSpeed1939 = engineSpeed1939;
    }

    public Double getTotalFuel1708()
    {
        return totalFuel1708;
    }

    public void setTotalFuel1708(Double totalFuel1708)
    {
        this.totalFuel1708 = totalFuel1708;
    }

    public Double getTotalFuel1939()
    {
        return totalFuel1939;
    }

    public void setTotalFuel1939(Double totalFuel1939)
    {
        this.totalFuel1939 = totalFuel1939;
    }

    public Double getTotalIdleFuel1708()
    {
        return totalIdleFuel1708;
    }

    public void setTotalIdleFuel1708(Double totalIdleFuel1708)
    {
        this.totalIdleFuel1708 = totalIdleFuel1708;
    }

    public Double getTotalIdleFuel1939()
    {
        return totalIdleFuel1939;
    }

    public void setTotalIdleFuel1939(Double totalIdleFuel1939)
    {
        this.totalIdleFuel1939 = totalIdleFuel1939;
    }

    public Double getTotalIdleHours1708()
    {
        return totalIdleHours1708;
    }

    public void setTotalIdleHours1708(Double totalIdleHours1708)
    {
        this.totalIdleHours1708 = totalIdleHours1708;
    }

    public Double getTotalIdleHours1939()
    {
        return totalIdleHours1939;
    }

    public void setTotalIdleHours1939(Double totalIdleHours1939)
    {
        this.totalIdleHours1939 = totalIdleHours1939;
    }

    public Double getTotalEngineHours1708()
    {
        return totalEngineHours1708;
    }

    public void setTotalEngineHours1708(Double totalEngineHours1708)
    {
        this.totalEngineHours1708 = totalEngineHours1708;
    }

    public Integer getSPNValue()
    {
        return SPNValue;
    }

    public void setSPNValue(Integer sPNValue)
    {
        SPNValue = sPNValue;
    }

    public Integer getFMIValue()
    {
        return FMIValue;
    }

    public void setFMIValue(Integer fMIValue)
    {
        FMIValue = fMIValue;
    }

    public Integer getOCValue()
    {
        return OCValue;
    }

    public void setOCValue(Integer oCValue)
    {
        OCValue = oCValue;
    }

    public Double getTotalEngineHours1939()
    {
        return totalEngineHours1939;
    }

    public void setTotalEngineHours1939(Double totalEngineHours1939)
    {
        this.totalEngineHours1939 = totalEngineHours1939;
    }

    public Integer getEngineCoolantTemperature1708()
    {
        return engineCoolantTemperature1708;
    }

    public void setEngineCoolantTemperature1708(Integer engineCoolantTemperature1708)
    {
        this.engineCoolantTemperature1708 = engineCoolantTemperature1708;
    }

    public Integer getEngineCoolantTemperature1939()
    {
        return engineCoolantTemperature1939;
    }

    public void setEngineCoolantTemperature1939(Integer engineCoolantTemperature1939)
    {
        this.engineCoolantTemperature1939 = engineCoolantTemperature1939;
    }

    public Double getEngineOilTemperature1708()
    {
        return engineOilTemperature1708;
    }

    public void setEngineOilTemperature1708(Double engineOilTemperature1708)
    {
        this.engineOilTemperature1708 = engineOilTemperature1708;
    }

    public Double getEngineOilTemperature1939()
    {
        return engineOilTemperature1939;
    }

    public void setEngineOilTemperature1939(Double engineOilTemperature1939)
    {
        this.engineOilTemperature1939 = engineOilTemperature1939;
    }

    public Boolean getSeatBeltUsed()
    {
        return seatBeltUsed;
    }

    public void setSeatBeltUsed(Boolean seatBeltUsed)
    {
        this.seatBeltUsed = seatBeltUsed;
    }

    public String getVin1708()
    {
        return vin1708;
    }

    public void setVin1708(String vin1708)
    {
        this.vin1708 = vin1708;
    }

    public String getVin1939()
    {
        return vin1939;
    }

    public void setVin1939(String vin1939)
    {
        this.vin1939 = vin1939;
    }

    public List getJ1708DTCCodes()
    {
        return J1708DTCCodes;
    }

    public void setJ1708DTCCodes(List j1708DTCCodes)
    {
        J1708DTCCodes = j1708DTCCodes;
    }

    public List getJ1939DTCCodes()
    {
        return J1939DTCCodes;
    }

    public void setJ1939DTCCodes(List j1939DTCCodes)
    {
        J1939DTCCodes = j1939DTCCodes;
    }

    public Boolean isSeatBeltUsed()
    {
        return seatBeltUsed;
    }

    public String getDailyEngineTotalHours()
    {
        return dailyEngineTotalHours;
    }

    public void setDailyEngineTotalHours(String dailyEngineTotalHours)
    {
        this.dailyEngineTotalHours = dailyEngineTotalHours;
    }

    public String getDailyEngineIdleHours()
    {
        return dailyEngineIdleHours;
    }

    public void setDailyEngineIdleHours(String dailyEngineIdleHours)
    {
        this.dailyEngineIdleHours = dailyEngineIdleHours;
    }

    public String getDailyEngineIdleFuel()
    {
        return dailyEngineIdleFuel;
    }

    public void setDailyEngineIdleFuel(String dailyEngineIdleFuel)
    {
        this.dailyEngineIdleFuel = dailyEngineIdleFuel;
    }

    public String getDailyEngineOilLevel()
    {
        return dailyEngineOilLevel;
    }

    public void setDailyEngineOilLevel(String dailyEngineOilLevel)
    {
        this.dailyEngineOilLevel = dailyEngineOilLevel;
    }

    public String getDailyEngineCoolantLevel()
    {
        return dailyEngineCoolantLevel;
    }

    public void setDailyEngineCoolantLevel(String dailyEngineCoolantLevel)
    {
        this.dailyEngineCoolantLevel = dailyEngineCoolantLevel;
    }

    public String getDailyNoxTankLevel()
    {
        return dailyNoxTankLevel;
    }

    public void setDailyNoxTankLevel(String dailyNoxTankLevel)
    {
        this.dailyNoxTankLevel = dailyNoxTankLevel;
    }

    public String getHourlyEngineCoolantTemperature()
    {
        return hourlyEngineCoolantTemperature;
    }

    public void setHourlyEngineCoolantTemperature(String hourlyEngineCoolantTemperature)
    {
        this.hourlyEngineCoolantTemperature = hourlyEngineCoolantTemperature;
    }

    public String getHourlyEngineOilTemperature()
    {
        return hourlyEngineOilTemperature;
    }

    public void setHourlyEngineOilTemperature(String hourlyEngineOilTemperature)
    {
        this.hourlyEngineOilTemperature = hourlyEngineOilTemperature;
    }

    public String getHourlyEngineOilPressure()
    {
        return hourlyEngineOilPressure;
    }

    public void setHourlyEngineOilPressure(String hourlyEngineOilPressure)
    {
        this.hourlyEngineOilPressure = hourlyEngineOilPressure;
    }

    public String getHourlyEngineCrankcasePressure()
    {
        return hourlyEngineCrankcasePressure;
    }

    public void setHourlyEngineCrankcasePressure(String hourlyEngineCrankcasePressure)
    {
        this.hourlyEngineCrankcasePressure = hourlyEngineCrankcasePressure;
    }

    public String getHourlyEngineCoolantPressure()
    {
        return hourlyEngineCoolantPressure;
    }

    public void setHourlyEngineCoolantPressure(String hourlyEngineCoolantPressure)
    {
        this.hourlyEngineCoolantPressure = hourlyEngineCoolantPressure;
    }

    public String getHourlyEngineBatteryVoltage()
    {
        return hourlyEngineBatteryVoltage;
    }

    public void setHourlyEngineBatteryVoltage(String hourlyEngineBatteryVoltage)
    {
        this.hourlyEngineBatteryVoltage = hourlyEngineBatteryVoltage;
    }

    public String getHourlyEngineFuelTankLevel1()
    {
        return hourlyEngineFuelTankLevel1;
    }

    public void setHourlyEngineFuelTankLevel1(String hourlyEngineFuelTankLevel1)
    {
        this.hourlyEngineFuelTankLevel1 = hourlyEngineFuelTankLevel1;
    }

    public String getHourlyEngineFuelTankLevel2()
    {
        return hourlyEngineFuelTankLevel2;
    }

    public void setHourlyEngineFuelTankLevel2(String hourlyEngineFuelTankLevel2)
    {
        this.hourlyEngineFuelTankLevel2 = hourlyEngineFuelTankLevel2;
    }

    public String getHourlyTransmissionOilTemperature()
    {
        return hourlyTransmissionOilTemperature;
    }

    public void setHourlyTransmissionOilTemperature(String hourlyTransmissionOilTemperature)
    {
        this.hourlyTransmissionOilTemperature = hourlyTransmissionOilTemperature;
    }

    public String getHourlyAverageFuelEconomy()
    {
        return hourlyAverageFuelEconomy;
    }

    public void setHourlyAverageFuelEconomy(String hourlyAverageFuelEconomy)
    {
        this.hourlyAverageFuelEconomy = hourlyAverageFuelEconomy;
    }

    public String getTotalEngineHours()
    {
        return totalEngineHours;
    }

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }

    public String getEngineTotalFuelUsed()
    {
        return engineTotalFuelUsed;
    }

    public void setEngineTotalFuelUsed(String engineTotalFuelUsed)
    {
        this.engineTotalFuelUsed = engineTotalFuelUsed;
    }

    public String getAvgEngineFuelRate()
    {
        return avgEngineFuelRate;
    }

    public void setAvgEngineFuelRate(String avgEngineFuelRate)
    {
        this.avgEngineFuelRate = avgEngineFuelRate;
    }

    public String getAvgActualEngineTorque()
    {
        return avgActualEngineTorque;
    }

    public void setAvgActualEngineTorque(String avgActualEngineTorque)
    {
        this.avgActualEngineTorque = avgActualEngineTorque;
    }

    public String getMinEngineSpeed()
    {
        return minEngineSpeed;
    }

    public void setMinEngineSpeed(String minEngineSpeed)
    {
        this.minEngineSpeed = minEngineSpeed;
    }

    public String getMaxEngineSpeed()
    {
        return maxEngineSpeed;
    }

    public void setMaxEngineSpeed(String maxEngineSpeed)
    {
        this.maxEngineSpeed = maxEngineSpeed;
    }

    public String getAvgEngineSpeed()
    {
        return avgEngineSpeed;
    }

    public void setAvgEngineSpeed(String avgEngineSpeed)
    {
        this.avgEngineSpeed = avgEngineSpeed;
    }

    public String getMinDEFConcentration()
    {
        return minDEFConcentration;
    }

    public void setMinDEFConcentration(String minDEFConcentration)
    {
        this.minDEFConcentration = minDEFConcentration;
    }

    public String getMaxDEFConcentration()
    {
        return maxDEFConcentration;
    }

    public void setMaxDEFConcentration(String maxDEFConcentration)
    {
        this.maxDEFConcentration = maxDEFConcentration;
    }

    public String getAvgDEFConcentration()
    {
        return avgDEFConcentration;
    }

    public void setAvgDEFConcentration(String avgDEFConcentration)
    {
        this.avgDEFConcentration = avgDEFConcentration;
    }

    public String getMinDEFTempr()
    {
        return minDEFTempr;
    }

    public void setMinDEFTempr(String minDEFTempr)
    {
        this.minDEFTempr = minDEFTempr;
    }

    public String getMaxDEFTempr()
    {
        return maxDEFTempr;
    }

    public void setMaxDEFTempr(String maxDEFTempr)
    {
        this.maxDEFTempr = maxDEFTempr;
    }

    public String getAvgDEFTempr()
    {
        return avgDEFTempr;
    }

    public void setAvgDEFTempr(String avgDEFTempr)
    {
        this.avgDEFTempr = avgDEFTempr;
    }

    public String getMinEngineOilPressure()
    {
        return minEngineOilPressure;
    }

    public void setMinEngineOilPressure(String minEngineOilPressure)
    {
        this.minEngineOilPressure = minEngineOilPressure;
    }

    public String getMaxEngineOilPressure()
    {
        return maxEngineOilPressure;
    }

    public void setMaxEngineOilPressure(String maxEngineOilPressure)
    {
        this.maxEngineOilPressure = maxEngineOilPressure;
    }

    public String getAvgEngineOilPressure()
    {
        return avgEngineOilPressure;
    }

    public void setAvgEngineOilPressure(String avgEngineOilPressure)
    {
        this.avgEngineOilPressure = avgEngineOilPressure;
    }

    public String getMinEngineOilTempr()
    {
        return minEngineOilTempr;
    }

    public void setMinEngineOilTempr(String minEngineOilTempr)
    {
        this.minEngineOilTempr = minEngineOilTempr;
    }

    public String getMaxEngineOilTempr()
    {
        return maxEngineOilTempr;
    }

    public void setMaxEngineOilTempr(String maxEngineOilTempr)
    {
        this.maxEngineOilTempr = maxEngineOilTempr;
    }

    public String getAvgEngineOilTempr()
    {
        return avgEngineOilTempr;
    }

    public void setAvgEngineOilTempr(String avgEngineOilTempr)
    {
        this.avgEngineOilTempr = avgEngineOilTempr;
    }

    public String getMinEngineCoolantTempr()
    {
        return minEngineCoolantTempr;
    }

    public void setMinEngineCoolantTempr(String minEngineCoolantTempr)
    {
        this.minEngineCoolantTempr = minEngineCoolantTempr;
    }

    public String getMaxEngineCoolantTempr()
    {
        return maxEngineCoolantTempr;
    }

    public void setMaxEngineCoolantTempr(String maxEngineCoolantTempr)
    {
        this.maxEngineCoolantTempr = maxEngineCoolantTempr;
    }

    public String getAvgEngineCoolantTempr()
    {
        return avgEngineCoolantTempr;
    }

    public void setAvgEngineCoolantTempr(String avgEngineCoolantTempr)
    {
        this.avgEngineCoolantTempr = avgEngineCoolantTempr;
    }

    public String getMinEngineFuelTempr1()
    {
        return minEngineFuelTempr1;
    }

    public void setMinEngineFuelTempr1(String minEngineFuelTempr1)
    {
        this.minEngineFuelTempr1 = minEngineFuelTempr1;
    }

    public String getMaxEngineFuelTempr1()
    {
        return maxEngineFuelTempr1;
    }

    public void setMaxEngineFuelTempr1(String maxEngineFuelTempr1)
    {
        this.maxEngineFuelTempr1 = maxEngineFuelTempr1;
    }

    public String getAvgEngineFuelTempr1()
    {
        return avgEngineFuelTempr1;
    }

    public void setAvgEngineFuelTempr1(String avgEngineFuelTempr1)
    {
        this.avgEngineFuelTempr1 = avgEngineFuelTempr1;
    }

    public String getMinAmbientAirTempr()
    {
        return minAmbientAirTempr;
    }

    public void setMinAmbientAirTempr(String minAmbientAirTempr)
    {
        this.minAmbientAirTempr = minAmbientAirTempr;
    }

    public String getMaxAmbientAirTempr()
    {
        return maxAmbientAirTempr;
    }

    public void setMaxAmbientAirTempr(String maxAmbientAirTempr)
    {
        this.maxAmbientAirTempr = maxAmbientAirTempr;
    }

    public String getAvgAmbientAirTempr()
    {
        return avgAmbientAirTempr;
    }

    public void setAvgAmbientAirTempr(String avgAmbientAirTempr)
    {
        this.avgAmbientAirTempr = avgAmbientAirTempr;
    }

    public String getMinAuxiliaryTempr1()
    {
        return minAuxiliaryTempr1;
    }

    public void setMinAuxiliaryTempr1(String minAuxiliaryTempr1)
    {
        this.minAuxiliaryTempr1 = minAuxiliaryTempr1;
    }

    public String getMaxAuxiliaryTempr1()
    {
        return maxAuxiliaryTempr1;
    }

    public void setMaxAuxiliaryTempr1(String maxAuxiliaryTempr1)
    {
        this.maxAuxiliaryTempr1 = maxAuxiliaryTempr1;
    }

    public String getAvgAuxiliaryTempr1()
    {
        return avgAuxiliaryTempr1;
    }

    public void setAvgAuxiliaryTempr1(String avgAuxiliaryTempr1)
    {
        this.avgAuxiliaryTempr1 = avgAuxiliaryTempr1;
    }

    public String getEngineTorque0To10PercentUsage()
    {
        return engineTorque0To10PercentUsage;
    }

    public void setEngineTorque0To10PercentUsage(String engineTorque0To10PercentUsage)
    {
        this.engineTorque0To10PercentUsage = engineTorque0To10PercentUsage;
    }

    public String getEngineTorque10To20PercentUsage()
    {
        return engineTorque10To20PercentUsage;
    }

    public void setEngineTorque10To20PercentUsage(String engineTorque10To20PercentUsage)
    {
        this.engineTorque10To20PercentUsage = engineTorque10To20PercentUsage;
    }

    public String getEngineTorque20To30PercentUsage()
    {
        return engineTorque20To30PercentUsage;
    }

    public void setEngineTorque20To30PercentUsage(String engineTorque20To30PercentUsage)
    {
        this.engineTorque20To30PercentUsage = engineTorque20To30PercentUsage;
    }

    public String getEngineTorque30To40PercentUsage()
    {
        return engineTorque30To40PercentUsage;
    }

    public void setEngineTorque30To40PercentUsage(String engineTorque30To40PercentUsage)
    {
        this.engineTorque30To40PercentUsage = engineTorque30To40PercentUsage;
    }

    public String getEngineTorque40To50PercentUsage()
    {
        return engineTorque40To50PercentUsage;
    }

    public void setEngineTorque40To50PercentUsage(String engineTorque40To50PercentUsage)
    {
        this.engineTorque40To50PercentUsage = engineTorque40To50PercentUsage;
    }

    public String getEngineTorque50To60PercentUsage()
    {
        return engineTorque50To60PercentUsage;
    }

    public void setEngineTorque50To60PercentUsage(String engineTorque50To60PercentUsage)
    {
        this.engineTorque50To60PercentUsage = engineTorque50To60PercentUsage;
    }

    public String getEngineTorque60To70PercentUsage()
    {
        return engineTorque60To70PercentUsage;
    }

    public void setEngineTorque60To70PercentUsage(String engineTorque60To70PercentUsage)
    {
        this.engineTorque60To70PercentUsage = engineTorque60To70PercentUsage;
    }

    public String getEngineTorque70To80PercentUsage()
    {
        return engineTorque70To80PercentUsage;
    }

    public void setEngineTorque70To80PercentUsage(String engineTorque70To80PercentUsage)
    {
        this.engineTorque70To80PercentUsage = engineTorque70To80PercentUsage;
    }

    public String getEngineTorque80To90PercentUsage()
    {
        return engineTorque80To90PercentUsage;
    }

    public void setEngineTorque80To90PercentUsage(String engineTorque80To90PercentUsage)
    {
        this.engineTorque80To90PercentUsage = engineTorque80To90PercentUsage;
    }

    public String getEngineTorqueOver90PercentUsage()
    {
        return engineTorqueOver90PercentUsage;
    }

    public void setEngineTorqueOver90PercentUsage(String engineTorqueOver90PercentUsage)
    {
        this.engineTorqueOver90PercentUsage = engineTorqueOver90PercentUsage;
    }

    public String getPositionTorque0To10PercentUsage()
    {
        return positionTorque0To10PercentUsage;
    }

    public void setPositionTorque0To10PercentUsage(String positionTorque0To10PercentUsage)
    {
        this.positionTorque0To10PercentUsage = positionTorque0To10PercentUsage;
    }

    public String getPositionTorque10To20PercentUsage()
    {
        return positionTorque10To20PercentUsage;
    }

    public void setPositionTorque10To20PercentUsage(String positionTorque10To20PercentUsage)
    {
        this.positionTorque10To20PercentUsage = positionTorque10To20PercentUsage;
    }

    public String getPositionTorque20To30PercentUsage()
    {
        return positionTorque20To30PercentUsage;
    }

    public void setPositionTorque20To30PercentUsage(String positionTorque20To30PercentUsage)
    {
        this.positionTorque20To30PercentUsage = positionTorque20To30PercentUsage;
    }

    public String getPositionTorque30To40PercentUsage()
    {
        return positionTorque30To40PercentUsage;
    }

    public void setPositionTorque30To40PercentUsage(String positionTorque30To40PercentUsage)
    {
        this.positionTorque30To40PercentUsage = positionTorque30To40PercentUsage;
    }

    public String getPositionTorque40To50PercentUsage()
    {
        return positionTorque40To50PercentUsage;
    }

    public void setPositionTorque40To50PercentUsage(String positionTorque40To50PercentUsage)
    {
        this.positionTorque40To50PercentUsage = positionTorque40To50PercentUsage;
    }

    public String getPositionTorque50To60PercentUsage()
    {
        return positionTorque50To60PercentUsage;
    }

    public void setPositionTorque50To60PercentUsage(String positionTorque50To60PercentUsage)
    {
        this.positionTorque50To60PercentUsage = positionTorque50To60PercentUsage;
    }

    public String getPositionTorque60To70PercentUsage()
    {
        return positionTorque60To70PercentUsage;
    }

    public void setPositionTorque60To70PercentUsage(String positionTorque60To70PercentUsage)
    {
        this.positionTorque60To70PercentUsage = positionTorque60To70PercentUsage;
    }

    public String getPositionTorque70To80PercentUsage()
    {
        return positionTorque70To80PercentUsage;
    }

    public void setPositionTorque70To80PercentUsage(String positionTorque70To80PercentUsage)
    {
        this.positionTorque70To80PercentUsage = positionTorque70To80PercentUsage;
    }

    public String getPositionTorque80To90PercentUsage()
    {
        return positionTorque80To90PercentUsage;
    }

    public void setPositionTorque80To90PercentUsage(String positionTorque80To90PercentUsage)
    {
        this.positionTorque80To90PercentUsage = positionTorque80To90PercentUsage;
    }

    public String getPositionTorqueOver90PercentUsage()
    {
        return positionTorqueOver90PercentUsage;
    }

    public void setPositionTorqueOver90PercentUsage(String positionTorqueOver90PercentUsage)
    {
        this.positionTorqueOver90PercentUsage = positionTorqueOver90PercentUsage;
    }

    public String getDefOrNoxTankLevel()
    {
        return defOrNoxTankLevel;
    }

    public void setDefOrNoxTankLevel(String defOrNoxTankLevel)
    {
        this.defOrNoxTankLevel = defOrNoxTankLevel;
    }

    public String getFuelTankLevel1()
    {
        return fuelTankLevel1;
    }

    public void setFuelTankLevel1(String fuelTankLevel1)
    {
        this.fuelTankLevel1 = fuelTankLevel1;
    }

    public void setTotalEngineHours(String totalEngineHours)
    {
        this.totalEngineHours = totalEngineHours;
    }

    public String getMinHydraulicChargePressure()
    {
        return minHydraulicChargePressure;
    }

    public void setMinHydraulicChargePressure(String minHydraulicChargePressure)
    {
        this.minHydraulicChargePressure = minHydraulicChargePressure;
    }

    public String getMaxHydraulicChargePressure()
    {
        return maxHydraulicChargePressure;
    }

    public void setMaxHydraulicChargePressure(String maxHydraulicChargePressure)
    {
        this.maxHydraulicChargePressure = maxHydraulicChargePressure;
    }

    public String getAvgHydraulicChargePressure()
    {
        return avgHydraulicChargePressure;
    }

    public void setAvgHydraulicChargePressure(String avgHydraulicChargePressure)
    {
        this.avgHydraulicChargePressure = avgHydraulicChargePressure;
    }

    public String getMinHydraulicOilTemperature()
    {
        return minHydraulicOilTemperature;
    }

    public void setMinHydraulicOilTemperature(String minHydraulicOilTemperature)
    {
        this.minHydraulicOilTemperature = minHydraulicOilTemperature;
    }

    public String getMaxHydraulicOilTemperature()
    {
        return maxHydraulicOilTemperature;
    }

    public void setMaxHydraulicOilTemperature(String maxHydraulicOilTemperature)
    {
        this.maxHydraulicOilTemperature = maxHydraulicOilTemperature;
    }

    public String getAvgHydraulicOilTemperature()
    {
        return avgHydraulicOilTemperature;
    }

    public void setAvgHydraulicOilTemperature(String avgHydraulicOilTemperature)
    {
        this.avgHydraulicOilTemperature = avgHydraulicOilTemperature;
    }

    public Integer getDevice()
    {
        return device;
    }

    public void setDevice(Integer device)
    {
        this.device = device;
    }

    public Integer getFunction()
    {
        return function;
    }

    public void setFunction(Integer function)
    {
        this.function = function;
    }

    public Integer getFailure()
    {
        return failure;
    }

    public void setFailure(Integer failure)
    {
        this.failure = failure;
    }

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }
    
    public Boolean getOdometerFound() {
		return odometerFound;
	}
    
	public void setOdometerFound(Boolean odometerFound) {
		this.odometerFound = odometerFound;
	}

	public Boolean getTotalFuelFound() {
		return totalFuelFound;
	}

	public void setTotalFuelFound(Boolean totalFuelFound) {
		this.totalFuelFound = totalFuelFound;
	}
	
	public Boolean getVehicleSpeedFound() {
		return vehicleSpeedFound;
	}

	public void setVehicleSpeedFound(Boolean vehicleSpeedFound) {
		this.vehicleSpeedFound = vehicleSpeedFound;
	}

	public Boolean getVinFound() {
		return vinFound;
	}

	public void setVinFound(Boolean vinFound) {
		this.vinFound = vinFound;
	}

	public Boolean getBatteryVoltageSourcesFound() {
		return batteryVoltageSourcesFound;
	}

	public void setBatteryVoltageSourcesFound(Boolean batteryVoltageSourcesFound) {
		this.batteryVoltageSourcesFound = batteryVoltageSourcesFound;
	}

	public Boolean getDiscoveryReportSourcesFound1() {
		return discoveryReportSourcesFound1;
	}

	public void setDiscoveryReportSourcesFound1(Boolean discoveryReportSourcesFound1) {
		this.discoveryReportSourcesFound1 = discoveryReportSourcesFound1;
	}

	public Boolean getDiscoveryReportSourcesFound2() {
		return discoveryReportSourcesFound2;
	}

	public void setDiscoveryReportSourcesFound2(Boolean discoveryReportSourcesFound2) {
		this.discoveryReportSourcesFound2 = discoveryReportSourcesFound2;
	}

	public Boolean getDiscoveryReportSourcesFound3() {
		return discoveryReportSourcesFound3;
	}

	public void setDiscoveryReportSourcesFound3(Boolean discoveryReportSourcesFound3) {
		this.discoveryReportSourcesFound3 = discoveryReportSourcesFound3;
	}

	public Boolean getDiscoveryReportSourcesFound4() {
		return discoveryReportSourcesFound4;
	}

	public void setDiscoveryReportSourcesFound4(Boolean discoveryReportSourcesFound4) {
		this.discoveryReportSourcesFound4 = discoveryReportSourcesFound4;
	}

	public Boolean getFuelTankSourcesFound() {
		return fuelTankSourcesFound;
	}

	public void setFuelTankSourcesFound(Boolean fuelTankSourcesFound) {
		this.fuelTankSourcesFound = fuelTankSourcesFound;
	}

	public Boolean getAverageFuelTankSourcesFound() {
		return averageFuelTankSourcesFound;
	}

	public void setAverageFuelTankSourcesFound(Boolean averageFuelTankSourcesFound) {
		this.averageFuelTankSourcesFound = averageFuelTankSourcesFound;
	}

	public Boolean getPtoSourcesFound() {
		return ptoSourcesFound;
	}

	public void setPtoSourcesFound(Boolean ptoSourcesFound) {
		this.ptoSourcesFound = ptoSourcesFound;
	}

	public Boolean getPtoSourcesActive() {
		return ptoSourcesActive;
	}

	public void setPtoSourcesActive(Boolean ptoSourcesActive) {
		this.ptoSourcesActive = ptoSourcesActive;
	}

	public Boolean getEngineTorqueSourcesFound() {
		return engineTorqueSourcesFound;
	}

	public void setEngineTorqueSourcesFound(Boolean engineTorqueSourcesFound) {
		this.engineTorqueSourcesFound = engineTorqueSourcesFound;
	}

	public Boolean getEngineThrottleSourcesFound() {
		return engineThrottleSourcesFound;
	}

	public void setEngineThrottleSourcesFound(Boolean engineThrottleSourcesFound) {
		this.engineThrottleSourcesFound = engineThrottleSourcesFound;
	}
}
