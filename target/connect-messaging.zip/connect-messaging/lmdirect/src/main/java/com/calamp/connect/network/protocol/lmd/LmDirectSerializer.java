package com.calamp.connect.network.protocol.lmd;

import java.nio.ByteBuffer;
import java.util.Arrays;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.MessageContent;
import com.calamp.connect.network.protocol.lmd.serializers.MessageContentSerializer;
import com.calamp.connect.network.protocol.lmd.serializers.MessageHeaderSerializer;
import com.calamp.connect.network.protocol.lmd.serializers.OptionsHeaderSerializer;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw Date: Oct 13, 2010
 */
public class LmDirectSerializer
{
    private static Logger logger                         = LogManager.getLogger(LmDirectSerializer.class);
    private static Logger calAmpMessageLogger            = LogManager.getLogger("calAmpHexMessageLogger");
    private static Logger calAmpDownlinkHexMessageLogger = LogManager.getLogger("calAmpDownlinkHexMessageLogger");

    public static byte[] encode(LMDirectMessage message)
    {
        logger.debug(" encoding the following message " + message);
        byte[] optionsHeader = new OptionsHeaderSerializer().encode(message.getOptionsHeader());
        int optionHeaderLen = (optionsHeader == null) ? 0 : optionsHeader.length;
        byte[] messageHeader = new MessageHeaderSerializer().encode(message.getMessageHeader());
        byte[] messageContents = MessageContentSerializer.encode(message.getMessageContent(), message.getMessageType());
        ByteBuffer byteBuffer = ByteBuffer.allocate(optionHeaderLen + messageHeader.length + messageContents.length);
        if(optionsHeader != null)
        	byteBuffer.put(optionsHeader);
        byteBuffer.put(messageHeader);
        byteBuffer.put(messageContents);
        return byteBuffer.array();
    }

    public static LMDirectMessage decode(byte[] data)
    {
        logger.debug("message received " + Arrays.toString(data));
        String messageInHex = HexUtil.convertToHexString(data);
        logger.debug("message received (hex) " + messageInHex);
        // fix this properly.
        ByteBuffer byteBuffer = ByteBuffer.wrap(data);
        OptionsHeader optionsHeader = new OptionsHeaderSerializer().decode(byteBuffer);
        MessageHeader messageHeader = new MessageHeaderSerializer().decode(byteBuffer);
        MessageType type = messageHeader.getMessageType();
        logger.debug("received a message of type " + type);
        boolean isUplink = (optionsHeader != null && optionsHeader.getMobileId() != null);
        MessageContent messageContent = MessageContentSerializer.decode(byteBuffer, type, isUplink);

        LMDirectMessage message = new LMDirectMessage();
        message.setMessageHeader(messageHeader);
        message.setOptionsHeader(optionsHeader);
        message.setMessageContent(messageContent);
        logger.debug("formatted message " + message);
        if (MessageType.CONFIGURATION_PARAMETER.equals(type) || MessageType.LOCATE_REPORT.equals(type) || MessageType.ACK_NAK.equals(type)
                || MessageType.ID_REPORT.equals(type))
            calAmpDownlinkHexMessageLogger.info("Mobile id: " + message.getOptionsHeader().getMobileId() + " | " + messageInHex);
        else if(message.getOptionsHeader() != null)
            calAmpMessageLogger.info("Mobile id: " + message.getOptionsHeader().getMobileId() + " | " + messageInHex);
        return message;
    }

}
