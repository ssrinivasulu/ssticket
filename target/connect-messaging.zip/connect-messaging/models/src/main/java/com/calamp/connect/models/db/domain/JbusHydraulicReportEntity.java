package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusHydraulicReportEntity extends DeviceEventEntity
{

    private MachineStateEntity machineState;
    // version 1 fields we can remove this fields after all documents in mongo are new structure
    private Double             minHydraulicChargePressure;
    private Double             maxHydraulicChargePressure;
    private Double             avgHydraulicChargePressure;
    private Integer            minHydraulicOilTemperature;
    private Integer            maxHydraulicOilTemperature;
    private Integer            avgHydraulicOilTemperature;

    public JbusHydraulicReportEntity()
    {
        setMsgType(MsgType.JBUS_HYDRAULIC_REPORT);
    }

    public MachineStateEntity getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineStateEntity machineState)
    {
        this.machineState = machineState;
    }

    public Double getMinHydraulicChargePressure()
    {
        return minHydraulicChargePressure;
    }

    public void setMinHydraulicChargePressure(Double minHydraulicChargePressure)
    {
        this.minHydraulicChargePressure = minHydraulicChargePressure;
    }

    public Double getMaxHydraulicChargePressure()
    {
        return maxHydraulicChargePressure;
    }

    public void setMaxHydraulicChargePressure(Double maxHydraulicChargePressure)
    {
        this.maxHydraulicChargePressure = maxHydraulicChargePressure;
    }

    public Double getAvgHydraulicChargePressure()
    {
        return avgHydraulicChargePressure;
    }

    public void setAvgHydraulicChargePressure(Double avgHydraulicChargePressure)
    {
        this.avgHydraulicChargePressure = avgHydraulicChargePressure;
    }

    public Integer getMinHydraulicOilTemperature()
    {
        return minHydraulicOilTemperature;
    }

    public void setMinHydraulicOilTemperature(Integer minHydraulicOilTemperature)
    {
        this.minHydraulicOilTemperature = minHydraulicOilTemperature;
    }

    public Integer getMaxHydraulicOilTemperature()
    {
        return maxHydraulicOilTemperature;
    }

    public void setMaxHydraulicOilTemperature(Integer maxHydraulicOilTemperature)
    {
        this.maxHydraulicOilTemperature = maxHydraulicOilTemperature;
    }

    public Integer getAvgHydraulicOilTemperature()
    {
        return avgHydraulicOilTemperature;
    }

    public void setAvgHydraulicOilTemperature(Integer avgHydraulicOilTemperature)
    {
        this.avgHydraulicOilTemperature = avgHydraulicOilTemperature;
    }

}
