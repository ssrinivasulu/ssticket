package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDtcEvent;
import com.calamp.connect.models.network.Jbus.JbusDtcData;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToToJbusDtcMesssageConverter")
public class DeviceEventToJbusDtcMesssageConverter extends GenericDeviceEventToEventMessageConverter {

	public JbusDtcData convertTo(JbusDtcEvent event) {

		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusDtcData jbusDtcData = mapper.map(event, JbusDtcData.class);
		return jbusDtcData;

	}
	
	public JbusDtcEvent convertFrom(JbusDtcData event) {

		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusDtcEvent jbusDtcEvent = mapper.map(event, JbusDtcEvent.class);
		return jbusDtcEvent;

	}
}
