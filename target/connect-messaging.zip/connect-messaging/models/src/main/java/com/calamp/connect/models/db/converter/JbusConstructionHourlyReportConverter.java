package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusConstructionHourlyReportEntity;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportData;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEvent;

public class JbusConstructionHourlyReportConverter extends
        DeviceEventConverter<JbusConstructionHourlyReportEntity, JbusConstructionHourlyReportEvent>
{

    @Override
    public JbusConstructionHourlyReportEvent domainToModel(JbusConstructionHourlyReportEntity constructionHourlyReportEntity)
    {
        JbusConstructionHourlyReportEvent constructionHourlyReportEvent = super.convert(constructionHourlyReportEntity,
                JbusConstructionHourlyReportEvent.class);

        return customConvert(constructionHourlyReportEntity, constructionHourlyReportEvent);
    }

    @Override
    public JbusConstructionHourlyReportEntity modelToDomain(JbusConstructionHourlyReportEvent constructionHourlyReportEvent)
    {
        JbusConstructionHourlyReportEntity constructionHourlyReportEntity = super.convert(constructionHourlyReportEvent,
                JbusConstructionHourlyReportEntity.class);

        return customConvert(constructionHourlyReportEvent, constructionHourlyReportEntity);
    }

    @Override
    protected JbusConstructionHourlyReportEvent customConvert(JbusConstructionHourlyReportEntity entity, JbusConstructionHourlyReportEvent model)
    {
        if (entity.getDeviceData() != null)
        {
            JbusConstructionHourlyReportData constructionHourlyReportData = (JbusConstructionHourlyReportData) entity.getDeviceData();
            if (constructionHourlyReportData.getDefOrNoxTankLevel() != null)
                model.setDefOrNoxTankLevel(convertHeaderDataToDouble(constructionHourlyReportData.getDefOrNoxTankLevel()));
            if (constructionHourlyReportData.getFuelTankLevel1() != null)
                model.setFuelTankLevel1(convertHeaderDataToDouble(constructionHourlyReportData.getFuelTankLevel1()));
            if (constructionHourlyReportData.getTotalEngineHours() != null)
                model.setTotalEngineHours(convertHeaderDataToDouble(constructionHourlyReportData.getTotalEngineHours()));
        }
        model.setDeviceDataConverted(null);
        return model;
    }

    @Override
    protected JbusConstructionHourlyReportEntity customConvert(JbusConstructionHourlyReportEvent model, JbusConstructionHourlyReportEntity entity)
    {
        return entity;
    }

    @Override
    public JbusConstructionHourlyReportEvent domainToModel(JbusConstructionHourlyReportEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusConstructionHourlyReportEntity> getDomainType()
    {
        return JbusConstructionHourlyReportEntity.class;
    }

    @Override
    public Class<JbusConstructionHourlyReportEvent> getModelType()
    {
        return JbusConstructionHourlyReportEvent.class;
    }

}
