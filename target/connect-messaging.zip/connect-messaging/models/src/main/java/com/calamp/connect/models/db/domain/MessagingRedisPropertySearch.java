package com.calamp.connect.models.db.domain;

/**
 * @author ssrinivasulu
 *
 */
public enum MessagingRedisPropertySearch {
	LocationTime, UUID, FIXSTATUSTRUE;
}
