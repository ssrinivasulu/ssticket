package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Created by agamulo on 5/26/15.
 */

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusDailyReportEntity extends DeviceEventEntity
{
    // version 1 fields we can remove this fields after all documents in mongo are new structure
    private Double engineTotalHours;
    private Double engineIdleHours;
    private Double engineIdleFuel;
    private Double engineOilLevel;
    private Double engineCoolantLevel;
    private Double noxTankLevel;

    public JbusDailyReportEntity()
    {
        setMsgType(MsgType.JBUS_DAILY_REPORT);
    }

    public Double getEngineTotalHours()
    {
        return engineTotalHours;
    }

    public void setEngineTotalHours(Double engineTotalHours)
    {
        this.engineTotalHours = engineTotalHours;
    }

    public Double getEngineIdleHours()
    {
        return engineIdleHours;
    }

    public void setEngineIdleHours(Double engineIdleHours)
    {
        this.engineIdleHours = engineIdleHours;
    }

    public Double getEngineIdleFuel()
    {
        return engineIdleFuel;
    }

    public void setEngineIdleFuel(Double engineIdleFuel)
    {
        this.engineIdleFuel = engineIdleFuel;
    }

    public Double getEngineOilLevel()
    {
        return engineOilLevel;
    }

    public void setEngineOilLevel(Double engineOilLevel)
    {
        this.engineOilLevel = engineOilLevel;
    }

    public Double getEngineCoolantLevel()
    {
        return engineCoolantLevel;
    }

    public void setEngineCoolantLevel(Double engineCoolantLevel)
    {
        this.engineCoolantLevel = engineCoolantLevel;
    }

    public Double getNoxTankLevel()
    {
        return noxTankLevel;
    }

    public void setNoxTankLevel(Double noxTankLevel)
    {
        this.noxTankLevel = noxTankLevel;
    }

}
