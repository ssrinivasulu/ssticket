package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.Address;

/**
 * @author rshields
 * 
 */
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class IdReportEntity extends DeviceEventEntity
{
    private int    scriptVersion;
    private int    configVersion;
    private String appVersion;
    private int    vehicleClass;
    private String imei;
    private String imsi;
    private String min;
    private String iccId;
    private String extension;
    private Double                 latitude;
    private Double                 longitude;
    private Address                address;

    public IdReportEntity()
    {
        setMsgType(MsgType.ID_REPORT);
    }

    public int getScriptVersion()
    {
        return scriptVersion;
    }

    public void setScriptVersion(int scriptVersion)
    {
        this.scriptVersion = scriptVersion;
    }

    public int getConfigVersion()
    {
        return configVersion;
    }

    public void setConfigVersion(int configVersion)
    {
        this.configVersion = configVersion;
    }

    public String getAppVersion()
    {
        return appVersion;
    }

    public void setAppVersion(String appVersion)
    {
        this.appVersion = appVersion;
    }

    public int getVehicleClass()
    {
        return vehicleClass;
    }

    public void setVehicleClass(int vehicleClass)
    {
        this.vehicleClass = vehicleClass;
    }

    public String getImei()
    {
        return imei;
    }

    public void setImei(String imei)
    {
        this.imei = imei;
    }

    public String getImsi()
    {
        return imsi;
    }

    public void setImsi(String imsi)
    {
        this.imsi = imsi;
    }

    public String getMin()
    {
        return min;
    }

    public void setMin(String min)
    {
        this.min = min;
    }

    public String getIccId()
    {
        return iccId;
    }

    public void setIccId(String iccId)
    {
        this.iccId = iccId;
    }

    public String getExtension()
    {
        return extension;
    }

    public void setExtension(String extension)
    {
        this.extension = extension;
    }

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

    
}
