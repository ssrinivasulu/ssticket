package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDailyReportEvent;
import com.calamp.connect.models.network.Jbus.DailyReport;
import com.calamp.connect.models.network.Jbus.DailyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusDailyReportConverter")
public class DeviceEventToJbusDailyReportConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusDailyReportEvent, DailyReport>
{

    @Override
    public DailyReport modelToDomain(JbusDailyReportEvent event)
    {
        return null;
    }

    @Override
    public JbusDailyReportEvent domainToModel(DailyReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusDailyReportEvent jbusDailyReportEvent = mapper.map(event, JbusDailyReportEvent.class);
        if (event.getDeviceData() != null)
        {
            DailyReportData dailyReportData = (DailyReportData) event.getDeviceData();
            if (dailyReportData.getDailyEngineCoolantLevel() != null)
                jbusDailyReportEvent.setEngineCoolantLevel(convertHeaderDataToDouble(dailyReportData.getDailyEngineCoolantLevel()));
            if (dailyReportData.getDailyEngineIdleFuel() != null)
                jbusDailyReportEvent.setEngineIdleFuel(convertHeaderDataToDouble(dailyReportData.getDailyEngineIdleFuel()));
            if (dailyReportData.getDailyEngineIdleHours() != null)
                jbusDailyReportEvent.setEngineIdleHours(convertHeaderDataToDouble(dailyReportData.getDailyEngineIdleHours()));
            if (dailyReportData.getDailyEngineOilLevel() != null)
                jbusDailyReportEvent.setEngineOilLevel(convertHeaderDataToDouble(dailyReportData.getDailyEngineOilLevel()));
            if (dailyReportData.getDailyEngineTotalHours() != null)
                jbusDailyReportEvent.setEngineTotalHours(convertHeaderDataToDouble(dailyReportData.getDailyEngineTotalHours()));
            if (dailyReportData.getDailyNoxTankLevel() != null)
                jbusDailyReportEvent.setNoxTankLevel(convertHeaderDataToDouble(dailyReportData.getDailyNoxTankLevel()));
        }
        return jbusDailyReportEvent;
    }

    @Override
    public JbusDailyReportEvent domainToModel(DailyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<DailyReport> getDomainType()
    {
        return DailyReport.class;
    }

    @Override
    public Class<JbusDailyReportEvent> getModelType()
    {
        return JbusDailyReportEvent.class;
    }
}
