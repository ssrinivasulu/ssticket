package com.calamp.connect.models.util;

import com.calamp.connect.models.messaging.devicecommand.DeviceCommandParameterDecoder;

/**
 * @author Sidlingappa
 *
 */
public class UnsignedIntegerDecoder implements DeviceCommandParameterDecoder<String, Long>
{
    @Override
    public byte[] toBytes(String parameter)
    {
        long unsignedInt = Long.valueOf(parameter);
        byte[] bytes = new byte[4];

        bytes[0] = (byte) ((unsignedInt >> 24) & 0xFF);
        bytes[1] = (byte) ((unsignedInt >> 16) & 0xFF);
        bytes[2] = (byte) ((unsignedInt >> 8) & 0xFF);
        bytes[3] = (byte) (unsignedInt & 0xFF);

        return bytes;
    }

    @Override
    public Long fromBytes(byte[] array)
    {
        long longNum = 0;

        longNum |= ((long) (array[0] & 0xFF)) << 24;
        longNum |= ((long) (array[1] & 0xFF)) << 16;
        longNum |= ((long) (array[2] & 0xFF)) << 8;
        longNum |= (long) (array[3] & 0xFF);

        return longNum;
    }
}
