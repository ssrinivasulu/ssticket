package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusConstructionHourlyReportEntity;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportData;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEventV2;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusConstructionHourlyReportV2Converter extends
        DeviceEventConverter<JbusConstructionHourlyReportEntity, JbusConstructionHourlyReportEventV2>
{

    @Override
    public JbusConstructionHourlyReportEventV2 domainToModel(JbusConstructionHourlyReportEntity constructionHourlyReportEntity)
    {
        JbusConstructionHourlyReportEventV2 constructionHourlyReportEvent = super.convert(constructionHourlyReportEntity,
                JbusConstructionHourlyReportEventV2.class);

        return customConvert(constructionHourlyReportEntity, constructionHourlyReportEvent);
    }

    @Override
    public JbusConstructionHourlyReportEntity modelToDomain(JbusConstructionHourlyReportEventV2 constructionHourlyReportEvent)
    {
        JbusConstructionHourlyReportEntity constructionHourlyReportEntity = super.convert(constructionHourlyReportEvent,
                JbusConstructionHourlyReportEntity.class);

        return customConvert(constructionHourlyReportEvent, constructionHourlyReportEntity);
    }

    @Override
    protected JbusConstructionHourlyReportEventV2 customConvert(JbusConstructionHourlyReportEntity entity, JbusConstructionHourlyReportEventV2 model)
    {
        if (entity.getDeviceData() != null && entity.getDeviceDataConverted() != null)
        {
            model.setDeviceDataConverted((JbusConstructionHourlyReportData)entity.getDeviceDataConverted());
        }
        else
        {
            JbusConstructionHourlyReportData constructionHourlyReportData = new JbusConstructionHourlyReportData();
            if (entity.getDefOrNoxTankLevel() != null)
                constructionHourlyReportData.setDefOrNoxTankLevel(new HeaderData(entity.getDefOrNoxTankLevel().toString(), null));
            if (entity.getFuelTankLevel1() != null)
                constructionHourlyReportData.setFuelTankLevel1(new HeaderData(entity.getFuelTankLevel1().toString(), null));
            if (entity.getTotalEngineHours() != null)
                constructionHourlyReportData.setTotalEngineHours(new HeaderData(entity.getTotalEngineHours().toString(), null));
            entity.setDeviceData(constructionHourlyReportData);
            entity.setDeviceDataConverted(constructionHourlyReportData);
            model.setDeviceDataConverted(constructionHourlyReportData);
        }

        return model;
    }

    @Override
    protected JbusConstructionHourlyReportEntity customConvert(JbusConstructionHourlyReportEventV2 model, JbusConstructionHourlyReportEntity entity)
    {
        entity.setDeviceData(model.getDeviceData());
        entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    public JbusConstructionHourlyReportEventV2 domainToModel(JbusConstructionHourlyReportEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusConstructionHourlyReportEventV2> getModelType()
    {
        return JbusConstructionHourlyReportEventV2.class;
    }

    @Override
    public Class<JbusConstructionHourlyReportEntity> getDomainType()
    {
        return JbusConstructionHourlyReportEntity.class;
    }

}
