package com.calamp.connect.models.db.domain;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.CumulativeOperatingHours;
import com.calamp.connect.models.messaging.Distance;
import com.calamp.connect.models.messaging.EquipmentHeader;
import com.calamp.connect.models.messaging.FuelUsed;
import com.calamp.connect.models.messaging.FuelUsedLast24;
import com.calamp.connect.models.messaging.Location;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class AempMessageEventEntity extends DeviceEventEntity
{
    private EquipmentHeader          equipmentHeader;
    private Location                 location;
    private CumulativeOperatingHours cumulativeOperatingHours;
    private Distance                 distance;
    private FuelUsed                 fuelUsed;
    private FuelUsedLast24           fuelUsedLast24;

    public AempMessageEventEntity()
    {
        setMsgType(MsgType.AEMP);
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }

    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }

    public EquipmentHeader getEquipmentHeader()
    {
        return equipmentHeader;
    }

    public void setEquipmentHeader(EquipmentHeader equipmentHeader)
    {
        this.equipmentHeader = equipmentHeader;
    }

    public Location getLocation()
    {
        return location;
    }

    public void setLocation(Location location)
    {
        this.location = location;
    }

    public CumulativeOperatingHours getCumulativeOperatingHours()
    {
        return cumulativeOperatingHours;
    }

    public void setCumulativeOperatingHours(CumulativeOperatingHours cumulativeOperatingHours)
    {
        this.cumulativeOperatingHours = cumulativeOperatingHours;
    }

    public Distance getDistance()
    {
        return distance;
    }

    public void setDistance(Distance distance)
    {
        this.distance = distance;
    }

    public FuelUsed getFuelUsed()
    {
        return fuelUsed;
    }

    public void setFuelUsed(FuelUsed fuelUsed)
    {
        this.fuelUsed = fuelUsed;
    }

    public FuelUsedLast24 getFuelUsedLast24()
    {
        return fuelUsedLast24;
    }

    public void setFuelUsedLast24(FuelUsedLast24 fuelUsedLast24)
    {
        this.fuelUsedLast24 = fuelUsedLast24;
    }
}
