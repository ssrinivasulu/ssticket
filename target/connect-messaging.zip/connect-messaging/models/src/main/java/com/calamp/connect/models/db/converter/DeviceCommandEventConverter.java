package com.calamp.connect.models.db.converter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.db.domain.DeviceCommandEventEntity.CommandStatus;
import com.calamp.connect.models.messaging.DeviceCommandEvent;
import com.calamp.connect.models.messaging.GeoZoneInformation;
import com.calamp.connect.models.messaging.devicecommand.CommandParamConstant;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandType;
import com.calamp.connect.models.messaging.devicecommand.IdReportRequest;
import com.calamp.connect.models.messaging.devicecommand.LocateReportRequest;
import com.calamp.connect.models.messaging.devicecommand.OtaDownloadRequest;
import com.calamp.connect.models.messaging.devicecommand.ParameterConfigInfo;
import com.calamp.connect.models.messaging.devicecommand.ParameterRequest;
import com.calamp.connect.models.messaging.devicecommand.PegActionRequest;
import com.calamp.connect.models.messaging.devicecommand.RebootRequest;
import com.calamp.connect.models.messaging.devicecommand.SetAndEnableZoneRequest;
import com.calamp.connect.models.messaging.devicecommand.UnitRequest;
import com.calamp.connect.models.messaging.devicecommand.ZoneDecoder;
import com.calamp.connect.models.util.CommanUtil;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class DeviceCommandEventConverter extends DeviceEventConverter<DeviceCommandEventEntity, DeviceCommandEvent>
{

    @Override
    public DeviceCommandEventEntity modelToDomain(DeviceCommandEvent deviceCommandEvent) throws Exception
    {

        DeviceCommandEventEntity deviceCommandEventEntity = super.convert(deviceCommandEvent, DeviceCommandEventEntity.class);

        return customConvert(deviceCommandEvent, deviceCommandEventEntity);

    }

    @Override
    public DeviceCommandEvent domainToModel(DeviceCommandEventEntity deviceCommandEventEntity) throws Exception
    {

        DeviceCommandEvent deviceCommandEvent = super.convert(deviceCommandEventEntity, DeviceCommandEvent.class);

        return customConvert(deviceCommandEventEntity, deviceCommandEvent);

    }

    @Override
    protected DeviceCommandEvent customConvert(DeviceCommandEventEntity entity, DeviceCommandEvent model)
    {
        if (entity.getExternalDeviceId() != null)
        {
            model.setDeviceEsn(entity.getExternalDeviceId());
        }
        if (entity.getCreated() != null)
        {
            model.setCreated(entity.getCreated());
        }
        if (entity.getResponse() != null)
            model.getResponse().setDeviceDataConverted(entity.getResponse().getDeviceDataConverted());
        if (model.getResponse() != null)
        {
            // temp fix need to check this orika mapper
            model.getResponse().setDeviceEsn(null);
        }

        if (entity.getCommand() != null)
        {
            DeviceCommandType commandType = entity.getCommand().getCommandType();
            Map<String, String> params = entity.getCommand().getParameters();
            switch (commandType) {
                case LocateReport:
                    LocateReportRequest locateReportRequest = new LocateReportRequest();
                    if (params != null)
                    {
                        locateReportRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            locateReportRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.LOCATE_ACCUMULATOR_COUNT) != null)
                            locateReportRequest.setNumberOfAccumulators(Integer.valueOf(params.get(CommandParamConstant.LOCATE_ACCUMULATOR_COUNT)));
                    }
                    locateReportRequest.setSent(entity.getSentOn());
                    model.setRequest(locateReportRequest);
                    break;
                case Reboot:
                    RebootRequest rebootRequest = new RebootRequest();
                    if (params != null)
                    {
                        rebootRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            rebootRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                    }
                    rebootRequest.setSent(entity.getSentOn());
                    model.setRequest(rebootRequest);
                    break;
                case IdReport:
                    IdReportRequest idReportRequest = new IdReportRequest();
                    if (params != null)
                    {
                        idReportRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            idReportRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                    }
                    idReportRequest.setSent(entity.getSentOn());
                    model.setRequest(idReportRequest);
                    break;
                case OtaDownload:
                    OtaDownloadRequest otaDownloadRequest = new OtaDownloadRequest();
                    if (params != null)
                    {
                        otaDownloadRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            otaDownloadRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.OTA_DEVICE_TYPE) != null)
                            otaDownloadRequest.setDeviceType(params.get(CommandParamConstant.OTA_DEVICE_TYPE));
                        if (params.get(CommandParamConstant.OTA_FILETYPE) != null)
                            otaDownloadRequest.setFileType(params.get("fileType"));
                        if (params.get(CommandParamConstant.OTA_FILE_LENGTH) != null)
                            otaDownloadRequest.setFileLength(params.get(CommandParamConstant.OTA_FILE_LENGTH));
                        if (params.get(CommandParamConstant.OTA_FILEVERSION) != null)
                            otaDownloadRequest.setFileVersion(params.get(CommandParamConstant.OTA_FILEVERSION));
                        if (params.get(CommandParamConstant.OTA_DOWNLOAD_PROTOCOL) != null)
                            otaDownloadRequest.setDownloadProtocol(params.get(CommandParamConstant.OTA_DOWNLOAD_PROTOCOL));
                        if (params.get(CommandParamConstant.OTA_SERVERNAME) != null)
                            otaDownloadRequest.setServerName(params.get(CommandParamConstant.OTA_SERVERNAME));
                        if (params.get(CommandParamConstant.OTA_FILE_PATH) != null)
                            otaDownloadRequest.setFilePath(params.get(CommandParamConstant.OTA_FILE_PATH));
                        if (params.get(CommandParamConstant.OTA_USERNAME) != null)
                            otaDownloadRequest.setUsername(params.get(CommandParamConstant.OTA_USERNAME));
                        if (params.get(CommandParamConstant.OTA_PASSWORD) != null)
                            otaDownloadRequest.setPassword(params.get(CommandParamConstant.OTA_PASSWORD));
                        if (params.get(CommandParamConstant.OTA_APPLY_DATE) != null)
                            otaDownloadRequest.setApplyDate(params.get(CommandParamConstant.OTA_APPLY_DATE));
                        if (params.get(CommandParamConstant.OTA_CHECKSUM) != null)
                            otaDownloadRequest.setChecksum(params.get(CommandParamConstant.OTA_CHECKSUM));
                        if (params.get(CommandParamConstant.OTA_ATTACHED_DEVICE_ADDRESS) != null)
                            otaDownloadRequest.setAttachedDeviceAddress(params.get(CommandParamConstant.OTA_ATTACHED_DEVICE_ADDRESS));
                    }
                    otaDownloadRequest.setSent(entity.getSentOn());
                    model.setRequest(otaDownloadRequest);
                    break;
                case ParameterRead:
                    ParameterRequest parameterRequest = new ParameterRequest();
                    List<ParameterConfigInfo> parameters = new ArrayList<>();
                    if (params != null)
                    {
                        ParameterConfigInfo configInfo = new ParameterConfigInfo();
                        parameterRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            parameterRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.PARAMETER_IDS) != null && params.get(CommandParamConstant.PARAMETER_INDEXES) != null)
                        {
                            String[] paramIds = params.get(CommandParamConstant.PARAMETER_IDS).split(",");
                            String[] indexes = params.get(CommandParamConstant.PARAMETER_INDEXES).split(",");
                            for (int i = 0; i < paramIds.length; i++)
                            {
                                configInfo.setParameterId(Integer.valueOf(paramIds[i]));
                                configInfo.setParameterIndex(Integer.valueOf(indexes[i]));
                            }
                        }
                        parameters.add(configInfo);
                        parameterRequest.setParameters(parameters);
                    }
                    parameterRequest.setRequestType("read");
                    parameterRequest.setSent(entity.getSentOn());
                    model.setRequest(parameterRequest);
                    break;
                case ParameterWrite:
                    parameterRequest = new ParameterRequest();
                    parameters = new ArrayList<>();
                    if (params != null)
                    {
                        ParameterConfigInfo configInfo = new ParameterConfigInfo();
                        parameterRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            parameterRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.PARAMETER_IDS) != null && params.get(CommandParamConstant.PARAMETER_INDEXES) != null
                                && params.get(CommandParamConstant.PARAMETER_VALUES) != null)
                        {
                            String[] paramIds = params.get(CommandParamConstant.PARAMETER_IDS).split(",");
                            String[] indexes = params.get(CommandParamConstant.PARAMETER_INDEXES).split(",");
                            String[] values = params.get(CommandParamConstant.PARAMETER_VALUES).split(",");
                            for (int i = 0; i < paramIds.length; i++)
                            {
                                if (!paramIds[i].equals("261"))
                                {
                                    configInfo.setParameterId(Integer.valueOf(paramIds[i]));
                                    configInfo.setParameterIndex(Integer.valueOf(indexes[i]));
                                    configInfo.setValue(CommanUtil.hexToByetConversion(values[i]));
                                }
                                else
                                {
                                    configInfo.setParameterId(Integer.valueOf(paramIds[i]));
                                    configInfo.setParameterIndex(Integer.valueOf(indexes[i]));

                                    // configInfo.setValue(new ZoneDecoder().toBytes(values[i]));
                                }
                            }
                        }
                        parameters.add(configInfo);
                        parameterRequest.setParameters(parameters);
                    }
                    parameterRequest.setRequestType("write");
                    parameterRequest.setSent(entity.getSentOn());
                    model.setRequest(parameterRequest);
                    break;
                case PegAction:
                    PegActionRequest pegActionRequest = new PegActionRequest();
                    if (params != null)
                    {
                        pegActionRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            pegActionRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.PEG_ACTION_CODE) != null)
                            pegActionRequest.setPegActionCode(Integer.valueOf(params.get(CommandParamConstant.PEG_ACTION_CODE)));
                        if (params.get(CommandParamConstant.PEG_ACTION_MODIFIER) != null)
                            pegActionRequest.setPegActionModifier(Integer.valueOf(params.get(CommandParamConstant.PEG_ACTION_MODIFIER)));
                    }
                    pegActionRequest.setSent(entity.getSentOn());
                    model.setRequest(pegActionRequest);
                    break;
                case SetAndEnableZone:
                    SetAndEnableZoneRequest setAndEnableZoneRequest = new SetAndEnableZoneRequest();
                    if (params != null)
                    {
                        setAndEnableZoneRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            setAndEnableZoneRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.ZONE_HYSTERESIS) != null)
                            setAndEnableZoneRequest.setHysteresis(Integer.valueOf(params.get(CommandParamConstant.ZONE_HYSTERESIS)));
                        if (params.get(CommandParamConstant.ZONE_NUMBER) != null)
                            setAndEnableZoneRequest.setNumber(Integer.valueOf(params.get(CommandParamConstant.ZONE_NUMBER)));
                        if (params.get(CommandParamConstant.ZONE_SIZE) != null)
                            setAndEnableZoneRequest.setSize(Integer.valueOf(params.get(CommandParamConstant.ZONE_SIZE)));
                    }
                    setAndEnableZoneRequest.setSent(entity.getSentOn());
                    model.setRequest(setAndEnableZoneRequest);
                    break;
                case SetGeoZone:
                    parameterRequest = new ParameterRequest();
                    parameters = new ArrayList<>();
                    if (params != null)
                    {
                        ParameterConfigInfo configInfo = new ParameterConfigInfo();
                        parameterRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            parameterRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        GeoZoneInformation zoneInformation = CommanUtil.getGeoZoneInformation(params);
                        byte[] value = new ZoneDecoder().toBytes(zoneInformation);
                        configInfo.setParameterId(261);
                        if (params.get(CommandParamConstant.GEO_ZONE_ID) != null)
                            configInfo.setParameterIndex(Integer.parseInt(params.get(CommandParamConstant.GEO_ZONE_ID)));
                        configInfo.setValue(value);
                        parameters.add(configInfo);
                        parameterRequest.setParameters(parameters);
                        parameterRequest.setRequestType("write");
                    }
                    parameterRequest.setSent(entity.getSentOn());
                    model.setRequest(parameterRequest);
                    break;
                case UnitRequest:
                    UnitRequest unitRequest = new UnitRequest();
                    if (params != null)
                    {
                        unitRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            unitRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.UNIT_ACTION_CODE) != null)
                            unitRequest.setActionCode(Integer.parseInt(params.get(CommandParamConstant.UNIT_ACTION_CODE)));
                        if (params.get(CommandParamConstant.UNIT_ACTION_NAME) != null)
                            unitRequest.setActionName(params.get(CommandParamConstant.UNIT_ACTION_NAME));
                        if (params.get(CommandParamConstant.UNIT_8BIT_DATA) != null)
                            unitRequest.setData8bit(params.get(CommandParamConstant.UNIT_8BIT_DATA));
                        if (params.get(CommandParamConstant.UNIT_16BIT_DATA) != null)
                            unitRequest.setData16bit(params.get(CommandParamConstant.UNIT_16BIT_DATA));
                        if (params.get(CommandParamConstant.UNIT_32BIT_DATA) != null)
                            unitRequest.setData32bit(params.get(CommandParamConstant.UNIT_32BIT_DATA));
                    }
                    unitRequest.setSent(entity.getSentOn());
                    model.setRequest(unitRequest);
                    break;
                default:
                    break;
            }
        }
        if (!(entity.getStatus().equals(CommandStatus.COMPLETE) || entity.getStatus().equals(CommandStatus.COMPLETED)))
        {
            model.setStatus(DeviceCommandEvent.CommandStatus.PENDING);
        }
        else
        {
            model.setStatus(DeviceCommandEvent.CommandStatus.COMPLETE);
        }
        return model;
    }

    @Override
    protected DeviceCommandEventEntity customConvert(DeviceCommandEvent model, DeviceCommandEventEntity entity)
    {

        return entity;
    }

    @Override
    public DeviceCommandEvent domainToModel(DeviceCommandEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<DeviceCommandEvent> getModelType()
    {
        return DeviceCommandEvent.class;
    }

    @Override
    public Class<DeviceCommandEventEntity> getDomainType()
    {
        return DeviceCommandEventEntity.class;
    }
}
