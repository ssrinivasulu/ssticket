package com.calamp.connect.models.orika.converter;

import ma.glasnost.orika.CustomConverter;
import ma.glasnost.orika.metadata.Type;

import org.joda.time.DateTime;

public class DateTimeToLongTimeConverter extends CustomConverter<Long, DateTime>
{

    @Override
    public DateTime convert(Long source, Type<? extends DateTime> destinationType)
    {
        return new DateTime(source);
    }

}