package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.DataReportContents;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class SelfDescribingJPODEntity extends AppMessageEntity {
	private DataReportContents dataReportContents;
	
	public SelfDescribingJPODEntity(){
		setMsgType(MsgType.SELF_DESCRIBING_JPOD);
	}

	public DataReportContents getDataReportContents() {
		return dataReportContents;
	}

	public void setDataReportContents(DataReportContents dataReportContents) {
		this.dataReportContents = dataReportContents;
	}
	
}
