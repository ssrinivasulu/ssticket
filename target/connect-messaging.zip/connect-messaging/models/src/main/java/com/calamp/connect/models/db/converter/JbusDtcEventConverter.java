package com.calamp.connect.models.db.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.models.db.domain.JbusDtcEventEntity;
import com.calamp.connect.models.messaging.JbusDtcEvent;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusDtcEventConverter extends DeviceEventConverter<JbusDtcEventEntity, JbusDtcEvent>
{
    private Logger logger = LoggerFactory.getLogger(JbusDtcEventConverter.class);
   
    @Override
    public JbusDtcEvent domainToModel(JbusDtcEventEntity jbusDtcEventEntity)
    {
    	JbusDtcEvent jbusDtcEvent = super.convert(jbusDtcEventEntity, JbusDtcEvent.class);

        return customConvert(jbusDtcEventEntity, jbusDtcEvent);

    }

    @Override
    public JbusDtcEventEntity modelToDomain(JbusDtcEvent jbusDtcEvent)
    {
    	JbusDtcEventEntity jbusDtcEventEntity = super.convert(jbusDtcEvent, JbusDtcEventEntity.class);

        return customConvert(jbusDtcEvent, jbusDtcEventEntity);

    }

    @Override
    protected JbusDtcEvent customConvert(JbusDtcEventEntity jbusDtcEventEntity, JbusDtcEvent jbusDtcEvent)
    {
        return jbusDtcEvent;
    }

    @Override
    protected JbusDtcEventEntity customConvert(JbusDtcEvent jbusDtcEvent, JbusDtcEventEntity jbusDtcEventEntity)
    {
        return jbusDtcEventEntity;
    }


    @Override
    public JbusDtcEvent domainToModel(JbusDtcEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }


    @Override
    public Class<JbusDtcEvent> getModelType()
    {
        return JbusDtcEvent.class;
    }

    @Override
    public Class<JbusDtcEventEntity> getDomainType()
    {
        return JbusDtcEventEntity.class;
    }
}
