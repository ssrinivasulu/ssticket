package com.calamp.connect.models.db.domain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Address
{
    private final static Logger logger = LoggerFactory.getLogger(Address.class);
    private String country;
    private String state;
    private String county;
    private String city;
    private String address1;
    private String address2;
    private String crossStreet;
    private Double crossStreetDistance;
    private String stateProvinceCd;
    private String speedLimitMPH;
    private String postalCode;
    private String roadTypeCode;
    private String tollRoadFlag;
    private String firstQuery;
    private String firstResponse;
    private String secondQuery;
    private String secondResponse;
    private Double latitude;
    private Double longitude;
      
    public String getCountry()
    {
        return country;
    }

    public void setCountry(String country)
    {
        this.country = country;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getCounty()
    {
        return county;
    }

    public void setCounty(String county)
    {
        this.county = county;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }


    @Override
    public String toString()
    {
        return "Address{" +
                "country='" + country + '\'' +
                ", state='" + state + '\'' +
                ", county='" + county + '\'' +
                ", city='" + city + '\'' +
                ", address1='" + address1 + '\'' +
                ", address2='" + address2 + '\'' +
                ", crossStreet='" + crossStreet + '\'' +
                ", crossStreetDistance='" + crossStreetDistance + '\'' +
                ", stateProvinceCd='" + stateProvinceCd + '\'' +
                ", speedLimitMPH='" + speedLimitMPH + '\'' +
                ", postalCode='" + postalCode + '\'' +
                ", roadTypeCode='" + roadTypeCode + '\'' +
                ", tollRoadFlag='" + tollRoadFlag + '\'' +
                '}';
    }

    public void setAddress1(String address1)
    {
        this.address1 = address1;
    }

    public void setAddress2(String address2)
    {
        this.address2 = address2;
    }
    public String getAddress1()
    {
        return address1;
    }

    public String getAddress2()
    {
        return address2;
    }

    public void setCrossStreet(String crossStreet)
    {
        this.crossStreet = crossStreet;
    }

    public void setStateProvinceCd(String stateProvinceCd)
    {
        this.stateProvinceCd = stateProvinceCd;
    }

    public void setSpeedLimitMPH(String speedLimitMPH)
    {
        this.speedLimitMPH = speedLimitMPH;
    }

    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }

    public void setRoadTypeCode(String roadTypeCode)
    {
        this.roadTypeCode = roadTypeCode;
    }

    public void setTollRoadFlag(String tollRoadFlag)
    {
        this.tollRoadFlag = tollRoadFlag;
    }


    public boolean equalsIgnoreCase(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Address address = (Address) o;

        if (address1 != null ? !address1.equalsIgnoreCase(address.address1) : address.address1 != null) return false;
        if (address2 != null ? !address2.equalsIgnoreCase(address.address2) : address.address2 != null) return false;
        if (city != null ? !city.equalsIgnoreCase(address.city) : address.city != null) return false;
        if (country != null ? !country.equalsIgnoreCase(address.country) : address.country != null) return false;
        if (county != null ? !county.equalsIgnoreCase(address.county) : address.county != null) return false;
        if (crossStreet != null ? !crossStreet.equalsIgnoreCase(address.crossStreet) : address.crossStreet != null) return false;
        if (postalCode != null ? !postalCode.equalsIgnoreCase(address.postalCode) : address.postalCode != null) return false;
        if (roadTypeCode != null ? !roadTypeCode.equalsIgnoreCase(address.roadTypeCode) : address.roadTypeCode != null)
            return false;
        if (speedLimitMPH != null ? !speedLimitMPH.equalsIgnoreCase(address.speedLimitMPH) : address.speedLimitMPH != null)
            return false;
        if (state != null ? !state.equalsIgnoreCase(address.state) : address.state != null) return false;
        if (stateProvinceCd != null ? !stateProvinceCd.equalsIgnoreCase(address.stateProvinceCd) : address.stateProvinceCd != null)
            return false;
        if (tollRoadFlag != null ? !tollRoadFlag.equalsIgnoreCase(address.tollRoadFlag) : address.tollRoadFlag != null)
            return false;

        return true;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Address address = (Address) o;

        if (address1 != null ? !address1.equals(address.address1) : address.address1 != null) return false;
        if (address2 != null ? !address2.equals(address.address2) : address.address2 != null) return false;
        if (city != null ? !city.equals(address.city) : address.city != null) return false;
        if (country != null ? !country.equals(address.country) : address.country != null) return false;
        if (county != null ? !county.equals(address.county) : address.county != null) return false;
        if (crossStreet != null ? !crossStreet.equals(address.crossStreet) : address.crossStreet != null) return false;
        if (postalCode != null ? !postalCode.equals(address.postalCode) : address.postalCode != null) return false;
        if (roadTypeCode != null ? !roadTypeCode.equals(address.roadTypeCode) : address.roadTypeCode != null)
            return false;
        if (speedLimitMPH != null ? !speedLimitMPH.equals(address.speedLimitMPH) : address.speedLimitMPH != null)
            return false;
        if (state != null ? !state.equals(address.state) : address.state != null) return false;
        if (stateProvinceCd != null ? !stateProvinceCd.equals(address.stateProvinceCd) : address.stateProvinceCd != null)
            return false;
        if (tollRoadFlag != null ? !tollRoadFlag.equals(address.tollRoadFlag) : address.tollRoadFlag != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = country != null ? country.hashCode() : 0;
        result = 31 * result + (state != null ? state.hashCode() : 0);
        result = 31 * result + (county != null ? county.hashCode() : 0);
        result = 31 * result + (city != null ? city.hashCode() : 0);
        result = 31 * result + (address1 != null ? address1.hashCode() : 0);
        result = 31 * result + (address2 != null ? address2.hashCode() : 0);
        result = 31 * result + (crossStreet != null ? crossStreet.hashCode() : 0);
        result = 31 * result + (stateProvinceCd != null ? stateProvinceCd.hashCode() : 0);
        result = 31 * result + (speedLimitMPH != null ? speedLimitMPH.hashCode() : 0);
        result = 31 * result + (postalCode != null ? postalCode.hashCode() : 0);
        result = 31 * result + (roadTypeCode != null ? roadTypeCode.hashCode() : 0);
        result = 31 * result + (tollRoadFlag != null ? tollRoadFlag.hashCode() : 0);
        return result;
    }

    public String getCrossStreet() {
        return crossStreet;
    }

    public String getStateProvinceCd() {
        return stateProvinceCd;
    }

    public String getSpeedLimitMPH() {
        return speedLimitMPH;
    }
    public Integer getSpeedLimitMPHInteger() {
        if(speedLimitMPH == null) {
            return null;
        }

        try
        {
            return Integer.valueOf(speedLimitMPH);
        }
        catch(NumberFormatException e)
        {
            logger.error("Error converting "+speedLimitMPH, e);
            return null;
        }
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getRoadTypeCode() {
        return roadTypeCode;
    }

    public String getTollRoadFlag() {
        return tollRoadFlag;
    }
    public boolean isTollRoad() {
        if(tollRoadFlag==null)
            return false;
        return tollRoadFlag.equalsIgnoreCase("Y");
    }

    public void setFirstQuery(String firstQuery) {
        this.firstQuery = firstQuery;
    }

    public void setFirstResponse(String firstResponse) {
        this.firstResponse = firstResponse;
    }

    public void setSecondQuery(String secondQuery) {
        this.secondQuery = secondQuery;
    }

    public void setSecondResponse(String secondResponse) {
        this.secondResponse = secondResponse;
    }

    public String getFirstQuery() {
        return firstQuery;
    }

    public String getFirstResponse() {
        return firstResponse;
    }

    public String getSecondQuery() {
        return secondQuery;
    }

    public String getSecondResponse() {
        return secondResponse;
    }

    public Double getCrossStreetDistance() {
        return crossStreetDistance;
    }

    public void setCrossStreetDistance(Double crossStreetDistance) {
        this.crossStreetDistance = crossStreetDistance;
    }

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
}
