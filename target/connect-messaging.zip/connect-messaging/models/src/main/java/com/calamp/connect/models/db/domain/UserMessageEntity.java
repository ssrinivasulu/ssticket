package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.UserMessageContainer;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class UserMessageEntity extends AvlEventEntity{
	UserMessageContainer	userMessageContainer;
	
	public UserMessageEntity()
    {
        setMsgType(MsgType.USER);
    }

	public UserMessageContainer getUserMessageContainer() {
		return userMessageContainer;
	}

	public void setUserMessageContainer(UserMessageContainer userMessageContainer) {
		this.userMessageContainer = userMessageContainer;
	}

	
}
