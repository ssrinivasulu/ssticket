package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusHydraulicReportData;
import com.calamp.connect.models.messaging.JbusHydraulicReportEventV2;
import com.calamp.connect.models.network.Jbus.JbusHydraulicReport;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusHydraulicReportV2Converter")
public class DeviceEventToJbusHydraulicReportV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusHydraulicReportEventV2, JbusHydraulicReport>
{

    @Override
    public JbusHydraulicReport modelToDomain(JbusHydraulicReportEventV2 event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusHydraulicReport jbusHydraulic = mapper.map(event, JbusHydraulicReport.class);
        com.calamp.connect.models.network.Jbus.JbusHydraulicReportData deviceData = mapper.map(event.getDeviceData(),
                com.calamp.connect.models.network.Jbus.JbusHydraulicReportData.class);
        com.calamp.connect.models.network.Jbus.JbusHydraulicReportData deviceDataConverted = mapper.map(event.getDeviceDataConverted(),
                com.calamp.connect.models.network.Jbus.JbusHydraulicReportData.class);
        jbusHydraulic.setDeviceData(deviceData);
        jbusHydraulic.setDeviceDataConverted(deviceDataConverted);
        return jbusHydraulic;

    }

    @Override
    public JbusHydraulicReportEventV2 domainToModel(JbusHydraulicReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusHydraulicReportEventV2 jbusHydraulicReportEvent = mapper.map(event, JbusHydraulicReportEventV2.class);
        JbusHydraulicReportData jbusHydraulicReportDataConverted = mapper.map(event.getDeviceDataConverted(), JbusHydraulicReportData.class);
        jbusHydraulicReportEvent.setDeviceDataConverted(jbusHydraulicReportDataConverted);
        JbusHydraulicReportData jbusHydraulicReportData = mapper.map(event.getDeviceData(), JbusHydraulicReportData.class);
        jbusHydraulicReportEvent.setDeviceData(jbusHydraulicReportData);
        return jbusHydraulicReportEvent;
    }

    @Override
    public JbusHydraulicReportEventV2 domainToModel(JbusHydraulicReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusHydraulicReport> getDomainType()
    {
        return JbusHydraulicReport.class;
    }

    @Override
    public Class<JbusHydraulicReportEventV2> getModelType()
    {
        return JbusHydraulicReportEventV2.class;
    }
}
