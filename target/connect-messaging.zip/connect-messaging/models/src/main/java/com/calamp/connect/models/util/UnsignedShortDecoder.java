package com.calamp.connect.models.util;

import com.calamp.connect.models.messaging.devicecommand.DeviceCommandParameterDecoder;

/**
 * @author Sidlingappa
 *
 */
public class UnsignedShortDecoder implements DeviceCommandParameterDecoder<String, Integer>
{
    @Override
    public byte[] toBytes(String parameter)
    {
        int unsignedShort = Integer.valueOf(parameter);
        byte[] bytes = new byte[2];

        bytes[0] = (byte) ((unsignedShort >> 8) & 0xFF);
        bytes[1] = (byte) (unsignedShort & 0xFF);

        return bytes;
    }

    @Override
    public Integer fromBytes(byte[] array)
    {
        int intNum = 0;

        intNum |= (array[0] & 0xFF) << 8;
        intNum |= array[1] & 0xFF;

        return intNum;
    }
}
