package com.calamp.connect.models.mp.domain;

import com.calamp.connect.models.mp.domain.ModuleExecutionStatus.ExecutionStatus;

/**
 * @author Anand
 *
 */
public class ServiceExecutionStatus
{
    private String          serviceName;
    private ExecutionStatus executionStatus;
    private String          comments;

    public String getServiceName()
    {
        return serviceName;
    }

    public void setServiceName(String serviceName)
    {
        this.serviceName = serviceName;
    }

    public ExecutionStatus getExecutionStatus()
    {
        return executionStatus;
    }

    public void setExecutionStatus(ExecutionStatus executionStatus)
    {
        this.executionStatus = executionStatus;
    }

    public String getComments()
    {
        return comments;
    }

    public void setComments(String comments)
    {
        this.comments = comments;
    }
    
    public enum ServiceName
    {
        ALL, deviceAccess, assetAccess, vinAccess, accountAccess, deviceIpUpdate, subscriptionAccess, headerDataConvert, 
        pegBehaviorAccess, pegEventAccess, systemOfUnitsAccess, quantityUnitsAccess, createAutoAsset, dtcLookup, reverseGeoCodeAccess,
        duplicateCheck
    }

}
