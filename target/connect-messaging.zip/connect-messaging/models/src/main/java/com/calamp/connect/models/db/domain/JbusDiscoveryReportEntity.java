package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusDiscoveryReportEntity extends DeviceEventEntity
{
    private MachineStateEntity machineState;
    private Boolean vehicleSpeedFound;
   	private Boolean odometerFound;
    private Boolean totalFuelFound;
    private Boolean vinFound;
    private Boolean batteryVoltageSourcesFound;
    private Boolean discoveryReportSourcesFound1;
    private Boolean discoveryReportSourcesFound2;
    private Boolean discoveryReportSourcesFound3;
    private Boolean discoveryReportSourcesFound4;
    private Boolean fuelTankSourcesFound;
    private Boolean averageFuelTankSourcesFound;
    private Boolean ptoSourcesFound;
    private Boolean ptoSourcesActive; 
    private Boolean engineTorqueSourcesFound;
    private Boolean engineThrottleSourcesFound;

    public JbusDiscoveryReportEntity()
    {
        setMsgType(MsgType.JBUS_DISCOVERY_REPORT);
    }

    public MachineStateEntity getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineStateEntity machineState)
    {
        this.machineState = machineState;
    }

	public Boolean getVehicleSpeedFound() {
		return vehicleSpeedFound;
	}

	public void setVehicleSpeedFound(Boolean vehicleSpeedFound) {
		this.vehicleSpeedFound = vehicleSpeedFound;
	}

	public Boolean getOdometerFound() {
		return odometerFound;
	}

	public void setOdometerFound(Boolean odometerFound) {
		this.odometerFound = odometerFound;
	}

	public Boolean getTotalFuelFound() {
		return totalFuelFound;
	}

	public void setTotalFuelFound(Boolean totalFuelFound) {
		this.totalFuelFound = totalFuelFound;
	}

	public Boolean getVinFound() {
		return vinFound;
	}

	public void setVinFound(Boolean vinFound) {
		this.vinFound = vinFound;
	}

	public Boolean getBatteryVoltageSourcesFound() {
		return batteryVoltageSourcesFound;
	}

	public void setBatteryVoltageSourcesFound(Boolean batteryVoltageSourcesFound) {
		this.batteryVoltageSourcesFound = batteryVoltageSourcesFound;
	}

	public Boolean getDiscoveryReportSourcesFound1() {
		return discoveryReportSourcesFound1;
	}

	public void setDiscoveryReportSourcesFound1(Boolean discoveryReportSourcesFound1) {
		this.discoveryReportSourcesFound1 = discoveryReportSourcesFound1;
	}

	public Boolean getDiscoveryReportSourcesFound2() {
		return discoveryReportSourcesFound2;
	}

	public void setDiscoveryReportSourcesFound2(Boolean discoveryReportSourcesFound2) {
		this.discoveryReportSourcesFound2 = discoveryReportSourcesFound2;
	}

	public Boolean getDiscoveryReportSourcesFound3() {
		return discoveryReportSourcesFound3;
	}

	public void setDiscoveryReportSourcesFound3(Boolean discoveryReportSourcesFound3) {
		this.discoveryReportSourcesFound3 = discoveryReportSourcesFound3;
	}

	public Boolean getDiscoveryReportSourcesFound4() {
		return discoveryReportSourcesFound4;
	}

	public void setDiscoveryReportSourcesFound4(Boolean discoveryReportSourcesFound4) {
		this.discoveryReportSourcesFound4 = discoveryReportSourcesFound4;
	}

	public Boolean getFuelTankSourcesFound() {
		return fuelTankSourcesFound;
	}

	public void setFuelTankSourcesFound(Boolean fuelTankSourcesFound) {
		this.fuelTankSourcesFound = fuelTankSourcesFound;
	}

	public Boolean getAverageFuelTankSourcesFound() {
		return averageFuelTankSourcesFound;
	}

	public void setAverageFuelTankSourcesFound(Boolean averageFuelTankSourcesFound) {
		this.averageFuelTankSourcesFound = averageFuelTankSourcesFound;
	}

	public Boolean getPtoSourcesFound() {
		return ptoSourcesFound;
	}

	public void setPtoSourcesFound(Boolean ptoSourcesFound) {
		this.ptoSourcesFound = ptoSourcesFound;
	}

	public Boolean getPtoSourcesActive() {
		return ptoSourcesActive;
	}

	public void setPtoSourcesActive(Boolean ptoSourcesActive) {
		this.ptoSourcesActive = ptoSourcesActive;
	}

	public Boolean getEngineTorqueSourcesFound() {
		return engineTorqueSourcesFound;
	}

	public void setEngineTorqueSourcesFound(Boolean engineTorqueSourcesFound) {
		this.engineTorqueSourcesFound = engineTorqueSourcesFound;
	}

	public Boolean getEngineThrottleSourcesFound() {
		return engineThrottleSourcesFound;
	}

	public void setEngineThrottleSourcesFound(Boolean engineThrottleSourcesFound) {
		this.engineThrottleSourcesFound = engineThrottleSourcesFound;
	}

    

}
