package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusEventEntity extends DeviceEventEntity
{
    private Double  batteryVoltage1708;
    private Double  batteryVoltage1939;
    private Long    deviceTravelStatusHistoryId;
    private Integer engineCoolantTemperature1708;
    private Integer engineCoolantTemperature1939;
    private Double  engineOilTemperature1708;
    private Double  engineOilTemperature1939;
    private Double  engineSpeed1708;
    private Double  engineSpeed1939;
    private Double  highRezOdometer1939;
    private Long    jbusHistoryEventId;
    private Double  odometer1708;
    private Double  odometer1939;
    private Boolean seatBeltUsed1939;
    private Double  switchedBatteryVoltage1708;
    private Double  switchedBatteryVoltage1939;
    private Double  totalEngineHours1708;
    private Double  totalEngineHours1939;
    private Double  totalFuel1708;
    private Double  totalFuel1939;
    private Double  totalIdleFuel1708;
    private Double  totalIdleFuel1939;
    private Double  totalIdleHours1708;
    private Double  totalIdleHours1939;
    private String  vin1708;
    private String  vin1939;

    public JbusEventEntity()
    {
        setMsgType(MsgType.JBUS);
    }

    public Double getBatteryVoltage1708()
    {
        return batteryVoltage1708;
    }

    public Double getBatteryVoltage1939()
    {
        return batteryVoltage1939;
    }

    public Long getDeviceTravelStatusHistoryId()
    {
        return deviceTravelStatusHistoryId;
    }

    public Integer getEngineCoolantTemperature1708()
    {
        return engineCoolantTemperature1708;
    }

    public Integer getEngineCoolantTemperature1939()
    {
        return engineCoolantTemperature1939;
    }

    public Double getEngineOilTemperature1708()
    {
        return engineOilTemperature1708;
    }

    public Double getEngineOilTemperature1939()
    {
        return engineOilTemperature1939;
    }

    public Double getEngineSpeed1708()
    {
        return engineSpeed1708;
    }

    public Double getEngineSpeed1939()
    {
        return engineSpeed1939;
    }

    public Double getHighRezOdometer1939()
    {
        return highRezOdometer1939;
    }

    public Long getJbusHistoryEventId()
    {
        return jbusHistoryEventId;
    }

    public Double getOdometer1708()
    {
        return odometer1708;
    }

    public Double getOdometer1939()
    {
        return odometer1939;
    }

    public Boolean getSeatBeltUsed1939()
    {
        return seatBeltUsed1939;
    }

    public Double getSwitchedBatteryVoltage1708()
    {
        return switchedBatteryVoltage1708;
    }

    public Double getSwitchedBatteryVoltage1939()
    {
        return switchedBatteryVoltage1939;
    }

    public Double getTotalEngineHours1708()
    {
        return totalEngineHours1708;
    }

    public Double getTotalEngineHours1939()
    {
        return totalEngineHours1939;
    }

    public Double getTotalFuel1708()
    {
        return totalFuel1708;
    }

    public Double getTotalFuel1939()
    {
        return totalFuel1939;
    }

    public Double getTotalIdleFuel1708()
    {
        return totalIdleFuel1708;
    }

    public Double getTotalIdleFuel1939()
    {
        return totalIdleFuel1939;
    }

    public Double getTotalIdleHours1708()
    {
        return totalIdleHours1708;
    }

    public Double getTotalIdleHours1939()
    {
        return totalIdleHours1939;
    }

    public String getVin1708()
    {
        return vin1708;
    }

    public String getVin1939()
    {
        return vin1939;
    }

    public void setBatteryVoltage1708(Double batteryVoltage1708)
    {
        this.batteryVoltage1708 = batteryVoltage1708;
    }

    public void setBatteryVoltage1939(Double batteryVoltage1939)
    {
        this.batteryVoltage1939 = batteryVoltage1939;
    }

    public void setDeviceTravelStatusHistoryId(Long deviceTravelStatusHistoryId)
    {
        this.deviceTravelStatusHistoryId = deviceTravelStatusHistoryId;
    }

    public void setEngineCoolantTemperature1708(Integer engineCoolantTemperature1708)
    {
        this.engineCoolantTemperature1708 = engineCoolantTemperature1708;
    }

    public void setEngineCoolantTemperature1939(Integer engineCoolantTemperature1939)
    {
        this.engineCoolantTemperature1939 = engineCoolantTemperature1939;
    }

    public void setEngineOilTemperature1708(Double engineOilTemperature1708)
    {
        this.engineOilTemperature1708 = engineOilTemperature1708;
    }

    public void setEngineOilTemperature1939(Double engineOilTemperature1939)
    {
        this.engineOilTemperature1939 = engineOilTemperature1939;
    }

    public void setEngineSpeed1708(Double engineSpeed1708)
    {
        this.engineSpeed1708 = engineSpeed1708;
    }

    public void setEngineSpeed1939(Double engineSpeed1939)
    {
        this.engineSpeed1939 = engineSpeed1939;
    }

    public void setHighRezOdometer1939(Double highRezOdometer1939)
    {
        this.highRezOdometer1939 = highRezOdometer1939;
    }

    public void setJbusHistoryEventId(Long jbusHistoryEventId)
    {
        this.jbusHistoryEventId = jbusHistoryEventId;
    }

    public void setOdometer1708(Double odometer1708)
    {
        this.odometer1708 = odometer1708;
    }

    public void setOdometer1939(Double odometer1939)
    {
        this.odometer1939 = odometer1939;
    }

    public void setSeatBeltUsed1939(Boolean seatBeltUsed1939)
    {
        this.seatBeltUsed1939 = seatBeltUsed1939;
    }

    public void setSwitchedBatteryVoltage1708(Double switchedBatteryVoltage1708)
    {
        this.switchedBatteryVoltage1708 = switchedBatteryVoltage1708;
    }

    public void setSwitchedBatteryVoltage1939(Double switchedBatteryVoltage1939)
    {
        this.switchedBatteryVoltage1939 = switchedBatteryVoltage1939;
    }

    public void setTotalEngineHours1708(Double totalEngineHours1708)
    {
        this.totalEngineHours1708 = totalEngineHours1708;
    }

    public void setTotalEngineHours1939(Double totalEngineHours1939)
    {
        this.totalEngineHours1939 = totalEngineHours1939;
    }

    public void setTotalFuel1708(Double totalFuel1708)
    {
        this.totalFuel1708 = totalFuel1708;
    }

    public void setTotalFuel1939(Double totalFuel1939)
    {
        this.totalFuel1939 = totalFuel1939;
    }

    public void setTotalIdleFuel1708(Double totalIdleFuel1708)
    {
        this.totalIdleFuel1708 = totalIdleFuel1708;
    }

    public void setTotalIdleFuel1939(Double totalIdleFuel1939)
    {
        this.totalIdleFuel1939 = totalIdleFuel1939;
    }

    public void setTotalIdleHours1708(Double totalIdleHours1708)
    {
        this.totalIdleHours1708 = totalIdleHours1708;
    }

    public void setTotalIdleHours1939(Double totalIdleHours1939)
    {
        this.totalIdleHours1939 = totalIdleHours1939;
    }

    public void setVin1708(String vin1708)
    {
        this.vin1708 = vin1708;
    }

    public void setVin1939(String vin1939)
    {
        this.vin1939 = vin1939;
    }
}
