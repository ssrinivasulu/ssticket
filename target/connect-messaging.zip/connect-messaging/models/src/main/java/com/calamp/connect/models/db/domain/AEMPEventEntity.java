/**
 * 
 */
package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author Anand
 *
 */
@Document(collection = "AEMPEventEntity")
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
// all fields are included by default
public class AEMPEventEntity extends AvlEventEntity
{
}
