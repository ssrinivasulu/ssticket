package com.calamp.connect.models.datapump.converter;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.ExtendedIdReportDeviceData;
import com.calamp.connect.models.messaging.ExtendedIdReportEvent;
import com.calamp.connect.models.messaging.IdReportEventUtil;
import com.calamp.connect.models.messaging.RouterModemReport;
import com.calamp.connect.models.network.Event.ExtendedIdReportNetworkEvent;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author xwei
 *
 */
@Component("deviceEventToExtendedIdReportEventConverter")
public class DeviceEventToExtendedIdReportEventConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<ExtendedIdReportEvent, ExtendedIdReportNetworkEvent>
{
    @Override
    public ExtendedIdReportNetworkEvent modelToDomain(ExtendedIdReportEvent event)
    {
        ExtendedIdReportNetworkEvent dpEvent = mapperFactory.getMapperFacade().map(event, ExtendedIdReportNetworkEvent.class);
        dpEvent.setNagReceivedTime(new Date(event.getMessageReceivedTime()));
        return dpEvent;
    }

    @Override
    public ExtendedIdReportEvent domainToModel(ExtendedIdReportNetworkEvent entity)
    {
    	ExtendedIdReportEvent extendedIdReportEvent = mapperFactory.getMapperFacade().map(entity, ExtendedIdReportEvent.class);
    	String extension = extendedIdReportEvent.getExtension();
        if(extension == null)
        	return extendedIdReportEvent;
        
        List<RouterModemReport> modemReports = IdReportEventUtil.parseModemReport(extension);
        if(modemReports.size() > 0) {
        	ExtendedIdReportDeviceData deviceData = new ExtendedIdReportDeviceData();
        	deviceData.setModemReports(modemReports);
        	extendedIdReportEvent.setDeviceData(deviceData);
        }
        if(entity.getNagReceivedTime() != null) 
        {
        	extendedIdReportEvent.setEventTime(entity.getNagReceivedTime());
        }
    	return extendedIdReportEvent;
    }

	@Override
	public ExtendedIdReportEvent domainToModel(ExtendedIdReportNetworkEvent domain, boolean buildAssociations) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<ExtendedIdReportEvent> getModelType() {
		return ExtendedIdReportEvent.class;
	}

	@Override
	public Class<ExtendedIdReportNetworkEvent> getDomainType() {
		return ExtendedIdReportNetworkEvent.class;
	}
   
}
