package com.calamp.connect.models.db.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.models.db.domain.JbusDailyReportEntity;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.JbusDailyReportData;
import com.calamp.connect.models.messaging.JbusDailyReportEventV2;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusDailyReportV2Converter extends DeviceEventConverter<JbusDailyReportEntity, JbusDailyReportEventV2>
{
    private Logger logger = LoggerFactory.getLogger(JbusDailyReportV2Converter.class);

    @Override
    public JbusDailyReportEntity modelToDomain(JbusDailyReportEventV2 jbusDailyReportEvent)
    {
        JbusDailyReportEntity jbusDailyReportEntity = super.convert(jbusDailyReportEvent, JbusDailyReportEntity.class);

        return customConvert(jbusDailyReportEvent, jbusDailyReportEntity);

    }

    @Override
    public JbusDailyReportEventV2 domainToModel(JbusDailyReportEntity jbusDailyReportEventEntity)
    {
        JbusDailyReportEventV2 jbusDailyReportEvent = super.convert(jbusDailyReportEventEntity, JbusDailyReportEventV2.class);

        return customConvert(jbusDailyReportEventEntity, jbusDailyReportEvent);

    }

    @Override
    protected JbusDailyReportEntity customConvert(JbusDailyReportEventV2 model, JbusDailyReportEntity entity)
    {
        entity.setDeviceData(model.getDeviceData());
        entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    protected JbusDailyReportEventV2 customConvert(JbusDailyReportEntity entity, JbusDailyReportEventV2 model)
    {
        if (entity.getDeviceData() != null && entity.getDeviceDataConverted() != null)
        {
            model.setDeviceDataConverted((JbusDailyReportData)entity.getDeviceDataConverted());
        }
        else
        {
            JbusDailyReportData dailyReportData = new JbusDailyReportData();
            if (entity.getEngineCoolantLevel() != null)
                dailyReportData.setEngineCoolantLevel(new HeaderData(entity.getEngineCoolantLevel().toString(), null));
            if (entity.getEngineIdleFuel() != null)
                dailyReportData.setEngineIdleFuel(new HeaderData(entity.getEngineIdleFuel().toString(), null));
            if (entity.getEngineIdleHours() != null)
                dailyReportData.setEngineIdleHours(new HeaderData(entity.getEngineIdleHours().toString(), null));
            if (entity.getEngineOilLevel() != null)
                dailyReportData.setEngineOilLevel(new HeaderData(entity.getEngineOilLevel().toString(), null));
            if (entity.getEngineTotalHours() != null)
                dailyReportData.setEngineTotalHours(new HeaderData(entity.getEngineTotalHours().toString(), null));
            if (entity.getNoxTankLevel() != null)
                dailyReportData.setNoxTankLevel(new HeaderData(entity.getNoxTankLevel().toString(), null));
            entity.setDeviceData(dailyReportData);
            entity.setDeviceDataConverted(dailyReportData);
            model.setDeviceDataConverted(dailyReportData);
        }
        return model;
    }

    @Override
    public JbusDailyReportEventV2 domainToModel(JbusDailyReportEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusDailyReportEventV2> getModelType()
    {
        return JbusDailyReportEventV2.class;
    }

    @Override
    public Class<JbusDailyReportEntity> getDomainType()
    {
        return JbusDailyReportEntity.class;
    }
}
