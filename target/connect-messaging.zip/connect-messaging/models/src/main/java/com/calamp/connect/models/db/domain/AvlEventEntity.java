/**
 *
 */
package com.calamp.connect.models.db.domain;

import java.util.List;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.CommGpsStatus;
import com.calamp.connect.models.messaging.CommState;
import com.calamp.connect.models.messaging.ExtendedAccumulatorValues;
import com.calamp.connect.models.messaging.FixStatusAndSatellites;
import com.calamp.connect.models.messaging.GeozoneEvent;
import com.calamp.connect.models.messaging.Inputs;
import com.calamp.connect.models.messaging.UnitStatus;

/**
 * @author SSrinivasulu
 *
 */
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
// all fields are included by default
public class AvlEventEntity extends DeviceEventEntity
{
    private String                    eventType;
    private String                    eventCode;
    private String                    eventLabel;
    private UnitStatus                unitStatus;
    private VbusIndicatorsEntity      vbusIndicators;
    private String                    pegZonesCurrent;
    private String                    pegZonesPrevious;
    private Integer                   carrier;
    private Double                    hdop;
    private Integer                   heading;
    private Double                    latitude;
    private Double                    longitude;
    private Integer                   satellites;
    private Address                   address;
    private FixStatusEntity           gpsFixStatus;
    private boolean                   fixStatus;
    private Inputs                    inputs;
    private CommState                 commState;

    private Double                    odometer;
    private Double                    gpsOdometer;
    private Double                    obdOdometer;
    private Double                    fuelUsage;
    private Long                      altitude;
    private Integer                   rssi;
    private Integer                   speed;

    private AvlHardAccelEvent         avlHardAccelEvent;
    private AssetDeviceInformation    assetDeviceInformation;
    private SpeedEvent                speedEvent;
    private ExtendedAccumulatorValues extendedAccumulatorValues;
    private Long                      engineHourOffset;
    private Long                      odometerOffset;
    
    private CommGpsStatus			  commGpsStatus;
    private FixStatusAndSatellites    fixStatusAndSatellites;
    private List<GeozoneEvent>        geozoneEvents;

    public AvlEventEntity()
    {
        setMsgType(MsgType.AVL);
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }

    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }

    public CommGpsStatus getCommGpsStatus() {
		return commGpsStatus;
	}

	public void setCommGpsStatus(CommGpsStatus commGpsStatus) {
		this.commGpsStatus = commGpsStatus;
	}

	public String getEventType()
    {
        return eventType;
    }

	
    public FixStatusAndSatellites getFixStatusAndSatellites() {
		return fixStatusAndSatellites;
	}

	public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites) {
		this.fixStatusAndSatellites = fixStatusAndSatellites;
	}

	public void setEventType(String eventType)
    {
        this.eventType = eventType;
    }

    public String getEventCode()
    {
        return eventCode;
    }

    public void setEventCode(String eventCode)
    {
        this.eventCode = eventCode;
    }

    public String getEventLabel()
    {
        return eventLabel;
    }

    public void setEventLabel(String eventLabel)
    {
        this.eventLabel = eventLabel;
    }

    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    public VbusIndicatorsEntity getVbusIndicators()
    {
        return vbusIndicators;
    }

    public void setVbusIndicators(VbusIndicatorsEntity vbusIndicators)
    {
        this.vbusIndicators = vbusIndicators;
    }

    public String getPegZonesCurrent()
    {
        return pegZonesCurrent;
    }

    public void setPegZonesCurrent(String pegZonesCurrent)
    {
        this.pegZonesCurrent = pegZonesCurrent;
    }

    public String getPegZonesPrevious()
    {
        return pegZonesPrevious;
    }

    public void setPegZonesPrevious(String pegZonesPrevious)
    {
        this.pegZonesPrevious = pegZonesPrevious;
    }

    public Integer getCarrier()
    {
        return carrier;
    }

    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public Address getAddress()
    {
        return address;
    }

    public void setAddress(Address address)
    {
        this.address = address;
    }

    public FixStatusEntity getGpsFixStatus()
    {
        return gpsFixStatus;
    }

    public void setGpsFixStatus(FixStatusEntity gpsFixStatus)
    {
        this.gpsFixStatus = gpsFixStatus;
    }

    public boolean getFixStatus()
    {
        return fixStatus;
    }

    public void setFixStatus(boolean fixStatus)
    {
        this.fixStatus = fixStatus;
    }

    public Inputs getInputs()
    {
        return inputs;
    }

    public void setInputs(Inputs inputs)
    {
        this.inputs = inputs;
    }

    public CommState getCommState()
    {
        return commState;
    }

    public void setCommState(CommState commState)
    {
        this.commState = commState;
    }

    public Double getOdometer()
    {
        return odometer;
    }

    public void setOdometer(Double odometer)
    {
        this.odometer = odometer;
    }

    public Double getGpsOdometer()
    {
        return gpsOdometer;
    }

    public void setGpsOdometer(Double gpsOdometer)
    {
        this.gpsOdometer = gpsOdometer;
    }

    public Double getObdOdometer()
    {
        return obdOdometer;
    }

    public void setObdOdometer(Double obdOdometer)
    {
        this.obdOdometer = obdOdometer;
    }

    public Double getFuelUsage()
    {
        return fuelUsage;
    }

    public void setFuelUsage(Double fuelUsage)
    {
        this.fuelUsage = fuelUsage;
    }

    public Long getAltitude()
    {
        return altitude;
    }

    public void setAltitude(Long altitude)
    {
        this.altitude = altitude;
    }

    public Integer getRssi()
    {
        return rssi;
    }

    public void setRssi(Integer rssi)
    {
        this.rssi = rssi;
    }

    public Integer getSpeed()
    {
        return speed;
    }

    public void setSpeed(Integer speed)
    {
        this.speed = speed;
    }

    public AvlHardAccelEvent getAvlHardAccelEvent()
    {
        return avlHardAccelEvent;
    }

    public void setAvlHardAccelEvent(AvlHardAccelEvent avlHardAccelEvent)
    {
        this.avlHardAccelEvent = avlHardAccelEvent;
    }

    public AssetDeviceInformation getAssetDeviceInformation()
    {
        return assetDeviceInformation;
    }

    public void setAssetDeviceInformation(AssetDeviceInformation assetDeviceInformation)
    {
        this.assetDeviceInformation = assetDeviceInformation;
    }

    public SpeedEvent getSpeedEvent()
    {
        return speedEvent;
    }

    public void setSpeedEvent(SpeedEvent speedEvent)
    {
        this.speedEvent = speedEvent;
    }

    public ExtendedAccumulatorValues getExtendedAccumulatorValues()
    {
        return extendedAccumulatorValues;
    }

    public void setExtendedAccumulatorValues(ExtendedAccumulatorValues extendedAccumulatorValues)
    {
        this.extendedAccumulatorValues = extendedAccumulatorValues;
    }
    
    public Long getEngineHourOffset()
    {
        return engineHourOffset;
    }

    public void setEngineHourOffset(Long engineHourOffset)
    {
        this.engineHourOffset = engineHourOffset;
    }

    public Long getOdometerOffset()
    {
        return odometerOffset;
    }

    public void setOdometerOffset(Long odometerOffset)
    {
        this.odometerOffset = odometerOffset;
    }

	public List<GeozoneEvent> getGeozoneEvents() {
		return geozoneEvents;
	}

	public void setGeozoneEvents(List<GeozoneEvent> geozoneEvents) {
		this.geozoneEvents = geozoneEvents;
	}

    
}
