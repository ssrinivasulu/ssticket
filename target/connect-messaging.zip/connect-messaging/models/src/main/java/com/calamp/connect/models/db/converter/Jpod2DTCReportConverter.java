package com.calamp.connect.models.db.converter;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.Jpod2DTCReportEntity;
import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.Jpod2DTCReport;
import com.calamp.connect.models.messaging.GpsFixStatus;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class Jpod2DTCReportConverter extends DeviceEventConverter<Jpod2DTCReportEntity, Jpod2DTCReport>
{
    @Override
    protected Jpod2DTCReportEntity customConvert(Jpod2DTCReport model, Jpod2DTCReportEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        if (model.getGpsFixStatus() != null)
        {
            mapper.map(model.getFixStatus(), entity);
        }

        if (model.getDeviceData() != null)
            entity.setDeviceData(model.getDeviceData());

        if (model.getDeviceDataConverted() != null)
            entity.setDeviceDataConverted(model.getDeviceDataConverted());

        return entity;
    }

    @Override
    protected Jpod2DTCReport customConvert(Jpod2DTCReportEntity entity, Jpod2DTCReport model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        Address address = mapper.map(entity.getAddress(), Address.class);
        if (address != null)
        {
            address.setStreet(address.getAddress1());
            address.setAddress1(null);
            model.setAddress(address);
        }

        GpsFixStatus fixStatus = mapper.map(entity, GpsFixStatus.class);

        if (beanContainsData(fixStatus))
        {
            model.setGpsFixStatus(fixStatus);
        }

        if (entity.getDeviceDataConverted() != null)
            model.setDeviceDataConverted((AvlDeviceData)entity.getDeviceDataConverted());

        return model;
    }

    @Override
    public Jpod2DTCReport domainToModel(Jpod2DTCReportEntity entity) throws Exception
    {
        Jpod2DTCReport message = super.convert(entity, Jpod2DTCReport.class);

        return message;
    }

    @Override
    public Jpod2DTCReport domainToModel(Jpod2DTCReportEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Jpod2DTCReportEntity modelToDomain(Jpod2DTCReport message) throws Exception
    {
        Jpod2DTCReportEntity Jpod2DTCReportEntity = super.convert(message, Jpod2DTCReportEntity.class);

        return Jpod2DTCReportEntity;
    }

    @Override
    public Class<Jpod2DTCReport> getModelType()
    {
        return Jpod2DTCReport.class;
    }

    @Override
    public Class<Jpod2DTCReportEntity> getDomainType()
    {
        return Jpod2DTCReportEntity.class;
    }
}
