package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Created by agamulo on 5/26/15.
 */

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusHourlyReportEntity extends DeviceEventEntity
{
    // version 1 fields we can remove this fields after all documents in mongo are new structure
    private Integer engineCoolantTemperature;
    private Double  engineOilTemperature;
    private Integer engineOilPressure;
    private Double  engineCrankcasePressure;
    private Integer engineCoolantPressure;
    private Double  engineBatteryVoltage;
    private Double  engineFuelTankLevel1;
    private Double  engineFuelTankLevel2;
    private Double  transmissionOilTemperature;
    private Double  averageFuelEconomy;

    public JbusHourlyReportEntity()
    {
        setMsgType(MsgType.JBUS_HOURLY_REPORT);
    }

    public Integer getEngineCoolantTemperature()
    {
        return engineCoolantTemperature;
    }

    public void setEngineCoolantTemperature(Integer engineCoolantTemperature)
    {
        this.engineCoolantTemperature = engineCoolantTemperature;
    }

    public Double getEngineOilTemperature()
    {
        return engineOilTemperature;
    }

    public void setEngineOilTemperature(Double engineOilTemperature)
    {
        this.engineOilTemperature = engineOilTemperature;
    }

    public Integer getEngineOilPressure()
    {
        return engineOilPressure;
    }

    public void setEngineOilPressure(Integer engineOilPressure)
    {
        this.engineOilPressure = engineOilPressure;
    }

    public Double getEngineCrankcasePressure()
    {
        return engineCrankcasePressure;
    }

    public void setEngineCrankcasePressure(Double engineCrankcasePressure)
    {
        this.engineCrankcasePressure = engineCrankcasePressure;
    }

    public Integer getEngineCoolantPressure()
    {
        return engineCoolantPressure;
    }

    public void setEngineCoolantPressure(Integer engineCoolantPressure)
    {
        this.engineCoolantPressure = engineCoolantPressure;
    }

    public Double getEngineBatteryVoltage()
    {
        return engineBatteryVoltage;
    }

    public void setEngineBatteryVoltage(Double engineBatteryVoltage)
    {
        this.engineBatteryVoltage = engineBatteryVoltage;
    }

    public Double getEngineFuelTankLevel1()
    {
        return engineFuelTankLevel1;
    }

    public void setEngineFuelTankLevel1(Double engineFuelTankLevel1)
    {
        this.engineFuelTankLevel1 = engineFuelTankLevel1;
    }

    public Double getEngineFuelTankLevel2()
    {
        return engineFuelTankLevel2;
    }

    public void setEngineFuelTankLevel2(Double engineFuelTankLevel2)
    {
        this.engineFuelTankLevel2 = engineFuelTankLevel2;
    }

    public Double getTransmissionOilTemperature()
    {
        return transmissionOilTemperature;
    }

    public void setTransmissionOilTemperature(Double transmissionOilTemperature)
    {
        this.transmissionOilTemperature = transmissionOilTemperature;
    }

    public Double getAverageFuelEconomy()
    {
        return averageFuelEconomy;
    }

    public void setAverageFuelEconomy(Double averageFuelEconomy)
    {
        this.averageFuelEconomy = averageFuelEconomy;
    }

}
