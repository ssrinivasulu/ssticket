package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.DtcDeviceData;
import com.calamp.connect.models.messaging.DtcEventV2;
import com.calamp.connect.models.network.Event;
import com.calamp.focis.framework.converter.ModelEntityConverter;

@Component("deviceEventToDtcEventV2Converter")
public class DeviceEventToDtcEventV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<DtcEventV2, Event.DtcEvent>
{
    @Override
    public Event.DtcEvent modelToDomain(DtcEventV2 event)
    {
        MapperFacade mapper = this.mapperFactory.getMapperFacade();
        Event.DtcEvent dtcEvent = (Event.DtcEvent) mapper.map(event, Event.DtcEvent.class);
        Event.DtcDeviceData deviceDataConverted = (Event.DtcDeviceData) mapper.map(event.getDeviceDataConverted(), Event.DtcDeviceData.class);
        dtcEvent.setDeviceDataConverted(deviceDataConverted);
        Event.DtcDeviceData deviceData = mapper.map(event.getDeviceData(), Event.DtcDeviceData.class);
        dtcEvent.setDeviceData(deviceData);
        return dtcEvent;
    }

    @Override
    public DtcEventV2 domainToModel(Event.DtcEvent event)
    {
        MapperFacade mapper = this.mapperFactory.getMapperFacade();
        DtcEventV2 dtcEvent = (DtcEventV2) mapper.map(event, DtcEventV2.class);
        DtcDeviceData dtcDeviceDataConverted = (DtcDeviceData) mapper.map(event.getDeviceDataConverted(), DtcDeviceData.class);
        dtcEvent.setDeviceDataConverted(dtcDeviceDataConverted);
        DtcDeviceData dtcDeviceData = (DtcDeviceData) mapper.map(event.getDeviceData(), DtcDeviceData.class);
        dtcEvent.setDeviceData(dtcDeviceData);
        
        return dtcEvent;
    }

    @Override
    public DtcEventV2 domainToModel(Event.DtcEvent arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<Event.DtcEvent> getDomainType()
    {
        return Event.DtcEvent.class;
    }

    @Override
    public Class<DtcEventV2> getModelType()
    {
        return DtcEventV2.class;
    }
}