package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.SelfDescribingJPODMessage;
import com.calamp.connect.models.network.Event.AvlDeviceData;
import com.calamp.connect.models.network.Event.SelfDescribingJPODMessageEvent;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author seth
 *
 */
@Component("deviceEventToSelfDescribingJPODMessageConverter")
public class DeviceEventToSelfDescribingJPODMessageConverter extends GenericDeviceEventToEventMessageConverter
		implements ModelEntityConverter<com.calamp.connect.models.messaging.SelfDescribingJPODMessage, SelfDescribingJPODMessageEvent> {

	@Override
	public SelfDescribingJPODMessageEvent modelToDomain(com.calamp.connect.models.messaging.SelfDescribingJPODMessage event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		SelfDescribingJPODMessageEvent SelfDescribingJPODMessageEvent = mapper.map(event, SelfDescribingJPODMessageEvent.class);
		AvlDeviceData avlDeviceDataConverted = mapper.map(event.getDeviceDataConverted(), AvlDeviceData.class);
		SelfDescribingJPODMessageEvent.setDeviceDataConverted(avlDeviceDataConverted);
		AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(), AvlDeviceData.class);
		SelfDescribingJPODMessageEvent.setDeviceData(avlDeviceData);
		return SelfDescribingJPODMessageEvent;

	}

	@Override
	public com.calamp.connect.models.messaging.SelfDescribingJPODMessage domainToModel(SelfDescribingJPODMessageEvent event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		com.calamp.connect.models.messaging.SelfDescribingJPODMessage selfDescribingJPODMessage = mapper.map(event,
				com.calamp.connect.models.messaging.SelfDescribingJPODMessage.class);
		com.calamp.connect.models.messaging.AvlDeviceData avlDeviceDataConverted = mapper
				.map(event.getDeviceDataConverted(), com.calamp.connect.models.messaging.AvlDeviceData.class);
		selfDescribingJPODMessage.setDeviceDataConverted(avlDeviceDataConverted);
		com.calamp.connect.models.messaging.AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(),
				com.calamp.connect.models.messaging.AvlDeviceData.class);
		selfDescribingJPODMessage.setDeviceData(avlDeviceData);
		selfDescribingJPODMessage.setAddress(event.getAddress());
		return selfDescribingJPODMessage;

	}

	@Override
	public SelfDescribingJPODMessage domainToModel(SelfDescribingJPODMessageEvent arg0, boolean arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<SelfDescribingJPODMessageEvent> getDomainType() {
		// TODO Auto-generated method stub
		return SelfDescribingJPODMessageEvent.class;
	}

	@Override
	public Class<SelfDescribingJPODMessage> getModelType() {
		// TODO Auto-generated method stub
		return SelfDescribingJPODMessage.class;
	}
}
