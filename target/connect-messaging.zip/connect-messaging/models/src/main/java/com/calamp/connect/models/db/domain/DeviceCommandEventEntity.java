package com.calamp.connect.models.db.domain;

import java.util.Date;
import java.util.Map;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageRequestEntity;
import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageResponseEntity;
import com.calamp.connect.models.messaging.devicecommand.Command;
import com.calamp.focis.framework.hateoas.Link;

/**
 * This entity class to define DeviceCommand entity mapped with DeviceCommand model.
 *
 */
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class DeviceCommandEventEntity extends DeviceEventEntity
{
    private String                             UUID;
    private Date                               creationDate;
    private String                             deviceId;
    private Integer                            sequenceId;
    private DeviceCommandMessageRequestEntity  request;
    private DeviceCommandMessageResponseEntity response;
    private CommandStatus                      status;
    // v2 DC properties
    private int                                retries;
    private Date                               queuedFor;
    private Date                               sentOn;
    private Date                               completedOn;
    private Link                               device;
    private Command                            command;
    private String                             batchId;
    private int                                batchSeq;
    private boolean                            autoRetry = Boolean.TRUE;
    private RetryReason                        reason;
    private Map<String, String>				   callBack;

    /**
     * This enum class define the different status defined by DeviceCommand.
     */
    public static enum CommandStatus
    {
        PENDING, COMPLETE, // to support v1 request
        CREATED, QUEUED, SENT, COMPLETED, UNDELIVERABLE, EXPIRED_TIME, EXPIRED_ATTEMPTS, CANCELLED, CANCELLED_COMPLETED // new status for V2 request
    }

    /**
     * DeviceCommandEntity constructor set the messageType.
     */
    public DeviceCommandEventEntity()
    {
        setMsgType(MsgType.DEVICE_COMMAND);
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate()
    {
        return creationDate;
    }

    /**
     * @return the deviceId string
     */
    public String getDeviceId()
    {
        return deviceId;
    }

    /**
     * @return the DeviceCommandMessageRequestEntity.
     */
    public DeviceCommandMessageRequestEntity getRequest()
    {
        return request;
    }

    /**
     * @return the DeviceCommandMessageResponseEntity.
     */
    public DeviceCommandMessageResponseEntity getResponse()
    {
        return response;
    }

    /**
     * @return the deviceCommand Status
     */
    public CommandStatus getStatus()
    {
        return status;
    }

    /**
     * @return the uuid
     */
    public String getUUID()
    {
        return UUID;
    }

    /**
     * @param creationDate
     *            the creationDate to set.
     */
    public void setCreationDate(Date creationDate)
    {
        this.creationDate = creationDate;

        setCreated(creationDate);
        setLocationTime(creationDate);
    }

    /**
     * @param deviceId
     *            the deviceId to set.
     */
    public void setDeviceId(String deviceId)
    {
        this.deviceId = deviceId;

        setDeviceGuid(deviceId);
    }

    /**
     * @param request
     *            the deviceCommandMessage request to set.
     */
    public void setRequest(DeviceCommandMessageRequestEntity request)
    {
        this.request = request;
    }

    /**
     * @param response
     *            the deviceCommandMessage response to set.
     */
    public void setResponse(DeviceCommandMessageResponseEntity response)
    {
        this.response = response;
    }

    /**
     * @param status
     *            the status to set.
     */
    public void setStatus(CommandStatus status)
    {
        this.status = status;
    }

    /**
     * @param uUID
     *            the uuid to set.
     */
    public void setUUID(String uUID)
    {
        UUID = uUID;
    }

    /**
     * @return the sequenceId.
     */
    public Integer getSequenceId()
    {
        return sequenceId;
    }

    /**
     * @param sequenceId
     *            the sequenceId to set.
     */
    public void setSequenceId(Integer sequenceId)
    {
        this.sequenceId = sequenceId;
    }

    /**
     * @return the retries.
     */
    public int getRetries()
    {
        return retries;
    }

    /**
     * @param retries
     *            the retries to set.
     */
    public void setRetries(int retries)
    {
        this.retries = retries;
    }

    /**
     * @return the queuedFor
     */
    public Date getQueuedFor()
    {
        return queuedFor;
    }

    /**
     * @param queuedFor
     *            the queuedFor to set.
     */
    public void setQueuedFor(Date queuedFor)
    {
        this.queuedFor = queuedFor;
    }

    /**
     * @return the sentOn
     */
    public Date getSentOn()
    {
        return sentOn;
    }

    /**
     * @param sentOn
     *            the sentOn to set.
     */
    public void setSentOn(Date sentOn)
    {
        this.sentOn = sentOn;
    }

    /**
     * @return the completedOn
     */
    public Date getCompletedOn()
    {
        return completedOn;
    }

    /**
     * @param completedOn
     *            the completedOn to set.
     */
    public void setCompletedOn(Date completedOn)
    {
        this.completedOn = completedOn;
    }

    /**
     * @return the deviceLink
     */
    public Link getDevice()
    {
        return device;
    }

    /**
     * @param device
     *            the deviceLink to set.
     */
    public void setDevice(Link device)
    {
        this.device = device;
    }

    /**
     * @return the command
     */
    public Command getCommand()
    {
        return command;
    }

    /**
     * @param command
     *            the command to set.
     */
    public void setCommand(Command command)
    {
        this.command = command;
    }

    /**
     * @return the batchId.
     */
    public String getBatchId()
    {
        return batchId;
    }

    /**
     * @param batchId
     *            batchId to set.
     */
    public void setBatchId(String batchId)
    {
        this.batchId = batchId;
    }

    /**
     * @return batchSeqence.
     */
    public int getBatchSeq()
    {
        return batchSeq;
    }

    /**
     * @param batchSeq
     *            the batchSeq to set.
     */
    public void setBatchSeq(int batchSeq)
    {
        this.batchSeq = batchSeq;
    }

    /**
     * @return autoRetry is true or false.
     */
    public boolean isAutoRetry()
    {
        return (autoRetry == Boolean.TRUE);
    }

    /**
     * @param autoRetry
     *            the autoRetry to set.
     */
    public void setAutoRetry(boolean autoRetry)
    {
        this.autoRetry = autoRetry;
    }

    /**
     * @return the retryReason.
     */
    public RetryReason getReason()
    {
        return reason;
    }

    /**
     * @param reason
     *            the retryReason to set.
     */
    public void setReason(RetryReason reason)
    {
        this.reason = reason;
    }

	public Map<String, String> getCallBack() {
		return callBack;
	}

	public void setCallBack(Map<String, String> callBack) {
		this.callBack = callBack;
	}

}
