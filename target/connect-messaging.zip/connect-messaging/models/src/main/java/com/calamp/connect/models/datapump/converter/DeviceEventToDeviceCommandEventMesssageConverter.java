package com.calamp.connect.models.datapump.converter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.DeviceCommandEvent;
import com.calamp.connect.models.messaging.DeviceCommandEvent.CommandStatus;
import com.calamp.connect.models.messaging.GeoZoneInformation;
import com.calamp.connect.models.messaging.devicecommand.AckNakResponse;
import com.calamp.connect.models.messaging.devicecommand.CommandParamConstant;
import com.calamp.connect.models.messaging.devicecommand.IdReportRequest;
import com.calamp.connect.models.messaging.devicecommand.LocateReportRequest;
import com.calamp.connect.models.messaging.devicecommand.OtaDownloadRequest;
import com.calamp.connect.models.messaging.devicecommand.ParameterConfigInfo;
import com.calamp.connect.models.messaging.devicecommand.ParameterRequest;
import com.calamp.connect.models.messaging.devicecommand.PegActionRequest;
import com.calamp.connect.models.messaging.devicecommand.RebootRequest;
import com.calamp.connect.models.messaging.devicecommand.SetAndEnableZoneRequest;
import com.calamp.connect.models.messaging.devicecommand.UnitRequest;
import com.calamp.connect.models.messaging.devicecommand.ZoneDecoder;
import com.calamp.connect.models.network.Event.DeviceCommand;
import com.calamp.connect.models.network.Event.DeviceCommandResponse.DeviceCommandResponseTypes;
import com.calamp.connect.models.network.Event.DeviceCommandStatus;
import com.calamp.connect.models.network.Event.DeviceCommandType;
import com.calamp.connect.models.network.Event.DeviceParameterReadResponse;
import com.calamp.connect.models.network.Event.LocateReport;
import com.calamp.connect.models.network.Event.ParameterInfo;
import com.calamp.connect.models.network.Event.ParameterInfo.ReadResponseValueType;
import com.calamp.connect.models.util.CommanUtil;
import com.calamp.focis.framework.converter.ModelEntityConverter;

@Component("deviceEventToDeviceCommandEventMesssageConverter")
public class DeviceEventToDeviceCommandEventMesssageConverter extends GenericDeviceEventToEventMessageConverter
        implements ModelEntityConverter<com.calamp.connect.models.messaging.DeviceCommandEvent, DeviceCommand>
{
    @Override
    public DeviceCommandEvent domainToModel(DeviceCommand event) throws Exception
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        DeviceCommandEvent model = mapper.map(event, DeviceCommandEvent.class);
        if (event.getCommand() != null)
        {
            DeviceCommandType commandType = event.getCommand().getCommandType();
            Map<String, String> params = event.getCommand().getParameters();
            switch (commandType) {
                case LocateReport:
                    LocateReportRequest locateReportRequest = new LocateReportRequest();
                    if (params != null)
                    {
                        locateReportRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            locateReportRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.LOCATE_ACCUMULATOR_COUNT) != null)
                            locateReportRequest.setNumberOfAccumulators(Integer.valueOf(params.get(CommandParamConstant.LOCATE_ACCUMULATOR_COUNT)));
                    }
                    locateReportRequest.setSent(event.getSentOn());
                    model.setRequest(locateReportRequest);
                    break;
                case Reboot:
                    RebootRequest rebootRequest = new RebootRequest();
                    if (params != null)
                    {
                        rebootRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            rebootRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                    }
                    rebootRequest.setSent(event.getSentOn());
                    model.setRequest(rebootRequest);
                    break;
                case IdReport:
                    IdReportRequest idReportRequest = new IdReportRequest();
                    if (params != null)
                    {
                        idReportRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            idReportRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                    }
                    idReportRequest.setSent(event.getSentOn());
                    model.setRequest(idReportRequest);
                    break;
                case OtaDownload:
                    OtaDownloadRequest otaDownloadRequest = new OtaDownloadRequest();
                    if (params != null)
                    {
                        otaDownloadRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            otaDownloadRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.OTA_DEVICE_TYPE) != null)
                            otaDownloadRequest.setDeviceType(params.get(CommandParamConstant.OTA_DEVICE_TYPE));
                        if (params.get(CommandParamConstant.OTA_FILETYPE) != null)
                            otaDownloadRequest.setFileType(params.get("fileType"));
                        if (params.get(CommandParamConstant.OTA_FILE_LENGTH) != null)
                            otaDownloadRequest.setFileLength(params.get(CommandParamConstant.OTA_FILE_LENGTH));
                        if (params.get(CommandParamConstant.OTA_FILEVERSION) != null)
                            otaDownloadRequest.setFileVersion(params.get(CommandParamConstant.OTA_FILEVERSION));
                        if (params.get(CommandParamConstant.OTA_DOWNLOAD_PROTOCOL) != null)
                            otaDownloadRequest.setDownloadProtocol(params.get(CommandParamConstant.OTA_DOWNLOAD_PROTOCOL));
                        if (params.get(CommandParamConstant.OTA_SERVERNAME) != null)
                            otaDownloadRequest.setServerName(params.get(CommandParamConstant.OTA_SERVERNAME));
                        if (params.get(CommandParamConstant.OTA_FILE_PATH) != null)
                            otaDownloadRequest.setFilePath(params.get(CommandParamConstant.OTA_FILE_PATH));
                        if (params.get(CommandParamConstant.OTA_USERNAME) != null)
                            otaDownloadRequest.setUsername(params.get(CommandParamConstant.OTA_USERNAME));
                        if (params.get(CommandParamConstant.OTA_PASSWORD) != null)
                            otaDownloadRequest.setPassword(params.get(CommandParamConstant.OTA_PASSWORD));
                        if (params.get(CommandParamConstant.OTA_APPLY_DATE) != null)
                            otaDownloadRequest.setApplyDate(params.get(CommandParamConstant.OTA_APPLY_DATE));
                        if (params.get(CommandParamConstant.OTA_CHECKSUM) != null)
                            otaDownloadRequest.setChecksum(params.get(CommandParamConstant.OTA_CHECKSUM));
                        if (params.get(CommandParamConstant.OTA_ATTACHED_DEVICE_ADDRESS) != null)
                            otaDownloadRequest.setAttachedDeviceAddress(params.get(CommandParamConstant.OTA_ATTACHED_DEVICE_ADDRESS));
                    }
                    otaDownloadRequest.setSent(event.getSentOn());
                    model.setRequest(otaDownloadRequest);
                    break;
                case ParameterRead:
                    ParameterRequest parameterRequest = new ParameterRequest();
                    List<ParameterConfigInfo> parameters = new ArrayList<>();
                    if (params != null)
                    {
                        ParameterConfigInfo configInfo = new ParameterConfigInfo();
                        parameterRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            parameterRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.PARAMETER_IDS) != null && params.get(CommandParamConstant.PARAMETER_INDEXES) != null)
                        {
                            String[] paramIds = params.get(CommandParamConstant.PARAMETER_IDS).split(",");
                            String[] indexes = params.get(CommandParamConstant.PARAMETER_INDEXES).split(",");
                            for (int i = 0; i < paramIds.length; i++)
                            {
                                configInfo.setParameterId(Integer.valueOf(paramIds[i]));
                                configInfo.setParameterIndex(Integer.valueOf(indexes[i]));
                            }
                        }
                        parameters.add(configInfo);
                        parameterRequest.setParameters(parameters);
                    }
                    parameterRequest.setRequestType("read");
                    parameterRequest.setSent(event.getSentOn());
                    model.setRequest(parameterRequest);
                    break;
                case ParameterWrite:
                    parameterRequest = new ParameterRequest();
                    parameters = new ArrayList<>();
                    if (params != null)
                    {
                        ParameterConfigInfo configInfo = new ParameterConfigInfo();
                        parameterRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            parameterRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.PARAMETER_IDS) != null && params.get(CommandParamConstant.PARAMETER_INDEXES) != null
                                && params.get(CommandParamConstant.PARAMETER_VALUES) != null)
                        {
                            String[] paramIds = params.get(CommandParamConstant.PARAMETER_IDS).split(",");
                            String[] indexes = params.get(CommandParamConstant.PARAMETER_INDEXES).split(",");
                            String[] values = params.get(CommandParamConstant.PARAMETER_VALUES).split(",");
                            for (int i = 0; i < paramIds.length; i++)
                            {
                                if (!paramIds[i].equals("261"))
                                {
                                    configInfo.setParameterId(Integer.valueOf(paramIds[i]));
                                    configInfo.setParameterIndex(Integer.valueOf(indexes[i]));
                                    configInfo.setValue(CommanUtil.hexToByetConversion(values[i]));
                                }
                            }
                        }
                        parameters.add(configInfo);
                        parameterRequest.setParameters(parameters);
                    }
                    parameterRequest.setRequestType("write");
                    parameterRequest.setSent(event.getSentOn());
                    model.setRequest(parameterRequest);
                    break;
                case PegAction:
                    PegActionRequest pegActionRequest = new PegActionRequest();
                    if (params != null)
                    {
                        pegActionRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            pegActionRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.PEG_ACTION_CODE) != null)
                            pegActionRequest.setPegActionCode(Integer.valueOf(params.get(CommandParamConstant.PEG_ACTION_CODE)));
                        if (params.get(CommandParamConstant.PEG_ACTION_MODIFIER) != null)
                            pegActionRequest.setPegActionModifier(Integer.valueOf(params.get(CommandParamConstant.PEG_ACTION_MODIFIER)));
                    }
                    pegActionRequest.setSent(event.getSentOn());
                    model.setRequest(pegActionRequest);
                    break;
                case SetAndEnableZone:
                    SetAndEnableZoneRequest setAndEnableZoneRequest = new SetAndEnableZoneRequest();
                    if (params != null)
                    {
                        setAndEnableZoneRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            setAndEnableZoneRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.ZONE_HYSTERESIS) != null)
                            setAndEnableZoneRequest.setHysteresis(Integer.valueOf(params.get(CommandParamConstant.ZONE_HYSTERESIS)));
                        if (params.get(CommandParamConstant.ZONE_NUMBER) != null)
                            setAndEnableZoneRequest.setNumber(Integer.valueOf(params.get(CommandParamConstant.ZONE_NUMBER)));
                        if (params.get(CommandParamConstant.ZONE_SIZE) != null)
                            setAndEnableZoneRequest.setSize(Integer.valueOf(params.get(CommandParamConstant.ZONE_SIZE)));
                    }
                    setAndEnableZoneRequest.setSent(event.getSentOn());
                    model.setRequest(setAndEnableZoneRequest);
                    break;
                case SetGeoZone:
                    parameterRequest = new ParameterRequest();
                    parameters = new ArrayList<>();
                    if (params != null)
                    {
                        ParameterConfigInfo configInfo = new ParameterConfigInfo();
                        parameterRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            parameterRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        GeoZoneInformation zoneInformation = CommanUtil.getGeoZoneInformation(params);
                        byte[] value = new ZoneDecoder().toBytes(zoneInformation);
                        configInfo.setParameterId(261);
                        if (params.get(CommandParamConstant.GEO_ZONE_ID) != null)
                            configInfo.setParameterIndex(Integer.parseInt(params.get(CommandParamConstant.GEO_ZONE_ID)));
                        configInfo.setValue(value);
                        parameters.add(configInfo);
                        parameterRequest.setParameters(parameters);
                        parameterRequest.setRequestType("write");
                    }
                    parameterRequest.setSent(event.getSentOn());
                    model.setRequest(parameterRequest);
                    break;
                case UnitRequest:
                    UnitRequest unitRequest = new UnitRequest();
                    if (params != null)
                    {
                        unitRequest.setDeviceIpAddress(params.get(CommandParamConstant.DEVICE_IP_ADDRESS));
                        if (params.get(CommandParamConstant.PORT) != null)
                            unitRequest.setPort(Integer.valueOf(params.get(CommandParamConstant.PORT)));
                        if (params.get(CommandParamConstant.UNIT_ACTION_CODE) != null)
                            unitRequest.setActionCode(Integer.parseInt(params.get(CommandParamConstant.UNIT_ACTION_CODE)));
                        if (params.get(CommandParamConstant.UNIT_ACTION_NAME) != null)
                            unitRequest.setActionName(params.get(CommandParamConstant.UNIT_ACTION_NAME));
                        if (params.get(CommandParamConstant.UNIT_8BIT_DATA) != null)
                            unitRequest.setData8bit(params.get(CommandParamConstant.UNIT_8BIT_DATA));
                        if (params.get(CommandParamConstant.UNIT_16BIT_DATA) != null)
                            unitRequest.setData16bit(params.get(CommandParamConstant.UNIT_16BIT_DATA));
                        if (params.get(CommandParamConstant.UNIT_32BIT_DATA) != null)
                            unitRequest.setData32bit(params.get(CommandParamConstant.UNIT_32BIT_DATA));
                    }
                    unitRequest.setSent(event.getSentOn());
                    model.setRequest(unitRequest);
                    break;
                default:
                    break;
            }
           
        }
        model.setStatus(CommandStatus.valueOf(event.getStatus()));

        if (!(event.getStatus().equals(CommandStatus.COMPLETE.toString()) || event.getStatus().equals(CommandStatus.COMPLETED.toString())))
        {
            model.setStatus(DeviceCommandEvent.CommandStatus.PENDING);
        }
        else
        {
            model.setStatus(DeviceCommandEvent.CommandStatus.COMPLETE);
        }
        if (event.getDeviceCommandResponse() != null)
        {
            DeviceCommandResponseTypes type = event.getDeviceCommandResponse().getType();

            switch (type) {
                case STATUS:
                    AckNakResponse ackNakResponse = new AckNakResponse();
                    model.setResponse(ackNakResponse);
                    if (event.getDeviceCommandResponse().getDeviceCommandStatus() != null)
                    {
                        DeviceCommandStatus networkDeviceCommandResponse = event.getDeviceCommandResponse().getDeviceCommandStatus();
                        if (networkDeviceCommandResponse.getStatus() != null)
                        {
                            if (networkDeviceCommandResponse.getStatus().equals(DeviceCommandStatus.DeviceCommandStatuses.SUCCESS))
                            {
                                ackNakResponse.setSuccessfulAck(true);
                            }
                            else
                            {
                                ackNakResponse.setSuccessfulAck(false);
                            }
                        }
                    }
                    if (event.getDeviceCommandResponse().getRawDeviceHexMessage() != null)
                    {
                        ackNakResponse.setRawDeviceHexMessage(event.getDeviceCommandResponse().getRawDeviceHexMessage());
                    }
                    break;

                case READ_RESPONSE:
                    DeviceParameterReadResponse networkParameterResponse = event.getDeviceCommandResponse().getParameterReadResponse();
                    com.calamp.connect.models.messaging.devicecommand.ParameterResponse parameterResponse = new com.calamp.connect.models.messaging.devicecommand.ParameterResponse();
                    List<ParameterInfo> paramInfo = networkParameterResponse.getParameterInfo();
                    List<ParameterConfigInfo> parameters = new ArrayList<ParameterConfigInfo>();
                    for (ParameterInfo param : paramInfo)
                    {
                        if (param.getType().equals(ReadResponseValueType.NUMERIC))
                        {
                            ParameterConfigInfo parameterConfigInfo = new ParameterConfigInfo();
                            parameterConfigInfo.setParameterId(param.getParameterId());
                            parameterConfigInfo.setParameterIndex(param.getParameterIndex());
                            parameterConfigInfo.setValue(param.getValue());
                            parameters.add(parameterConfigInfo);
                            parameterResponse.setParameters(parameters);
                        }

                        if (param.getType().equals(ReadResponseValueType.GEOZONE_INFORMATION))
                        {
                            com.calamp.connect.models.network.Event.GeoZoneInformation geoZoneRequest = param.getGeoInformation();
                            com.calamp.connect.models.messaging.GeoZoneInformation geoZoneInformation = new com.calamp.connect.models.messaging.GeoZoneInformation();
                            geoZoneInformation.setDistanceEast(geoZoneRequest.getDistanceEast());
                            geoZoneInformation.setDistanceNorth(geoZoneRequest.getDistanceNorth());
                            geoZoneInformation.setLatitude(geoZoneRequest.getLatitude());
                            geoZoneInformation.setLongitude(geoZoneRequest.getLongitude());
                            geoZoneInformation.setHysteresis(geoZoneRequest.getHysteresis());
                            geoZoneInformation.setZoneId(geoZoneRequest.getZoneId());
                            geoZoneInformation.setType(com.calamp.connect.models.messaging.GeoZoneType.valueOf(geoZoneRequest.getType().name()));
                            parameterResponse.setGeoZoneInformation(geoZoneInformation);
                        }

                    }
                    if (event.getDeviceCommandResponse().getRawDeviceHexMessage() != null)
                    {
                        parameterResponse.setRawDeviceHexMessage(event.getDeviceCommandResponse().getRawDeviceHexMessage());
                    }
                    model.setResponse(parameterResponse);
                    break;

                case LOCATE_REPORT:
                    LocateReport networkLocateReport = event.getDeviceCommandResponse().getLocateReport();
                    com.calamp.connect.models.messaging.devicecommand.LocateReportResponse locateReportResponse = mapper.map(networkLocateReport,
                            com.calamp.connect.models.messaging.devicecommand.LocateReportResponse.class);
                    com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData locateReportResponseDataConverted = mapper.map(
                            networkLocateReport.getDeviceDataConverted(),
                            com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData.class);
                    locateReportResponse.setDeviceDataConverted(locateReportResponseDataConverted);

                    locateReportResponse.setDeviceDataConverted(locateReportResponseDataConverted);
                    com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData locateReportResponseData = mapper.map(
                            networkLocateReport.getDeviceData(), com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData.class);
                    locateReportResponse.setDeviceData(locateReportResponseData);
                    if (event.getDeviceCommandResponse().getRawDeviceHexMessage() != null)
                    {
                        locateReportResponse.setRawDeviceHexMessage(event.getDeviceCommandResponse().getRawDeviceHexMessage());
                    }
                    model.setResponse(locateReportResponse);
                    break;
            }
            if (event.getDeviceCommandResponse().getRawDeviceHexMessage() != null && model.getResponse() != null)
                model.getResponse().setRawDeviceHexMessage(event.getDeviceCommandResponse().getRawDeviceHexMessage());
        }
        return model;

    }

    @Override
    public DeviceCommandEvent domainToModel(DeviceCommand arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<DeviceCommand> getDomainType()
    {
        return DeviceCommand.class;
    }

    @Override
    public Class<DeviceCommandEvent> getModelType()
    {
        return DeviceCommandEvent.class;
    }

    @Override
    public DeviceCommand modelToDomain(DeviceCommandEvent arg0) throws Exception
    {
        return null;
    }

}
