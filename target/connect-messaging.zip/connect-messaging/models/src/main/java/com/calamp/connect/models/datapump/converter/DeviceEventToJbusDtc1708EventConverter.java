package com.calamp.connect.models.datapump.converter;

import java.util.ArrayList;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDtc1708Event;
import com.calamp.connect.models.messaging.JbusDtc1708Protocol;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToToJbusDtc1708EventConverter")
public class DeviceEventToJbusDtc1708EventConverter extends GenericDeviceEventToEventMessageConverter
{

    public List<JbusDtcDataJ1708> convertTo(JbusDtc1708Event event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        if (event.getJbusDtc1708ProtocolEvents() == null)
            event.setJbusDtc1708ProtocolEvents(new ArrayList<JbusDtc1708Protocol>());
        List<JbusDtcDataJ1708> jbusData1708s = mapper.mapAsList(event.getJbusDtc1708ProtocolEvents(), JbusDtcDataJ1708.class);
        return jbusData1708s;

    }

    public JbusDtc1708Event convertFrom(List<JbusDtcDataJ1708> event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusDtc1708Event jbusDtc1708Event = new JbusDtc1708Event();
        if (event == null)
            event = new ArrayList<JbusDtcDataJ1708>();
        List<JbusDtc1708Protocol> jbusDtc1708Protocol = mapper.mapAsList(event, JbusDtc1708Protocol.class);
        jbusDtc1708Event.setJbusDtc1708ProtocolEvents(jbusDtc1708Protocol);
        return jbusDtc1708Event;

    }
}
