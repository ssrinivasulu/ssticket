package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEvent;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReport;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusConstructionHourlyReportConverter")
public class DeviceEventToJbusConstructionHourlyReportConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusConstructionHourlyReportEvent, ConstructionHourlyReport>
{

    @Override
    public ConstructionHourlyReport modelToDomain(JbusConstructionHourlyReportEvent event)
    {
        return null;
    }

    @Override
    public JbusConstructionHourlyReportEvent domainToModel(ConstructionHourlyReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionHourlyReportEvent constructionHourlyReport = mapper.map(event, JbusConstructionHourlyReportEvent.class);
        if (event.getDeviceData() != null)
        {
            ConstructionHourlyReportData constructionHourlyReportData = (ConstructionHourlyReportData) event.getDeviceData();
            if (constructionHourlyReportData.getDefOrNoxTankLevel() != null)
                constructionHourlyReport.setDefOrNoxTankLevel(convertHeaderDataToDouble(constructionHourlyReportData.getDefOrNoxTankLevel()));
            if (constructionHourlyReportData.getFuelTankLevel1() != null)
                constructionHourlyReport.setFuelTankLevel1(convertHeaderDataToDouble(constructionHourlyReportData.getFuelTankLevel1()));
            if (constructionHourlyReportData.getTotalEngineHours() != null)
                constructionHourlyReport.setTotalEngineHours(convertHeaderDataToDouble(constructionHourlyReportData.getTotalEngineHours()));
        }
        return constructionHourlyReport;
    }

    @Override
    public JbusConstructionHourlyReportEvent domainToModel(ConstructionHourlyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<ConstructionHourlyReport> getDomainType()
    {
        return ConstructionHourlyReport.class;
    }

    @Override
    public Class<JbusConstructionHourlyReportEvent> getModelType()
    {
        return JbusConstructionHourlyReportEvent.class;
    }
}
