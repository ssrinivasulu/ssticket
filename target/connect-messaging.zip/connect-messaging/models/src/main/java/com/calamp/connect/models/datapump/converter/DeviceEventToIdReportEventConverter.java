package com.calamp.connect.models.datapump.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.IdReportDeviceData;
import com.calamp.connect.models.messaging.IdReportEvent;
import com.calamp.connect.models.messaging.IdReportEventUtil;
import com.calamp.connect.models.messaging.RouterModem;
import com.calamp.connect.models.network.Event.IdReportNetworkEvent;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author xwei
 *
 */
@Component("deviceEventToIdReportEventConverter")
public class DeviceEventToIdReportEventConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<IdReportEvent, IdReportNetworkEvent>
{
    @Override
    public IdReportNetworkEvent modelToDomain(IdReportEvent event)
    {
        IdReportNetworkEvent dpEvent = mapperFactory.getMapperFacade().map(event, IdReportNetworkEvent.class);
        dpEvent.setNagReceivedTime(new Date(event.getMessageReceivedTime()));
        return dpEvent;
    }

    @Override
    public IdReportEvent domainToModel(IdReportNetworkEvent entity)
    {
    	IdReportEvent idReportEvent = mapperFactory.getMapperFacade().map(entity, IdReportEvent.class);
    	String extension = idReportEvent.getExtension();
        if(extension == null)
        	return idReportEvent;
        
        Map<String, String> extensionMap = IdReportEventUtil.parseExtensionStr(extension);
        List<RouterModem> modems = IdReportEventUtil.parseModemInfo(extensionMap);
        IdReportDeviceData deviceData = new IdReportDeviceData();
        deviceData.setResourceRevisions(extensionMap.get("RREV"));
        deviceData.setFirmwareVersion(extensionMap.get("FVER"));
        if(modems.size() > 0) {
        	deviceData.setModems(modems);
        }
        if(entity.getNagReceivedTime() != null) 
        {
        	idReportEvent.setEventTime(entity.getNagReceivedTime());
        }
        idReportEvent.setDeviceData(deviceData);
    	return idReportEvent;
    }

	@Override
	public IdReportEvent domainToModel(IdReportNetworkEvent domain, boolean buildAssociations) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<IdReportEvent> getModelType() {
		return IdReportEvent.class;
	}

	@Override
	public Class<IdReportNetworkEvent> getDomainType() {
		return IdReportNetworkEvent.class;
	}
   
}
