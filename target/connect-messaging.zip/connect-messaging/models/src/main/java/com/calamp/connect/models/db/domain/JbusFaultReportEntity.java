package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusFaultReportEntity extends DeviceEventEntity
{
    private MachineStateEntity machineState;
    private Integer            sourceAddress;
    private Integer            device;
    private Integer            function;
    private Integer            failure;

    public JbusFaultReportEntity()
    {
        setMsgType(MsgType.JBUS_FAULT_REPORT);
    }

    public MachineStateEntity getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineStateEntity machineState)
    {
        this.machineState = machineState;
    }

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }

    public Integer getDevice()
    {
        return device;
    }

    public void setDevice(Integer device)
    {
        this.device = device;
    }

    public Integer getFunction()
    {
        return function;
    }

    public void setFunction(Integer function)
    {
        this.function = function;
    }

    public Integer getFailure()
    {
        return failure;
    }

    public void setFailure(Integer failure)
    {
        this.failure = failure;
    }

}
