package com.calamp.connect.services.util;

import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;

import org.apache.commons.io.input.Tailer;
import org.apache.commons.io.input.TailerListener;
import org.apache.commons.io.input.TailerListenerAdapter;

import com.calamp.connect.network.protocol.lmd.LmDirectSerializer;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * @author ssrinivasulu
 *
 */
public class HexLogProcessor {
	private static final int SLEEP = 500;

	public static void main(String[] args) throws Exception {
		TailerListener listener = new HexLogListener();
		Tailer tailer = new Tailer(new File("./HexLogger.log"), listener, SLEEP);
		System.out.println("tailer.getFile().canRead() : "+tailer.getFile().canRead());
		tailer.run();
	}
}

class HexLogListener extends TailerListenerAdapter {
	public void handle(String line) {
		//System.out.println(line);
		String hostName = "localhost"; // dev
		int port = 20510;
		try {
			InetAddress address = InetAddress.getByName(hostName);
			DatagramSocket socket = new DatagramSocket();
			if (line.lastIndexOf("| ") > 0) {
				int startIndex = line.lastIndexOf("| ") + "| ".length();
				System.out.println(line.substring(startIndex));
				byte[] myPayload = HexUtil.convertFromHexString(
						line.substring(startIndex).replace("\n", "").replace("\r", ""));
				LMDirectMessage message = LmDirectSerializer.decode(myPayload);
				((EventReportMessageContent) message.getMessageContent())
						.getLocationStatusInfo().setUpdateTime(new Date());
				myPayload = LmDirectSerializer.encode(message);
				DatagramPacket packet = new DatagramPacket(myPayload, myPayload.length,
						address, port);
				socket.send(packet);
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
