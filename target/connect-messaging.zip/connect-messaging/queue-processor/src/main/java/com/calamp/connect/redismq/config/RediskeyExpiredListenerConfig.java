/**
 * 
 */
package com.calamp.connect.redismq.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisKeyExpiredEvent;

import com.calamp.connect.redismq.cmd.ClearMessageVisibilityTimeAttributesCmd;
import com.calamp.connect.redismq.model.QueueAckExpiryLog;
import com.calamp.connect.redismq.model.QueueDef;

/**
 * @author ssrinivasulu
 *
 */
@Configuration
public class RediskeyExpiredListenerConfig {
	
	@Bean
	ApplicationListener<RedisKeyExpiredEvent<QueueAckExpiryLog>> eventListener(@Autowired ClearMessageVisibilityTimeAttributesCmd clearMessageVisibilityTimeAttributesCmd) {
		return event -> {
			System.out.println(String.format("Received expire event for key=%s with value %s.",
					new String(event.getSource()), event.getValue()));
			QueueAckExpiryLog queueAckExpiryLog = (QueueAckExpiryLog)event.getValue();
			QueueDef queueDef = new QueueDef();
			queueDef.setUid(queueAckExpiryLog.getUid());
			queueDef.setQname(queueAckExpiryLog.getQueueName());
			clearMessageVisibilityTimeAttributesCmd.exec(queueDef);
		};
	}
}
