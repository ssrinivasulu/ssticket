package com.calamp.connect.redismq.cmd;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;
import com.calamp.connect.redismq.model.Validator;

/**
 * Receive the next message from the queue and delete it.
 * <br>
 * Important: This method deletes the message it receives right away.
 * There is no way to receive the message again if something goes wrong while working on the message.
 */
@Service("popMessageCmd")
public class PopMessageCmd extends BaseQueueCmd<List<QueueMessage>> {

	/**
	 * @return {@link QueueMessage} or {@code null} if no message is there.
	 */
	@Override
	public List<QueueMessage> exec(QueueDef queueDef) {
		Validator.create().assertValidQname(queueDef.getQname());
		
		

		QueueDef q = getQueue(queueDef.getQname(), false);
		
		List<List<Object>> result = (List<List<Object>>)  getRedisQueueTemplate().execute(getRedisQueueConfig().getPopMessageScript(), Collections.singletonList(getRedisQueueConfig().getRedisns() + queueDef.getQname()),
				String.valueOf(q.getTs()), String.valueOf(queueDef.getReceiveNoOfMessages()));

		return createQueueMessageList(result);
	}
}
