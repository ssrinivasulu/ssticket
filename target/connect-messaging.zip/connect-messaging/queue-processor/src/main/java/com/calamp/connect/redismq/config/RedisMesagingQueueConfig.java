/**
 * 
 */
package com.calamp.connect.redismq.config;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.script.DefaultRedisScript;

import com.calamp.connect.redismq.model.RedisQueueConfig;

/**
 * @author SSrinivasulu
 *
 */

@Configuration
public class RedisMesagingQueueConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(RedisMesagingQueueConfig.class);

	@Value("${messagingdb.redis.redishostname}")
	private String host;
	@Value("${messagingdb.redis.port}")
	private int port;
	@Value("${redis.queue.timeout:5000}")
	private int timeout;
	@Value("${redis.queue.database:0}")
	private int database;
	@Value("${redis.queue.namespace:'datapump'}")
	private String namespace;
	@Value("${messagingdb.redis.redispasssword:null}")
	private String password;

	@Value("${messagingdb.redis.maxidle}")
	private int redisMaxIdle;
	@Value("${messagingdb.redis.maxtotal}")
	private int redisMaxTotal;
	@Value("${redis.queue.redisns:'datapump:'}")
	private String redisns;

	// ---------------------------------------------------------------- scripts
	private static final String SCRIPT_POPMESSAGE = "local msg = redis.call(\"ZRANGEBYSCORE\", KEYS[1], \"-inf\", ARGV[1], \"WITHSCORES\", \"LIMIT\", \"0\", ARGV[2]) if #msg == 0 then return {} end local o= {} for i=1,#msg, 2 do redis.call(\"HINCRBY\", KEYS[1] .. \":Q\", \"totalrecv\", 1) local mbody = redis.call(\"HGET\", KEYS[1] .. \":Q\", msg[i]) table.insert(o, {msg[i], mbody}) redis.call(\"ZREM\", KEYS[1], msg[i]) redis.call(\"HDEL\", KEYS[1] .. \":Q\", msg[i], msg[i] .. \":rc\", msg[i] .. \":fr\", msg[i] .. \":oct\") end return o";
	private static final String SCRIPT_RECEIVEMESSAGE = "local msg = redis.call(\"ZRANGEBYSCORE\", KEYS[1], \"-inf\", ARGV[1], \"WITHSCORES\", \"LIMIT\", \"0\", ARGV[3]) if #msg == 0 then return {} end local o= {} for i=1,#msg, 2 do redis.call(\"ZADD\", KEYS[1], ARGV[2], msg[i]) redis.call(\"HINCRBY\", KEYS[1] .. \":Q\", \"totalrecv\", 1) local mbody = redis.call(\"HGET\", KEYS[1] .. \":Q\", msg[i]) local rc = redis.call(\"HINCRBY\", KEYS[1] .. \":Q\", msg[i] .. \":rc\", 1) if rc == 1 then redis.call(\"HSET\", KEYS[1] .. \":Q\", msg[i] .. \":fr\", ARGV[1]) redis.call(\"HSET\", KEYS[1] .. \":Q\", msg[i] .. \":oct\", msg[i+1]) o[i]={msg[i], mbody, rc, ARGV[1], msg[i+1]} else local fr = redis.call(\"HGET\", KEYS[1] .. \":Q\", msg[i] .. \":fr\") local oct = redis.call(\"HGET\", KEYS[1] .. \":Q\", msg[i] .. \":oct\") o[i]={msg[i], mbody, rc, fr, oct} end end return o";
	private static final String SCRIPT_CHANGEMESSAGEVISIBILITY = "local msg = redis.call(\"ZSCORE\", KEYS[1], ARGV[1]) if not msg then return 0 end redis.call(\"ZADD\", KEYS[1], ARGV[2], ARGV[1]) return 1";
	private static final String SCRIPT_CLEARMESSAGEVISIBILITY = "local msg = redis.call(\"ZSCORE\", KEYS[1], ARGV[1]) if not msg then return 0 end local fr = redis.call(\"HGET\", KEYS[1] .. \":Q\", ARGV[1] .. \":oct\") redis.call(\"ZADD\", KEYS[1], fr, ARGV[1]) local rc = redis.call(\"HINCRBY\", KEYS[1] .. \":Q\", ARGV[1] .. \":rc\", -1) redis.call(\"HINCRBY\", KEYS[1] .. \":Q\", \"totalrecv\", -1) return 1";

	
	@Bean
	public DefaultRedisScript<Long> changeMessageVisibilityScript() {
		DefaultRedisScript<Long> defaultRedisScript = new DefaultRedisScript<>(SCRIPT_CHANGEMESSAGEVISIBILITY,
				Long.class);
		return defaultRedisScript;
	}
	
	@Bean
	public DefaultRedisScript<Long> clearMessageVisibilityScript() {
		DefaultRedisScript<Long> defaultRedisScript = new DefaultRedisScript<>(SCRIPT_CLEARMESSAGEVISIBILITY,
				Long.class);
		return defaultRedisScript;
	}


	@Bean
	public DefaultRedisScript<List> receiveMessageScript() {
		DefaultRedisScript<List> defaultRedisScript = new DefaultRedisScript<>(SCRIPT_RECEIVEMESSAGE, List.class);
		return defaultRedisScript;
	}

	@Bean
	public DefaultRedisScript<List> popMessageScript() {
		DefaultRedisScript<List> defaultRedisScript = new DefaultRedisScript<>(SCRIPT_POPMESSAGE, List.class);
		return defaultRedisScript;
	}

	@Bean
	public RedisQueueConfig redisQueueConfig() {
		RedisQueueConfig redisQueueConfig = new RedisQueueConfig();
		return redisQueueConfig;
	}
}
