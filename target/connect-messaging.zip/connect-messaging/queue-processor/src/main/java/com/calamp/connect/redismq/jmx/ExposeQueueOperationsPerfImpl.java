/**
 * 
 */
package com.calamp.connect.redismq.jmx;

import static org.junit.Assert.assertNotNull;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.cmd.CreateQueueCmd;
import com.calamp.connect.redismq.cmd.DeleteMessageCmd;
import com.calamp.connect.redismq.cmd.DeleteQueueCmd;
import com.calamp.connect.redismq.cmd.GetQueueAttributesCmd;
import com.calamp.connect.redismq.cmd.PopMessageCmd;
import com.calamp.connect.redismq.cmd.ReceiveMessageCmd;
import com.calamp.connect.redismq.cmd.SendMessageCmd;
import com.calamp.connect.redismq.model.QueueAttributes;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;
import com.calamp.connect.redismq.model.RedisSMQException;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author ssrinivasulu
 *
 */
@Service("exposeQueueOperationsPerf")
@ManagedResource(objectName = "bean:name=exposeQueueOperationsPerfImpl,type=ExposeQueueOperationsPerf", description = "Redis queue processor operations performance testing")
public class ExposeQueueOperationsPerfImpl implements ExposeQueueOperationsPerf {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ExposeQueueOperationsPerfImpl.class);

	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private GetQueueAttributesCmd getQueueAttributesCmd;
	@Autowired
	private ReceiveMessageCmd receiveMessageCmd;
	@Autowired
	private PopMessageCmd popMessageCmd;
	@Autowired
	private SendMessageCmd sendMessageCmd;
	@Autowired
	private DeleteMessageCmd deleteMessageCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	private Integer  numberOfSeconds;
	
	private String queueName;
	
	private static final ObjectMapper JSON_MAPPER = new ObjectMapper();
	
	private ExecutorService threadPool = null;
	private Hashtable<String, Future<ArrayList<QueueDef>>> listOfThreadPoolFuture = new Hashtable<String, Future<ArrayList<QueueDef>>>();

	@ManagedAttribute(description="Get execution time in number of seconds")
	public Integer getNumberOfSeconds() {
		return numberOfSeconds;
	}

	@ManagedAttribute(description="Set execution time in number of seconds")
	public void setNumberOfSeconds(Integer numberOfSeconds) {
		this.numberOfSeconds = numberOfSeconds;
	}

	@ManagedAttribute(description="Set queue name")
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	@Override
	@ManagedOperation(description = "Retrive QueueAttributes")
    @ManagedOperationParameters({@ManagedOperationParameter(name = "queueName", description = "Set queue name to fetch queue attributes")})
	public String retriveQueueAttributes(String queueName) throws Exception {
		ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
		LOGGER.debug("getQueueAttributes start time :"+new Date(threadMXBean.getCurrentThreadCpuTime()));
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(queueName);;
		QueueAttributes queueAttributes = getQueueAttributesCmd.exec(queueDef);	
		JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		LOGGER.debug("getQueueAttributes end time :"+new Date(threadMXBean.getCurrentThreadCpuTime()));
		return JSON_MAPPER.writeValueAsString(queueAttributes);
	}
	
	@Override
	@ManagedOperation(description = "Execute Create, SendMessage Performance Testing")
    @ManagedOperationParameters({@ManagedOperationParameter(name = "numberOfQueues", description = "Nuber of seconds to run"), 
    	@ManagedOperationParameter(name = "numberOfMessages", description = "Nuber of seconds to run"), 
    	@ManagedOperationParameter(name = "cleanup", description = "Cleaup messages after test execution")})
	public String[] executeCreateSendMessagePerfTesting(int numberOfQueues, int numberOfMessages, boolean cleanup) throws Exception {
		ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
		QueueDef queueDef;
		LOGGER.debug("executeCreateSendMessagePerfTesting start time :"+new Date(threadMXBean.getCurrentThreadCpuTime()));
		threadPool = Executors.newFixedThreadPool(numberOfQueues);
		Future<ArrayList<QueueDef>> future = null;
		for (int i = 0; i < numberOfQueues; i++) {
			queueDef = new QueueDef();
			queueDef.setQname("Perf_Temp_Queue_"+i);	
			try {
				createQueueCmd.exec(queueDef);
			}
			catch(RedisSMQException ex){
				ex.printStackTrace();
			}
			future = threadPool.submit(new CreateSendMessageQueueProcessor(queueDef, numberOfMessages));
			listOfThreadPoolFuture.put(queueDef.getQname(), future);
		}
		final ArrayList<String> results =new ArrayList<String>(numberOfQueues);
		listOfThreadPoolFuture.forEach((queueName, futureTaskStatus)->{
			System.out.println("QueueName : " + queueName + " Count : " + futureTaskStatus.isDone());
			try {
				while(true) {
					if(futureTaskStatus.isDone()){
						//futureTaskStatus.cancel(true);
						QueueDef queueDef1 = new QueueDef();
						queueDef1.setQname(queueName);;
						QueueAttributes queueAttributes = getQueueAttributesCmd.exec(queueDef1);	
						JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
						results.add(JSON_MAPPER.writeValueAsString(queueAttributes));
						LOGGER.debug("Message creation for Queue name "+ queueName + " Completed");
						
						if(cleanup) {
							ArrayList<QueueDef> queueMessages = futureTaskStatus.get();
							queueMessages.forEach(queueDef11 -> deleteMessageCmd.exec(queueDef11));
							//Optional<QueueDef> firstElement = queueMessages.stream().findFirst();
							//deleteQueueCmd.exec(firstElement.get());
							/*FutureTask<String> futureTask = new FutureTask<>(new DeleteMessageQueueProcessor(queueMessages));
							Thread t=new Thread(futureTask);
							t.start();
							*/
						}
						break;
					}
				}	
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		LOGGER.debug("executeCreateSendMessagePerfTesting end time :"+new Date(threadMXBean.getCurrentThreadCpuTime()));
		
		/*if(cleanup) {
			queueMessages.forEach(queueDef -> deleteMessageCmd.exec(queueDef));
			Optional<QueueDef> firstElement = queueMessages.stream().findFirst();
			//deleteQueueCmd.exec(firstElement.get());
			
			/*FutureTask<String> futureTask = new FutureTask<>(new DeleteMessageQueueProcessor(queueMessages));
			Thread t=new Thread(futureTask);
			t.start();
			*/
		//}
		return results.toArray(new String[results.size()]);
	}

	/* (non-Javadoc)
	 * @see com.calamp.connect.redismq.jmx.ExposeQueueOperationsPerf#executePopQueueMessagePerfTesting()
	 */
	@Override
	@ManagedOperation(description = "Execute POP message flow Performance Testing")
    @ManagedOperationParameters({@ManagedOperationParameter(name = "queueName", description = "Set queue name to fetch queue attributes"), 
    	@ManagedOperationParameter(name = "numberOfMessages", description = "Nuber of messages to be fetched")})
	public ArrayList<String> executePopQueueMessagePerfTesting(String queueName, int numberOfMessages) throws Exception {
		ThreadMXBean threadMXBean =
	            ManagementFactory.getThreadMXBean();
		final ArrayList<String> results =new ArrayList<String>(numberOfMessages);
		LOGGER.debug("executePopQueueMessagePerfTesting start time :"+new Date(threadMXBean.getCurrentThreadCpuTime()));
		QueueDef queueDef;
		queueDef = new QueueDef();
		queueDef.setQname(queueName);	
		List<QueueMessage> msgs = new ArrayList<QueueMessage>(numberOfMessages);
		if(numberOfMessages>999){
			for (int j = 0; j < numberOfMessages; j+=999) {
				queueDef.setReceiveNoOfMessages(999);
				msgs.addAll(popMessageCmd.exec(queueDef));
				if(msgs.size()==999)
					continue;
				else
					break;
			}
		}
		if(msgs.size()==0 || msgs.size()!=numberOfMessages) {
			queueDef.setReceiveNoOfMessages(numberOfMessages-msgs.size());
			msgs.addAll(popMessageCmd.exec(queueDef));
		}
		JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		for (Iterator iterator = msgs.iterator(); iterator.hasNext();) {
			QueueMessage queueMessage = (QueueMessage) iterator.next();
			results.add(JSON_MAPPER.writeValueAsString(queueMessage));
		}
		
		LOGGER.debug("executePopQueueMessagePerfTesting end time :"+new Date(threadMXBean.getCurrentThreadCpuTime()));
		return results;
	}

	@Override
	@ManagedOperation(description = "Execute Receive message flow Performance Testing")
	public void executeReceiveMessagePerfTesting() throws Exception {

	}
	
	class CreateSendMessageQueueProcessor implements Callable<ArrayList<QueueDef>> {
		private QueueDef queueDef;
		private int numberOfMessages;
		private ArrayList<QueueDef> queueMessages;
		public CreateSendMessageQueueProcessor(QueueDef queueDefObj, int numberOfMessages) {
			this.queueDef = queueDefObj;
			this.numberOfMessages = numberOfMessages;
			this.queueMessages = new ArrayList<>(numberOfMessages);
			//this.cleanup = cleanup;
		}

		@Override
		public ArrayList<QueueDef> call() throws Exception{
			for (int i = 0; i < numberOfMessages; i++) {
				queueDef.setMessage("Adding Test message, for performance testing");
				QueueMessage queueMessage = sendMessageCmd.exec(queueDef);
				assertNotNull(queueMessage.getId());
				QueueDef queueDef = new QueueDef();
				queueDef.setQname(queueDef.getQname());
				queueDef.setUid(queueMessage.getId());
				queueMessages.add(queueDef);
			}
			
			return queueMessages;
		}

		public QueueDef getQueueDef() {
			return queueDef;
		}

		public void setQueueDef(QueueDef queueDef) {
			this.queueDef = queueDef;
		}
	}
	
	/*class DeleteMessageQueueProcessor implements Callable<String> {
<<<<<<< HEAD
=======
<<<<<<< HEAD
=======
=======
	class DeleteMessageQueueProcessor implements Callable<String> {
>>>>>>> ba8a57020cc4fa45f25693d2e87452fccb73174c
>>>>>>> ae4c6b6df8e33f1960d5f90330113f83a284b05b
>>>>>>> a87316ccaa4a1a2dc57f328d8db8fcb60ef69eec
		private ArrayList<QueueDef> queueMessages;
		public DeleteMessageQueueProcessor(ArrayList<QueueDef> queueMessagesDefObj) {
			this.queueMessages = queueMessagesDefObj;
		}

		@Override
		public String call() throws Exception{
			queueMessages.forEach(queueDef -> deleteMessageCmd.exec(queueDef));
			Optional<QueueDef> firstElement = queueMessages.stream().findFirst();
			deleteQueueCmd.exec(firstElement.get());
			return "SUCCESS";
		}
<<<<<<< HEAD
	}*/

}
