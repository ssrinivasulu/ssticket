package com.calamp.connect.redismq.cmd;

import org.junit.Test;
import org.springframework.context.annotation.Profile;

import com.calamp.connect.redismq.model.Util;

import static org.junit.Assert.assertEquals;
@Profile("test")
public class UtilTest {

	@Test
	public void testFormatZeroPad() {
		assertEquals("123", Util.formatZeroPad("123", 1));
		assertEquals("123", Util.formatZeroPad("123", 2));
		assertEquals("123", Util.formatZeroPad("123", 3));
		assertEquals("0123", Util.formatZeroPad("123", 4));
		assertEquals("00123", Util.formatZeroPad("123", 5));
		assertEquals("000123", Util.formatZeroPad("123", 6));
	}

	@Test
	public void testMakeId() {
		assertEquals(3, Util.makeId(3).length());
	}

}
