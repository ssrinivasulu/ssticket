/**
 * 
 */
package com.calamp.connect.redismq.cmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.redismq.Application;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.RedisSMQException;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})
public class RQCreateGetDeleteCmdTestIT extends AbstractQueueCmdTest{

	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;

	@Test
	public void testCreateQueue() {

		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		int result = createQueueCmd.exec(queueDef);

		assertEquals(1, result);

		queueDef = createQueueCmd.getQueue(TEST_QNAME, false);

		Assert.assertEquals(TEST_QNAME, queueDef.getQname());
		Assert.assertEquals(65536, queueDef.getMaxsize());
	}
	
	@Test
	public void testCreateQueue_existingName() {
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		try {
			createQueueCmd.exec(queueDef);
			fail();
		}
		catch (RedisSMQException e) {
			// ignore
		}

		// cleanup

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testDeleteQueue_noQueue() {
		
		try {
			QueueDef queueDef = new QueueDef();
			queueDef.setQname(TEST_QNAME);	
			deleteQueueCmd.exec(queueDef);
			//fail();
		}
		catch (Exception ex) {
			// ignore
		}
	}
	
	@Test
	public void testGetQueue_missingQueue() {
		try {
			QueueDef queueDef = createQueueCmd.getQueue("nonexisting", false);
			fail();
		}
		catch (Exception e) {
			// ignore
		}

	}
	
	
}
