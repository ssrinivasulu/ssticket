package com.calamp.connect.redismq.cmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.redismq.Application;
import com.calamp.connect.redismq.model.QueueAttributes;
import com.calamp.connect.redismq.model.QueueDef;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})
public class QueueAttributesTestIT extends AbstractQueueCmdTest{
	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private ReceiveMessageCmd receiveMessageCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	@Autowired
	private GetQueueAttributesCmd getQueueAttributesCmd;
	@Autowired
	private SetQueueAttributesCmd setQueueAttributesCmd;
	@Autowired
	private SendMessageCmd sendMessageCmd;
	
	
	@Test
	public void testGetQueueAttributes() {

		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);		
		createQueueCmd.exec(queueDef);

		queueDef.setMessage("Hello1");
		sendMessageCmd.exec(queueDef);
		receiveMessageCmd.exec(queueDef);
		
		queueDef.setMessage("Hello2");
		sendMessageCmd.exec(queueDef);
		receiveMessageCmd.exec(queueDef);

		QueueAttributes qa = getQueueAttributesCmd.exec(queueDef);

		assertNotNull(qa);
		assertEquals(0, qa.getDelay());
		assertEquals(2, qa.getTotalSent());
		assertEquals(2, qa.getTotalRecv());
		assertEquals(2, qa.getMsgs());
		assertEquals(2, qa.getHiddenMsgs());

		// cleanup

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testSetQueueAttributes_noChange() throws InterruptedException {
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);		
		createQueueCmd.exec(queueDef);

		try {
			setQueueAttributesCmd.exec(queueDef);
			//fail();
		}
		catch (Exception ignore) {}
		// cleanup

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testSetQueueAttributes() throws InterruptedException {
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		Thread.sleep(1000);

		queueDef.setDelay(100);
		QueueAttributes qa =setQueueAttributesCmd.exec(queueDef);

		assertEquals(100, qa.getDelay());
		assertTrue(qa.getModified() > qa.getCreated());

		// cleanup
		deleteQueueCmd.exec(queueDef);
	}
}
