/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.calamp.connect.messagingdb.config.db.MessagingDBLocalConfig;
import com.calamp.connect.messagingdb.dao.AvlEventRedisDao;
import com.calamp.connect.messagingdb.repository.AvlEventMongoRepository;
import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MsgType;

/**
 * User: SSrinivasulu Date:04/18/14
 *
 */
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MessagingDBLocalConfig.class})
public class AvlEventServiceTest extends AbstractMessagingDBServiceTest
{
	private AvlEventServiceImpl avlEventService;
	protected AvlEventMongoRepository avlEventMongoRepository;
	private AvlEventRedisDao avlEventRedisDao;
	
	/*
	@Before
    public void setUp()
    {
		avlEventMongoDao = mock(AvlEventMongoDao.class);
        avlEventRedisDao = mock(AvlEventRedisDao.class);
        avlEventService= new AvlEventServiceImpl(avlEventMongoDao);
        
        ReflectionTestUtils.setField(avlEventService, "avlEventMongoDao", avlEventMongoDao);
        ReflectionTestUtils.setField(avlEventService, "avlEventRedisDao", avlEventRedisDao);
    }
    */
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCacheMissToMongoHit(){
		String deviceGuid = "TEST";
		DateTime date = DateTime.now();
        DateTime dateTime = DateTime.now();
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        AvlEventEntity expectedAvlEvent = createAvlEvent();
        when(avlEventMongoRepository.findByDeviceGuidAndLocationTime("TEST", new Date())).thenReturn(Arrays.asList(expectedAvlEvent));
        when(avlEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<AvlEventEntity>());
        
        List<AvlEventEntity> results = avlEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        verify(avlEventMongoRepository, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        verify(avlEventMongoRepository, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        assertEquals(1, results.size());
        AvlEventEntity actualAvlEvent = results.get(0);
        assertEquals(expectedAvlEvent.getDeviceMessageSequenceNumber(), actualAvlEvent.getDeviceMessageSequenceNumber());
        assertEquals(expectedAvlEvent.getLatitude(), actualAvlEvent.getLatitude());
        assertEquals(expectedAvlEvent.getLongitude(), actualAvlEvent.getLongitude());
	}
	
	@SuppressWarnings("deprecation")
	@Test
    public void testRedisHitMongoNotHit() {
		String deviceGuid = "TEST";
        DateTime date = DateTime.now();
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        AvlEventEntity expectedAvlEvent = new AvlEventEntity();
        expectedAvlEvent.setLatitude(43.33);
        expectedAvlEvent.setLongitude(66.454);
        expectedAvlEvent.setDeviceMessageSequenceNumber(8888888L);
        
        when(avlEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(Arrays.asList(expectedAvlEvent));
       
        List<AvlEventEntity> results = avlEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        verify(avlEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(avlEventMongoRepository, never()).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
                
        assertEquals(1, results.size());
        AvlEventEntity actualAvlEvent = results.get(0);
        assertEquals(expectedAvlEvent.getDeviceMessageSequenceNumber(), actualAvlEvent.getDeviceMessageSequenceNumber());
        assertEquals(expectedAvlEvent.getLatitude(), actualAvlEvent.getLatitude());
        assertEquals(expectedAvlEvent.getLongitude(), actualAvlEvent.getLongitude());
    }
	
	@SuppressWarnings("deprecation")
	@Test
    public void testRangeQueryAllInMongo()
    {
        DateTime endDate = DateTime.now();
        DateTime dayBeforeToday = endDate.minusDays(1);
        DateTime dayBeforeTheDayBeforeToday = dayBeforeToday.minusDays(1);
        DateTime startDate = dayBeforeTheDayBeforeToday.minusDays(1);
        AvlEventEntity expectedAvlEvent = createAvlEvent();
        List<AvlEventEntity>  emptyResults = Arrays.asList(expectedAvlEvent);
        when(avlEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<AvlEventEntity>());
        when(avlEventMongoRepository.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(endDate.getMillis())))).thenReturn(emptyResults);
        when(avlEventMongoRepository.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(dayBeforeToday.getMillis())))).thenReturn(emptyResults);
        when(avlEventMongoRepository.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(dayBeforeTheDayBeforeToday.getMillis())))).thenReturn(emptyResults);
        when(avlEventMongoRepository.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(startDate.getMillis())))).thenReturn(emptyResults);
       
        List<AvlEventEntity> results = avlEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, endDate, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();

        verify(avlEventRedisDao, times(4)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(avlEventMongoRepository, times(4)).findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any());
        //verify(jpaDtshDao, never()).getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any());

        assertEquals(4, results.size());
        AvlEventEntity actualAvlEvent = results.get(0);
        assertEquals(expectedAvlEvent.getDeviceMessageSequenceNumber(), actualAvlEvent.getDeviceMessageSequenceNumber());
        assertEquals(expectedAvlEvent.getLatitude(), actualAvlEvent.getLatitude());
        assertEquals(expectedAvlEvent.getLongitude(), actualAvlEvent.getLongitude());
    }
	
	/**
     * If redis doesn't have the information,  but mongo does, put it into redis.
     */
    @SuppressWarnings("deprecation")
	@Test
    public void testMongoHitLoadsIntoRedis()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now();
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        AvlEventEntity expectedAvlEvent = createAvlEvent();
        List<AvlEventEntity>  mongoResults = Arrays.asList(expectedAvlEvent);
        when(avlEventMongoRepository.findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any())).thenReturn(mongoResults);
        when(avlEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<AvlEventEntity>());
       
        List<AvlEventEntity> results = avlEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        verify(avlEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(avlEventMongoRepository, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, never()).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
        assertEquals(1, results.size());
        AvlEventEntity actualAvlEvent = results.get(0);

        verify(avlEventRedisDao, times(1)).addDeviceEvents(Matchers.<Map<AvlEventEntity, List<DeviceEventRedisKey>>>any());
        assertEquals(expectedAvlEvent.getDeviceMessageSequenceNumber(), actualAvlEvent.getDeviceMessageSequenceNumber());
        assertEquals(expectedAvlEvent.getLatitude(), actualAvlEvent.getLatitude());
        assertEquals(expectedAvlEvent.getLongitude(), actualAvlEvent.getLongitude());
    }

    @Test
    public void testEventOutsideOfCacheWindowNotCachedOnAddEvent() throws Exception
    {
        String deviceGuid = "TEST";
        LocalDateTime date = LocalDateTime.now();
        date = date.minusDays(15);

        AvlEventEntity avlEvent = new AvlEventEntity();
        avlEvent.setDeviceGuid(deviceGuid);
        avlEvent.setLocationTime(date.toDate());
        avlEventService.createEntity(avlEvent);
        verify(avlEventRedisDao, never()).addDeviceEvents(Matchers.<Map<AvlEventEntity, List<DeviceEventRedisKey>>>any());
        verify(avlEventMongoRepository, never()).save(Matchers.<List<AvlEventEntity>>any());
    }
	
    @SuppressWarnings("deprecation")
	@Test
    public void testEventOutsideOfCacheWindowNotCachedOnQuery()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now();
        date = date.minusDays(15);
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        AvlEventEntity expectedAvlEvent = createAvlEvent();
        List<AvlEventEntity>  jpaResults = Arrays.asList(expectedAvlEvent);
       /* when(avlEventMongoDao.getAvlData(eq(deviceGuid), Matchers.<LocalDate>any()))
                .thenReturn(new ArrayList<AvlEventEntity>());*/
        when(avlEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<AvlEventEntity>());
        when(avlEventMongoRepository.findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any())).thenReturn(jpaResults);
        List<AvlEventEntity> results = avlEventService.getDeviceEventData("TEST", DeviceIdType.IdType.DeviceId, startDate, date, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        verify(avlEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(avlEventMongoRepository, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
        assertEquals(1, results.size());
        AvlEventEntity actualAvlEvent = results.get(0);

        verify(avlEventRedisDao, never()).addDeviceEvents(Matchers.<Map<AvlEventEntity, List<DeviceEventRedisKey>>>any());
        verify(avlEventMongoRepository, never()).save(Matchers.<List<AvlEventEntity>>any());
        assertEquals(expectedAvlEvent.getDeviceMessageSequenceNumber(), actualAvlEvent.getDeviceMessageSequenceNumber());
        assertEquals(expectedAvlEvent.getLatitude(), actualAvlEvent.getLatitude());
        assertEquals(expectedAvlEvent.getLongitude(), actualAvlEvent.getLongitude());
    }
    
    @Test
    public void testReadFromRedisFalseReadFromMongo()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now();
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        AvlEventEntity expectedAvlEvent = new AvlEventEntity();
        expectedAvlEvent.setLatitude(43.33);
        expectedAvlEvent.setLongitude(66.454);
        expectedAvlEvent.setDeviceMessageSequenceNumber(8888888L);
        ReflectionTestUtils.setField(avlEventService, "readFromRedis", false);
        avlEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        verify(avlEventRedisDao, never()).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(avlEventMongoRepository, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
    }

  
    @Test
    public void testReadFromRedisTrueReadFromMongo()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now();
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        AvlEventEntity expectedAvlEvent = new AvlEventEntity();
        expectedAvlEvent.setLatitude(43.33);
        expectedAvlEvent.setLongitude(66.454);
        expectedAvlEvent.setDeviceMessageSequenceNumber(8888888L);
        ReflectionTestUtils.setField(avlEventService, "readFromMongo", true);
        avlEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        verify(avlEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(avlEventMongoRepository, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
    }
    
    @Test
    public void testReadFromRedisFalseReadFromMongoFalse()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now();
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        AvlEventEntity expectedAvlEvent = new AvlEventEntity();
        expectedAvlEvent.setLatitude(43.33);
        expectedAvlEvent.setLongitude(66.454);
        expectedAvlEvent.setDeviceMessageSequenceNumber(8888888L);
        ReflectionTestUtils.setField(avlEventService, "readFromMongo", false);
        ReflectionTestUtils.setField(avlEventService, "readFromRedis", false);
        avlEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        verify(avlEventRedisDao, never()).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(avlEventMongoRepository, never()).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
    }
    private AvlEventEntity createAvlEvent()
    {
    	AvlEventEntity history = new AvlEventEntity();
    	history.setDeviceGuid("1");
        history.setLatitude(23.32);
        history.setLongitude(32.32);
        history.setDeviceMessageSequenceNumber(32L);
        return history;
    }
    
    @Test
    public void testFindLastKnownPositionAvlEventByDeviceGuid()
    {
        String deviceGuid = "1";
        AvlEventEntity expectedAvlEvent = createAvlEvent();
        expectedAvlEvent.setFixStatus(Boolean.TRUE);
        
        List<AvlEventEntity> expectedAvlEventList= new ArrayList<AvlEventEntity>();
        expectedAvlEventList.add(expectedAvlEvent);
        
        when(avlEventMongoRepository.findFirstByExternalDeviceIdAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(eq(deviceGuid), eq(Boolean.TRUE),eq(MsgType.AVL), eq(new Date()))).thenReturn(expectedAvlEventList);
        List<AvlEventEntity> results = avlEventService.findLastKnownPositionAvlEventById(deviceGuid,DeviceIdType.IdType.DeviceId, true);
        AvlEventEntity result =null;
        if(results!=null && !results.isEmpty())
        	result = results.get(0);
        verify(avlEventMongoRepository, times(1)).findFirstByDeviceGuidAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(eq(deviceGuid), eq(Boolean.TRUE),eq(MsgType.AVL), eq(new Date()));
        assertNotNull(result);
        assertEquals(expectedAvlEvent.getDeviceMessageSequenceNumber(), result.getDeviceMessageSequenceNumber());
        assertEquals(expectedAvlEvent.getLatitude(), result.getLatitude());
        assertEquals(expectedAvlEvent.getLongitude(), result.getLongitude());
        assertEquals(expectedAvlEvent.getFixStatus(), result.getFixStatus());
    }
}
