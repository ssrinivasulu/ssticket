/**
 * 
 */
package com.calamp.connect.messagingdb.config.db;

import java.util.regex.Pattern;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.type.filter.RegexPatternTypeFilter;
import org.springframework.jmx.support.MBeanServerFactoryBean;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.config.db.MessagingDBConfig;
import com.calamp.connect.messagingdb.config.db.MessagingMongoConfig;
import com.calamp.connect.messagingdb.config.db.MessagingRedisConfig;


/**
 * @author SSrinivasulu
 *
 */
@Configuration
@Import({ MessagingMongoConfig.class, MessagingRedisLocalConfig.class})
@ComponentScan(useDefaultFilters = false, basePackages = { "com.calamp.connect.messagingdb", "com.calamp.focis.framework" },
excludeFilters = { 
		@Filter(type=FilterType.ASSIGNABLE_TYPE, value={MessagingDBConfig.class, MessagingRedisConfig.class}), 
		@Filter(type = FilterType.ANNOTATION, value = {Controller.class})},
includeFilters = { @Filter(type = FilterType.ANNOTATION, value = { Repository.class, Service.class, Component.class })}
)
@PropertySource ({"classpath:/messagingdb.properties", "classpath:/mongo.properties", 
					"classpath:/redis.properties"})
public class MessagingDBLocalConfig 
{
    public static class ExcludeDomainObjects extends RegexPatternTypeFilter
    {
        public ExcludeDomainObjects()
        {
            super(Pattern.compile("com\\.calamp\\.focis\\.*domain\\.*"));
        }
    }

    public static class ExcludeTestConfigs extends RegexPatternTypeFilter
    {
        public ExcludeTestConfigs()
        {
            super(Pattern.compile("com\\.calamp\\.focis\\.*\\.config.Focis*TestSpringConfig"));
        }
    }
	
    @Bean
	public EhCacheManagerFactoryBean getEhCacheFactory(){
		EhCacheManagerFactoryBean factoryBean = new EhCacheManagerFactoryBean();
		factoryBean.setConfigLocation(new ClassPathResource("ehcache.xml"));
		factoryBean.setShared(true);
		return factoryBean;
	}
    
	@Bean
	public CacheManager getEhCacheManager(){
	        return new EhCacheCacheManager(getEhCacheFactory().getObject());
	}
	
	
	@Bean
	EhCacheManagerFactoryBean ehCacheManagerFactoryBean(){
		EhCacheManagerFactoryBean cacheManager = new EhCacheManagerFactoryBean();
		cacheManager.setConfigLocation(new ClassPathResource("ehcache.xml")); 
		return cacheManager;
	}
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer() {
	    return new PropertySourcesPlaceholderConfigurer();
	}
	
	@Bean
	public MBeanServerFactoryBean mBeanServerFactoryBean(){
		MBeanServerFactoryBean mBeanServerFactoryBean = new MBeanServerFactoryBean();
		mBeanServerFactoryBean.setLocateExistingServerIfPossible(true);
		return mBeanServerFactoryBean;
	}
}
