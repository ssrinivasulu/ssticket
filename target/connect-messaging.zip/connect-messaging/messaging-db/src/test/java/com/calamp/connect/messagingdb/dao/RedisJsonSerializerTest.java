/**
 * 
 */
package com.calamp.connect.messagingdb.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.Month;
import java.util.Date;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Protocol;

import com.calamp.connect.messagingdb.converter.JsonRedisSerializer;
import com.calamp.connect.messagingdb.service.AbstractMessagingDBServiceTest;
import com.calamp.connect.models.db.domain.AvlEventEntity;


/**
 * @author ssrinivasulu
 *
 */
@Ignore
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = {MessagingDBLocalConfig.class})
public class RedisJsonSerializerTest extends AbstractMessagingDBServiceTest
{
	AvlEventEntity avlEvent;
	JsonRedisSerializer  jsonRedisSerializer;
	protected JedisPool jedisPool;
	protected volatile static boolean benchmarkMode;
	@Before
    public void setUp() throws Exception {
		super.setUp();
		avlEvent = new AvlEventEntity();
        avlEvent.setLatitude(23.32);
        avlEvent.setLongitude(32.32);
        avlEvent.setDeviceGuid("TEST");
        avlEvent.setLocationTime(new Date());
        avlEvent.setDeviceMessageSequenceNumber(123L);
        jsonRedisSerializer = new JsonRedisSerializer();
        //startJedisEngine();
    }
	

    protected void startJedisEngine() {
        if (benchmarkMode) {
            jedisPool = new JedisPool(new GenericObjectPoolConfig(), "localhost",
                    Protocol.DEFAULT_PORT, 2000);
        } else {
            jedisPool = new JedisPool(new GenericObjectPoolConfig(), "localhost");
        }
        purgeRedis();
    }

    protected void purgeRedis() {
        Jedis jedis = jedisPool.getResource();
        jedis.flushAll();
        jedisPool.returnResource(jedis);
    }

    private AvlEventEntity createAvlEntity(String deviceGuid, Long locationTime){
		AvlEventEntity avlEvent = new AvlEventEntity();
        avlEvent.setLatitude(23.32);
        avlEvent.setLongitude(32.32);
        avlEvent.setDeviceGuid(deviceGuid);
        avlEvent.setLocationTime(new Date(locationTime));
        avlEvent.setDeviceMessageSequenceNumber(123L);
        
        return avlEvent;
	}
	//@Test
	public void serializeAndDeserializeSuccess() {
		
		byte[] serializedJsonObject = jsonRedisSerializer.serialize(avlEvent);
		AvlEventEntity deserializeJsonObject = (AvlEventEntity) jsonRedisSerializer.deserialize(serializedJsonObject);
		assertEquals(deserializeJsonObject.getDeviceGuid(), avlEvent.getDeviceGuid());
		
	}
	
	@Test
	public void subtract_milliseconds_from_date_in_java_with_joda () {
	    
	    DateTime newYearsDay = new DateTime(2013, 1, 1, 0, 0, 0, 0);
	    DateTime newYearsEve = newYearsDay.minusMillis(60);

	    DateTimeFormatter fmt = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss S z");
	    Date startDate = new DateTime().withTimeAtStartOfDay().minusMonths(LocalDate.now().getMonthOfYear()-(Month.JANUARY.getValue()-1)).withTimeAtStartOfDay().minusMillis(60).toDate();
	    DateTime daybefore = new DateTime().minusDays(3);
        int diffdays = Days.daysBetween(new DateTime().minusDays(3), new DateTime()).getDays();


	    assertTrue(newYearsEve.isBefore(newYearsDay));
	}
	public class EventRedisModel {
		
	    private Long id;
	    private String eventType;
	    private Set<AvlEventEntity> avlEvents;
	    
	    public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getEventType() {
			return eventType;
		}
		public void setEventType(String eventType) {
			this.eventType = eventType;
		}
		public Set<AvlEventEntity> getAvlEvents() {
			return avlEvents;
		}
		public void setAvlEvents(Set<AvlEventEntity> avlEvents) {
			this.avlEvents = avlEvents;
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + ((avlEvents == null) ? 0 : avlEvents.hashCode());
			result = prime * result + ((eventType == null) ? 0 : eventType.hashCode());
			result = prime * result + ((id == null) ? 0 : id.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			EventRedisModel other = (EventRedisModel) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (avlEvents == null) {
				if (other.avlEvents != null)
					return false;
			} else if (!avlEvents.equals(other.avlEvents))
				return false;
			if (eventType == null) {
				if (other.eventType != null)
					return false;
			} else if (!eventType.equals(other.eventType))
				return false;
			if (id == null) {
				if (other.id != null)
					return false;
			} else if (!id.equals(other.id))
				return false;
			return true;
		}
		private RedisJsonSerializerTest getOuterType() {
			return RedisJsonSerializerTest.this;
		}
		@Override
		public String toString() {
			return "EventRedisModel [id=" + id + ", eventType=" + eventType + ", avlEvents=" + avlEvents.size() + "]";
		}

	}
	
	
}
