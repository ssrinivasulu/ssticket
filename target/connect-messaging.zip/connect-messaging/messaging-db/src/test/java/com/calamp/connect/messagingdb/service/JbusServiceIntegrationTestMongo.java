/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import com.calamp.connect.messagingdb.repository.JbusEventMongoRepository;
import com.calamp.connect.models.db.domain.JbusEventEntity;
import com.calamp.connect.models.db.domain.MsgType;

/**
 * This class is temporary until i get some stuff to stub out the mongo/redis stuff so it doesn't make remote calls.
 * @author SSrinivasulu
 *
 */

/*@RunWith(SpringJUnit4ClassRunner.class)
@ComponentScan(useDefaultFilters = false, basePackages = { "com.calamp.focis.messagingdb" },
includeFilters = { @Filter(type = FilterType.ANNOTATION, value = { Repository.class, Service.class, Component.class }) })
@PropertySource ({"classpath:/messagingdb.properties", 
	"classpath:/mongo.properties", "classpath:/redis.properties"})
@ContextConfiguration(classes = {MessagingDBLocalConfig.class, MessagingRedisLocalConfig.class})
@DirtiesContext
*/
public class JbusServiceIntegrationTestMongo extends AbstractMessagingDBServiceTest
{
	@Autowired
	@Qualifier("jbusEventService")
	private JbusEventServiceImpl jbusEventService;
	@Autowired
	@Qualifier("jbusEventMongoRepository")
    private JbusEventMongoRepository jbusEventMongoDao;
    
	@Autowired
	@Qualifier("redisTemplate")
    private RedisTemplate redisTemplate;
	
    @After
    public void tearDown() throws Exception
    {
    	super.tearDown();
    	//don't do this as it will drop the entire collection
    	//jbusEventMongoDao.getCollection().drop();
    }
    
    @Before
    public void setUp() throws Exception
    {
    	super.setUp();
    	jbusEventMongoDao.deleteAll();
    	JbusEventEntity jbusEvent = new JbusEventEntity();
    	jbusEvent.setDeviceGuid("TEST");
    	jbusEvent.setLocationTime(new Date());
    	jbusEvent.setOdometer1708(23.32);
    	jbusEvent.setOdometer1939(32.32);
    	jbusEvent.setTotalFuel1708(14.3);
    	jbusEventService.createEntity(jbusEvent);
    }
    
    @SuppressWarnings("deprecation")
	@Test
    public void testCacheMissToDatabase() throws Exception
    {
        DateTime date = DateTime.now().toDateMidnight().toDateTime();
        DateTime endDate = DateTime.now();
        List<JbusEventEntity> results = jbusEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, date, endDate, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        assertEquals(1, results.size());
        JbusEventEntity actualJbusEvent = results.get(0);
        assertNotNull(actualJbusEvent.getTotalFuel1708());
        assertEquals(new Double(23.32), actualJbusEvent.getOdometer1708());
        assertEquals(new Double(32.32), actualJbusEvent.getOdometer1939());
        jbusEventMongoDao.delete(actualJbusEvent);
    }
    
    @BeforeClass
    public static void setupJndI() throws Exception
    {
        SimpleNamingContextBuilder.emptyActivatedContextBuilder();
        Context context = new InitialContext();
        context.bind("resultsServiceRedisHostName", "localhost");

    }
}
