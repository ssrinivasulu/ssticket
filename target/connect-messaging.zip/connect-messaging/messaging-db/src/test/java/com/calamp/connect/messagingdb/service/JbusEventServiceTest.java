/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.calamp.connect.messagingdb.config.db.MessagingDBLocalConfig;
import com.calamp.connect.messagingdb.dao.JbusEventRedisDao;
import com.calamp.connect.messagingdb.repository.JbusEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusEventEntity;
import com.calamp.connect.models.db.domain.MsgType;

/**
 * User: SSrinivasulu Date:04/18/14
 *
 */
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MessagingDBLocalConfig.class})
public class JbusEventServiceTest extends AbstractMessagingDBServiceTest
{
	private JbusEventServiceImpl jbusEventService;
	private JbusEventMongoRepository jbusEventMongoDao;
	private JbusEventRedisDao jbusEventRedisDao;
	
	/*
	@Before
    public void setUp()
    {
		jbusEventMongoDao = mock(JbusEventMongoDao.class);
        jbusEventRedisDao = mock(JbusEventRedisDao.class);
        jbusEventService= new JbusEventServiceImpl(jbusEventMongoDao);
        
        ReflectionTestUtils.setField(jbusEventService, "jbusEventMongoDao", jbusEventMongoDao);
        ReflectionTestUtils.setField(jbusEventService, "jbusEventRedisDao", jbusEventRedisDao);
    }
    */
	
	@SuppressWarnings("deprecation")
	@Test
	public void testCacheMissToMongoHit(){
		String deviceGuid = "TEST";
        DateTime date = DateTime.now();
        DateTime startDate = DateTime.now().toDateMidnight().toDateTime();
        JbusEventEntity expectedJbusEvent = createJbusEvent();
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime("TEST", new Date())).thenReturn(Arrays.asList(expectedJbusEvent));
        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<JbusEventEntity>());
        
        List<JbusEventEntity> results = jbusEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        assertEquals(1, results.size());
        JbusEventEntity actualJbusEvent = results.get(0);
        assertEquals(expectedJbusEvent.getOdometer1708(), actualJbusEvent.getOdometer1708());
        assertEquals(expectedJbusEvent.getOdometer1939(), actualJbusEvent.getOdometer1939());
        assertEquals(expectedJbusEvent.getTotalFuel1708(), actualJbusEvent.getTotalFuel1708());
	}

	@SuppressWarnings("deprecation")
	@Test
    public void testRedisHitMongoNotHit() {
		String deviceGuid = "TEST";
        DateTime date = DateTime.now().toDateMidnight().toDateTime();
        DateTime endDate = DateTime.now();
        JbusEventEntity expectedJbusEvent = new JbusEventEntity();
        expectedJbusEvent.setOdometer1708(23.32);
        expectedJbusEvent.setOdometer1939(32.32);
        expectedJbusEvent.setTotalFuel1708(14.3);
        
        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(Arrays.asList(expectedJbusEvent));
        List<JbusEventEntity> results = jbusEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, date, endDate, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, never()).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
                
        assertEquals(1, results.size());
        JbusEventEntity actualJbusEvent = results.get(0);
        assertEquals(expectedJbusEvent.getOdometer1708(), actualJbusEvent.getOdometer1708());
        assertEquals(expectedJbusEvent.getOdometer1939(), actualJbusEvent.getOdometer1939());
        assertEquals(expectedJbusEvent.getTotalFuel1708(), actualJbusEvent.getTotalFuel1708());
    }
	
	@SuppressWarnings("deprecation")
	@Test
    public void testRangeQueryAllInMongo()
    {
        DateTime endDate = DateTime.now();
        DateTime dayBeforeToday = endDate.minusDays(1);
        DateTime dayBeforeTheDayBeforeToday = dayBeforeToday.minusDays(1);
        DateTime startDate = dayBeforeTheDayBeforeToday.minusDays(1);
        JbusEventEntity expectedJbusEvent = createJbusEvent();
        List<JbusEventEntity>  emptyResults = Arrays.asList(expectedJbusEvent);
        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<JbusEventEntity>());
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(endDate.getMillis())))).thenReturn(emptyResults);
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(dayBeforeToday.getMillis())))).thenReturn(emptyResults);
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(dayBeforeTheDayBeforeToday.getMillis())))).thenReturn(emptyResults);
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), eq(new Date(startDate.getMillis())))).thenReturn(emptyResults);
        List<JbusEventEntity> results = jbusEventService.getDeviceEventData("TEST", DeviceIdType.IdType.DeviceId,startDate, endDate, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();

        verify(jbusEventRedisDao, times(4)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(4)).findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any());
        //verify(jpaDtshDao, never()).getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any());

        assertEquals(4, results.size());
        JbusEventEntity actualJbusEvent = results.get(0);
        assertEquals(expectedJbusEvent.getOdometer1708(), actualJbusEvent.getOdometer1708());
        assertEquals(expectedJbusEvent.getOdometer1939(), actualJbusEvent.getOdometer1939());
        assertEquals(expectedJbusEvent.getTotalFuel1708(), actualJbusEvent.getTotalFuel1708());
    }
	
	/**
     * If redis doesn't have the information,  but mongo does, put it into redis.
     */
    @SuppressWarnings("deprecation")
	@Test
    public void testMongoHitLoadsIntoRedis()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now().toDateMidnight().toDateTime();
        DateTime endDate = DateTime.now();
        JbusEventEntity expectedJbusEvent = createJbusEvent();
        List<JbusEventEntity>  mongoResults = Arrays.asList(expectedJbusEvent);
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any())).thenReturn(mongoResults);
        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<JbusEventEntity>());
        List<JbusEventEntity> results = jbusEventService.getDeviceEventData("TEST", DeviceIdType.IdType.DeviceId,date, endDate, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, never()).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
        assertEquals(1, results.size());
        JbusEventEntity actualJbusEvent = results.get(0);
        assertEquals(expectedJbusEvent.getOdometer1708(), actualJbusEvent.getOdometer1708());
        assertEquals(expectedJbusEvent.getOdometer1939(), actualJbusEvent.getOdometer1939());
        assertEquals(expectedJbusEvent.getTotalFuel1708(), actualJbusEvent.getTotalFuel1708());
    }

    @Test
    public void testEventOutsideOfCacheWindowNotCachedOnAddEvent() throws Exception
    {
        String deviceGuid = "TEST";
        LocalDateTime date = LocalDateTime.now();
        date = date.minusDays(15);

        JbusEventEntity jbusEvent = new JbusEventEntity();
        jbusEvent.setDeviceGuid(deviceGuid);
        jbusEvent.setLocationTime(date.toDate());
        jbusEventService.createEntity(jbusEvent);
        verify(jbusEventRedisDao, never()).addDeviceEvents(Matchers.<Map<JbusEventEntity, List<DeviceEventRedisKey>>>any());
        verify(jbusEventMongoDao, never()).save(Matchers.<List<JbusEventEntity>>any());
    }
	
    @SuppressWarnings("deprecation")
	@Test
    public void testEventOutsideOfCacheWindowNotCachedOnQuery()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now().toDateMidnight().toDateTime();
        date = date.minusDays(15);
        DateTime startDate = DateTime.now().minusDays(20);

        JbusEventEntity expectedJbusEvent = createJbusEvent();
        List<JbusEventEntity>  jpaResults = Arrays.asList(expectedJbusEvent);
       /* when(avlEventMongoDao.getAvlData(eq(deviceGuid), Matchers.<LocalDate>any()))
                .thenReturn(new ArrayList<AvlEventEntity>());*/
        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any())).thenReturn(new ArrayList<JbusEventEntity>());
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any())).thenReturn(jpaResults);
        List<JbusEventEntity> results = jbusEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, startDate, date, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
        assertEquals(1, results.size());
        JbusEventEntity actualJbusEvent = results.get(0);
        assertEquals(expectedJbusEvent.getOdometer1708(), actualJbusEvent.getOdometer1708());
        assertEquals(expectedJbusEvent.getOdometer1939(), actualJbusEvent.getOdometer1939());
        assertEquals(expectedJbusEvent.getTotalFuel1708(), actualJbusEvent.getTotalFuel1708());
    }
    
    @Test
    public void testReadFromRedisFalseReadFromMongo()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now().toDateMidnight().toDateTime();
        DateTime endDate = DateTime.now();
        JbusEventEntity expectedJbusEvent = new JbusEventEntity();
        expectedJbusEvent.setOdometer1708(23.32);
        expectedJbusEvent.setOdometer1939(32.32);
        expectedJbusEvent.setTotalFuel1708(14.3);
        ReflectionTestUtils.setField(jbusEventService, "readFromRedis", false);
        jbusEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, date, endDate, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        verify(jbusEventRedisDao, never()).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
    }

  
    @Test
    public void testReadFromRedisTrueReadFromMongo()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now().toDateMidnight().toDateTime();
        DateTime endDate = DateTime.now();
        JbusEventEntity expectedJbusEvent = new JbusEventEntity();
        expectedJbusEvent.setOdometer1708(23.32);
        expectedJbusEvent.setOdometer1939(32.32);
        expectedJbusEvent.setTotalFuel1708(14.3);
        ReflectionTestUtils.setField(jbusEventService, "readFromMongo", true);
        jbusEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, date, endDate, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
    }
    
    @Test
    public void testReadFromRedisFalseReadFromMongoFalse()
    {
        String deviceGuid = "TEST";
        DateTime date = DateTime.now().toDateMidnight().toDateTime();
        DateTime endDate = DateTime.now();
        JbusEventEntity expectedJbusEvent = new JbusEventEntity();
        expectedJbusEvent.setOdometer1708(23.32);
        expectedJbusEvent.setOdometer1939(32.32);
        expectedJbusEvent.setTotalFuel1708(14.3);
        ReflectionTestUtils.setField(jbusEventService, "readFromMongo", false);
        ReflectionTestUtils.setField(jbusEventService, "readFromRedis", false);
        jbusEventService.getDeviceEventData("TEST",DeviceIdType.IdType.DeviceId, date, endDate, MsgType.JBUS, true, false, new PageRequest(0, 1)).getContent();
        verify(jbusEventRedisDao, never()).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, never()).findByDeviceGuidAndLocationTime(eq(deviceGuid), Matchers.<Date>any());
        //verify(jpaDtshDao, times(1)).getAvlData(eq(deviceGuid), Matchers.<LocalDate>any());
    }
    private JbusEventEntity createJbusEvent()
    {
    	JbusEventEntity history = new JbusEventEntity();
    	history.setDeviceGuid("1");
        history.setOdometer1708(23.32);
        history.setOdometer1939(32.32);
        history.setTotalFuel1708(14.3);
        history.setTotalFuel1939(24.3);
        return history;
    }
}
