/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.connect.models.messaging.Accumulator;
import com.calamp.connect.models.messaging.AvlDeviceData;

/**
 * This class is temporary until i get some stuff to stub out the mongo/redis stuff so it doesn't make remote calls.
 * @author SSrinivasulu
 *
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = {MessagingDBLocalConfig.class})
public class AvlServiceIntegrationTestMongo extends AbstractMessagingDBServiceTest
{
	@Autowired
	@Qualifier("avlEventService")
	private AvlEventServiceImpl avlEventService;
	
	AvlEventEntity avlEvent = new AvlEventEntity();
    
	@Autowired
	@Qualifier("avlRedisTemplate")
    private RedisTemplate redisTemplate;
	
    @After
    public void tearDown() throws Exception
    {
    	super.tearDown();
    	avlEventService.deviceEventMongoRepository.delete(avlEvent);
    	
    }
    
    @Before
    public void setUp() throws Exception
    {
    	super.setUp();
    	//avlEventMongoDao.makePersistent(avlEvent);
        avlEvent = new AvlEventEntity();
        avlEvent.setLatitude(23.32);
        avlEvent.setLongitude(32.32);
        avlEvent.setDeviceGuid("3");
        avlEvent.setLocationTime(new Date());
        avlEvent.setDeviceMessageSequenceNumber(123L);

        List<Accumulator> rawAccumulators = new ArrayList<Accumulator>();
        Accumulator m = new Accumulator();
        m.setLabel("Accumulator 0");
        m.setValue(String.valueOf(0l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 1");
        m.setValue(String.valueOf(1l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 2");
        m.setValue(String.valueOf(2l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 3");
        m.setValue(String.valueOf(3l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 4");
        m.setValue(String.valueOf(4l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 5");
        m.setValue(String.valueOf(5l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 6");
        m.setValue(String.valueOf(6l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 7");
        m.setValue(String.valueOf(7l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 8");
        m.setValue(String.valueOf(8l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 9");
        m.setValue(String.valueOf(9l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 10");
        m.setValue(String.valueOf(10l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 11");
        m.setValue(String.valueOf(11l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 12");
        m.setValue(String.valueOf(12l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 13");
        m.setValue(String.valueOf(13l));
        rawAccumulators.add(m);
        
        AvlDeviceData deviceData = new AvlDeviceData();
        deviceData.setAccumulators(rawAccumulators);
        avlEvent.setDeviceData(deviceData);
        avlEventService.createEntity(avlEvent);
    }
    
    @SuppressWarnings("deprecation")
	@Test
    public void testCacheMissToDatabase() throws Exception
    {
    	//SimpleDateFormat format = 
    	//	    new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z");
    	//	format.setCalendar(new GregorianCalendar(new SimpleTimeZone(0, "GMT")));
    	//Date dt = format.parse("2014-09-04T15:00:41.519Z");
    	final DateTimeFormatter dtf = DateTimeFormat.forPattern("MM-dd-yyyy");
    	//final LocalDate date = format.parseLocalDate("2014-09-04T15:00:41.519Z");
    	//LocalDate date = LocalDate.parse("07-02-2014", dtf);
    	DateTime date = DateTime.now().toDateMidnight().toDateTime();
    	DateTime endDate = DateTime.now();
        List<AvlEventEntity> results = avlEventService.getDeviceEventData("3",DeviceIdType.IdType.DeviceId, date, endDate, MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
        assertTrue(results.size()>0);
        AvlEventEntity actualDtsh = results.get(0);
        assertNotNull(actualDtsh.getDeviceMessageSequenceNumber());
        assertEquals(new Double(23.32), actualDtsh.getLatitude());
        assertEquals(14, ((AvlDeviceData) actualDtsh.getDeviceData()).getAccumulators().size());
        
        assertEquals(new Double(32.32), actualDtsh.getLongitude());
        avlEventService.deviceEventMongoRepository.delete(actualDtsh);
    }
    
    @BeforeClass
    public static void setupJndI() throws Exception
    {
        SimpleNamingContextBuilder.emptyActivatedContextBuilder();
        Context context = new InitialContext();
        context.bind("resultsServiceRedisHostName", "localhost");

    }
    
    @SuppressWarnings("deprecation")
	@Test
    public void tesFindLastKnownPositionAvlEventByDeviceGuidNoResult()
    {
    	List<AvlEventEntity> result = avlEventService.findLastKnownPositionAvlEventById("TESTLastKnown",DeviceIdType.IdType.DeviceId, true);
        assertNull(result);
    }
    @SuppressWarnings("deprecation")
	@Test
    public void testFindLastKnownPositionAvlEventByDeviceGuidOkResult() throws Exception
    {
    	AvlEventEntity avlEventEntity = createNewAvlEvent(24.32, 34.32, 124L, "TESTLastKnown");
    	AvlEventEntity result = avlEventService.findLastKnownPositionAvlEventById("TESTLastKnown", DeviceIdType.IdType.DeviceId,true).get(0);
        assertNotNull(result);
        assertNotNull(result.getDeviceMessageSequenceNumber());
        assertTrue(result.getFixStatus());
        assertEquals(new Double(24.32), result.getLatitude());
        assertEquals(new Double(34.32), result.getLongitude());
        avlEventService.deviceEventMongoRepository.delete(avlEventEntity);
    }
    
    @SuppressWarnings("deprecation")
	@Test
    public void testFindLastKnownPositionAvlEventByDeviceGuidNokResult() throws Exception
    {
    	AvlEventEntity avlEventEntity = createNewAvlEvent(24.32, 34.32, 124L, "TESTLastKnown");
    	AvlEventEntity avlEventEntity1 = createNewAvlEvent(25.32, 35.32, 125L, "TESTLastKnown");
    	AvlEventEntity result = avlEventService.findLastKnownPositionAvlEventById("TESTLastKnown",DeviceIdType.IdType.DeviceId, true).get(0);
        assertNotNull(result);
        assertNotNull(result.getDeviceMessageSequenceNumber());
        assertTrue(result.getFixStatus());
        assertNotSame(24.32, result.getLatitude());
        assertNotSame(34.32, result.getLongitude());
        avlEventService.deviceEventMongoRepository.delete(avlEventEntity);
        avlEventService.deviceEventMongoRepository.delete(avlEventEntity1);
    }
    
    private AvlEventEntity createNewAvlEvent( double latitude, double longitude, long sequenceNumber, String deviceGuid ) throws Exception
    {
    	avlEventService.deviceEventMongoRepository.deleteAll();
        AvlEventEntity avlEventEntity = new AvlEventEntity();
        avlEventEntity.setLatitude(latitude);
        avlEventEntity.setLongitude(longitude);
        avlEventEntity.setDeviceGuid(deviceGuid);
        avlEventEntity.setLocationTime(new Date());
        avlEventEntity.setDeviceMessageSequenceNumber(sequenceNumber);
        avlEventEntity.setFixStatus(Boolean.TRUE);
        avlEventService.createEntity(avlEventEntity);
        return avlEventEntity;
    }
}