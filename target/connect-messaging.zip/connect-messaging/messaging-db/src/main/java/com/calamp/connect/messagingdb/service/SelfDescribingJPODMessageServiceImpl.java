package com.calamp.connect.messagingdb.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.SelfDescribingJPODMessageRedisDao;
import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.SelfDescribingJPODMessageMongoRepository;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.messagingdb.service.DeviceIdType.IdType;
import com.calamp.connect.models.db.domain.SelfDescribingJPODEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MessagingRedisPropertySearch;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("selfDescribingJPODMessageService")
public class SelfDescribingJPODMessageServiceImpl extends DeviceEventService<SelfDescribingJPODEntity, DeviceEventRedisKey>
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier("selfDescribingJPODMessageMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<SelfDescribingJPODEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }
    
    @Override
    public List<DeviceEventRedisKey> redisKeyBuilder(SelfDescribingJPODEntity representation)
    {
    	DateTime dateTime = new DateTime(representation.getLocationTime(), DateTimeZone.UTC);
        LocalDate date = dateTime.toLocalDate();
    	List<DeviceEventRedisKey> eventRedisKeys = new ArrayList<DeviceEventRedisKey>();
        eventRedisKeys.addAll(super.redisKeyBuilder(representation));
        if (representation.getDeviceGuid() != null)
        {
            eventRedisKeys.add(new DeviceEventRedisKey(eventCacheName(), representation.getDeviceGuid(), MessagingRedisPropertySearch.FIXSTATUSTRUE, date));
        }
        if(representation.getExternalDeviceId()!=null) {
            eventRedisKeys.add(new DeviceEventRedisKey(eventCacheName(), representation.getExternalDeviceId(), MessagingRedisPropertySearch.FIXSTATUSTRUE, date));
    	}
        
        return eventRedisKeys;
    }

    @Autowired
    @Qualifier("selfDescribingJPODMessageRedisDao")
    @Override
    public void setDeviceEventRedisDao(DeviceEventRedisDao<SelfDescribingJPODEntity, DeviceEventRedisKey> redisDao)
    {
        this.deviceEventRedisDao = (SelfDescribingJPODMessageRedisDao) redisDao;
    }

    
    public List<SelfDescribingJPODEntity> findLastKnownPositionSelfDescribingJPODMessageById(String id, IdType idType, Boolean fixStatus)
    {
        logger.debug("Inside getLatestDeviceEventData");
        List<SelfDescribingJPODEntity> convertedResults = new ArrayList<SelfDescribingJPODEntity>();
        DateTime endDate = DateTime.now(DateTimeZone.UTC);
        DateTime startDate = endDate.minusDays(getMaxNumberOfDaysToCache());
        int days = Days.daysBetween(startDate, endDate).getDays();
        boolean queryMongo = false;
        for (int i = 0; i <= days && convertedResults.size() < 1; i++)
        {
            LocalDate date = endDate.minusDays(i).toLocalDate();
            DeviceEventRedisKey key = new DeviceEventRedisKey(eventCacheName(), id, MessagingRedisPropertySearch.FIXSTATUSTRUE, date);
            queryMongo = true;
            if (isReadFromRedis() )
            {
            	if(deviceEventRedisDao.keyExists(key.toString())) {
            		if (i == 0)
	                {
	                    logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key, date.toDateTimeAtStartOfDay(),
	                            new Date(endDate.getMillis())));
	                    convertedResults.addAll(deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(date.toDateTimeAtStartOfDay(),
	                            endDate, false, key, new PageRequest(0,1)).getContent());
	                }
	                else
	                {
	                    logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key, date.toDateTimeAtStartOfDay(), date
	                            .plusDays(1).toDateTimeAtStartOfDay().minusMillis(1)));
	                    convertedResults.addAll(deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(date.toDateTimeAtStartOfDay(), date
	                            .plusDays(1).toDateTimeAtStartOfDay().minusMillis(1), false, key, new PageRequest(0,1)).getContent());
	                }
            	}
            }
            else
            {
	            queryMongo = true;
	            break;
            }
        }
        logger.debug(String.format("EventsSize after fetching from Redis:%s", convertedResults.size()));
        if (convertedResults.size() < 1)
        {
            if (queryMongo)
            {
                if (DeviceIdType.IdType.ESN == idType)
                {
                    convertedResults = ((SelfDescribingJPODMessageMongoRepository) deviceEventMongoRepository)
                            .findFirstByExternalDeviceIdAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(id, fixStatus, MsgType.SELF_DESCRIBING_JPOD, new Date());
                }
                else
                {
                    convertedResults = ((SelfDescribingJPODMessageMongoRepository) deviceEventMongoRepository)
                            .findFirstByDeviceGuidAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(id, fixStatus, MsgType.SELF_DESCRIBING_JPOD, new Date());
                }
            }
        }
        logger.debug(String.format("EventsSize before returning:%s", convertedResults.size()));
        if (logger.isDebugEnabled())
            logger.debug(String.format("About to return last known Self describing jpod message Message for deviceGuid and fixstatus: %s, %s.", id, fixStatus));

            return convertedResults;
    }
    
    @Override
    public void validateEntity(SelfDescribingJPODEntity arg0) throws ConstraintViolationException
    {
        // TODO Auto-generated method stub

    }

    @Override
    public Map<String, SearchableField> getSearchableFields()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public SelfDescribingJPODEntity updateEntity(String arg0, SelfDescribingJPODEntity arg1) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long count(Query arg0)
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public String eventCacheName()
    {
        return "selfDescribingJPODMessage";
    }

    @Override
    public String entityName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SearchResult<SelfDescribingJPODEntity> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(SELF_DESCRIBING_JPOD)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<SelfDescribingJPODEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}
}
