package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusConstructionDailyReportEntity;

@Repository("jbusConstructionDailyReportRedisDao")
public class JbusConstructionDailyReportRedisDao extends DeviceEventRedisDao<JbusConstructionDailyReportEntity, DeviceEventRedisKey>
{

    public JbusConstructionDailyReportRedisDao() {
        super();
    }
}
