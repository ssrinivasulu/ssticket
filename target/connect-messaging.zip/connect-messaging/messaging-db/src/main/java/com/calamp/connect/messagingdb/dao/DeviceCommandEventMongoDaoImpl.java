package com.calamp.connect.messagingdb.dao;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.db.domain.DeviceCommandEventEntity.CommandStatus;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.connect.models.db.domain.RetryReason;
import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageResponseEntity;
import com.mongodb.WriteResult;

/**
 * This DAO layer implementation class is to handle the deviceCommand DB operations.
 */

@Repository("deviceCommandEventMongoDao")
public class DeviceCommandEventMongoDaoImpl implements DeviceCommandEventMongoDao
{
    private static Logger logger = LoggerFactory.getLogger(DeviceCommandEventMongoDaoImpl.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    @Value("${device.command.guarantee.delivery.db.limit:99}")
    private int           dbLimit;

    /**
     * This method creates the given deviceCommand entity in mongodb.
     */
    @Override
    public void createEntity(DeviceCommandEventEntity requestEntity)
    {
        mongoTemplate.save(requestEntity);
    }

    /**
     * This method return the list of deviceCommand entities based on given messageUuid.
     */
    @Override
    public List<DeviceCommandEventEntity> findByMessageUUID(String messageUuid)
    {
        Query query = new Query();
        query.addCriteria(Criteria.where("messageUuid").is(messageUuid).and("msgType").is(MsgType.DEVICE_COMMAND.toString()));
        return mongoTemplate.find(query, DeviceCommandEventEntity.class);
    }

    /**
     * This method retrieves list of deviceCmmand entities of given deviceId between the given date range.
     */
    @Override
    public List<DeviceCommandEventEntity> findDeviceEventByDeviceGuid(String id, DateTime startDate, DateTime endDate)
    {
        Query query = new Query();
        query.addCriteria(Criteria.where("deviceGuid").is(id).and("msgType").is(MsgType.DEVICE_COMMAND.toString())
                .andOperator(Criteria.where("created").gte(startDate.toDate()).and("created").lte(endDate.toDate())));
        return mongoTemplate.find(query, DeviceCommandEventEntity.class);
    }

    /**
     * This method find and modifies the existing deviceCommand. Method will find the deviceCommand message based on esn and sequenceId whose status
     * is not COMPLETE. Then update the given deviceCommand response to those entities.
     */
    @Override
    public DeviceCommandEventEntity findAndModify(DeviceCommandMessageResponseEntity deviceCommandMessageResponse, String esn, int seqId)
    {
        if (deviceCommandMessageResponse == null)
            return null;
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("externalDeviceId").is(esn), Criteria.where("sequenceId").is(seqId),
                Criteria.where("status").ne(CommandStatus.COMPLETE.toString()), Criteria.where("status").ne(CommandStatus.COMPLETED.toString()),
                Criteria.where("status").ne(CommandStatus.CANCELLED_COMPLETED.toString()),
                // Criteria.where("status").regex("COMPLETE[D]??").not(),
                Criteria.where("msgType").is(MsgType.DEVICE_COMMAND.toString()));
        query = new Query(criteria);
        logger.debug(String.format("ESN:%s:UUID:%s:Query to find DeviceCommand:%s", esn, deviceCommandMessageResponse.getMessageUuid(),
                query.toString()));
        DeviceCommandEventEntity commandEventEntity = mongoTemplate.findOne(query, DeviceCommandEventEntity.class);

        if (commandEventEntity != null)
        {
            // If the response received for the DeviceCommand and user already triggered CANCEL command then need to update the status with
            // CANCELLED_COMPLETED
            if (deviceCommandMessageResponse.getOptionsExtension() != null)
            {
                commandEventEntity.setOptionsExtension(deviceCommandMessageResponse.getOptionsExtension());
                // setting it as null to avoid OptionsExtension value to store inside the response
                deviceCommandMessageResponse.setOptionsExtension(null);
            }
            commandEventEntity.setResponse(deviceCommandMessageResponse);
            if ((commandEventEntity.getStatus().equals(CommandStatus.CANCELLED)) && (null != commandEventEntity.getReason())
                    && (commandEventEntity.getReason().equals(RetryReason.USER_TRIGGERED_CANCEL)))
            {
                commandEventEntity.setStatus(CommandStatus.CANCELLED_COMPLETED);
            }
            else
            {
                commandEventEntity.setStatus(CommandStatus.COMPLETED);
            }
            updateDevicCommand(commandEventEntity);
        }
        return commandEventEntity;

    }

    /**
     * @return the mongoTemplate
     */
    public MongoTemplate getMongoTemplate()
    {
        return mongoTemplate;
    }

    /**
     * @param mongoTemplate
     *            the mongoTemplate to set.
     */
    public void setMongoTemplate(MongoTemplate mongoTemplate)
    {
        this.mongoTemplate = mongoTemplate;
    }

    /**
     * Method retrieves the list of deviceCommands for the given command status list.
     */
    @Override
    public List<DeviceCommandEventEntity> findDeviceEventByStatus(List<CommandStatus> commandStatusList)
    {
        Criteria criteria = new Criteria();
        List<Criteria> criterias = new ArrayList<Criteria>();
        for (CommandStatus commandStatus : commandStatusList)
        {
            criterias.add(Criteria.where("status").is(commandStatus.name().toString()));
        }
        criterias.add(Criteria.where("msgType").is(MsgType.DEVICE_COMMAND.toString()));
        Criteria[] arryOfCriteria = (Criteria[]) criterias.toArray();
        criteria.orOperator(arryOfCriteria);
        Query query = new Query(criteria);
        return mongoTemplate.find(query, DeviceCommandEventEntity.class);
    }

    /**
     * Method retrieves the pending deviceCommands entities for the given deviceIds.
     */
    @Override
    public List<DeviceCommandEventEntity> getPendingCommandsForDeviceIds(List<String> ids)
    {
        Query query = new Query();
        Criteria criteria = new Criteria();
        List<CommandStatus> commandStatus = new ArrayList<CommandStatus>();
        commandStatus.add(CommandStatus.CREATED);
        commandStatus.add(CommandStatus.QUEUED);
        commandStatus.add(CommandStatus.SENT);
        criteria.andOperator(Criteria.where("deviceGuid").in(ids).and("status").in(commandStatus).and("msgType")
                .is(MsgType.DEVICE_COMMAND.toString()));
        query.addCriteria(criteria);
        query.with(new Sort(Sort.Direction.ASC, "queuedFor"));
        query.limit(dbLimit);

        return mongoTemplate.find(query, DeviceCommandEventEntity.class);

    }

    @Override
    public void updateDevicCommand(DeviceCommandEventEntity commandEventEntity)
    {
        mongoTemplate.save(commandEventEntity);
    }

    /**
     * Method to update all the messages status to 'CANCELLED' for given messageUuid, whose status is either CREATED, QUEUED or SENT
     * 
     * @return the list of updated DeviceCommandEventEntity.
     */
    @Override
    public List<DeviceCommandEventEntity> findAndUpdateStatusByMessageUUID(String messageUuid)
    {
        if (messageUuid == null)
            return null;

        Query query = new Query();
        Criteria criteria = new Criteria();
        List<CommandStatus> commandStatus = new ArrayList<CommandStatus>(3);
        commandStatus.add(CommandStatus.CREATED);
        commandStatus.add(CommandStatus.QUEUED);
        commandStatus.add(CommandStatus.SENT);

        criteria.andOperator(Criteria.where("messageUuid").is(messageUuid).and("status").in(commandStatus).and("msgType")
                .is(MsgType.DEVICE_COMMAND.toString()));
        query.addCriteria(criteria);

        Update update = new Update();
        update.set("status", CommandStatus.CANCELLED);
        update.set("reason", RetryReason.USER_TRIGGERED_CANCEL);
        WriteResult writeResult = mongoTemplate.updateMulti(query, update, DeviceCommandEventEntity.class);

        if (writeResult.getN() > 0)
        {
            // Added for debug purpose. Just to check the due to replica set the latest data is not fetching immediately after update. In the above
            // code we are updating the record which go to primarySet and immediately in the below step we are fetching which is read from secondary
            // read replica set. May be by this time read replica set is not updated with latest data. So added 1 sec sleep to verify.
            try
            {
                Thread.sleep(1000);
            }
            catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return findByMessageUUID(messageUuid);
        }

        return null;
    }

}
