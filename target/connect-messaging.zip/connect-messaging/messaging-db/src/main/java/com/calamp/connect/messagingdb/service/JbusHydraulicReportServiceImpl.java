package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusHydraulicReportEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("jbusHydraulicReportService")
public class JbusHydraulicReportServiceImpl extends DeviceEventService<JbusHydraulicReportEntity, DeviceEventRedisKey>{

    @Autowired
    @Qualifier("jbusHydraulicReportMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<JbusHydraulicReportEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("jbusHydraulicReportRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<JbusHydraulicReportEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

    @Override
    public void validateEntity(JbusHydraulicReportEntity arg0)
            throws ConstraintViolationException {
        
    }

    @Override
    public Map<String, SearchableField> getSearchableFields() {
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0) {
        
    }

	@Override
	public JbusHydraulicReportEntity updateEntity(String arg0, JbusHydraulicReportEntity arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Query arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

    @Override
    public SearchResult<JbusHydraulicReportEntity> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(JBUS_HYDRAULIC_REPORT)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public String eventCacheName() {
		return "jbusHydraulicReport";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<JbusHydraulicReportEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}

}
