package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusHourlyReportEntity;

@Repository("jbusHourlyReportRedisDao")
public class JbusHourlyReportRedisDao extends DeviceEventRedisDao<JbusHourlyReportEntity, DeviceEventRedisKey>
{
	public JbusHourlyReportRedisDao() {
		super();
	}
}
