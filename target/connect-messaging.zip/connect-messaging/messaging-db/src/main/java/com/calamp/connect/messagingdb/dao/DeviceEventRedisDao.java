package com.calamp.connect.messagingdb.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.repository.NoRepositoryBean;

import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;

@NoRepositoryBean
public class DeviceEventRedisDao<T extends DeviceEventEntity, K extends DeviceEventRedisKey> implements IDeviceEventResultsDao<T, K>
{
    @Value("${messagingdb.redis.maxdaystocache}")
    private int maxNumberOfDaysToCache;
    private Logger                                   logger           =
        LoggerFactory.getLogger(DeviceEventRedisDao.class);
    @Autowired
    @Qualifier("deviceRedisTemplate")
    private RedisTemplate<String, DeviceEventEntity> redisTemplate;

    @Override
    public void addDeviceEvent(T entity, List<K> keys) 
    {
        boolean       firstEntry = false;
        DateTime dateTime   = new DateTime(entity.getLocationTime(), DateTimeZone.UTC);
        DateTime uUIDdateTime   = new DateTime(entity.getNagReceivedTime());
        if(dateTime.isAfter(new DateTime(DateTimeZone.UTC).minusDays(maxNumberOfDaysToCache))) {
            for (K key : keys) {
                if (!redisTemplate.hasKey(key.toString())){
                    firstEntry = true;
                }
                if(key!=null && key.toString().contains("UUID"))
                	redisTemplate.opsForZSet().add(key.toString(), entity, uUIDdateTime.getMillisOfDay());
                else
                	redisTemplate.opsForZSet().add(key.toString(), entity, dateTime.getMillisOfDay());
    
                if (firstEntry){
                    setRedisExpire(key.toString());
                }
            }
        }   
    }
    

    public void addDeviceEvents(Map<T, List<K>> deviceEvents) 
    {
        deviceEvents.forEach((t, k) -> addDeviceEvent(t, k));

    }

    public Boolean keyExists(String redisKey) {
        try {
            return redisTemplate.hasKey(redisKey);
        }
        catch(Exception e){
            logger.error(String.format("Redis Exception occured, when checking Device key exist in Redis :%s", ExceptionUtils.getStackTrace(e)));
        }
        return false;
    }

    @Override
    public List<T> getDeviceEventData(K deviceEventRedisKey) 
    {
        List<DeviceEventEntity> deviceEventEntityList = new ArrayList<DeviceEventEntity>();
        Set<DeviceEventEntity> deviceEventEntityMessages = redisTemplate.opsForZSet().rangeByScore(
                deviceEventRedisKey.toString(), 0,Long.MAX_VALUE);
        deviceEventEntityList.addAll(deviceEventEntityMessages);
        if (logger.isDebugEnabled()){
            logger.debug("About to return " + deviceEventEntityList.size() + " for " + deviceEventRedisKey.toString());
        }
        return (List<T>) deviceEventEntityList;
    }
    
    @Override
    public List<T> getDeviceEventDataByTimeStampRange(DateTime startTime, 
    		DateTime endTime, Boolean sortASC, DeviceEventRedisKey deviceEventRedisKey) 
    {
        List<DeviceEventEntity> deviceEventEntityList = new ArrayList<DeviceEventEntity>();
        Set<DeviceEventEntity> deviceEventEntityMessages = null;
        if(sortASC)
             deviceEventEntityMessages = redisTemplate.opsForZSet().rangeByScore(deviceEventRedisKey.toString(), 
            		 startTime.getMillisOfDay(),
            		 endTime.getMillisOfDay());
        else
            deviceEventEntityMessages = redisTemplate.opsForZSet().reverseRangeByScore(deviceEventRedisKey.toString(), 
            		 startTime.getMillisOfDay(),
            		 endTime.getMillisOfDay());
        
        if(deviceEventEntityMessages != null)
            deviceEventEntityList.addAll(deviceEventEntityMessages);

        if (logger.isDebugEnabled()){
            logger.debug("About to return " + deviceEventEntityList.size() + " for " + deviceEventRedisKey.toString());
        }
        return (List<T>) deviceEventEntityList;
    }
    
    @Override
    public Page<T> getDeviceEventDataByTimeStampLimitRange(DateTime startTime, 
    		DateTime endTime, Boolean sortASC, DeviceEventRedisKey deviceEventRedisKey, Pageable page) 
    {
    	
        List<DeviceEventEntity> deviceEventEntityList = new ArrayList<DeviceEventEntity>();
        Set<DeviceEventEntity> deviceEventEntityMessages = null;
        Long deviceEventsCount = 0l;
        	
        if(sortASC) {
            if(page.getPageNumber()==0l)
            	//deviceEventsCount = redisTemplate.opsForZSet().count(deviceEventRedisKey.toString(),startTime.getMillisOfDay(), endTime.getMillisOfDay());
            deviceEventEntityMessages = redisTemplate.opsForZSet().rangeByScore(deviceEventRedisKey.toString(), 
            		 startTime.getMillisOfDay(),
            		 endTime.getMillisOfDay(), page.getOffset(), page.getPageSize());
        }
        else {
            if(page.getPageNumber()==0l)
            	//deviceEventsCount = redisTemplate.opsForZSet().count(deviceEventRedisKey.toString(),startTime.getMillisOfDay(), endTime.getMillisOfDay());
            deviceEventEntityMessages = redisTemplate.opsForZSet().reverseRangeByScore(deviceEventRedisKey.toString(), 
            		startTime.getMillisOfDay(),
            		endTime.getMillisOfDay(), page.getOffset(), page.getPageSize());
        } 
        
        if(deviceEventEntityMessages != null)
            deviceEventEntityList.addAll(deviceEventEntityMessages);

        if (logger.isDebugEnabled()){
            logger.debug("About to return " + deviceEventEntityList.size() + " for " + deviceEventRedisKey.toString());
        }
        @SuppressWarnings("unchecked")
		Page<T> deviceEventEntityPageList = (Page<T>) new PageImpl<DeviceEventEntity>(deviceEventEntityList, page, deviceEventsCount);
        return deviceEventEntityPageList;
    }

    public List<T> getLatestDeviceEventData(String keyPattern) 
    {
        List<DeviceEventEntity> deviceEventEntityList = new ArrayList<DeviceEventEntity>();
        Set<String> keys = redisTemplate.keys(keyPattern);
        Map<Integer,String> keyPatternMatching = new TreeMap<Integer,String>();
        for (String eventKey : keys) {
            Integer year = Integer.parseInt(eventKey.substring(eventKey.lastIndexOf(":")+1).split("-")[0]);
            keyPatternMatching.put(year, eventKey);
        }
        String eventRedisKey = null;
        if(!keyPatternMatching.isEmpty()) {
            eventRedisKey = keyPatternMatching.entrySet().iterator().next().getValue();
            
            Set<DeviceEventEntity> deviceEventEntityMessages = redisTemplate.opsForZSet().range(
                    eventRedisKey, -1, -1);
            deviceEventEntityList.addAll(deviceEventEntityMessages);
        }    
        if (logger.isDebugEnabled()){
            logger.debug("About to return " + deviceEventEntityList.size() + " for " + eventRedisKey);
        }
        return (List<T>) deviceEventEntityList;
    }
    
    private void setRedisExpire(String key)
    {
        redisTemplate.expire(key, maxNumberOfDaysToCache, TimeUnit.DAYS);
    }
}
