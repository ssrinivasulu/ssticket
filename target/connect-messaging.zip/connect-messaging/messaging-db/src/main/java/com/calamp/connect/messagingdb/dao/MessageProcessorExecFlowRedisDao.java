package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MessageProcessorExecutionFlowEntity;

@Repository("messageProcessorExecFlowRedisDao")
public class MessageProcessorExecFlowRedisDao extends DeviceEventRedisDao<MessageProcessorExecutionFlowEntity, DeviceEventRedisKey>
{

    public MessageProcessorExecFlowRedisDao() {
        super();
    }

}
