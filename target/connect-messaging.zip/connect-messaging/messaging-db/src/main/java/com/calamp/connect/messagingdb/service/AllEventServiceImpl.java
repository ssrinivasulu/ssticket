package com.calamp.connect.messagingdb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.AllEventRedisDao;
import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceCommandEventMongoRepository;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.messagingdb.service.DeviceIdType.IdType;
import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("allEventServiceImpl")
public class AllEventServiceImpl<T extends DeviceEventEntity, K extends DeviceEventRedisKey> extends DeviceEventService<T, K>
{
    private Logger                    logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    @Qualifier("deviceCommandEventMongoRepository")
    DeviceCommandEventMongoRepository deviceCommandEventMongoRepository;

    @Autowired
    @Qualifier("allEventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<T> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @SuppressWarnings("unchecked")
	@Override
    public Page<T> getDeviceEventData(String id, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType,
            boolean uUIDSearch, Boolean order, Pageable pageable)
    {
        logger.debug("Inside getDeviceEventData");
        List<T> combinedEvents = new ArrayList<T>();
        Page<T> deviceEventsPage = null;
        deviceEventsPage = super.getDeviceEventData(id, idType, startDate, endDate, messageType, uUIDSearch, order, pageable);
        combinedEvents.addAll(deviceEventsPage.getContent());
        logger.debug(String.format("EventSize before returning:%s", combinedEvents.size()));
        Page<T> deviceEvents = new PageImpl<T>(combinedEvents, pageable, 
        		deviceEventsPage.getTotalElements());
        return deviceEvents;
    }
    
    @SuppressWarnings("unchecked")
	@Override
	public Page<T> getLatestDeviceEventData(String id, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType, Boolean order, Pageable pageable)
    {
        logger.debug("Inside getLatestDeviceEventData");
        List<T> combinedEvents = new ArrayList<T>();
        Page<T> deviceEventsPage = null;
        deviceEventsPage = super.getLatestDeviceEventData(id, idType, startDate, endDate, messageType, order, pageable);
        combinedEvents.addAll(deviceEventsPage.getContent());
        logger.debug(String.format("EventsSize before returning:%s", combinedEvents.size()));
        Page<T> deviceEvents = new PageImpl<T>(combinedEvents, pageable, 
        		deviceEventsPage.getTotalElements());
        return deviceEvents;
    }

    
    /** Due to the nature of search functionlaity, This search will not leverage Redis cache functionality and will query directly Mongo for fetching the results of multiple devices. 
     * @see com.calamp.connect.messagingdb.service.DeviceEventService#getDeviceEventByDeviceIds(java.util.List, org.joda.time.DateTime, org.joda.time.DateTime, org.springframework.data.domain.Pageable)
     */
    @Override
	public Page<T> getDeviceEventByDeviceIds(List<String> devices, DateTime startDate, DateTime endDate, Pageable pageable)
    {
        logger.debug("Inside getDeviceEventData");
        List<T> combinedEvents = new ArrayList<T>();
        Page<T> deviceEventsPage = null;
        if(startDate.isAfterNow())
        	startDate = DateTime.now().withTimeAtStartOfDay();
        if(endDate.isAfterNow())
        	endDate = DateTime.now().plusDays(1).withTimeAtStartOfDay().minusMillis(1);
        logger.debug(String.format("Fetching data from MongoDB: id:%s startDate:%s endDate:%s", devices, startDate.toDate(), endDate.toDate()));
        deviceEventsPage = deviceEventMongoRepository.findByDeviceGuidInAndLocationTimeBetweenOrderByLocationTimeDesc(devices, startDate.toDate(),
                endDate.toDate(), pageable);
        combinedEvents.addAll(deviceEventsPage.getContent());
        logger.debug(String.format("EventSize before returning:%s", combinedEvents.size()));
        Page<T> deviceEvents = new PageImpl<T>(combinedEvents, pageable, 
        		deviceEventsPage.getTotalElements());
        return deviceEvents;
    }


    @Autowired
    @Qualifier("allEventRedisDao")
    @Override
    public void setDeviceEventRedisDao(DeviceEventRedisDao<T, K> redisDao)
    {
        this.deviceEventRedisDao = (AllEventRedisDao) redisDao;
    }

	@Override
	public Map<String, SearchableField> getSearchableFields() {
		// TODO Auto-generated method stub
		return null;
	}
	
    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0) {
        // TODO Auto-generated method stub
        
    }
    
    @Override
    public String eventCacheName() {
        return "deviceall";
    }

    @Override
    public String entityName() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void validateEntity(T representation) throws ConstraintViolationException {
        // TODO Auto-generated method stub
        
    }

    @Override
    public SearchResult<T> search(Query query)
    {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}