package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;

@Repository("motionLogsEventRedisDao")
public class MotionLogsEventRedisDao<T extends DeviceEventEntity, K extends DeviceEventRedisKey> extends DeviceEventRedisDao<T, K>
{
    public MotionLogsEventRedisDao()
    {
        super();
    }
}
