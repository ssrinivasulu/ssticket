package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.MessageProcessorExecutionFlowEntity;

//@Repository
public interface MessageProcessorExecFlowMongoRepository extends DeviceEventMongoRepository<MessageProcessorExecutionFlowEntity>
{
	
}
