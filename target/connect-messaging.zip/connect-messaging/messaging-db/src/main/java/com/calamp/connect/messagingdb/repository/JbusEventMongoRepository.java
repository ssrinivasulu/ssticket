package com.calamp.connect.messagingdb.repository;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.JbusEventEntity;

//@Repository
public interface JbusEventMongoRepository extends DeviceEventMongoRepository<JbusEventEntity>
{
}
