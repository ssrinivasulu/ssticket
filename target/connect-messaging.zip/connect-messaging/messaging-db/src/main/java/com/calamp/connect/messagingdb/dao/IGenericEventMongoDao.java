package com.calamp.connect.messagingdb.dao;

import com.calamp.focis.framework.search.Searchable;

public interface IGenericEventMongoDao<T> extends Searchable<T>
{
}
