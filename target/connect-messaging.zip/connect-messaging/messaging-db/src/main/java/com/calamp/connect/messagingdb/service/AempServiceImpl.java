package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.AVLEventMongoDao;
import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.AempEventMongoRepository;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.AEMPEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("aempService")
public class AempServiceImpl extends DeviceEventService<AEMPEventEntity, DeviceEventRedisKey>
{

    @Autowired
    private AVLEventMongoDao           avlEventMongoDao;

    @Autowired
    @Qualifier("aempEventMongoRepository")
    protected AempEventMongoRepository aempEventMongoRepository;

    @Autowired
    @Qualifier("aempEventMongoRepository")
    @Override
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<AEMPEventEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    public Map<String, AEMPEventEntity> getLatestEventsByAssetIds(List<Long> assetIds)
    {
        return avlEventMongoDao.getLatestEventsByAssetIds(assetIds);
    }

    @Override
    public String entityName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void validateEntity(AEMPEventEntity representation) throws ConstraintViolationException
    {
        // TODO Auto-generated method stub

    }

    @Override
    public Map<String, SearchableField> getSearchableFields()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> searchableFields)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public String eventCacheName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setDeviceEventRedisDao(DeviceEventRedisDao<AEMPEventEntity, DeviceEventRedisKey> redisDao)
    {
        // TODO Auto-generated method stub

    }

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<AEMPEventEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

}
