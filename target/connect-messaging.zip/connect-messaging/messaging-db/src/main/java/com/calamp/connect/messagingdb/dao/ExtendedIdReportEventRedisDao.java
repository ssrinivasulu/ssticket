/**
 * 
 */
package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.ExtendedIdReportEntity;

@Repository("extendedIdReportEventRedisDao")
public class ExtendedIdReportEventRedisDao extends DeviceEventRedisDao<ExtendedIdReportEntity, DeviceEventRedisKey>
{
	public ExtendedIdReportEventRedisDao() {
		super();
	}
}
