package com.calamp.connect.messagingdb.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.DtcEventEntity;

@Repository("dtcEventRedisDao")
public class DtcEventRedisDao
		extends DeviceEventRedisDao<DtcEventEntity, DeviceEventRedisKey> {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public DtcEventRedisDao() {
		super();
	}
	
}
