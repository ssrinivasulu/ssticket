package com.calamp.connect.messagingdb.repository;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.MotionLogsEventEntity;

@Repository("motionLogsEventMongoRepository")
public interface MotionLogsEventMongoRepository extends DeviceEventMongoRepository<MotionLogsEventEntity>
{
}
