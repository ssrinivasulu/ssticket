package com.calamp.connect.messagingdb.service;

import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.AempMessageEventMongoRepository;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.AempMessageEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("aempMessageEventServiceImpl")
public class AempMessageEventServiceImpl extends DeviceEventService<AempMessageEventEntity, DeviceEventRedisKey>
{
    @Autowired
    @Qualifier("aempMessageEventMongoRepository")
    protected AempMessageEventMongoRepository aempMessageEventMongoRepository;

    @Autowired
    @Qualifier("aempMessageEventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<AempMessageEventEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("aempMessageEventRedisDao")
    @Override
    public void setDeviceEventRedisDao(DeviceEventRedisDao<AempMessageEventEntity, DeviceEventRedisKey> redisDao)
    {
        this.deviceEventRedisDao = redisDao;
    }

    @Override
    public void validateEntity(AempMessageEventEntity arg0) throws ConstraintViolationException
    {
        // TODO Auto-generated method stub
    }

    @Override
    public Map<String, SearchableField> getSearchableFields()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public String eventCacheName()
    {
        return "aemp";
    }

    @Override
    public String entityName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SearchResult<AempMessageEventEntity> search(Query query)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Authorizer getAuthorizer()
    {
        // TODO Auto-generated method stub
        return null;
    }
}
