package com.calamp.connect.messagingdb.service;

import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.messagingdb.repository.IdReportLocationEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.IdReportLocationEventEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("idReportLocationEventService")
public class IdReportLocationEventServiceImpl extends DeviceEventService<IdReportLocationEventEntity, DeviceEventRedisKey>
{

    @Autowired
    @Qualifier("idReportLocationEventMongoRepository")
    protected IdReportLocationEventMongoRepository idReportLocationEventMongoRepository;

    @Autowired
    @Qualifier("idReportLocationEventMongoRepository")
    @Override
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<IdReportLocationEventEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Override
    public String entityName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void validateEntity(IdReportLocationEventEntity representation) throws ConstraintViolationException
    {
        // TODO Auto-generated method stub

    }

    @Override
    public Map<String, SearchableField> getSearchableFields()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> searchableFields)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public String eventCacheName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setDeviceEventRedisDao(DeviceEventRedisDao<IdReportLocationEventEntity, DeviceEventRedisKey> redisDao)
    {
        // TODO Auto-generated method stub

    }

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<IdReportLocationEventEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

}
