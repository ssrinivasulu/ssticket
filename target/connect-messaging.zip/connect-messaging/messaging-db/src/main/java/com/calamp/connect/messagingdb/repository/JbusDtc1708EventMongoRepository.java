package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusDtc1708EventEntity;

public interface JbusDtc1708EventMongoRepository extends DeviceEventMongoRepository<JbusDtc1708EventEntity>
{
}
