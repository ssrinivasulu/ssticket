package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusEventEntity;

@Repository("jbusEventRedisDao")
public class JbusEventRedisDao extends DeviceEventRedisDao<JbusEventEntity, DeviceEventRedisKey>
{
	public JbusEventRedisDao() {
		super();
	}
}
