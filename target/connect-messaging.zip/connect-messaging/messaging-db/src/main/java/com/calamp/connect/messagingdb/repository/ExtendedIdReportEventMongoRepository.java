package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.ExtendedIdReportEntity;

//@Repository
public interface ExtendedIdReportEventMongoRepository extends DeviceEventMongoRepository<ExtendedIdReportEntity>
{
}
