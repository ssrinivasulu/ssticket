package com.calamp.connect.messagingdb.dao;

import java.util.List;

import org.joda.time.DateTime;

import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.db.domain.DeviceCommandEventEntity.CommandStatus;
import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageResponseEntity;

/**
 * This DAO layer interface class is to handle the deviceCommand DB operations.  
 */

public interface DeviceCommandEventMongoDao
{

    void createEntity(DeviceCommandEventEntity requestEntity);

    List<DeviceCommandEventEntity> findByMessageUUID(String messageUuid);

    List<DeviceCommandEventEntity> findDeviceEventByDeviceGuid(String id, DateTime startDate, DateTime endDate);

    DeviceCommandEventEntity findAndModify(DeviceCommandMessageResponseEntity deviceCommandEntity, String esn, int seqId);

    List<DeviceCommandEventEntity> findDeviceEventByStatus(List<CommandStatus> commandStatus);

    List<DeviceCommandEventEntity> getPendingCommandsForDeviceIds(List<String> ids);

    void updateDevicCommand(DeviceCommandEventEntity commandEventEntity);

    List<DeviceCommandEventEntity> findAndUpdateStatusByMessageUUID(String messageUuid);

}
