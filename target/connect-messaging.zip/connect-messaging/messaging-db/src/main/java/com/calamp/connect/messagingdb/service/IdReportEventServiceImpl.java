package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.IdReportEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("idReportEventService")
public class IdReportEventServiceImpl
		extends DeviceEventService<IdReportEntity, DeviceEventRedisKey> {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	@Qualifier("idReportEventMongoRepository")
	public void setDeviceEventMongoRepository(
			DeviceEventMongoRepository<IdReportEntity> mongoRepository) {
		deviceEventMongoRepository = mongoRepository;
	}

	@Autowired
	@Qualifier("idReportEventRedisDao")
	@Override
	public void setDeviceEventRedisDao(
			DeviceEventRedisDao<IdReportEntity, DeviceEventRedisKey> redisDao) {
		this.deviceEventRedisDao = redisDao;
	}

	@Override
	public void validateEntity(IdReportEntity arg0) throws ConstraintViolationException {
	}

	@Override
	public Map<String, SearchableField> getSearchableFields() {
		return null;
	}

	@Override
	public void setSearchableFields(Map<String, SearchableField> arg0) {
	}

	@Override
	public IdReportEntity updateEntity(String arg0, IdReportEntity arg1)
			throws Exception {
		return null;
	}

	@Override
	public long count(Query arg0) {
		return 0;
	}

    @Override
    public SearchResult<IdReportEntity> search(Query query, List<String> devices, Integer maxDefaultDays,  Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(ID_REPORT)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public String eventCacheName() {
		return "idReport";
	}

	@Override
	public String entityName() {
		return null;
	}

	@Override
	public SearchResult<IdReportEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
