package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusDtc1939EventEntity;

public interface JbusDtc1939EventMongoRepository extends DeviceEventMongoRepository<JbusDtc1939EventEntity>
{
}
