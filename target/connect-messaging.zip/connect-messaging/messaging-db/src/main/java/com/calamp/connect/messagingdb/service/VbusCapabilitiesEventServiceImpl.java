package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.messagingdb.repository.VbusCapabilitiesEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.connect.models.db.domain.VehicleBusCapabilitiesEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("vbusCapabilitiesEventService")
public class VbusCapabilitiesEventServiceImpl extends DeviceEventService<VehicleBusCapabilitiesEntity, DeviceEventRedisKey>
{
    private Logger                                 logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier("vbusCapabilitiesEventMongoRepository")
    protected VbusCapabilitiesEventMongoRepository vbusCapabilitiesEventMongoRepository;

    @Autowired
    @Qualifier("vbusCapabilitiesEventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<VehicleBusCapabilitiesEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("vbusCapabilitiesEventRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<VehicleBusCapabilitiesEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

    @Override
    public void validateEntity(VehicleBusCapabilitiesEntity arg0) throws ConstraintViolationException
    {
        // TODO Auto-generated method stub

    }
    
   public VehicleBusCapabilitiesEntity findByDeviceGuid(String deviceGuid)
    {
	   VehicleBusCapabilitiesEntity entity = vbusCapabilitiesEventMongoRepository.findFirstByDeviceGuidAndMsgTypeOrderByLocationTimeDesc(deviceGuid,
                MsgType.VEHICLE_BUS_CAPABILITIES);
       
        return entity;
    }

    @Override
    public Map<String, SearchableField> getSearchableFields()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public VehicleBusCapabilitiesEntity updateEntity(String arg0, VehicleBusCapabilitiesEntity arg1) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long count(Query arg0)
    {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public SearchResult<VehicleBusCapabilitiesEntity> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + "AND msgType:(VEHICLE_BUS_CAPABILITIES)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

    @Override
    public String eventCacheName()
    {
        return "vbus";
    }

    @Override
    public String entityName()
    {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public SearchResult<VehicleBusCapabilitiesEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
