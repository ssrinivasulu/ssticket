package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.AempMessageEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;

@Repository("aempMessageEventRedisDao")
public class AempMessageEventRedisDao extends DeviceEventRedisDao<AempMessageEventEntity, DeviceEventRedisKey>
{
    public AempMessageEventRedisDao()
    {
        super();
    }
}
