/**
 * 
 */
package com.calamp.connect.messagingdb.dao;

import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * @author SSrinivasulu
 *
 */
public interface IDeviceEventResultsDao<T, K> 
{
    public List<T> getDeviceEventDataByTimeStampRange(DateTime startTime, DateTime endTime, Boolean sortASC, K key);
    public Page<T> getDeviceEventDataByTimeStampLimitRange(DateTime startTime, DateTime endTime, Boolean sortASC, K deviceEventRedisKey, Pageable page);
	public List<T> getDeviceEventData(K key);
	public void addDeviceEvent(T entity, List<K> keys);
	public void addDeviceEvents(Map<T, List<K>> deviceEvents);
}
