package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusDtcEventEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("jbusDtcEventService")
public class JbusDtcEventServiceImpl extends DeviceEventService<JbusDtcEventEntity, DeviceEventRedisKey>
{
    @Autowired
    @Qualifier("jbusDtcEventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<JbusDtcEventEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("jbusDtcEventRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<JbusDtcEventEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

	@Override
	public void validateEntity(JbusDtcEventEntity arg0)
			throws ConstraintViolationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<String, SearchableField> getSearchableFields() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSearchableFields(Map<String, SearchableField> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JbusDtcEventEntity updateEntity(String arg0, JbusDtcEventEntity arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Query arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

    @Override
    public SearchResult<JbusDtcEventEntity> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(JBUS_DTC)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public String eventCacheName() {
		return "jbusdtc";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<JbusDtcEventEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
