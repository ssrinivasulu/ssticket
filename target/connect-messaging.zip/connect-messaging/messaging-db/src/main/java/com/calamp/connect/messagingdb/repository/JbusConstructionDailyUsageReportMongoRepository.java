package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusConstructionDailyUsageReportEntity;

public interface JbusConstructionDailyUsageReportMongoRepository extends DeviceEventMongoRepository<JbusConstructionDailyUsageReportEntity> {

}
