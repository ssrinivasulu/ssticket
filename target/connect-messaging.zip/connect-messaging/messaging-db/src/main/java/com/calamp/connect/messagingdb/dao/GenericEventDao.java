package com.calamp.connect.messagingdb.dao;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.calamp.focis.framework.dao.MongoGenericDao;

@Repository("genericEventDao")
public abstract class GenericEventDao<T> extends MongoGenericDao<T, Long> implements IGenericEventMongoDao<T>
{
    public GenericEventDao(Class<T> persistentClass, MongoTemplate mongoTemplate, String defaultField)
    {
        super(persistentClass, mongoTemplate, defaultField);
    }
}
