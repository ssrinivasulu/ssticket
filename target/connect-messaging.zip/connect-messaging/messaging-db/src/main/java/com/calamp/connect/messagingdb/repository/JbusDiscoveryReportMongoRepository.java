package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusDiscoveryReportEntity;

//@Repository
public interface JbusDiscoveryReportMongoRepository extends DeviceEventMongoRepository<JbusDiscoveryReportEntity> {

}
