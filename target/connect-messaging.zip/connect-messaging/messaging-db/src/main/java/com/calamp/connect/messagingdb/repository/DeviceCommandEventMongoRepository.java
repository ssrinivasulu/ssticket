package com.calamp.connect.messagingdb.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.db.domain.DeviceCommandEventEntity.CommandStatus;
import com.calamp.connect.models.db.domain.MsgType;

public interface DeviceCommandEventMongoRepository extends DeviceEventMongoRepository<DeviceCommandEventEntity>
{
    public List<DeviceCommandEventEntity> findByDeviceGuidAndCreationDate(String deviceId, Date date);
    public List<DeviceCommandEventEntity> findByDeviceGuidAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(String deviceId, MsgType msgType, Date start, Date end);
    public Page<DeviceCommandEventEntity> findByDeviceGuidAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(String deviceId, MsgType msgType,  Date start, Date end, Pageable pageable);
    public Page<DeviceCommandEventEntity> findByExternalDeviceIdAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(String esn, MsgType msgType, Date start, Date end, Pageable pageable);
    public DeviceCommandEventEntity findFirstByDeviceGuidAndMsgTypeAndMessageUuid(String deviceId, MsgType msgType, String messageUuid);
    public DeviceCommandEventEntity findFirstByExternalDeviceIdAndMsgTypeAndMessageUuid(String deviceId, MsgType msgType, String messageUuid);
    public Page<DeviceCommandEventEntity> findByDeviceGuidAndSequenceId(String deviceId, Integer sequenceId, Pageable pageable);
    public Page<DeviceCommandEventEntity> findByExternalDeviceIdAndSequenceId(String esn, Integer sequenceId, Pageable pageable);
    public Page<DeviceCommandEventEntity> findByDeviceGuidInAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(List<String> devices, MsgType msgType, Date starte, Date end, Pageable pageable);
    public Page<DeviceCommandEventEntity> findByExternalDeviceIdAndMsgTypeAndStatusInOrderByQueuedForAsc(String esn, MsgType msgType, List<CommandStatus> status, Pageable pageable);
}
