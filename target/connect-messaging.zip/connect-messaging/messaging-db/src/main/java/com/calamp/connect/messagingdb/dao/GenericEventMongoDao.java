package com.calamp.connect.messagingdb.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventEntity;

@Repository("genericEventMongoDao")
public class GenericEventMongoDao<T extends DeviceEventEntity> extends GenericEventDao<T>
{
    @Autowired
    public GenericEventMongoDao(@Qualifier("mongoTemplate") MongoTemplate mongoTemplate)
    {
        super((Class<T>) DeviceEventEntity.class, mongoTemplate, null);
    }
}
