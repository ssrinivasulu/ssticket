package com.calamp.connect.messagingdb.repository;

import java.util.Date;
import java.util.List;

import com.calamp.connect.models.db.domain.AppMessageEntity;
import com.calamp.connect.models.db.domain.MsgType;

//@Repository
public interface AppMessageMongoRepository extends DeviceEventMongoRepository<AppMessageEntity>
{
    public List<AppMessageEntity> findFirstByDeviceGuidAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String deviceGuid, Boolean fixStatus, MsgType messageType, Date date);

    public List<AppMessageEntity> findFirstByExternalDeviceIdAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String esn, Boolean fixStatus, MsgType messageType, Date date);
}