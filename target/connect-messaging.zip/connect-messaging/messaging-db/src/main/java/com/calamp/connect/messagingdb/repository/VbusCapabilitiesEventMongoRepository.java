package com.calamp.connect.messagingdb.repository;

import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.connect.models.db.domain.VehicleBusCapabilitiesEntity;

//@Repository
public interface VbusCapabilitiesEventMongoRepository extends DeviceEventMongoRepository<VehicleBusCapabilitiesEntity>
{
	public List<VehicleBusCapabilitiesEntity> findByDeviceGuidOrderByLocationTimeDesc(String deviceGuid);

	public List<VehicleBusCapabilitiesEntity> findByExternalDeviceIdOrderByLocationTimeDesc(String esn);

    public List<VehicleBusCapabilitiesEntity> findByExternalDeviceIdAndMsgTypeOrderByLocationTimeDesc(String id, MsgType msgType, Pageable pageable);

    public List<VehicleBusCapabilitiesEntity> findByDeviceGuidAndMsgTypeOrderByLocationTimeDesc(String id, MsgType msgType, Pageable pageable);
    
}
