package com.calamp.connect.messagingdb.repository;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.AempMessageEventEntity;

@Repository("aempMessageEventMongoRepository")
public interface AempMessageEventMongoRepository extends DeviceEventMongoRepository<AempMessageEventEntity>
{
}
