package com.calamp.connect.messagingdb.repository;

import java.util.Date;
import java.util.List;

import com.calamp.connect.models.db.domain.Jpod2DTCReportEntity;
import com.calamp.connect.models.db.domain.MsgType;

//@Repository
public interface Jpod2DTCReportMongoRepository extends DeviceEventMongoRepository<Jpod2DTCReportEntity>
{
    public List<Jpod2DTCReportEntity> findFirstByDeviceGuidAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String deviceGuid, Boolean fixStatus, MsgType messageType, Date date);

    public List<Jpod2DTCReportEntity> findFirstByExternalDeviceIdAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String esn, Boolean fixStatus, MsgType messageType, Date date);
}