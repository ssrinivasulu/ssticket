package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusConstructionHourlyReportEntity;

public interface JbusConstructionHourlyReportMongoRepository extends DeviceEventMongoRepository<JbusConstructionHourlyReportEntity> {

}
