//  change DB name to run tis script
db = db.getSiblingDB("FocisMessaging");
var logTime = new Date();
print(logTime.toISOString() + " Using database: " + db);

logTime.setTime(Date.now());
print("=======================================================================================================================");
print(logTime.toISOString() + " Update Started ");

logTime.setTime(Date.now());
print("=======================================================================================================================");
print(logTime.toISOString() + " Calculating total count ");

var totalCount = db.getCollection('DeviceEventEntity').find({}).count();

logTime.setTime(Date.now());
print("=======================================================================================================================");
print(logTime.toISOString() + " Total count = " + totalCount);

var count = 0;

db.getCollection('DeviceEventEntity').find({accountId:null}).forEach(function(data){
	var id = null;
	var accountName = null;

	if (data.account)
	{
		if (data.account.href)
		{
			var accountLink = data.account.href;
			id = accountLink.substring(accountLink.lastIndexOf("/")+1, accountLink.length);
		}

		if (data.account.title)
			accountName = data.account.title;

		db.getCollection('DeviceEventEntity').update({"_id": data._id},{"$set":{"accountId":NumberLong(id), "accountName":accountName}});
	}

	count= count+1;
	if(count%100==0) //Change frequency to print count of domuments updated
		print("out of :"+ totalCount +" documents " +count+" are updated.");
});

print("out of :"+ totalCount +" documents " +count+" are updated.");
logTime.setTime(Date.now());
print("=======================================================================================================================");
print(logTime.toISOString() + " Update Finished ");
print(logTime.toISOString() + " Number of documents Updated: "+ count);
