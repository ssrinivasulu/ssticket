//Drop indexes
db.DeviceEventEntity.dropIndex("deviceGuid_1_msgType_1_locationTime_-1");
db.DeviceEventEntity.dropIndex("externalDeviceId_1_msgType_1_locationTime_-1");

//Create indexes
//ALL
db.DeviceEventEntity.createIndex({"messageUuid": 1},{background: true});
db.DeviceEventEntity.createIndex({"locationTime": -1},{background: true});
db.DeviceEventEntity.createIndex({"nagReceivedTime": -1}, {background: true});
db.DeviceEventEntity.createIndex({"deviceGuid": 1, "msgType": 1},{background: true});
db.DeviceEventEntity.createIndex({"externalDeviceId": 1, "msgType": 1},{background: true});

//AVL
db.DeviceEventEntity.createIndex({"deviceGuid": 1, "fixStatus" : 1, "msgType": 1, "locationTime": -1},{background: true});
db.DeviceEventEntity.createIndex({"externalDeviceId": 1, "fixStatus" : 1, "msgType": 1, "locationTime": -1},{background: true});
//DeviceCommand
db.DeviceEventEntity.createIndex({"deviceGuid": 1, "created" : -1},{background: true});
db.DeviceEventEntity.createIndex({"deviceGuid": 1, "sequenceId" : 1},{background: true});
db.DeviceEventEntity.createIndex({"externalDeviceId": 1, "sequenceId" : 1},{background: true});
//ETL
db.DeviceEventEntity.createIndex({"msgType": 1, "created" : -1},{background: true});
//AVL Search API 
db.getCollection('DeviceEventEntity').createIndex({"eventCode": 1,"eventLabel":1},{background: true});

//MessageProcessorExecutionFlowEntity
db.MessageProcessorExecutionFlowEntity.createIndex({created : -1}, {background : 1});
db.MessageProcessorExecutionFlowEntity.createIndex({locationTime : 1}, {background : 1});
db.MessageProcessorExecutionFlowEntity.createIndex({messageUuid : 1}, {background : 1});