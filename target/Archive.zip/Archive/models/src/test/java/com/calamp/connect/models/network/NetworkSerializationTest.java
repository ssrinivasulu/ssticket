package com.calamp.connect.models.network;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Ignore;
import org.junit.Test;

import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.connect.models.messaging.DeviceEvent;
import com.calamp.connect.models.messaging.converter.NetworkToAempMessageConverter;
import com.calamp.connect.models.messaging.converter.NetworkToAvlMesssageConverter;
import com.calamp.connect.models.messaging.converter.NetworkToDeviceEventMesssageConverter;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class NetworkSerializationTest {

	@Test
	public void testJSONtoAempMessageDeSerialize() {
		
		//String testmsg = "{\"ackStatus\":0,\"deviceId\":0,\"aempData\":{\"fuelUsed\":{\"fuelUnits\":\"gallon\",\"fuelConsumed\":\"2733\",\"datetime\":\"2016-12-31T00:00:00Z\"},\"accountId\":5556,\"location\":{\"latitude\":\"32.9768\",\"datetime\":\"2016-12-27T22:59:17Z\",\"longitude\":\"-96.9167\"},\"equipmentHeader\":{\"make\":\"JOHN DEERE\",\"model\":\"310K EP\",\"serialNumber\":\"1T0310EKADG250893\",\"equipmentID\":\"121333\"},\"cumulativeOperatingHours\":{\"datetime\":\"2016-12-28T10:23:28Z\",\"hour\":\"P64DT9H15M0S\"}},\"nagReceivedTime\":1495118893,\"deviceIp\":\"0.0.0.0\",\"sequenceId\":0,\"type\":\"AEMP_MESSAGE\",\"port\":0,\"lmdirectMessageType\":0,\"externalDeviceId\":\"0\",\"messageUuid\":\"16a9d7ab-6c60-1014-955c-f38cfeafba05\"}";
		String testmsg = "{\"sequenceId\":0,\"port\":0,\"deviceIp\":\"0.0.0.0\",\"deviceId\":0,\"externalDeviceId\":\"0\",\"type\":\"AEMP_MESSAGE\",\"ackStatus\":0,\"nagReceivedTime\":1495123246,\"messageUuid\":\"a76bad91-6c62-1014-b574-9d13c34041f2\",\"aempData\":{\"cumulativeOperatingHours\":{\"hour\":\"P83DT13H48M0S\",\"datetime\":\"2016-12-30T09:47:30Z\"},\"equipmentHeader\":{\"serialNumber\":\"111\",\"model\":\"310J\",\"equipmentID\":\"105004\",\"make\":\"John Deere\"},\"location\":{\"longitude\":\"-95.3717\",\"datetime\":\"2016-12-30T00:41:50Z\",\"latitude\":\"29.9408\"},\"fuelUsed\":{\"fuelConsumed\":\"39678\",\"datetime\":\"2016-12-31T00:00:00Z\",\"fuelUnits\":\"gallon\"},\"accountId\":5556},\"lmdirectMessageType\":0}";
		ObjectMapper mapper = new ObjectMapper();
	
	
			NetworkMessage msg;
			try {
				msg = mapper.readValue(testmsg, NetworkMessage.class);
				assert(msg.getAempData() != null);
				
				/*NetworkToAempMessageConverter maptoevent = new NetworkToAempMessageConverter();
				AempMessageEvent event = maptoevent.convert(msg);
				assert(event.getMessageType() != null);*/
				
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	
		
	}
	
	
	@Test
	public void testJSONtoAppMessageDeSerialize() {
		
		//
		String testmsg = "{\"type\":\"APP_MESSAGE\",\"rawJbusMessage\":{\"locationTime\":0,\"unknownReportRaw\":{\"message\":\"mOApDgc/TRV4Ff+iFU4VsRX/dRU=\"},\"sourceAddress\":0,\"timeOfFix\":1495717861000,\"jbusMessageType\":\"Type value 130\"},\"deviceId\":0,\"externalDeviceId\":\"4843002511\",\"sequenceId\":63560,\"deviceIp\":\"1.1.1.1\",\"port\":20510,\"nagReceivedTime\":1496167951913,\"rawDeviceHexMessage\":\"8305484300251101010105f8485926d7e55926d7e518476183d3eff7f6000000000000000000c50a020016ffbd0f09f4000082001498e0290e073f4d157815ffa2154e15b115ff7515\",\"messageUuid\":\"8c7c61c3-4563-11e7-b393-df82cce2eb97\",\"ackStatus\":false,\"lmdirectMessageType\":5}";
		ObjectMapper mapper = new ObjectMapper();
	
	
			NetworkMessage msg;
			try {
				msg = mapper.readValue(testmsg, NetworkMessage.class);
				assert(msg.getRawJbusMessage().getUnknownReportRaw() != null);
				
				/*NetworkToAempMessageConverter maptoevent = new NetworkToAempMessageConverter();
				AempMessageEvent event = maptoevent.convert(msg);
				assert(event.getMessageType() != null);*/
				
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	
		
	}
//{\"type\":\"APP_MESSAGE\",\"messageDetail\":{\"deviceId\":0,\"locationTime\":1481247398000,\"latitude\":33.1377935,\"longitude\":-117.2778005,\"speed\":0,\"heading\":0,\"gpsFixStatus\":{\"predicted\":false,\"differentiallyCorrected\":true,\"lastKnown\":false,\"invalidFix\":false,\"twoDFix\":false,\"historic\":false,\"invalidTime\":false},\"fixStatus\":true,\"carrier\":410,\"hdop\":1.4,\"rssi\":-57,\"obdSpeed\":0,\"odometer\":0.0,\"deviceMsgSeqNumber\":0,\"maxSpeed\":0,\"duration\":0,\"createDate\":0,\"fuelConsumption\":0.0,\"acquiredMessageId\":0,\"timeAdjustmentSeconds\":0,\"rawObdOdometer\":0.0,\"rawOdometer\":0.0,\"timeStationary\":0,\"altitudeCertainty\":0,\"latLongAccuracy\":0,\"cellSiteLatitude\":0.0,\"cellSiteLongitude\":0.0,\"speedCertainty\":0,\"currentIdleDuration\":0,\"currentEngineOffDuration\":0,\"currentTravelDuration\":0,\"currentMilesTraveled\":0.0,\"ignitionStatusChangeTime\":0,\"currentStopDuration\":0,\"batteryVoltage\":0,\"cellSiteId\":0,\"locationAge\":0,\"serviceProviderId\":0,\"serviceProviderNetworkId\":0,\"timeOffset\":0,\"wideAreaServiceId\":0,\"odometerDelta\":0.0,\"checkFirstMessageCount\":0,\"satelliteCount\":8,\"currentFuelUsed\":0.0,\"stopDuration\":0,\"dtshId\":0,\"deviceActiveFlg\":0,\"deviceMessageId\":0,\"pegZone\":0,\"unitStatus\":{\"memoryTest\":false,\"gpsAntennaStatus\":false,\"gpsReceiverSelfTest\":false,\"gpsReceiverTracking\":false,\"modemMinTest\":false,\"gpsExceptionReported\":false},\"inputs\":{\"ignition\":false,\"input1\":true,\"input2\":true,\"input3\":true,\"input4\":true,\"input5\":true,\"input6\":true,\"input7\":true,\"value\":\"01111111111111111111111111111111\"},\"commState\":{\"available\":true,\"connected\":true,\"dataService\":true,\"networkService\":true,\"roaming\":false,\"threeGNetwork\":true,\"voiceCallIsActive\":false},\"timeOfFix\":1481247398000},\"rawJbusMessage\":{\"locationTime\":0,\"unknownReportRaw\":{\"message\":\"EGYUAABuAAABAGQAAQUAYQAPCQBeAAINAKgAAREAnQAEFQCuAAMZAK8AAh0AbwABIQAuAgIlAHICCykAOQQLLQC+AAIxAFsABDUAvgAAOQByAgI9AL4ACkEALgIDRQAQAARJAHICCE0=\"},\"sourceAddress\":0,\"timeOfFix\":1481247398000,\"jbusMessageType\":\"138\"},\"deviceId\":0,\"externalDeviceId\":\"4865001724\",\"sequenceId\":6,\"deviceIp\":\"1.1.1.1\",\"port\":20510,\"nagReceivedTime\":1506616992158,\"rawDeviceHexMessage\":\"83054865001724010101050006584a0aa6584a0aa613c06d0fba18d3eb000018b20000000000000802019affc74f0efe00008a006810661400006e00000100640001050061000f09005e00020d00a8000111009d00041500ae00031900af00021d006f000121002e0202250072020b290039040b2d00be000231005b00043500be000039007202023d00be000a41002e0203450010000449007202084d\",\"messageUuid\":\"1dce6bf0-a46c-11e7-aab4-5f43178aede6\",\"ackStatus\":false,\"lmdirectMessageType\":5}
	@Test
	@Ignore
	public void testJSONto138DTCJPODMessageDeSerialize() {
		
		//
		String testmsg = "{\"type\":\"APP_MESSAGE\",\"messageDetail\":{\"deviceId\":0,\"locationTime\":1481247398000,\"latitude\":33.1377935,\"longitude\":-117.2778005,\"speed\":0,\"heading\":0,\"gpsFixStatus\":{\"predicted\":false,\"differentiallyCorrected\":true,\"lastKnown\":false,\"invalidFix\":false,\"twoDFix\":false,\"historic\":false,\"invalidTime\":false},\"fixStatus\":true,\"carrier\":410,\"hdop\":1.4,\"rssi\":-57,\"obdSpeed\":0,\"odometer\":0.0,\"deviceMsgSeqNumber\":0,\"maxSpeed\":0,\"duration\":0,\"createDate\":0,\"fuelConsumption\":0.0,\"acquiredMessageId\":0,\"timeAdjustmentSeconds\":0,\"rawObdOdometer\":0.0,\"rawOdometer\":0.0,\"timeStationary\":0,\"altitudeCertainty\":0,\"latLongAccuracy\":0,\"cellSiteLatitude\":0.0,\"cellSiteLongitude\":0.0,\"speedCertainty\":0,\"currentIdleDuration\":0,\"currentEngineOffDuration\":0,\"currentTravelDuration\":0,\"currentMilesTraveled\":0.0,\"ignitionStatusChangeTime\":0,\"currentStopDuration\":0,\"batteryVoltage\":0,\"cellSiteId\":0,\"locationAge\":0,\"serviceProviderId\":0,\"serviceProviderNetworkId\":0,\"timeOffset\":0,\"wideAreaServiceId\":0,\"odometerDelta\":0.0,\"checkFirstMessageCount\":0,\"satelliteCount\":8,\"currentFuelUsed\":0.0,\"stopDuration\":0,\"dtshId\":0,\"deviceActiveFlg\":0,\"deviceMessageId\":0,\"pegZone\":0,\"unitStatus\":{\"memoryTest\":false,\"gpsAntennaStatus\":false,\"gpsReceiverSelfTest\":false,\"gpsReceiverTracking\":false,\"modemMinTest\":false,\"gpsExceptionReported\":false},\"inputs\":{\"ignition\":false,\"input1\":true,\"input2\":true,\"input3\":true,\"input4\":true,\"input5\":true,\"input6\":true,\"input7\":true,\"value\":\"01111111111111111111111111111111\"},\"commState\":{\"available\":true,\"connected\":true,\"dataService\":true,\"networkService\":true,\"roaming\":false,\"threeGNetwork\":true,\"voiceCallIsActive\":false},\"timeOfFix\":1481247398000},\"rawJbusMessage\":{\"locationTime\":0,\"unknownReportRaw\":{\"message\":\"EGYUAABuAAABAGQAAQUAYQAPCQBeAAINAKgAAREAnQAEFQCuAAMZAK8AAh0AbwABIQAuAgIlAHICCykAOQQLLQC+AAIxAFsABDUAvgAAOQByAgI9AL4ACkEALgIDRQAQAARJAHICCE0=\"},\"sourceAddress\":0,\"timeOfFix\":1481247398000,\"jbusMessageType\":\"138\"},\"deviceId\":0,\"externalDeviceId\":\"4865001724\",\"sequenceId\":6,\"deviceIp\":\"1.1.1.1\",\"port\":20510,\"nagReceivedTime\":1506616992158,\"rawDeviceHexMessage\":\"83054865001724010101050006584a0aa6584a0aa613c06d0fba18d3eb000018b20000000000000802019affc74f0efe00008a006810661400006e00000100640001050061000f09005e00020d00a8000111009d00041500ae00031900af00021d006f000121002e0202250072020b290039040b2d00be000231005b00043500be000039007202023d00be000a41002e0203450010000449007202084d\",\"messageUuid\":\"1dce6bf0-a46c-11e7-aab4-5f43178aede6\",\"ackStatus\":false,\"lmdirectMessageType\":5}";
		ObjectMapper mapper = new ObjectMapper();
	
	
			NetworkMessage msg;
			try {
				msg = mapper.readValue(testmsg, NetworkMessage.class);
				assert(msg.getRawJbusMessage().getUnknownReportRaw() != null);
				NetworkToDeviceEventMesssageConverter converter = new NetworkToDeviceEventMesssageConverter();
				DeviceEvent de = converter.convert(msg);
				assert(de.getLmdirectMessageType() != null);
				/*NetworkToAempMessageConverter maptoevent = new NetworkToAempMessageConverter();
				AempMessageEvent event = maptoevent.convert(msg);
				assert(event.getMessageType() != null);*/
				
			} catch (JsonParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JsonMappingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	
		
	}
	
}
