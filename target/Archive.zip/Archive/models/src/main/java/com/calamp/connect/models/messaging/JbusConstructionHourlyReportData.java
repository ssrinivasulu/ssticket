package com.calamp.connect.models.messaging;

import javax.measure.quantity.Dimensionless;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.DurationHours;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("jbusConstructionHourlyReportData")
@JsonTypeName("jbusConstructionHourlyReportData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "defOrNoxTankLevel", "fuelTankLevel1", "totalEngineHours" })
@JsonPropertyOrder({ "defOrNoxTankLevel", "fuelTankLevel1", "totalEngineHours" })
public class JbusConstructionHourlyReportData extends DeviceData
{
    @ConvertUnit(type = DurationHours.class)
    private HeaderData totalEngineHours;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData defOrNoxTankLevel;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData fuelTankLevel1;

    public HeaderData getTotalEngineHours()
    {
        return totalEngineHours;
    }

    public void setTotalEngineHours(HeaderData totalEngineHours)
    {
        this.totalEngineHours = totalEngineHours;
    }

    public HeaderData getDefOrNoxTankLevel()
    {
        return defOrNoxTankLevel;
    }

    public void setDefOrNoxTankLevel(HeaderData defOrNoxTankLevel)
    {
        this.defOrNoxTankLevel = defOrNoxTankLevel;
    }

    public HeaderData getFuelTankLevel1()
    {
        return fuelTankLevel1;
    }

    public void setFuelTankLevel1(HeaderData fuelTankLevel1)
    {
        this.fuelTankLevel1 = fuelTankLevel1;
    }

}
