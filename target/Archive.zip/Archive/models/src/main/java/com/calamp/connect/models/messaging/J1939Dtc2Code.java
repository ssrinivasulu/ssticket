package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@XmlRootElement(name = "j1939Dtc2Code")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("j1939Dtc2Code")
@JsonTypeName("j1939Dtc2Code")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType (propOrder = {"sourceAddress","spn","fmi","conversionMethod","occurrenceCount" })
@JsonPropertyOrder ( {"sourceAddress","spn","fmi","conversionMethod","occurrenceCount"})

public class J1939Dtc2Code {
	private Integer	sourceAddress;
	private Integer spn;
	private Integer fmi;
	private Integer conversionMethod;
	private Integer occurrenceCount;

	public Integer getSourceAddress() {
		return sourceAddress;
	}
	public void setSourceAddress(Integer sourceAddress) {
		this.sourceAddress = sourceAddress;
	}
	public Integer getSpn() {
		return spn;
	}
	public void setSpn(Integer spn) {
		this.spn = spn;
	}
	public Integer getFmi() {
		return fmi;
	}
	public void setFmi(Integer fmi) {
		this.fmi = fmi;
	}
	public Integer getConversionMethod() {
		return conversionMethod;
	}
	public void setConversionMethod(Integer conversionMethod) {
		this.conversionMethod = conversionMethod;
	}
	public Integer getOccurrenceCount() {
		return occurrenceCount;
	}
	public void setOccurrenceCount(Integer occurrenceCount) {
		this.occurrenceCount = occurrenceCount;
	}

	
}
