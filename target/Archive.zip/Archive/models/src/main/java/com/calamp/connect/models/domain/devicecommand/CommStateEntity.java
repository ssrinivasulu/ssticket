package com.calamp.connect.models.domain.devicecommand;

/**
 * User: ericw
 * Date: 5/14/14
 */
public class CommStateEntity
{
    private boolean available;
    private boolean connected;
    private boolean dataService;
    private boolean networkService;
    private boolean roaming;
    private boolean threeGNetwork;
    private boolean voiceCallIsActive;

    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        CommStateEntity commState = (CommStateEntity) o;

        if (available != commState.available){
            return false;
        }

        if (connected != commState.connected){
            return false;
        }

        if (dataService != commState.dataService){
            return false;
        }

        if (networkService != commState.networkService){
            return false;
        }

        if (roaming != commState.roaming){
            return false;
        }

        if (threeGNetwork != commState.threeGNetwork){
            return false;
        }

        if (voiceCallIsActive != commState.voiceCallIsActive){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (available
                      ? 1
                      : 0);

        result = 31 * result + (networkService
                                ? 1
                                : 0);
        result = 31 * result + (dataService
                                ? 1
                                : 0);
        result = 31 * result + (connected
                                ? 1
                                : 0);
        result = 31 * result + (voiceCallIsActive
                                ? 1
                                : 0);
        result = 31 * result + (roaming
                                ? 1
                                : 0);
        result = 31 * result + (threeGNetwork
                                ? 1
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "CommState{" + "available=" + available + ", networkService=" + networkService + ", dataService="
               + dataService + ", connected=" + connected + ", voiceCallIsActive=" + voiceCallIsActive + ", roaming="
               + roaming + ", threeGNetwork=" + threeGNetwork + '}';
    }

    public boolean isAvailable()
    {
        return available;
    }

    public boolean isConnected()
    {
        return connected;
    }

    public boolean isDataService()
    {
        return dataService;
    }

    public boolean isNetworkService()
    {
        return networkService;
    }

    public boolean isRoaming()
    {
        return roaming;
    }

    public boolean isThreeGNetwork()
    {
        return threeGNetwork;
    }

    public boolean isVoiceCallIsActive()
    {
        return voiceCallIsActive;
    }

    public void setAvailable(boolean available)
    {
        this.available = available;
    }

    public void setConnected(boolean connected)
    {
        this.connected = connected;
    }

    public void setDataService(boolean dataService)
    {
        this.dataService = dataService;
    }

    public void setNetworkService(boolean networkService)
    {
        this.networkService = networkService;
    }

    public void setRoaming(boolean roaming)
    {
        this.roaming = roaming;
    }

    public void setThreeGNetwork(boolean threeGNetwork)
    {
        this.threeGNetwork = threeGNetwork;
    }

    public void setVoiceCallIsActive(boolean voiceCallIsActive)
    {
        this.voiceCallIsActive = voiceCallIsActive;
    }
}
