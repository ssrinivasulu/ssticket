package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "jbusFaultReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusFaultReportEvent")
@JsonTypeName("jbusFaultReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "device", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode", "eventTime",
        "eventType", "failure", "function", "inputs", "lmdirectMessageType", "machineState", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "sourceAddress",
        "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusFaultReportEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName", "device",
        "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber",
        "eventCode", "eventTime", "eventType", "failure", "function", "inputs", "lmdirectMessageType", "machineState", "messageReceivedTime",
        "messageType", "messageUuid", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId",
        "rawDeviceHexMessage", "sourceAddress", "timeOfFix", "vin", "vinResponse" })
public class JbusFaultReportEvent extends DeviceEvent
{
    private MachineState machineState;
    private Integer      sourceAddress;
    private Integer      device;
    private Integer      function;
    private Integer      failure;

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }

    public Integer getDevice()
    {
        return device;
    }

    public void setDevice(Integer device)
    {
        this.device = device;
    }

    public Integer getFunction()
    {
        return function;
    }

    public void setFunction(Integer function)
    {
        this.function = function;
    }

    public Integer getFailure()
    {
        return failure;
    }

    public void setFailure(Integer failure)
    {
        this.failure = failure;
    }

}
