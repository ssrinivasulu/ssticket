package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AssetDeviceInformation;
import com.calamp.connect.models.messaging.AvlHardAccelEvent;
import com.calamp.connect.models.messaging.ExtendedAccumulatorValues;
import com.calamp.connect.models.messaging.GPS;
import com.calamp.connect.models.messaging.SpeedEvent;
import com.calamp.connect.models.messaging.Telemetry;
import com.calamp.connect.models.network.Event.AvlDeviceData;
import com.calamp.connect.models.network.Event.AvlEvent;
import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelCalibrationType;
import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelEventType;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Abhijit
 *
 */
@Component("deviceEventToAvlEventConverter")
public class DeviceEventToAvlEventConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<com.calamp.connect.models.messaging.AvlEvent, AvlEvent>
{

    @Override
    public AvlEvent modelToDomain(com.calamp.connect.models.messaging.AvlEvent event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        AvlEvent avlEvent = mapper.map(event, AvlEvent.class);
        AvlDeviceData avlDeviceData = mapper.map(event.getDeviceDataConverted(), AvlDeviceData.class);
        if(event.getAvlHardAccelEvent()!= null && event.getAvlHardAccelEvent().getAccelerationType()!= null){
            avlDeviceData.getAcceleration().setLabel(event.getAvlHardAccelEvent().getAccelerationType().toString());
        }
        avlEvent.setDeviceDataConverted(avlDeviceData);
        return avlEvent;

    }

    @Override
    public com.calamp.connect.models.messaging.AvlEvent domainToModel(AvlEvent event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        com.calamp.connect.models.messaging.AvlEvent avlEvent = mapper.map(event, com.calamp.connect.models.messaging.AvlEvent.class);
        return customConvert(event, avlEvent);

    }

    @Override
    public com.calamp.connect.models.messaging.AvlEvent domainToModel(AvlEvent arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<AvlEvent> getDomainType()
    {
        // TODO Auto-generated method stub
        return AvlEvent.class;
    }

    @Override
    public Class<com.calamp.connect.models.messaging.AvlEvent> getModelType()
    {
        // TODO Auto-generated method stub
        return com.calamp.connect.models.messaging.AvlEvent.class;
    }

    protected com.calamp.connect.models.messaging.AvlEvent customConvert(AvlEvent entity, com.calamp.connect.models.messaging.AvlEvent model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        AvlDeviceData avlDeviceData = (AvlDeviceData) entity.getDeviceData();
        GPS gps = mapper.map(entity, GPS.class);
        Address address = mapper.map(entity.getAddress(), Address.class);
        if (gps != null)
        {
            if (address != null)
            {
                address.setStreet(address.getAddress1());
                address.setAddress1(null);
                gps.setAddress(address);
            }
            gps.setGpsValidity(entity.getFixStatus());
            if (avlDeviceData.getGpsSpeed() != null && avlDeviceData.getGpsSpeed().getValue() != null)
                gps.setSpeed(convertHeaderDataToInt(avlDeviceData.getGpsSpeed()));
            model.setGps(gps);
        }

        if (avlDeviceData != null && avlDeviceData.getSpeedEvent() != null)
        {
            SpeedEvent speedEvent = new SpeedEvent();
            if (avlDeviceData.getSpeedEvent().getDuration().getValue() != null)
                speedEvent.setDuration(convertHeaderDataToInt(avlDeviceData.getSpeedEvent().getDuration()));
            if (avlDeviceData.getSpeedEvent().getMaxSpeed().getValue() != null)
                speedEvent.setMaxSpeed(convertHeaderDataToInt(avlDeviceData.getSpeedEvent().getMaxSpeed()));
            model.setSpeedEvent(speedEvent);
        }
        if (avlDeviceData != null && avlDeviceData.getAcceleration() != null)
        {
            AvlHardAccelEvent avlHardAccelEvent = new AvlHardAccelEvent();
            if (avlDeviceData.getAcceleration().getDuration() != null && avlDeviceData.getAcceleration().getDuration().getValue() != null)
                avlHardAccelEvent.setAccelerationDuration(Float.parseFloat(avlDeviceData.getAcceleration().getDuration().getValue()));
            if (entity.getEventCodeString() != null)
                if(AvlHardAccelEventType.ACCEL.toString().equals(entity.getEventCodeString()))
                    avlHardAccelEvent.setAccelerationType(AvlHardAccelEventType.ACCEL);
                else if(AvlHardAccelEventType.DECEL.toString().equals(entity.getEventCodeString()))
                    avlHardAccelEvent.setAccelerationType(AvlHardAccelEventType.DECEL);
                else if(AvlHardAccelEventType.LATERAL_LEFT.toString().equals(entity.getEventCodeString()))
                    avlHardAccelEvent.setAccelerationType(AvlHardAccelEventType.LATERAL_LEFT);
                else if(AvlHardAccelEventType.LATERAL_RIGHT.toString().equals(entity.getEventCodeString()))
                    avlHardAccelEvent.setAccelerationType(AvlHardAccelEventType.LATERAL_RIGHT);
            if (avlDeviceData.getAcceleration().getCalibration() != null)
                if(avlDeviceData.getAcceleration().getCalibration().equals(AvlHardAccelCalibrationType.AVERAGE.toString()))
                    avlHardAccelEvent.setCalibrationType(AvlHardAccelCalibrationType.AVERAGE);
                else if(avlDeviceData.getAcceleration().getCalibration().equals(AvlHardAccelCalibrationType.BEST.toString()))
                    avlHardAccelEvent.setCalibrationType(AvlHardAccelCalibrationType.BEST);
            avlHardAccelEvent.setLateralAcceleration(0f);
            if (avlDeviceData.getAcceleration().getAccelerationMagnitude() != null
                    && avlDeviceData.getAcceleration().getAccelerationMagnitude().getValue() != null)
                avlHardAccelEvent
                        .setLongitudinalAcceleration(Float.parseFloat(avlDeviceData.getAcceleration().getAccelerationMagnitude().getValue()));
            if (avlDeviceData.getAcceleration().getStartingSpeed() != null && avlDeviceData.getAcceleration().getStartingSpeed().getValue() != null)
                avlHardAccelEvent.setStartingSpeed(Float.parseFloat(avlDeviceData.getAcceleration().getStartingSpeed().getValue()));
            model.setAvlHardAccelEvent(avlHardAccelEvent);
        }
        Telemetry telemetry = new Telemetry();
        AssetDeviceInformation assetDeviceInformation = null;
        ExtendedAccumulatorValues accumulatorValues = new ExtendedAccumulatorValues();
        if (entity.getDeviceData() != null)
        {
            if (avlDeviceData.getAltitude() != null && avlDeviceData.getAltitude().getValue() != null)
            {
                telemetry.setAltitude(convertHeaderDataToLong(avlDeviceData.getAltitude()));
            }
            if (avlDeviceData.getRssi() != null && avlDeviceData.getRssi().getValue() != null)
            {
                gps.setRssi(convertHeaderDataToInt(avlDeviceData.getRssi()));
            }
            if (avlDeviceData.getAccumulators() != null)
                for (com.calamp.connect.models.network.Event.Accumulator accumulator : avlDeviceData.getAccumulators())
                {
                    if (accumulator.getValue() != null)
                    {
                        if ("VBSpeed".equals(accumulator.getLabel()))
                        {
                            telemetry.setSpeed(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("VBUS: Calculated Fuel Usage".equals(accumulator.getType()))
                        {
                            telemetry.setFuelUsage(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBOdometer".equals(accumulator.getLabel()) && !accumulator.getValue().equals("0.00"))
                        {
                            telemetry.setOdometer(Double.valueOf(accumulator.getValue()));
                        }
                        if ("GPSOdometer".equals(accumulator.getLabel()))
                        {
                            if (gps != null)
                                gps.setOdometer(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS Max: Vehicle Speed".equals(accumulator.getType()) || "Accumulator 17".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setMaxSpeedObd(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS Max: Engine Speed".equals(accumulator.getType()) || "Accumulator 19".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setMaxEngineSpeed(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS Max: Throttle Position".equals(accumulator.getType()) || "Accumulator 20".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setMaxThrottlePosition(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Fuel Level Percentage".equals(accumulator.getType()) || "Accumulator 21".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setFuelLevelPct(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Fuel Level Remaining3000".equals(accumulator.getType()) || "Accumulator 22".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setFuelLevelVolume(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Engine Coolant Temp".equals(accumulator.getType()) || "Accumulator 23".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setEngineCoolantTemp(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Battery Voltage".equals(accumulator.getType()) || "Accumulator 24".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setBatteryVoltage(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Service Interval Days Remaining".equals(accumulator.getType()) || "Accumulator 25".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setDaysToService(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("VBUS: Service Interval Inspection Distance".equals(accumulator.getType())
                                || "Accumulator 26".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setDistanceToService(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("Battery Remaining %".equals(accumulator.getType()) && accumulator.getLabel().equals("BatteryRemainingPercent"))
                        {
                            if (assetDeviceInformation == null)
                                assetDeviceInformation = new AssetDeviceInformation();
                            assetDeviceInformation.setBatteryLevel(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("Time".equals(accumulator.getType()) && accumulator.getLabel().equals("OnPowerTime"))
                        {
                            if (assetDeviceInformation == null)
                                assetDeviceInformation = new AssetDeviceInformation();
                            assetDeviceInformation.setPowerOnTime(convertDoubleStringToLong(accumulator.getValue()));
                        }
                        if ("Time".equals(accumulator.getType()) && accumulator.getLabel().equals("AwakeTime"))
                        {
                            if (assetDeviceInformation == null)
                                assetDeviceInformation = new AssetDeviceInformation();
                            assetDeviceInformation.setAwakeDuration(convertDoubleStringToLong(accumulator.getValue()));
                        }
                    }
                }
            model.setAssetDeviceInformation(assetDeviceInformation);
            model.setTelemetry(telemetry);
            model.setExtendedAccumulatorValues(accumulatorValues);
        }
        model.setDeviceDataConverted(null);
        model.setDeviceData(null);
        model.setInputs(null);

        return model;
    }
}
