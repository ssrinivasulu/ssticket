package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "jbusDtc1708Event")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("jbusDtc1708Event")
@JsonTypeName("jbusDtc1708Event")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted",
        "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "inputs",
        "jbusDtc1708ProtocolEvents", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port",
        "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "sourceAddress", "searchFieldsDisplay", "searchFieldMap",
        "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusDtc1708Event", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId",
        "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode",
        "eventTime", "eventType", "inputs", "jbusDtc1708ProtocolEvents", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "searchFieldsDisplay",
        "searchFieldMap", "sourceAddress", "timeOfFix", "vin", "vinResponse" })
public class JbusDtc1708Event extends DeviceEvent
{
    @XmlElementWrapper(name = "jbusDtc1708ProtocolEvents")
    @XmlElement(name = "jbusDtc1708ProtocolEvent")
    private List<JbusDtc1708Protocol> jbusDtc1708ProtocolEvents;

    private Integer                   sourceAddress;

    public List<JbusDtc1708Protocol> getJbusDtc1708ProtocolEvents()
    {
        return jbusDtc1708ProtocolEvents;
    }

    public void setJbusDtc1708ProtocolEvents(List<JbusDtc1708Protocol> jbusDtc1708ProtocolEvents)
    {
        this.jbusDtc1708ProtocolEvents = jbusDtc1708ProtocolEvents;
    }

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }

}
