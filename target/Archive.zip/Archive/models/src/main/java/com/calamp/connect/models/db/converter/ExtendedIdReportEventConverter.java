package com.calamp.connect.models.db.converter;


import com.calamp.connect.models.db.domain.ExtendedIdReportEntity;
import com.calamp.connect.models.messaging.ExtendedIdReportEvent;

import com.calamp.focis.framework.converter.Converter;

@Converter
public class ExtendedIdReportEventConverter extends DeviceEventConverter<ExtendedIdReportEntity, ExtendedIdReportEvent>
{
    @Override
    protected ExtendedIdReportEntity customConvert(ExtendedIdReportEvent model, ExtendedIdReportEntity entity)
    {
    	if(model.getDeviceData() != null)
    		entity.setDeviceData(model.getDeviceData());
    	if(model.getDeviceDataConverted() != null)
    		entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    protected ExtendedIdReportEvent customConvert(ExtendedIdReportEntity entity, ExtendedIdReportEvent model)
    {
    	if(entity.getDeviceDataConverted() != null)
    		model.setDeviceDataConverted(entity.getDeviceDataConverted());
    	else if(entity.getDeviceData() != null)
    		model.setDeviceDataConverted(entity.getDeviceData());
        return model;
    }

    @Override
    public ExtendedIdReportEvent domainToModel(ExtendedIdReportEntity entity) throws Exception
    {
        return super.convert(entity, ExtendedIdReportEvent.class);
    }

    @Override
    public ExtendedIdReportEvent domainToModel(ExtendedIdReportEntity entity, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public ExtendedIdReportEntity modelToDomain(ExtendedIdReportEvent idReportEvent) throws Exception
    {
        return super.convert(idReportEvent, ExtendedIdReportEntity.class);
    }

    @Override
    public Class<ExtendedIdReportEvent> getModelType()
    {
        return ExtendedIdReportEvent.class;
    }

    @Override
    public Class<ExtendedIdReportEntity> getDomainType()
    {
        return ExtendedIdReportEntity.class;
    }
}
