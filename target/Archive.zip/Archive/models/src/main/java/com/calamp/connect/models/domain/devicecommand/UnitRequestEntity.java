package com.calamp.connect.models.domain.devicecommand;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * @author Sidlingappa
 *
 */
public class UnitRequestEntity extends DeviceCommandMessageRequestEntity
{
    private Integer actionCode;
    private String  actionName;
    private String  data8bit;
    private String  data16bit;
    private String  data32bit;

    @JsonCreator
    public UnitRequestEntity()
    {
    }

    public Integer getActionCode()
    {
        return actionCode;
    }

    public void setActionCode(Integer actionCode)
    {
        this.actionCode = actionCode;
    }

    public String getData8bit()
    {
        return data8bit;
    }

    public void setData8bit(String data8bit)
    {
        this.data8bit = data8bit;
    }

    public String getData16bit()
    {
        return data16bit;
    }

    public void setData16bit(String data16bit)
    {
        this.data16bit = data16bit;
    }

    public String getData32bit()
    {
        return data32bit;
    }

    public void setData32bit(String data32bit)
    {
        this.data32bit = data32bit;
    }

    public String getActionName()
    {
        return actionName;
    }

    public void setActionName(String actionName)
    {
        this.actionName = actionName;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }

        if ((o == null) || (getClass() != o.getClass()))
        {
            return false;
        }

        UnitRequestEntity that = (UnitRequestEntity) o;

        if ((actionCode != null) ? !actionCode.equals(that.actionCode) : that.actionCode != null)
        {
            return false;
        }
        if ((data8bit != null) ? !data8bit.equals(that.data8bit) : that.data8bit != null)
        {
            return false;
        }
        if ((data16bit != null) ? !data16bit.equals(that.data16bit) : that.data16bit != null)
        {
            return false;
        }
        if ((data32bit != null) ? !data32bit.equals(that.data32bit) : that.data32bit != null)
        {
            return false;
        }
        if ((actionName != null) ? !actionName.equals(that.actionName) : that.actionName != null)
        {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (actionCode != null) ? actionCode.hashCode() : 0;

        result = 31 * result + ((actionName != null) ? actionName.hashCode() : 0);
        result = 31 * result + ((data8bit != null) ? data8bit.hashCode() : 0);
        result = 31 * result + ((data16bit != null) ? data16bit.hashCode() : 0);
        result = 31 * result + ((data32bit != null) ? data32bit.hashCode() : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "UnitRequestEntity{" + "actionCode=" + actionCode + ", actionName=" + actionName + ", data8bit=" + data8bit + ", data16bit=" + data16bit
                + ", data32bit=" + data32bit + '}';
    }
}
