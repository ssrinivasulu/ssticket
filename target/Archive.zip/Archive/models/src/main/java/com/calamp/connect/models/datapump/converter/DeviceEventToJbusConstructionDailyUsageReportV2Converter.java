package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEventV2;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusConstructionDailyUsageReportV2Converter")
public class DeviceEventToJbusConstructionDailyUsageReportV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusConstructionDailyUsageReportEventV2, ConstructionDailyUsageReport>
{

    @Override
    public ConstructionDailyUsageReport modelToDomain(JbusConstructionDailyUsageReportEventV2 event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        ConstructionDailyUsageReport constructionDailyUsage = mapper.map(event, ConstructionDailyUsageReport.class);
        ConstructionDailyUsageReportData deviceData = mapper.map(event.getDeviceData(), ConstructionDailyUsageReportData.class);
        ConstructionDailyUsageReportData deviceDataConverted = mapper.map(event.getDeviceDataConverted(), ConstructionDailyUsageReportData.class);
        constructionDailyUsage.setDeviceData(deviceData);
        constructionDailyUsage.setDeviceDataConverted(deviceDataConverted);
        return constructionDailyUsage;

    }

    @Override
    public JbusConstructionDailyUsageReportEventV2 domainToModel(ConstructionDailyUsageReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionDailyUsageReportEventV2 jbusConstructionDailyUsageReportEvent = mapper.map(event,
                JbusConstructionDailyUsageReportEventV2.class);
        JbusConstructionDailyUsageReportData constructionDailyUsageReportDataConverted = mapper.map(event.getDeviceDataConverted(),
                JbusConstructionDailyUsageReportData.class);
        jbusConstructionDailyUsageReportEvent.setDeviceDataConverted(constructionDailyUsageReportDataConverted);
        JbusConstructionDailyUsageReportData constructionDailyUsageReportData = mapper.map(event.getDeviceData(),
                JbusConstructionDailyUsageReportData.class);
        jbusConstructionDailyUsageReportEvent.setDeviceData(constructionDailyUsageReportData);
        return jbusConstructionDailyUsageReportEvent;
    }

    @Override
    public JbusConstructionDailyUsageReportEventV2 domainToModel(ConstructionDailyUsageReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<ConstructionDailyUsageReport> getDomainType()
    {
        return ConstructionDailyUsageReport.class;
    }

    @Override
    public Class<JbusConstructionDailyUsageReportEventV2> getModelType()
    {
        return JbusConstructionDailyUsageReportEventV2.class;
    }
}
