package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * Java class for JBUSHourlyReportEvent complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JBUSHourlyReportEvent"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GMTTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="deviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="vehicleID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="vehicleVIN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="driverID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="JBUSHourlyReportMessage" type="{http://calamp.com/DataFeedService/}JBUSHourlyReportMessage"/&gt;
 *         &lt;any processContents='skip' maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "jbusHourlyReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusHourlyReportEvent")
@JsonTypeName("jbusHourlyReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId",
        "deviceIp", "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "inputs", "messageReceivedTime", "messageType",
        "messageUuid", "pegBehaviorId", "port", "rawDeviceHexMessage", "vinResponse" })
@XmlType(name = "jbusHourlyReportEvent", propOrder = { "account", "asset", "assetId", "assetName", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "inputs",
        "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port", "rawDeviceHexMessage", "vinResponse" })
@ApiVersion("2.0")
public class JbusHourlyReportEventV2 extends JbusHourlyReportEvent
{

    private JbusHourlyReportData deviceData;
    private JbusHourlyReportData deviceDataConverted;

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusHourlyReportData getDeviceData()
    {
        return (JbusHourlyReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusHourlyReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusHourlyReportData getDeviceDataConverted()
    {
        return (JbusHourlyReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusHourlyReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
