package com.calamp.connect.models.messaging.devicecommand;

/**
 * User: ericw Date: 4/25/14
 */
public enum UnitRequestMessageAction
{
    REBOOT(1), VERSION_REPORT(2), GENERATE_PEG_ACTION(3), CHANGE_PASSWORD(4), GPS_STATUS_REPORT(5), CLEAR_PEG_EVENT(6),
    SET_AUX_SLEEPTIME(7), PEG_SPECIAL_TRIGGER(8), RETURN_ID_REPORT(9), RETURN_LOCATE_REPORT(10), RETURNS_MSG_STATISTICS_REPORT(11),
    RESET_MSG_STATISTICS(12), CLEAR_ERROR_FLAGS(13), FORCE_INBOUND_AND_MAINTENANCE_DNS_LOOKUPS(14), REQUEST_STATE_REPORT(15),
    USER_FLAG_UPDATE(16), SET_ZONE_TO_CURRENT_LOCATION(17), BATTERY_GAUGE(18), ACCUMULATOR_SCHEDULE(19), GENERATES_PEG_MDT_TRIGGER(20),
    SET_BATTERY_USAGE(21), CHECK_6BYTE_DRIVER_ID(22), SUBSCRIBE(23), ONE_WIRE_INTERFACE_REQUEST(24), DEVICE_CONTROL(25);

    private int value;

    private UnitRequestMessageAction(int value)
    {
        this.value = value;
    }

    public int getValue()
    {
        return value;
    }

    public static UnitRequestMessageAction getUserRequestAction(int value)
    {
        for (UnitRequestMessageAction type : values())
        {
            if (type.value == value)
            {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown UnitRequestMessageAction " + value);
    }

}
