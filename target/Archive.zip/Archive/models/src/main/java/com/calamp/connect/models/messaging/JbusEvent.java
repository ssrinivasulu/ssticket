package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "jbusEvent")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("jbusEvent")
@JsonTypeName("jbusEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted",
        "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "inputs",
        "jProtocolEvents", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port", "primaryOperator",
        "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "searchFieldsDisplay", "searchFieldMap", "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode", "eventTime",
        "eventType", "inputs", "jProtocolEvents", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId",
        "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "searchFieldsDisplay", "searchFieldMap",
        "timeOfFix", "vin", "vinResponse" })
public class JbusEvent extends DeviceEvent
{
    @XmlElementWrapper(name = "jProtocolEvents")
    @XmlElement(name = "jProtocol")
    private List<JProtocol> jProtocolEvents;

    public List<JProtocol> getjProtocolEvents()
    {
        return jProtocolEvents;
    }

    public void setjProtocolEvents(List<JProtocol> jProtocolEvents)
    {
        this.jProtocolEvents = jProtocolEvents;
    }
}
