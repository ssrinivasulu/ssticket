package com.calamp.connect.models.messaging;

import javax.measure.quantity.Dimensionless;
import javax.measure.quantity.Pressure;
import javax.measure.quantity.Volume;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.JBUSRpm;
import com.calamp.connect.framework.quantity.JBUSTemperature;
import com.calamp.connect.framework.quantity.JBUSVolume;
import com.calamp.connect.framework.quantity.RPM;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("jbusConstructionDailyReportData")
@JsonTypeName("jbusConstructionDailyReportData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "avgActualEngineTorque", "avgAmbientAirTempr", "avgAuxiliaryTempr1", "avgDEFConcentration", "avgDEFTempr",
        "avgEngineCoolantTempr", "avgEngineFuelRate", "avgEngineFuelTempr1", "avgEngineOilPressure", "avgEngineOilTempr", "avgEngineSpeed",
        "engineTotalFuelUsed", "maxAmbientAirTempr", "maxAuxiliaryTempr1", "maxDEFConcentration", "maxDEFTempr", "maxEngineCoolantTempr",
        "maxEngineFuelTempr1", "maxEngineOilPressure", "maxEngineOilTempr", "maxEngineSpeed", "minAmbientAirTempr", "minAuxiliaryTempr1",
        "minDEFConcentration", "minDEFTempr", "minEngineCoolantTempr", "minEngineFuelTempr1", "minEngineOilPressure", "minEngineOilTempr",
        "minEngineSpeed" })
@JsonPropertyOrder({ "avgActualEngineTorque", "avgAmbientAirTempr", "avgAuxiliaryTempr1", "avgDEFConcentration", "avgDEFTempr",
        "avgEngineCoolantTempr", "avgEngineFuelRate", "avgEngineFuelTempr1", "avgEngineOilPressure", "avgEngineOilTempr", "avgEngineSpeed",
        "engineTotalFuelUsed", "maxAmbientAirTempr", "maxAuxiliaryTempr1", "maxDEFConcentration", "maxDEFTempr", "maxEngineCoolantTempr",
        "maxEngineFuelTempr1", "maxEngineOilPressure", "maxEngineOilTempr", "maxEngineSpeed", "minAmbientAirTempr", "minAuxiliaryTempr1",
        "minDEFConcentration", "minDEFTempr", "minEngineCoolantTempr", "minEngineFuelTempr1", "minEngineOilPressure", "minEngineOilTempr",
        "minEngineSpeed" })
public class JbusConstructionDailyReportData extends DeviceData
{
    @ConvertUnit(type = JBUSVolume.class)
    private HeaderData engineTotalFuelUsed;
    @ConvertUnit(type = JBUSVolume.class)
    private HeaderData avgEngineFuelRate;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData avgActualEngineTorque;
    @ConvertUnit(type = JBUSRpm.class)
    private HeaderData minEngineSpeed;
    @ConvertUnit(type = JBUSRpm.class)
    private HeaderData maxEngineSpeed;
    @ConvertUnit(type = JBUSRpm.class)
    private HeaderData avgEngineSpeed;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData minDEFConcentration;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData maxDEFConcentration;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData avgDEFConcentration;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData minDEFTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData maxDEFTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData avgDEFTempr;
    @ConvertUnit(type = Pressure.class)
    private HeaderData minEngineOilPressure;
    @ConvertUnit(type = Pressure.class)
    private HeaderData maxEngineOilPressure;
    @ConvertUnit(type = Pressure.class)
    private HeaderData avgEngineOilPressure;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData minEngineOilTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData maxEngineOilTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData avgEngineOilTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData minEngineCoolantTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData maxEngineCoolantTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData avgEngineCoolantTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData minEngineFuelTempr1;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData maxEngineFuelTempr1;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData avgEngineFuelTempr1;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData minAmbientAirTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData maxAmbientAirTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData avgAmbientAirTempr;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData minAuxiliaryTempr1;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData maxAuxiliaryTempr1;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData avgAuxiliaryTempr1;

    public HeaderData getEngineTotalFuelUsed()
    {
        return engineTotalFuelUsed;
    }

    public void setEngineTotalFuelUsed(HeaderData engineTotalFuelUsed)
    {
        this.engineTotalFuelUsed = engineTotalFuelUsed;
    }

    public HeaderData getAvgEngineFuelRate()
    {
        return avgEngineFuelRate;
    }

    public void setAvgEngineFuelRate(HeaderData avgEngineFuelRate)
    {
        this.avgEngineFuelRate = avgEngineFuelRate;
    }

    public HeaderData getAvgActualEngineTorque()
    {
        return avgActualEngineTorque;
    }

    public void setAvgActualEngineTorque(HeaderData avgActualEngineTorque)
    {
        this.avgActualEngineTorque = avgActualEngineTorque;
    }

    public HeaderData getMinEngineSpeed()
    {
        return minEngineSpeed;
    }

    public void setMinEngineSpeed(HeaderData minEngineSpeed)
    {
        this.minEngineSpeed = minEngineSpeed;
    }

    public HeaderData getMaxEngineSpeed()
    {
        return maxEngineSpeed;
    }

    public void setMaxEngineSpeed(HeaderData maxEngineSpeed)
    {
        this.maxEngineSpeed = maxEngineSpeed;
    }

    public HeaderData getAvgEngineSpeed()
    {
        return avgEngineSpeed;
    }

    public void setAvgEngineSpeed(HeaderData avgEngineSpeed)
    {
        this.avgEngineSpeed = avgEngineSpeed;
    }

    public HeaderData getMinDEFConcentration()
    {
        return minDEFConcentration;
    }

    public void setMinDEFConcentration(HeaderData minDEFConcentration)
    {
        this.minDEFConcentration = minDEFConcentration;
    }

    public HeaderData getMaxDEFConcentration()
    {
        return maxDEFConcentration;
    }

    public void setMaxDEFConcentration(HeaderData maxDEFConcentration)
    {
        this.maxDEFConcentration = maxDEFConcentration;
    }

    public HeaderData getAvgDEFConcentration()
    {
        return avgDEFConcentration;
    }

    public void setAvgDEFConcentration(HeaderData avgDEFConcentration)
    {
        this.avgDEFConcentration = avgDEFConcentration;
    }

    public HeaderData getMinDEFTempr()
    {
        return minDEFTempr;
    }

    public void setMinDEFTempr(HeaderData minDEFTempr)
    {
        this.minDEFTempr = minDEFTempr;
    }

    public HeaderData getMaxDEFTempr()
    {
        return maxDEFTempr;
    }

    public void setMaxDEFTempr(HeaderData maxDEFTempr)
    {
        this.maxDEFTempr = maxDEFTempr;
    }

    public HeaderData getAvgDEFTempr()
    {
        return avgDEFTempr;
    }

    public void setAvgDEFTempr(HeaderData avgDEFTempr)
    {
        this.avgDEFTempr = avgDEFTempr;
    }

    public HeaderData getMinEngineOilPressure()
    {
        return minEngineOilPressure;
    }

    public void setMinEngineOilPressure(HeaderData minEngineOilPressure)
    {
        this.minEngineOilPressure = minEngineOilPressure;
    }

    public HeaderData getMaxEngineOilPressure()
    {
        return maxEngineOilPressure;
    }

    public void setMaxEngineOilPressure(HeaderData maxEngineOilPressure)
    {
        this.maxEngineOilPressure = maxEngineOilPressure;
    }

    public HeaderData getAvgEngineOilPressure()
    {
        return avgEngineOilPressure;
    }

    public void setAvgEngineOilPressure(HeaderData avgEngineOilPressure)
    {
        this.avgEngineOilPressure = avgEngineOilPressure;
    }

    public HeaderData getMinEngineOilTempr()
    {
        return minEngineOilTempr;
    }

    public void setMinEngineOilTempr(HeaderData minEngineOilTempr)
    {
        this.minEngineOilTempr = minEngineOilTempr;
    }

    public HeaderData getMaxEngineOilTempr()
    {
        return maxEngineOilTempr;
    }

    public void setMaxEngineOilTempr(HeaderData maxEngineOilTempr)
    {
        this.maxEngineOilTempr = maxEngineOilTempr;
    }

    public HeaderData getAvgEngineOilTempr()
    {
        return avgEngineOilTempr;
    }

    public void setAvgEngineOilTempr(HeaderData avgEngineOilTempr)
    {
        this.avgEngineOilTempr = avgEngineOilTempr;
    }

    public HeaderData getMinEngineCoolantTempr()
    {
        return minEngineCoolantTempr;
    }

    public void setMinEngineCoolantTempr(HeaderData minEngineCoolantTempr)
    {
        this.minEngineCoolantTempr = minEngineCoolantTempr;
    }

    public HeaderData getMaxEngineCoolantTempr()
    {
        return maxEngineCoolantTempr;
    }

    public void setMaxEngineCoolantTempr(HeaderData maxEngineCoolantTempr)
    {
        this.maxEngineCoolantTempr = maxEngineCoolantTempr;
    }

    public HeaderData getAvgEngineCoolantTempr()
    {
        return avgEngineCoolantTempr;
    }

    public void setAvgEngineCoolantTempr(HeaderData avgEngineCoolantTempr)
    {
        this.avgEngineCoolantTempr = avgEngineCoolantTempr;
    }

    public HeaderData getMinEngineFuelTempr1()
    {
        return minEngineFuelTempr1;
    }

    public void setMinEngineFuelTempr1(HeaderData minEngineFuelTempr1)
    {
        this.minEngineFuelTempr1 = minEngineFuelTempr1;
    }

    public HeaderData getMaxEngineFuelTempr1()
    {
        return maxEngineFuelTempr1;
    }

    public void setMaxEngineFuelTempr1(HeaderData maxEngineFuelTempr1)
    {
        this.maxEngineFuelTempr1 = maxEngineFuelTempr1;
    }

    public HeaderData getAvgEngineFuelTempr1()
    {
        return avgEngineFuelTempr1;
    }

    public void setAvgEngineFuelTempr1(HeaderData avgEngineFuelTempr1)
    {
        this.avgEngineFuelTempr1 = avgEngineFuelTempr1;
    }

    public HeaderData getMinAmbientAirTempr()
    {
        return minAmbientAirTempr;
    }

    public void setMinAmbientAirTempr(HeaderData minAmbientAirTempr)
    {
        this.minAmbientAirTempr = minAmbientAirTempr;
    }

    public HeaderData getMaxAmbientAirTempr()
    {
        return maxAmbientAirTempr;
    }

    public void setMaxAmbientAirTempr(HeaderData maxAmbientAirTempr)
    {
        this.maxAmbientAirTempr = maxAmbientAirTempr;
    }

    public HeaderData getAvgAmbientAirTempr()
    {
        return avgAmbientAirTempr;
    }

    public void setAvgAmbientAirTempr(HeaderData avgAmbientAirTempr)
    {
        this.avgAmbientAirTempr = avgAmbientAirTempr;
    }

    public HeaderData getMinAuxiliaryTempr1()
    {
        return minAuxiliaryTempr1;
    }

    public void setMinAuxiliaryTempr1(HeaderData minAuxiliaryTempr1)
    {
        this.minAuxiliaryTempr1 = minAuxiliaryTempr1;
    }

    public HeaderData getMaxAuxiliaryTempr1()
    {
        return maxAuxiliaryTempr1;
    }

    public void setMaxAuxiliaryTempr1(HeaderData maxAuxiliaryTempr1)
    {
        this.maxAuxiliaryTempr1 = maxAuxiliaryTempr1;
    }

    public HeaderData getAvgAuxiliaryTempr1()
    {
        return avgAuxiliaryTempr1;
    }

    public void setAvgAuxiliaryTempr1(HeaderData avgAuxiliaryTempr1)
    {
        this.avgAuxiliaryTempr1 = avgAuxiliaryTempr1;
    }

}
