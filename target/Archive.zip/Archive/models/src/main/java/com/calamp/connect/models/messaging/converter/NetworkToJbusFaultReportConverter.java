package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusFaultReportEvent;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;
@Component
public class NetworkToJbusFaultReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusFaultReportConverter.class);
   
	public JbusFaultReportEvent convert(NetworkMessage network) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusFaultReportEvent jbusFaultReportEvent  = mapper.map(network, JbusFaultReportEvent.class);
		jbusFaultReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusFaultReportEvent;
	}

}
