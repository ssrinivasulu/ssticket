package com.calamp.connect.models.messaging.devicecommand;

import java.util.Date;

import com.calamp.connect.models.messaging.DeviceEvent;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.wordnik.swagger.annotations.ApiModelProperty;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.WRAPPER_OBJECT, property = "type")
@JsonSubTypes({ @JsonSubTypes.Type(value = ParameterResponse.class, name = "parameterResponse"),
        @JsonSubTypes.Type(value = AckNakResponse.class, name = "ackNakResponse"),
        @JsonSubTypes.Type(value = LocateReportResponse.class, name = "locateReportResponse"),
        @JsonSubTypes.Type(value = IdReportResponse.class, name = "idReportResponse") })
public abstract class DeviceCommandMessageResponse extends DeviceEvent implements DeviceCommandMessage
{
    @JsonIgnore
    private String  externalDeviceId;
    @ApiModelProperty(hidden = true)
    private Integer sequenceId;
    private Date    received;
    private Date    created;
    @JsonIgnore
    private String  nagUuid;

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }

        if ((o == null) || (getClass() != o.getClass()))
        {
            return false;
        }

        DeviceCommandMessageResponse that = (DeviceCommandMessageResponse) o;

        if ((externalDeviceId != null) ? !externalDeviceId.equals(that.externalDeviceId) : that.externalDeviceId != null)
        {
            return false;
        }

        if ((sequenceId != null) ? !sequenceId.equals(that.sequenceId) : that.sequenceId != null)
        {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (externalDeviceId != null) ? externalDeviceId.hashCode() : 0;

        result = 31 * result + ((sequenceId != null) ? sequenceId.hashCode() : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "DeviceCommandMessage{" + "externalDeviceId='" + externalDeviceId + '\'' + ", sequenceId=" + sequenceId + '}';
    }

    public String getExternalDeviceId()
    {
        return externalDeviceId;
    }

    public Integer getSequenceId()
    {
        return sequenceId;
    }

    public void setExternalDeviceId(String externalDeviceId)
    {
        this.externalDeviceId = externalDeviceId;
    }

    public void setSequenceId(Integer sequenceId)
    {
        this.sequenceId = sequenceId;
    }
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DeviceEvent.JSON_DATETIME_FORMAT)
    public Date getReceived()
    {
        return received;
    }

    public void setReceived(Date received)
    {
        this.received = received;
    }
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DeviceEvent.JSON_DATETIME_FORMAT)
    public Date getCreated()
    {
        return created;
    }

    public void setCreated(Date created)
    {
        this.created = created;
    }

    public String getNagUuid()
    {
        return nagUuid;
    }

    public void setNagUuid(String nagUuid)
    {
        this.nagUuid = nagUuid;
    }
}
