package com.calamp.connect.models.messaging;

import java.util.Date;

/**
 * 
 * @author Anand
 * This POJO is used only for duplicate checks. Only the below fields are used for duplicate checks. 
 *
 */
public class DuplicateEvent
{
    private int    eventCode;
    private Date   eventTime;
    private Double latitude;
    private Double longitude;
    
    public int getEventCode()
    {
        return eventCode;
    }
    
    public void setEventCode(int eventCode)
    {
        this.eventCode = eventCode;
    }
    
    public Date getEventTime()
    {
        return eventTime;
    }
    
    public void setEventTime(Date eventTime)
    {
        this.eventTime = eventTime;
    }
    
    public Double getLatitude()
    {
        return latitude;
    }
    
    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }
    
    public Double getLongitude()
    {
        return longitude;
    }
    
    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

}
