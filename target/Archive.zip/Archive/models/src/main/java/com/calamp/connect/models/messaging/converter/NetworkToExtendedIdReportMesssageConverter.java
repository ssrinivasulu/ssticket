package com.calamp.connect.models.messaging.converter;

import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.ExtendedIdReportDeviceData;
import com.calamp.connect.models.messaging.ExtendedIdReportEvent;
import com.calamp.connect.models.messaging.IdReportEventUtil;
import com.calamp.connect.models.messaging.RouterModemReport;
import com.calamp.connect.models.network.Network.NetworkMessage;

/**
 * @author xwei
 *
 */
@Component("networkToExtendedIdReportMesssageConverter")
public class NetworkToExtendedIdReportMesssageConverter extends GenericNetworkToDeviceEventConverter
{   
	
	public ExtendedIdReportEvent convert(NetworkMessage network)
    {
        ExtendedIdReportEvent event = mapperFactory.getMapperFacade().map(network, ExtendedIdReportEvent.class);
        String extension = event.getExtension();
        if(extension == null)
        	return event;
        
        List<RouterModemReport> modemReports = IdReportEventUtil.parseModemReport(extension);
        if(modemReports.size() > 0) {
        	ExtendedIdReportDeviceData deviceData = new ExtendedIdReportDeviceData();
        	deviceData.setModemReports(modemReports);
        	event.setDeviceData(deviceData);
        }
        return event;
    }

}
