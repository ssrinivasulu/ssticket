package com.calamp.connect.models.messaging;

public class DeviceParameterReadResponse
{
    GeoZoneInformation    geoZoneInformation;
    long                  numericValue;
    String                parameter;
    ReadResponseValueType type;

    public enum ReadResponseValueType { NUMERIC, GEOZONE_INFORMATION }

    public GeoZoneInformation getGeoZoneInformation()
    {
        return geoZoneInformation;
    }

    public long getNumericValue()
    {
        return numericValue;
    }

    public String getParameter()
    {
        return parameter;
    }

    public ReadResponseValueType getType()
    {
        return type;
    }

    public void setGeoZoneInformation(GeoZoneInformation geoZoneInformation)
    {
        this.geoZoneInformation = geoZoneInformation;
    }

    public void setNumericValue(long numericValue)
    {
        this.numericValue = numericValue;
    }

    public void setParameter(String parameter)
    {
        this.parameter = parameter;
    }

    public void setType(ReadResponseValueType type)
    {
        this.type = type;
    }
}
