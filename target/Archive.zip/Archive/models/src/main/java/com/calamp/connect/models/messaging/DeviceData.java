package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "deviceData")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("deviceData")
@JsonTypeName("deviceData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "systemOfUnits" })
@JsonPropertyOrder({ "systemOfUnits" })
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({ @JsonSubTypes.Type(value = AvlDeviceData.class, name = "avlDeviceData"),
        @JsonSubTypes.Type(value = DtcDeviceData.class, name = "dtcDeviceData"),
        @JsonSubTypes.Type(value = JbusConstructionDailyReportData.class, name = "jbusConstructionDailyReportData"),
        @JsonSubTypes.Type(value = JbusConstructionDailyUsageReportData.class, name = "jbusConstructionDailyUsageReportData"),
        @JsonSubTypes.Type(value = JbusConstructionHourlyReportData.class, name = "jbusConstructionHourlyReportData"),
        @JsonSubTypes.Type(value = JbusDailyReportData.class, name = "jbusDailyReportData"),
        @JsonSubTypes.Type(value = JbusHourlyReportData.class, name = "jbusHourlyReportData"),
        @JsonSubTypes.Type(value = JbusHydraulicReportData.class, name = "jbusHydraulicReportData"),
        @JsonSubTypes.Type(value = LocateReportResponseData.class, name="locateReportResponseData"),
        @JsonSubTypes.Type(value = IdReportDeviceData.class, name="idReportDeviceData"),
        @JsonSubTypes.Type(value = ExtendedIdReportDeviceData.class, name="extendedIdReportDeviceData")
       })

public class DeviceData
{

    private String systemOfUnits;

    public String getSystemOfUnits()
    {
        return systemOfUnits;
    }

    public void setSystemOfUnits(String systemOfUnits)
    {
        this.systemOfUnits = systemOfUnits;
    }

}
