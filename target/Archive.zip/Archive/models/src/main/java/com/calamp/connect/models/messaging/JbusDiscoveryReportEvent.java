package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "jbusDiscoveryReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusDiscoveryReportEvent")
@JsonTypeName("jbusDiscoveryReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiVersion()
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted",
        "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "deviceName", "eventCode", "eventTime", "eventType",
        "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port", "primaryOperator", "operators",
        "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "machineState", "timeOfFix", "inputs", "vin", "vinResponse", "vehicleSpeedFound",
        "odometerFound", "totalFuelFound", "vinFound", "batteryVoltageSourcesFound", "discoveryReportSourcesFound1", "discoveryReportSourcesFound2",
        "discoveryReportSourcesFound3", "discoveryReportSourcesFound4", "fuelTankSourcesFound", "averageFuelTankSourcesFound", "ptoSourcesFound",
        "ptoSourcesActive", "engineTorqueSourcesFound", "engineThrottleSourcesFound" })
@XmlType(name = "jbusDiscoveryReportEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId",
        "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "deviceName", "eventCode",
        "eventTime", "eventType", "lmdirectMessageType", "machineState", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId",
        "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix", "inputs", "vin",
        "vinResponse", "vehicleSpeedFound", "odometerFound", "totalFuelFound", "vinFound", "batteryVoltageSourcesFound",
        "discoveryReportSourcesFound1", "discoveryReportSourcesFound2", "discoveryReportSourcesFound3", "discoveryReportSourcesFound4",
        "fuelTankSourcesFound", "averageFuelTankSourcesFound", "ptoSourcesFound", "ptoSourcesActive", "engineTorqueSourcesFound",
        "engineThrottleSourcesFound" })
public class JbusDiscoveryReportEvent extends DeviceEvent
{
    private MachineState machineState;
    private Boolean      vehicleSpeedFound;
    private Boolean      odometerFound;
    private Boolean      totalFuelFound;
    private Boolean      vinFound;
    private Boolean      batteryVoltageSourcesFound;
    private Boolean      discoveryReportSourcesFound1;
    private Boolean      discoveryReportSourcesFound2;
    private Boolean      discoveryReportSourcesFound3;
    private Boolean      discoveryReportSourcesFound4;
    private Boolean      fuelTankSourcesFound;
    private Boolean      averageFuelTankSourcesFound;
    private Boolean      ptoSourcesFound;
    private Boolean      ptoSourcesActive;
    private Boolean      engineTorqueSourcesFound;
    private Boolean      engineThrottleSourcesFound;

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    public Boolean getVehicleSpeedFound()
    {
        return vehicleSpeedFound;
    }

    public void setVehicleSpeedFound(Boolean vehicleSpeedFound)
    {
        this.vehicleSpeedFound = vehicleSpeedFound;
    }

    public Boolean getOdometerFound()
    {
        return odometerFound;
    }

    public void setOdometerFound(Boolean odometerFound)
    {
        this.odometerFound = odometerFound;
    }

    public Boolean getTotalFuelFound()
    {
        return totalFuelFound;
    }

    public void setTotalFuelFound(Boolean totalFuelFound)
    {
        this.totalFuelFound = totalFuelFound;
    }

    public Boolean getVinFound()
    {
        return vinFound;
    }

    public void setVinFound(Boolean vinFound)
    {
        this.vinFound = vinFound;
    }

    public Boolean getBatteryVoltageSourcesFound()
    {
        return batteryVoltageSourcesFound;
    }

    public void setBatteryVoltageSourcesFound(Boolean batteryVoltageSourcesFound)
    {
        this.batteryVoltageSourcesFound = batteryVoltageSourcesFound;
    }

    public Boolean getDiscoveryReportSourcesFound1()
    {
        return discoveryReportSourcesFound1;
    }

    public void setDiscoveryReportSourcesFound1(Boolean discoveryReportSourcesFound1)
    {
        this.discoveryReportSourcesFound1 = discoveryReportSourcesFound1;
    }

    public Boolean getDiscoveryReportSourcesFound2()
    {
        return discoveryReportSourcesFound2;
    }

    public void setDiscoveryReportSourcesFound2(Boolean discoveryReportSourcesFound2)
    {
        this.discoveryReportSourcesFound2 = discoveryReportSourcesFound2;
    }

    public Boolean getDiscoveryReportSourcesFound3()
    {
        return discoveryReportSourcesFound3;
    }

    public void setDiscoveryReportSourcesFound3(Boolean discoveryReportSourcesFound3)
    {
        this.discoveryReportSourcesFound3 = discoveryReportSourcesFound3;
    }

    public Boolean getDiscoveryReportSourcesFound4()
    {
        return discoveryReportSourcesFound4;
    }

    public void setDiscoveryReportSourcesFound4(Boolean discoveryReportSourcesFound4)
    {
        this.discoveryReportSourcesFound4 = discoveryReportSourcesFound4;
    }

    public Boolean getFuelTankSourcesFound()
    {
        return fuelTankSourcesFound;
    }

    public void setFuelTankSourcesFound(Boolean fuelTankSourcesFound)
    {
        this.fuelTankSourcesFound = fuelTankSourcesFound;
    }

    public Boolean getAverageFuelTankSourcesFound()
    {
        return averageFuelTankSourcesFound;
    }

    public void setAverageFuelTankSourcesFound(Boolean averageFuelTankSourcesFound)
    {
        this.averageFuelTankSourcesFound = averageFuelTankSourcesFound;
    }

    public Boolean getPtoSourcesFound()
    {
        return ptoSourcesFound;
    }

    public void setPtoSourcesFound(Boolean ptoSourcesFound)
    {
        this.ptoSourcesFound = ptoSourcesFound;
    }

    public Boolean getPtoSourcesActive()
    {
        return ptoSourcesActive;
    }

    public void setPtoSourcesActive(Boolean ptoSourcesActive)
    {
        this.ptoSourcesActive = ptoSourcesActive;
    }

    public Boolean getEngineTorqueSourcesFound()
    {
        return engineTorqueSourcesFound;
    }

    public void setEngineTorqueSourcesFound(Boolean engineTorqueSourcesFound)
    {
        this.engineTorqueSourcesFound = engineTorqueSourcesFound;
    }

    public Boolean getEngineThrottleSourcesFound()
    {
        return engineThrottleSourcesFound;
    }

    public void setEngineThrottleSourcesFound(Boolean engineThrottleSourcesFound)
    {
        this.engineThrottleSourcesFound = engineThrottleSourcesFound;
    }
}
