package com.calamp.connect.models.domain.devicecommand;

import java.util.Arrays;

public class ParameterConfigInfoEntity
{
    private Integer parameterId;
    private Integer parameterIndex;
    private byte[]  value;

    public ParameterConfigInfoEntity() {}

    public ParameterConfigInfoEntity(Integer parameterId, Integer parameterIndex, byte[] value)
    {
        this.parameterId    = parameterId;
        this.parameterIndex = parameterIndex;
        this.value          = value;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        ParameterConfigInfoEntity that = (ParameterConfigInfoEntity) o;

        if ((parameterId != null)
            ? !parameterId.equals(that.parameterId)
            : that.parameterId != null){
            return false;
        }

        if ((parameterIndex != null)
            ? !parameterIndex.equals(that.parameterIndex)
            : that.parameterIndex != null){
            return false;
        }

        if (!Arrays.equals(value, that.value)){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (parameterId != null)
                     ? parameterId.hashCode()
                     : 0;

        result = 31 * result + ((parameterIndex != null)
                                ? parameterIndex.hashCode()
                                : 0);
        result = 31 * result + ((value != null)
                                ? Arrays.hashCode(value)
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "ParameterConfigInfo{" + "parameterId=" + parameterId + ", parameterIndex=" + parameterIndex
               + ", value=" + Arrays.toString(value) + '}';
    }

    public Integer getParameterId()
    {
        return parameterId;
    }

    public Integer getParameterIndex()
    {
        return parameterIndex;
    }

    public byte[] getValue()
    {
        return value;
    }
}
