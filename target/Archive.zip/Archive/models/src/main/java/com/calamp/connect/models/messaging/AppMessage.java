package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "appMessage")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("appMessage")
@JsonTypeName("appMessage")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType (propOrder = {"appMessageType","appMessageLength", "appMessageMessage"})
@JsonPropertyOrder ( {"appMessageType","appMessageLength", "appMessageMessage"})
@ApiVersion()
public class AppMessage extends AvlEventV2{
	private	String	appMessageType;
	private byte[]	appMessageMessage;
	private Integer		appMessageLength;
	public String getAppMessageType() {
		return appMessageType;
	}
	public void setAppMessageType(String appMessageType) {
		this.appMessageType = appMessageType;
	}
	public byte[] getAppMessageMessage() {
		return appMessageMessage;
	}
	public void setAppMessageMessage(byte[] appMessageMessage) {
		if(appMessageMessage != null)
			this.appMessageLength = appMessageMessage.length;
		else
			this.appMessageLength = 0;
		this.appMessageMessage = appMessageMessage;
	}
	public Integer getAppMessageLength() {
		return appMessageLength;
	}
	public void setAppMessageLength(Integer appMessageLength) {
		this.appMessageLength = appMessageLength;
	}
	
	
	
	
	

}
