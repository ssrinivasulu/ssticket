package com.calamp.connect.models.messaging;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.models.messaging.devicecommand.DeviceCommandMessageRequest;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandMessageResponse;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "deviceCommandEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("deviceCommandEvent")
@JsonTypeName("deviceCommandEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "UUID", "account", "accountId", "accountName", "asset", "assetId", "assetName", "created", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "deviceName", "eventCode", "eventTime",
        "eventType", "inputs", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port",
        "primaryOperator", "operators", "operatorIds",  "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "request", "response", "sequenceId", "status",
        "timeOfFix", "vin", "vinResponse" })
@JsonPropertyOrder({ "UUID", "account", "accountId", "accountName", "asset", "assetId", "assetName", "created", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "deviceName", "eventCode", "eventTime",
        "eventType", "inputs", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port",
        "primaryOperator", "operators", "operatorIds",  "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "request", "response", "sequenceId", "status",
        "timeOfFix", "vin", "vinResponse" })
public class DeviceCommandEvent extends DeviceEvent
{
    private Date                         created;
    private String                       UUID;
    private Long                         accountId;
    private CommandStatus                status;
    private Integer                      sequenceId;
    private DeviceCommandMessageRequest  request;
    private DeviceCommandMessageResponse response;

    public static enum CommandStatus
    {
        PENDING, COMPLETE, // to support v1 request
        CREATED, QUEUED, SENT, COMPLETED, UNDELIVERABLE, EXPIRED_TIME, EXPIRED_ATTEMPTS, CANCELLED, CANCELLED_COMPLETED // new status for V2 request
    }

    public DeviceCommandMessageRequest getRequest()
    {
        return request;
    }

    public DeviceCommandMessageResponse getResponse()
    {
        return response;
    }

    public CommandStatus getStatus()
    {
        return status;
    }

    public String getUUID()
    {
        return UUID;
    }

    public void setRequest(DeviceCommandMessageRequest request)
    {
        this.request = request;
    }

    public void setResponse(DeviceCommandMessageResponse response)
    {
        this.response = response;
    }

    public void setStatus(CommandStatus status)
    {
        this.status = status;
    }

    public void setUUID(String uUID)
    {
        UUID = uUID;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DeviceEvent.JSON_DATETIME_FORMAT)
    public Date getCreated()
    {
        return created;
    }

    public void setCreated(Date created)
    {
        this.created = created;
    }

    public Long getAccountId()
    {
        return accountId;
    }

    public void setAccountId(Long accountId)
    {
        this.accountId = accountId;
    }

    public Integer getSequenceId()
    {
        return sequenceId;
    }

    public void setSequenceId(Integer sequenceId)
    {
        this.sequenceId = sequenceId;
    }
}
