package com.calamp.connect.models.messaging.devicecommand;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
    use      = JsonTypeInfo.Id.NAME,
    include  = JsonTypeInfo.As.PROPERTY,
    property = "type"
)
@JsonSubTypes(
{
	@JsonSubTypes.Type(value = LocateReportRequest.class, name="locateReportRequest") ,
    @JsonSubTypes.Type(value = PegActionRequest.class, name="pegActionRequest") ,
    @JsonSubTypes.Type(value = UnitRequest.class, name="unitRequest") ,
    @JsonSubTypes.Type(value = SetAndEnableZoneRequest.class, name="setAndEnableZoneRequest"),
    @JsonSubTypes.Type(value = IdReportRequest.class, name="idReportRequest"),
    @JsonSubTypes.Type(value = ParameterRequest.class, name="parameterRequest"),
    @JsonSubTypes.Type(value = RebootRequest.class, name="rebootRequest"),
    @JsonSubTypes.Type(value = OtaDownloadRequest.class, name="otaDownloadRequest"),
	@JsonSubTypes.Type(value = ParameterResponse.class, name="parameterResponse") , 
    @JsonSubTypes.Type(value = AckNakResponse.class, name="ackNakResponse") ,
    @JsonSubTypes.Type(value = LocateReportResponse.class, name="locateReportResponse"),
    @JsonSubTypes.Type(value = IdReportResponse.class, name="idReportResponse")
})
public interface DeviceCommandMessage
{
    public String getExternalDeviceId();

    public Integer getSequenceId();
}
