package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonRootName("Fleet")
@JsonPropertyOrder({ "counts", "errors", "equipments" })
@XmlRootElement(name = "Fleet")
@XmlType(name = "Fleet")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@XmlSeeAlso(value = { Equipment.class })
@JsonTypeName("Fleet")
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
public class AempResponse<M>
{
    @XmlElement(name = "Error", required = false, nillable = true)
    private final List<String>  errors       = new ArrayList<>();
    @XmlElement(name = "Equipment", required = true, nillable = true, type = Equipment.class)
    private final List<M>       equipments   = new ArrayList<>();
    private M                   counts;
    @XmlAttribute(name = "version", required = false)
    private final static String Version      = "1.2";
    @XmlAttribute(name = "snapshotTime", required = false)
    @XmlJavaTypeAdapter(value = DateAdapter.class, type = Date.class)
    private Date                SnapshotTime = new Date();

    public void addErrors(String... errors)
    {
        if ((errors == null) || (errors.length == 0))
            return;

        for (String s : errors)
            this.errors.add(s);
    }

    @SafeVarargs
    public final void addEquipments(M... results)
    {
        if ((results == null) || (results.length == 0))
            return;

        for (M r : results)
            this.equipments.add(r);
    }

    public final void setCounts(M counts)
    {
        this.counts = counts;
    }

    @JsonProperty(value = "errors")
    public List<String> getErrors()
    {
        return errors;
    }

    @JsonProperty("results")
    @JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
    public List<M> getEquipments()
    {
        return equipments;
    }

    @XmlElement
    public M getCounts()
    {
        return counts;
    }
}