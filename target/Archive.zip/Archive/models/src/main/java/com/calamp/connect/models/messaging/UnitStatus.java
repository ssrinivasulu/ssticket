package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "unitStatus")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("unitStatus")
@JsonTypeName("unitStatus")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)

public class UnitStatus
{
    private Boolean gpsAntennaStatus;        // true = OK, false = Error
    private Boolean gpsExceptionReported;    // true = OK, false = Error
    private Boolean gpsReceiverSelfTest;     // true = OK, false = Error
    private Boolean gpsReceiverTracking;     // true=Yes, false=No
    private Boolean memoryTest;              // true = OK, false = error
    private Boolean modemMinTestResults;     // true = OK, false = Error

    public Boolean getGpsAntennaStatus()
    {
        return gpsAntennaStatus;
    }

    public Boolean getGpsExceptionReported()
    {
        return gpsExceptionReported;
    }

    public Boolean getGpsReceiverSelfTest()
    {
        return gpsReceiverSelfTest;
    }

    public Boolean getGpsReceiverTracking()
    {
        return gpsReceiverTracking;
    }

    public Boolean getMemoryTest()
    {
        return memoryTest;
    }

    public Boolean getModemMinTestResults()
    {
        return modemMinTestResults;
    }

    public void setGpsAntennaStatus(Boolean gpsAntennaStatus)
    {
        this.gpsAntennaStatus = gpsAntennaStatus;
    }

    public void setGpsExceptionReported(Boolean gpsExceptionReported)
    {
        this.gpsExceptionReported = gpsExceptionReported;
    }

    public void setGpsReceiverSelfTest(Boolean gpsReceiverSelfTest)
    {
        this.gpsReceiverSelfTest = gpsReceiverSelfTest;
    }

    public void setGpsReceiverTracking(Boolean gpsReceiverTracking)
    {
        this.gpsReceiverTracking = gpsReceiverTracking;
    }

    public void setMemoryTest(Boolean memoryTest)
    {
        this.memoryTest = memoryTest;
    }

    public void setModemMinTestResults(Boolean modemMinTestResults)
    {
        this.modemMinTestResults = modemMinTestResults;
    }
}
