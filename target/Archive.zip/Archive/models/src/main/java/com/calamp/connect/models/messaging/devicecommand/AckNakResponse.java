package com.calamp.connect.models.messaging.devicecommand;

import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@XmlType(propOrder = { "successfulAck" })
@JsonPropertyOrder({ "successfulAck" })
@JsonInclude(Include.NON_EMPTY)
public class AckNakResponse extends DeviceCommandMessageResponse
{
    private boolean successfulAck;

    public AckNakResponse() {}

    public AckNakResponse(String externalDeviceId, Integer sequenceId, boolean successfulAck)
    {
        setExternalDeviceId(externalDeviceId);
        setSequenceId(sequenceId);

        this.successfulAck = successfulAck;
    }

    public boolean isSuccessfulAck()
    {
        return successfulAck;
    }

    public void setSuccessfulAck(boolean successfulAck)
    {
        this.successfulAck = successfulAck;
    }
}
