package com.calamp.connect.models.messaging;

import javax.measure.quantity.Speed;
import javax.measure.quantity.Time;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.MaxAcceleration;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "acceleration")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("acceleration")
@JsonTypeName("acceleration")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "accelerationMagnitude", "calibration", "duration", "label", "startingSpeed" })
@JsonPropertyOrder({ "accelerationMagnitude", "calibration", "duration", "label", "startingSpeed" })
public class Acceleration
{

    private String     label;

    @ConvertUnit(type = MaxAcceleration.class)
    private HeaderData accelerationMagnitude;

    @ConvertUnit(type = Time.class)
    private HeaderData duration;

    @ConvertUnit(type = Speed.class)
    private HeaderData startingSpeed;

    private String     calibration;

    public String getLabel()
    {
        return label;
    }

    public void setLabel(String label)
    {
        this.label = label;
    }

    public HeaderData getAccelerationMagnitude()
    {
        return accelerationMagnitude;
    }

    public void setAccelerationMagnitude(HeaderData accelerationMagnitude)
    {
        this.accelerationMagnitude = accelerationMagnitude;
    }

    public HeaderData getDuration()
    {
        return duration;
    }

    public void setDuration(HeaderData duration)
    {
        this.duration = duration;
    }

    public HeaderData getStartingSpeed()
    {
        return startingSpeed;
    }

    public void setStartingSpeed(HeaderData startingSpeed)
    {
        this.startingSpeed = startingSpeed;
    }

    public String getCalibration()
    {
        return calibration;
    }

    public void setCalibration(String calibration)
    {
        this.calibration = calibration;
    }

}
