package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IdReportEventUtil {
	private static Map<String, String> modelModeMap;
	static {
		modelModeMap = new HashMap<String, String>();
		modelModeMap.put("MC7354", "LTE");
		modelModeMap.put("PLS8", "LTE");
		modelModeMap.put("ALS3", "LTE");
		modelModeMap.put("ELS61", "LTE");
		modelModeMap.put("PXS8", "3G");
		modelModeMap.put("MC7700", "LTE");
		modelModeMap.put("MC7710", "LTE");
		modelModeMap.put("MC7750", "LTE");
		modelModeMap.put("MC7455", "LTE");
		modelModeMap.put("MC7430", "LTE");
	}
		
	public static Map<String, String> parseExtensionStr(String extensionStr) {
    	Map<String, String> map = new HashMap<String, String>();
    	String[] extensions = extensionStr.split("\u0000");
    	for(String extension : extensions) {
    		String[] field = extension.trim().split(":");
    		if(field.length != 2) 
    			continue;
    		map.put(field[0], field[1]);
    	}
    	return map;
	}
	
	public static List<RouterModem> parseModemInfo(Map<String, String> extensionMap) {
		String numWan = extensionMap.get("#WAN");
		if(numWan == null)
			return null;
		
    	int numOfModems = Integer.valueOf(numWan);
    	List<RouterModem> modems = new ArrayList<RouterModem>();
    	for(int i = 0; i < numOfModems; i++) {
    		RouterModem modem = new RouterModem();
    		String keyPrefix = "W" + (i + 1);
    		modem.setCarrier(extensionMap.get(keyPrefix + "CR"));
    		modem.setIpAddress(extensionMap.get(keyPrefix + "IP"));
    		modem.setPhoneNum(extensionMap.get(keyPrefix + "PHN"));
    		modem.setRssi(extensionMap.get(keyPrefix + "RSSI"));
    		String model = extensionMap.get(keyPrefix + "MD");
    		modem.setModel(model);
    		modem.setNetworkMode(getNetworkMode(model));
    		modem.setCurrentNetworkMode(extensionMap.get(keyPrefix + "LNKTYP"));
    		modems.add(modem);
    	}
    	return modems;
	}
    
	private static String getNetworkMode(String model) {
		return modelModeMap.get(model);
	}
	
	public static List<RouterModemReport> parseModemReport(String extensionStr) {
		List<RouterModemReport> modemReports = new ArrayList<RouterModemReport>();
		Map<String, String> map = parseExtensionStr(extensionStr);
		int numOfModems = map.get("#WAN") != null ? Integer.valueOf(map.get("#WAN")) : 1;
    	for(int i = 0; i < numOfModems; i++) {
    		RouterModemReport modemReport = new RouterModemReport();
    		String keyPrefix = "W" + (i + 1);
    		modemReport.setDataPackets(map.get(keyPrefix + "DATA"));
    		modemReport.setRssi(map.get(keyPrefix + "RSSI"));
    		modemReports.add(modemReport);
    	}
    	
    	return modemReports;
	}
	
    public static final void main(String[] args) {
    	String sampleExtension = "SKU:VG5530-LVZ-M-VZAT\u0000SAFE:1\u0000FVER:CAVNG-v1.0.5.44\u0000RREV:0,,,,,,,,,|1,,,,,,,,,|9,,,,,,,,,|11,,,,,,,,,|12,,,,,,,,,\u0000OS:3.10.17-CAVNG-v1.0.5.40\n\u0000LATLON:\u0000OTA:1|0;0\u0000#WAN:1\u0000WACT:1\u0000W1MD:MC7354\u0000W1FW:SWI9X15C_05.05.58.01_VZW_005.029_000\u0000W1FRQ:LTE 1700 (B4)\u0000W1LNKTYP:LTE (4G)\u0000W1CR:Verizon Wireless\u0000W1RM:Home Network\u0000W1PRL:0\u0000W1PDNS:198.224.173.135\u0000W1SDNS:198.224.174.135\u0000W1TMP:38\u0000W1PHN:9492856927\u0000W1MEID:A100003DB08D0E\u0000W1IMSI:311480105372406\u0000W1IP:166.149.110.13\u0000W1NM:255.255.255.252\u0000W1GWIP:166.149.110.14\u0000W1ICCID:89148000001034452341\u0000W1IMEI:359225051841088\u0000W1RFT:LTE\u0000W1RSSI:-62\u0000W1RSRQ:\u0000W1SINR:\u0000";
    	Map<String, String> extensionMap = parseExtensionStr(sampleExtension);
    	System.out.println("the resource revision is: " + extensionMap.get("RREV"));
    	for(RouterModem modem : parseModemInfo(extensionMap)) {
    		System.out.println(modem);
    	}
    	
    }
}
