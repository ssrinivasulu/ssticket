package com.calamp.connect.models.messaging.devicecommand;

public class RebootRequest extends DeviceCommandMessageRequest
{
    @Override
    public String toString()
    {
        return "RebootRequest{" + super.toString() + '}';
    }
}
