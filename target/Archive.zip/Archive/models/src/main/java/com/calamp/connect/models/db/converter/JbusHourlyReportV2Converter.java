package com.calamp.connect.models.db.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.models.db.domain.JbusHourlyReportEntity;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.JbusHourlyReportData;
import com.calamp.connect.models.messaging.JbusHourlyReportEventV2;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusHourlyReportV2Converter extends DeviceEventConverter<JbusHourlyReportEntity, JbusHourlyReportEventV2>
{
    private Logger logger = LoggerFactory.getLogger(JbusHourlyReportV2Converter.class);

    @Override
    public JbusHourlyReportEntity modelToDomain(JbusHourlyReportEventV2 jbusHourlyReportEvent)
    {
        JbusHourlyReportEntity jbusHourlyReportEntity = super.convert(jbusHourlyReportEvent, JbusHourlyReportEntity.class);

        return customConvert(jbusHourlyReportEvent, jbusHourlyReportEntity);

    }

    @Override
    public JbusHourlyReportEventV2 domainToModel(JbusHourlyReportEntity jbusHourlyReportEventEntity)
    {
        JbusHourlyReportEventV2 jbusHourlyReportEvent = super.convert(jbusHourlyReportEventEntity, JbusHourlyReportEventV2.class);

        return customConvert(jbusHourlyReportEventEntity, jbusHourlyReportEvent);

    }

    @Override
    protected JbusHourlyReportEntity customConvert(JbusHourlyReportEventV2 model, JbusHourlyReportEntity entity)
    {
        entity.setDeviceData(model.getDeviceData());
        entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    protected JbusHourlyReportEventV2 customConvert(JbusHourlyReportEntity entity, JbusHourlyReportEventV2 model)
    {
        if (entity.getDeviceData() != null && entity.getDeviceDataConverted() != null)
        {
            model.setDeviceDataConverted((JbusHourlyReportData)entity.getDeviceDataConverted());
        }
        else
        {
            JbusHourlyReportData hourlyReportData = new JbusHourlyReportData();
            if (entity.getAverageFuelEconomy() != null)
                hourlyReportData.setAverageFuelEconomy(new HeaderData(entity.getAverageFuelEconomy().toString(), null));
            if (entity.getEngineBatteryVoltage() != null)
                hourlyReportData.setEngineBatteryVoltage(new HeaderData(entity.getEngineBatteryVoltage().toString(), null));
            if (entity.getEngineCoolantPressure() != null)
                hourlyReportData.setEngineCoolantPressure(new HeaderData(entity.getEngineCoolantPressure().toString(), null));
            if (entity.getEngineCoolantTemperature() != null)
                hourlyReportData.setEngineCoolantTemperature(new HeaderData(entity.getEngineCoolantTemperature().toString(), null));
            if (entity.getEngineFuelTankLevel1() != null)
                hourlyReportData.setEngineFuelTankLevel1(new HeaderData(entity.getEngineFuelTankLevel1().toString(), null));
            if (entity.getEngineFuelTankLevel2() != null)
                hourlyReportData.setEngineFuelTankLevel2(new HeaderData(entity.getEngineFuelTankLevel2().toString(), null));
            if (entity.getEngineOilPressure() != null)
                hourlyReportData.setEngineOilPressure(new HeaderData(entity.getEngineOilPressure().toString(), null));
            if (entity.getTransmissionOilTemperature() != null)
                hourlyReportData.setTransmissionOilTemperature(new HeaderData(entity.getTransmissionOilTemperature().toString(), null));
            entity.setDeviceData(hourlyReportData);
            entity.setDeviceDataConverted(hourlyReportData);
            model.setDeviceDataConverted(hourlyReportData);
        }

        return model;
    }

    @Override
    public JbusHourlyReportEventV2 domainToModel(JbusHourlyReportEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusHourlyReportEventV2> getModelType()
    {
        return JbusHourlyReportEventV2.class;
    }

    @Override
    public Class<JbusHourlyReportEntity> getDomainType()
    {
        return JbusHourlyReportEntity.class;
    }
}
