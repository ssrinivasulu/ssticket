package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEvent;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusConstructionDailyUsageReportConverter")
public class DeviceEventToJbusConstructionDailyUsageReportConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusConstructionDailyUsageReportEvent, ConstructionDailyUsageReport>
{

    @Override
    public ConstructionDailyUsageReport modelToDomain(JbusConstructionDailyUsageReportEvent event)
    {
        return null;
    }

    @Override
    public JbusConstructionDailyUsageReportEvent domainToModel(ConstructionDailyUsageReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionDailyUsageReportEvent jbusConstructionDailyUsageReportEvent = mapper.map(event, JbusConstructionDailyUsageReportEvent.class);
        if (event.getDeviceData() != null)
        {
            ConstructionDailyUsageReportData constructionDailyUsageReportData = (ConstructionDailyUsageReportData) event.getDeviceData();
            if (constructionDailyUsageReportData.getEngineTorque0To10PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque0To10PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque0To10PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque10To20PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque10To20PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque10To20PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque20To30PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque20To30PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque20To30PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque30To40PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque30To40PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque30To40PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque40To50PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque40To50PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque40To50PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque50To60PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque50To60PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque50To60PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque60To70PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque60To70PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque60To70PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque70To80PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque70To80PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque70To80PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque80To90PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorque80To90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque80To90PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorqueOver90PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setEngineTorqueOver90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorqueOver90PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque0To10PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque0To10PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque0To10PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque10To20PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque10To20PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque10To20PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque20To30PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque20To30PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque20To30PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque30To40PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque30To40PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque30To40PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque40To50PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque40To50PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque40To50PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque50To60PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque50To60PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque50To60PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque60To70PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque60To70PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque60To70PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque70To80PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque70To80PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque70To80PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque80To90PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorque80To90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque80To90PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorqueOver90PercentUsage() != null)
                jbusConstructionDailyUsageReportEvent.setPositionTorqueOver90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorqueOver90PercentUsage()));

        }
        return jbusConstructionDailyUsageReportEvent;
    }

    @Override
    public JbusConstructionDailyUsageReportEvent domainToModel(ConstructionDailyUsageReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<ConstructionDailyUsageReport> getDomainType()
    {
        return ConstructionDailyUsageReport.class;
    }

    @Override
    public Class<JbusConstructionDailyUsageReportEvent> getModelType()
    {
        return JbusConstructionDailyUsageReportEvent.class;
    }
}
