package com.calamp.connect.models.messaging.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.DeviceCommandResponseEvent.DeviceCommandResponseTypes;
import com.calamp.connect.models.messaging.DeviceCommandStatus;
import com.calamp.connect.models.messaging.devicecommand.Accumulator;
import com.calamp.connect.models.messaging.devicecommand.AckNakResponse;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandMessageResponse;
import com.calamp.connect.models.messaging.devicecommand.IdReportResponse;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponse;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData;
import com.calamp.connect.models.messaging.devicecommand.ParameterResponse;
import com.calamp.connect.models.network.Network;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;
import com.calamp.connect.models.network.Network.RawDeviceCommandResponse;

@Component("networkToDeviceCommandResponceMessageConverter")
public class NetworkToDeviceCommandResponceMessageConverter extends GenericNetworkToDeviceEventConverter
{

    public DeviceCommandMessageResponse convert(NetworkMessage network)
    {
        DeviceCommandMessageResponse commandMessageResponse = null;
        MapperFacade mapper = mapperFactory.getMapperFacade();

        if (network.getRawDeviceCommandResponse() != null)
        {
            NetworkMessageType type = network.getType();
            if (NetworkMessageType.CONFIGURATION_PARAMETER.equals(type))
            {

                ParameterResponse parameterResponse = mapper.map(network, ParameterResponse.class);
                parameterResponse.setMessageType(NetworkMessageType.CONFIGURATION_PARAMETER);
                commandMessageResponse = parameterResponse;

                // if there is no information in the message, then it was just a successful write message
                // once retry is in, you can make the messages more user friendly
                if (parameterResponse.getInvalidParameterIndexes().isEmpty() && parameterResponse.getInvalidParameterIndexes().isEmpty()
                        && parameterResponse.getParameters().isEmpty() && parameterResponse.getGeoZoneInformation() == null)
                {
                    if (network.getRawDeviceCommandResponse().getType().equals(RawDeviceCommandResponse.DeviceCommandResponseTypes.STATUS))
                    {
                        AckNakResponse ackNakResponse = mapper.map(network, AckNakResponse.class);
                        ackNakResponse.setMessageType(NetworkMessageType.ACK_MESSAGE);
                        if (network.getRawDeviceCommandResponse().getDeviceCommandStatus().getStatus()
                                .equals(Network.DeviceCommandStatus.DeviceCommandStatuses.SUCCESS))
                        {
                            ackNakResponse.setSuccessfulAck(true);
                        }
                        commandMessageResponse = ackNakResponse;
                    }
                }
                commandMessageResponse.setDeviceEsn(network.getExternalDeviceId());
            }
            else if (NetworkMessageType.LOCATE_REPORT_MESSAGE.equals(type))
            {
                LocateReportResponse locateReportResponse = mapper.map(network, LocateReportResponse.class);
                LocateReportResponseData locateReportResponseData = mapper.map(network, LocateReportResponseData.class);

                if (locateReportResponseData.getAccumulators() != null)
                {
                    for (Accumulator rawAccumulator : locateReportResponseData.getAccumulators())
                    {
                        rawAccumulator.setLabel("Accumulator " + rawAccumulator.getIndex());
                        // acc.setValue(String.valueOf(rawAccumulator));
                    }
                }
                locateReportResponse.setDeviceData(locateReportResponseData);
                LocateReportResponseData reportResponseData = new LocateReportResponseData();
                reportResponseData.setAccumulators(locateReportResponseData.getAccumulators());
                locateReportResponse.setDeviceDataConverted(reportResponseData);
                locateReportResponse.setMessageType(NetworkMessageType.LOCATE_REPORT_MESSAGE);
                commandMessageResponse = locateReportResponse;
                commandMessageResponse.setDeviceEsn(network.getExternalDeviceId());
            }
            else if (NetworkMessageType.ID_REPORT_MESSAGE.equals(type))
            {

                IdReportResponse idReportResponse = mapper.map(network, IdReportResponse.class);
                idReportResponse.setMessageType(NetworkMessageType.ID_REPORT_MESSAGE);
                commandMessageResponse = idReportResponse;
                commandMessageResponse.setDeviceEsn(network.getExternalDeviceId());
            }
            else if (NetworkMessageType.ACK_MESSAGE.equals(type))
            {
                AckNakResponse ackNakResponse = mapper.map(network, AckNakResponse.class);
                ackNakResponse.setMessageType(NetworkMessageType.ACK_MESSAGE);
                commandMessageResponse = ackNakResponse;
                commandMessageResponse.setDeviceEsn(network.getExternalDeviceId());
            }
        }
        return commandMessageResponse;

    }
}
