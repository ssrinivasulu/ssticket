package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusEventProtocol;
import com.calamp.connect.models.network.Event.JBusEvent;
import com.calamp.connect.models.network.Jbus.JbusData1708;
import com.calamp.connect.models.network.Jbus.JbusData1939;


@Component("deviceEventToJbusEventConverter")
public class DeviceEventToJbusEventConverter extends GenericDeviceEventToEventMessageConverter{
	
	
	public JBusEvent convertTo(JbusEventProtocol deviceEvent) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		JBusEvent jbusEvent = new JBusEvent();
		if (deviceEvent.getJbusProtocol().equals("1709")) {
			JbusData1708 jbusData1708 =	mapper.map(deviceEvent , JbusData1708.class);
			jbusEvent.setJbusData1708(jbusData1708);
			
		} else if(deviceEvent.getJbusProtocol().equals("1939")) {
			JbusData1939 jbusData1939 =	mapper.map(deviceEvent , JbusData1939.class);
			jbusEvent.setJbusData1939(jbusData1939);
		}
		return jbusEvent;
	}
	
	public JbusEventProtocol convertFrom(JBusEvent deviceEvent) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusEventProtocol jbusEventProtocol = new JbusEventProtocol();
		if (deviceEvent.getJbusData1708() != null) {
			jbusEventProtocol =	mapper.map(deviceEvent.getJbusData1708() , JbusEventProtocol.class);
			jbusEventProtocol.setJbusProtocol("1708");
		} else if(deviceEvent.getJbusData1939() != null) {
			jbusEventProtocol =	mapper.map(deviceEvent.getJbusData1939() , JbusEventProtocol.class);
			jbusEventProtocol.setJbusProtocol("1939");
		}
		return jbusEventProtocol;
	}

}
