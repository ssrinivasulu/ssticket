package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * Java class for JBUSDailyReportEvent complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JBUSDailyReportEvent"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GMTTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="deviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="vehicleID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="vehicleVIN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="driverID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="JBUSDailyReportMessage" type="{http://calamp.com/DataFeedService/}JBUSDailyReportMessage"/&gt;
 *         &lt;any processContents='skip' maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "jbusDailyReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusDailyReportEvent")
@JsonTypeName("jbusDailyReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted",
        "deviceId", "deviceEsn", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "engineCoolantLevel", "engineIdleFuel", "engineIdleHours",
        "engineOilLevel", "engineTotalHours", "eventCode", "eventTime", "eventType", "inputs", "lmdirectMessageType", "messageReceivedTime",
        "messageType", "messageUuid", "noxTankLevel", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId",
        "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusDailyReportEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId",
        "deviceData", "deviceDataConverted", "deviceId", "deviceEsn", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "engineCoolantLevel",
        "engineIdleFuel", "engineIdleHours", "engineOilLevel", "engineTotalHours", "eventCode", "eventTime", "eventType", "inputs",
        "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "noxTankLevel", "pegBehaviorId", "port", "primaryOperator",
        "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
public class JbusDailyReportEvent extends DeviceEvent
{
    private Double              engineTotalHours;
    private Double              engineIdleHours;
    private Double              engineIdleFuel;
    private Double              engineOilLevel;
    private Double              engineCoolantLevel;
    private Double              noxTankLevel;
    private JbusDailyReportData deviceData;
    private JbusDailyReportData deviceDataConverted;

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTotalHours()
    {
        return engineTotalHours;
    }

    public void setEngineTotalHours(Double engineTotalHours)
    {
        this.engineTotalHours = engineTotalHours;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineIdleHours()
    {
        return engineIdleHours;
    }

    public void setEngineIdleHours(Double engineIdleHours)
    {
        this.engineIdleHours = engineIdleHours;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineIdleFuel()
    {
        return engineIdleFuel;
    }

    public void setEngineIdleFuel(Double engineIdleFuel)
    {
        this.engineIdleFuel = engineIdleFuel;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineOilLevel()
    {
        return engineOilLevel;
    }

    public void setEngineOilLevel(Double engineOilLevel)
    {
        this.engineOilLevel = engineOilLevel;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineCoolantLevel()
    {
        return engineCoolantLevel;
    }

    public void setEngineCoolantLevel(Double engineCoolantLevel)
    {
        this.engineCoolantLevel = engineCoolantLevel;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getNoxTankLevel()
    {
        return noxTankLevel;
    }

    public void setNoxTankLevel(Double noxTankLevel)
    {
        this.noxTankLevel = noxTankLevel;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusDailyReportData getDeviceData()
    {
        return (JbusDailyReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusDailyReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusDailyReportData getDeviceDataConverted()
    {
        return (JbusDailyReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusDailyReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
