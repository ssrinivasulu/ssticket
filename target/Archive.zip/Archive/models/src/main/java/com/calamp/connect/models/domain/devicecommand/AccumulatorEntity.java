package com.calamp.connect.models.domain.devicecommand;

import java.util.Arrays;

public class AccumulatorEntity
{
    private byte[]  accumulatorValue;
    private Integer index;

    public AccumulatorEntity() {}

    public AccumulatorEntity(Integer index, byte[] accumulatorValue)
    {
        this.index            = index;
        this.accumulatorValue = accumulatorValue;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        AccumulatorEntity that = (AccumulatorEntity) o;

        if (!Arrays.equals(accumulatorValue, that.accumulatorValue)){
            return false;
        }

        if ((index != null)
            ? !index.equals(that.index)
            : that.index != null){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (index != null)
                     ? index.hashCode()
                     : 0;

        result = 31 * result + ((accumulatorValue != null)
                                ? Arrays.hashCode(accumulatorValue)
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "Accumulator{" + "index=" + index + ", accumulatorValue=" + Arrays.toString(accumulatorValue) + '}';
    }

    public byte[] getAccumulatorValue()
    {
        return accumulatorValue;
    }

    public Integer getIndex()
    {
        return index;
    }

    public void setAccumulatorValue(byte[] accumulatorValue)
    {
        this.accumulatorValue = accumulatorValue;
    }

    public void setIndex(Integer index)
    {
        this.index = index;
    }
}
