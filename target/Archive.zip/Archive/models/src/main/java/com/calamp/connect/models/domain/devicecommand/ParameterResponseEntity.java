package com.calamp.connect.models.domain.devicecommand;

import java.util.ArrayList;
import java.util.List;

public class ParameterResponseEntity extends DeviceCommandMessageResponseEntity
{
    private List<ParameterConfigInfoEntity> parameters              = new ArrayList<>();
    private List<Integer>                   invalidParameters       = new ArrayList<>();
    private List<ParameterConfigInfoEntity> invalidParameterIndexes = new ArrayList<>();
    private GeoZoneInformationEntity geoZoneInformation;

    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        ParameterResponseEntity that = (ParameterResponseEntity) o;

        if ((invalidParameterIndexes != null)
            ? !invalidParameterIndexes.equals(that.invalidParameterIndexes)
            : that.invalidParameterIndexes != null){
            return false;
        }

        if ((invalidParameters != null)
            ? !invalidParameters.equals(that.invalidParameters)
            : that.invalidParameters != null){
            return false;
        }

        if ((parameters != null)
            ? !parameters.equals(that.parameters)
            : that.parameters != null){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (parameters != null)
                     ? parameters.hashCode()
                     : 0;

        result = 31 * result + ((invalidParameters != null)
                                ? invalidParameters.hashCode()
                                : 0);
        result = 31 * result + ((invalidParameterIndexes != null)
                                ? invalidParameterIndexes.hashCode()
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "ParameterResponse{" + ", parameters=" + parameters + ", invalidParameters=" + invalidParameters
               + ", invalidParameterIndexes=" + invalidParameterIndexes + '}';
    }

    public List<ParameterConfigInfoEntity> getInvalidParameterIndexes()
    {
        return invalidParameterIndexes;
    }

    public List<Integer> getInvalidParameters()
    {
        return invalidParameters;
    }

    public List<ParameterConfigInfoEntity> getParameters()
    {
        return parameters;
    }

    public void setInvalidParameterIndexes(List<ParameterConfigInfoEntity> invalidParameterIndexes)
    {
        this.invalidParameterIndexes = invalidParameterIndexes;
    }

    public void setInvalidParameters(List<Integer> invalidParameters)
    {
        this.invalidParameters = invalidParameters;
    }

    public void setParameters(List<ParameterConfigInfoEntity> parameters)
    {
        this.parameters = parameters;
    }

    public GeoZoneInformationEntity getGeoZoneInformation()
    {
        return geoZoneInformation;
    }

    public void setGeoZoneInformation(GeoZoneInformationEntity geoZoneInformation)
    {
        this.geoZoneInformation = geoZoneInformation;
    }
    
}
