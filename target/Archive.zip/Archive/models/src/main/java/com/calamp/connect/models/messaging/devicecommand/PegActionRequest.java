package com.calamp.connect.models.messaging.devicecommand;

import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@XmlType(propOrder = { "pegActionCode", "pegActionModifier" })
@JsonPropertyOrder({ "deviceIpAddress", "pegActionCode", "pegActionModifier" })
public class PegActionRequest extends DeviceCommandMessageRequest
{
    private Integer pegActionCode;
    private Integer pegActionModifier;

    public PegActionRequest() {}

    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        PegActionRequest that = (PegActionRequest) o;

        if ((pegActionCode != null)
            ? !pegActionCode.equals(that.pegActionCode)
            : that.pegActionCode != null){
            return false;
        }

        if ((pegActionModifier != null)
            ? !pegActionModifier.equals(that.pegActionModifier)
            : that.pegActionModifier != null){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (pegActionCode != null)
                     ? pegActionCode.hashCode()
                     : 0;

        result = 31 * result + ((pegActionModifier != null)
                                ? pegActionModifier.hashCode()
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "PegActionRequest{" + "pegActionCode=" + pegActionCode + ", pegActionModifier=" + pegActionModifier
               + '}';
    }

    public Integer getPegActionCode()
    {
        return pegActionCode;
    }

    public Integer getPegActionModifier()
    {
        return pegActionModifier;
    }

    public void setPegActionCode(Integer pegActionCode)
    {
        this.pegActionCode = pegActionCode;
    }

    public void setPegActionModifier(Integer pegActionModifier)
    {
        this.pegActionModifier = pegActionModifier;
    }
}
