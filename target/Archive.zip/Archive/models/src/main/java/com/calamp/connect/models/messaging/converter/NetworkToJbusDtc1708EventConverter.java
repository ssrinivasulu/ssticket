package com.calamp.connect.models.messaging.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDtc1708Event;
import com.calamp.connect.models.messaging.JbusDtc1708Protocol;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;
import com.calamp.connect.models.network.Network.NetworkMessage;
@Component
public class NetworkToJbusDtc1708EventConverter extends GenericNetworkToDeviceEventConverter
{
    public JbusDtc1708Event convert(NetworkMessage network)
    {
    	JbusDtc1708Event jbusDtc1708Event = new JbusDtc1708Event();
    	List<JbusDtcDataJ1708> jbusDtcDataJ1708s = network.getRawJbusMessage().getJbusDtcDataJ1708();
    	List<JbusDtc1708Protocol> jbusDtc1708Protocols = new ArrayList<JbusDtc1708Protocol>();
    	MapperFacade    jbus1708Mapper = mapperFactory.getMapperFacade();
    	jbus1708Mapper.map(network, jbusDtc1708Event);
    	if(jbusDtcDataJ1708s!=null) {
	    	for (JbusDtcDataJ1708 jbusDtcDataJ1708 : jbusDtcDataJ1708s) {
	    		JbusDtc1708Protocol jbusDtc1708Protocol = new JbusDtc1708Protocol();
	    		jbus1708Mapper.map(jbusDtcDataJ1708, jbusDtc1708Protocol);
	    		jbusDtc1708Protocols.add(jbusDtc1708Protocol);
	    	}
    	}
    	jbusDtc1708Event.setJbusDtc1708ProtocolEvents(jbusDtc1708Protocols);
    	jbusDtc1708Event.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        jbusDtc1708Event.setSourceAddress(network.getRawJbusMessage().getSourceAddress());
        return jbusDtc1708Event;
    }

}
