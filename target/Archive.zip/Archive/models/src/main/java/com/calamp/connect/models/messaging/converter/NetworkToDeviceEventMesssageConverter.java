package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.AckNakEvent;
import com.calamp.connect.models.messaging.DeviceEvent;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class NetworkToDeviceEventMesssageConverter extends GenericNetworkToDeviceEventConverter  {
	
	private static Logger logger = LoggerFactory.getLogger(NetworkToDeviceEventMesssageConverter.class);

	public DeviceEvent convert(NetworkMessage network) {
		
		if(NetworkMessageType.ACK_MESSAGE == network.getType()) {
			return createAckNakEvent(network);
		}
		if(NetworkMessageType.AEMP_MESSAGE == network.getType()) {
			return networkToAempMessageConverter.convert(network);
		}
		else if(NetworkMessageType.EVENT_MESSAGE == network.getType()) {
			return networkToAvlMesssageConverter.convert(network);
		}
		else if(NetworkMessageType.PND_MESSAGE == network.getType()){
			return networkToUserMesssageConverter.convert(network);
		}
		else if(NetworkMessageType.APP_MESSAGE == network.getType()){
			
				if(network.getRawJbusMessage().getJbusMessageType().equals("142"))
				{
					return networkToSelfDescribingJPODMessageConverter.convert(network);
				} else if (network.getRawJbusMessage().getJbusMessageType().equals("138"))
				{
					return networkToJpod2DTCReportConverter.convert(network);
				}
				else
				{
					return networkToAppMesssageConverter.convert(network);
				}
				
			
		}
		else if(NetworkMessageType.ID_REPORT_MESSAGE == network.getType()) {
			return networkToIdReportMesssageConverter.convert(network);
		}
		else if(NetworkMessageType.EXTENDED_ID_REPORT_MESSAGE == network.getType()) {
			return networkToExtendedIdReportMesssageConverter.convert(network);
		} else {
			if(NetworkMessageType.PROVISION_MESSAGE == network.getType()){
				return provisionMesssageConverter.convert(network);
			}
			else {
				if(NetworkMessageType.DTC_MESSAGE == network.getType()){
					return networkToDtcMesssageConverter.convert(network);
				}
                else if (NetworkMessageType.MOTION_LOGS_MESSAGE == network.getType())
                {
                    return networkToMotionLogsMessageConverter.convert(network);
                }
				else {
					network.getType();
					if(NetworkMessageType.JBUS_MESSAGE ==  network.getType()){
						if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("BASIC_MAP"))
							return networkToJbusEventConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("J1939_DTC"))
							return networkToJbusDtc1939EventConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("J1708_DTC"))
							return networkToJbusDtc1708EventConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("DAILY_REPORT"))
							return networkToJbusDailyReportConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("HOURLY_REPORT"))
							return networkToJbusHourlyReportConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("DIAGNOSTICS_MAP"))
							return networkToJbusDtcMesssageConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("CONSTR_DAILY_REPORT"))
							return networkToJbusConstructionDailyReportConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("CONSTR_DAILY_USAGE_REPORT"))
							return networkToJbusConstructionDailyUsageReportConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("CONSTR_HOURLY_REPORT"))
							return networkToJbusConstructionHourlyReportConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("JHYDRAULIC_REPORT"))
							return networkToJbusHydraulicReportConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("JFAULT_REPORT"))
							return networkToJbusFaultReportConverter.convert(network);
						else if(network.getRawJbusMessage().getJbusMessageType()!=null && 
								network.getRawJbusMessage().getJbusMessageType().equals("DISCOVERY_REPORT"))
							return networkToJbusDiscoveryReportConverter.convert(network);
						else {
								//instead of returning null, feed back to app message
								network.setType(NetworkMessageType.APP_MESSAGE);
							    return networkToAppMesssageConverter.convert(network);
							}
					}
				}
			}
		}
		return null;
	}
	
	
	public NetworkMessage convert(DeviceEvent event) {
		//NetworkMessage networkMessage = super.convert(event, NetworkMessage.class);

        return null;
	}
	
	public AckNakEvent createAckNakEvent(NetworkMessage networkMsg) {
		AckNakEvent ackNakEvent = new AckNakEvent();
		ackNakEvent.setMessageUuid(networkMsg.getMessageUuid());
		ackNakEvent.setRawDeviceHexMessage(networkMsg.getRawDeviceHexMessage());
		ackNakEvent.setMessageReceivedTime(networkMsg.getNagReceivedTime());
		ackNakEvent.setDeviceMessageSequenceNumber((long)networkMsg.getSequenceId());;
		ackNakEvent.setDeviceEsn(networkMsg.getExternalDeviceId());
		ackNakEvent.setAckedMsgType(networkMsg.getAckMessage().getType());
		ackNakEvent.setAckStatus(networkMsg.getAckMessage().isAckStatus());
		return ackNakEvent;
	}
	
	@Autowired
	private NetworkToIdReportMesssageConverter networkToIdReportMesssageConverter;
	
	@Autowired
	private NetworkToExtendedIdReportMesssageConverter networkToExtendedIdReportMesssageConverter;
	
	@Autowired
	private NetworkToAvlMesssageConverter networkToAvlMesssageConverter;
	
	@Autowired
	private NetworkToAempMessageConverter networkToAempMessageConverter;
	
	@Autowired
	private NetworkToUserMessageConverter networkToUserMesssageConverter;
	@Autowired
	private NetworkToAppMessageConverter networkToAppMesssageConverter;
	@Autowired
	private NetworkToSelfDescribingJPODMessageConverter networkToSelfDescribingJPODMessageConverter;
	@Autowired
	private NetworkToJpod2DTCReportConverter networkToJpod2DTCReportConverter;
	@Autowired
	private NetworkToVbusCapabilitiesMesssageConverter provisionMesssageConverter;
	
	@Autowired
	private NetworkToJbusEventConverter networkToJbusEventConverter;
	
	@Autowired
	private NetworkToJbusDtc1708EventConverter networkToJbusDtc1708EventConverter;
	
	@Autowired
	private NetworkToJbusDtc1939EventConverter networkToJbusDtc1939EventConverter;
	
	@Autowired
	private NetworkToJbusDailyReportConverter networkToJbusDailyReportConverter;
	
	@Autowired
	private NetworkToJbusHourlyReportConverter networkToJbusHourlyReportConverter;
	
	@Autowired
	private NetworkToJbusDtcMesssageConverter networkToJbusDtcMesssageConverter;
	
	@Autowired
	private NetworkToJbusConstructionDailyReportConverter networkToJbusConstructionDailyReportConverter;
	
	@Autowired
	private NetworkToJbusConstructionDailyUsageReportConverter networkToJbusConstructionDailyUsageReportConverter;

	@Autowired
	private NetworkToJbusConstructionHourlyReportConverter networkToJbusConstructionHourlyReportConverter;
	
	@Autowired
	private NetworkToJbusHydraulicReportConverter networkToJbusHydraulicReportConverter;

	@Autowired
	private NetworkToJbusFaultReportConverter networkToJbusFaultReportConverter;
	
	@Autowired
	private NetworkToJbusDiscoveryReportConverter networkToJbusDiscoveryReportConverter;
	
	@Autowired
	private NetworkToDtcMesssageConverter networkToDtcMesssageConverter;

    @Autowired
    private NetworkToMotionLogsMessageConverter                networkToMotionLogsMessageConverter;

}
