package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "commGpsStatus")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("commGpsStatus")
@JsonTypeName("commGpsStatus")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "available", "networkService", "dataService", "connected", "voiceCallIsActive", "roaming", "gpsAntennaStatus", "gpsReceiverTracking" })
@JsonPropertyOrder({ "available", "networkService", "dataService", "connected", "voiceCallIsActive", "roaming", "gpsAntennaStatus", "gpsReceiverTracking" })
public class CommGpsStatus
{
	private Boolean	available;
	private Boolean	networkService;
	private Boolean	dataService;
	private Boolean	connected;
	private Boolean	voiceCallIsActive;
	private Boolean	roaming;
	private Boolean	gpsAntennaStatus;
	private Boolean	gpsReceiverTracking;
	
	
	public Boolean getAvailable() {
		return available;
	}
	public void setAvailable(Boolean available) {
		this.available = available;
	}
	public Boolean getNetworkService() {
		return networkService;
	}
	public void setNetworkService(Boolean networkService) {
		this.networkService = networkService;
	}
	public Boolean getDataService() {
		return dataService;
	}
	public void setDataService(Boolean dataService) {
		this.dataService = dataService;
	}
	public Boolean getConnected() {
		return connected;
	}
	public void setConnected(Boolean connected) {
		this.connected = connected;
	}
	public Boolean getVoiceCallIsActive() {
		return voiceCallIsActive;
	}
	public void setVoiceCallIsActive(Boolean voiceCallIsActive) {
		this.voiceCallIsActive = voiceCallIsActive;
	}
	public Boolean getRoaming() {
		return roaming;
	}
	public void setRoaming(Boolean roaming) {
		this.roaming = roaming;
	}
	public Boolean getGpsAntennaStatus() {
		return gpsAntennaStatus;
	}
	public void setGpsAntennaStatus(Boolean gpsAntennaStatus) {
		this.gpsAntennaStatus = gpsAntennaStatus;
	}
	public Boolean getGpsReceiverTracking() {
		return gpsReceiverTracking;
	}
	public void setGpsReceiverTracking(Boolean gpsReceiverTracking) {
		this.gpsReceiverTracking = gpsReceiverTracking;
	}
   
	
}


