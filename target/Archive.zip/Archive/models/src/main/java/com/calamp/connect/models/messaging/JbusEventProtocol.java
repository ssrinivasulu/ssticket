package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * <p>Java class for JBUSMessage complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="JBUSMessage"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="jbusProtocol" type="{http://calamp.com/DataFeedService/}JBusProtocol"/v
 *         &lt;element name="vin" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="odometer" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="highResolutionOdometer" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="batteryVoltage" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="switchedBatteryVoltage" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="engineSpeed" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="totalFuel" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="totalIdleFuel" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="totalIdleHours" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="totalEngineHours" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="engineCoolantTemperature" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="engineOilTemperature" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="seatBeltUsed" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;any processContents='skip' maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */

@XmlRootElement(name = "jProtocol")
@JsonRootName("jProtocol")
@JsonTypeName("jProtocol")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)
@JsonPropertyOrder(
{
 "account", "asset", "assetId", "assetName", "batteryVoltage", "deviceAirId", "deviceEsn",
		"deviceId", "deviceIp", "deviceMessageSequenceNumber", "engineCoolantTemperature", "engineOilTemperature",
		"engineSpeed", "eventTime", "highResolutionOdometer", "jbusProtocol", "messageReceivedTime", "messageType",
		"messageUuid", "odometer", "port", "rawAccumulators", "rawDeviceHexMessage", "seatBeltUsed",
		"switchedBatteryVoltage", "totalEngineHours", "totalFuel", "totalIdleFuel", "totalIdleHours", "vin"
})
@XmlType(
    name      = "jProtocol",
    propOrder =
    {
 "account", "asset", "assetId", "assetName", "batteryVoltage", "deviceAirId",
		"deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "engineCoolantTemperature",
		"engineOilTemperature", "engineSpeed", "eventTime", "highResolutionOdometer", "jbusProtocol",
		"messageReceivedTime", "messageType", "messageUuid", "odometer", "port", "rawAccumulators",
		"rawDeviceHexMessage", "seatBeltUsed", "switchedBatteryVoltage", "totalEngineHours", "totalFuel",
		"totalIdleFuel", "totalIdleHours", "vin"
    }
)
public class JbusEventProtocol extends DeviceEvent
{
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  batteryVoltage;
    @XmlElement(
        required = true,
        type     = Integer.class,
        nillable = true
    )
    protected Integer engineCoolantTemperature;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  engineOilTemperature;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  engineSpeed;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  highResolutionOdometer;
    @XmlElement(
        required = true,
        nillable = true
    )
    protected String  jbusProtocol;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  odometer;
    @XmlElement(
        required = true,
        type     = Boolean.class,
        nillable = true
    )
    protected Boolean seatBeltUsed;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  switchedBatteryVoltage;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  totalEngineHours;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  totalFuel;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  totalIdleFuel;
    @XmlElement(
        required = true,
        type     = Double.class,
        nillable = true
    )
    protected Double  totalIdleHours;
    @XmlElement(
        required = true,
        nillable = true
    )
    protected String  vin;

    /**
     * Gets the value of the batteryVoltage property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getBatteryVoltage()
    {
        return batteryVoltage;
    }

    /**
     * Gets the value of the engineCoolantTemperature property.
     *
     * @return
     *     possible object is
     *     {@link Integer }
     *
     */
    public Integer getEngineCoolantTemperature()
    {
        return engineCoolantTemperature;
    }

    /**
     * Gets the value of the engineOilTemperature property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getEngineOilTemperature()
    {
        return engineOilTemperature;
    }

    /**
     * Gets the value of the engineSpeed property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getEngineSpeed()
    {
        return engineSpeed;
    }

    /**
     * Gets the value of the highResolutionOdometer property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getHighResolutionOdometer()
    {
        return highResolutionOdometer;
    }

    /**
     * Gets the value of the jbusProtocol property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getJbusProtocol()
    {
        return jbusProtocol;
    }

    /**
     * Gets the value of the odometer property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getOdometer()
    {
        return odometer;
    }

    /**
     * Gets the value of the switchedBatteryVoltage property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getSwitchedBatteryVoltage()
    {
        return switchedBatteryVoltage;
    }

    /**
     * Gets the value of the totalEngineHours property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getTotalEngineHours()
    {
        return totalEngineHours;
    }

    /**
     * Gets the value of the totalFuel property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getTotalFuel()
    {
        return totalFuel;
    }

    /**
     * Gets the value of the totalIdleFuel property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getTotalIdleFuel()
    {
        return totalIdleFuel;
    }

    /**
     * Gets the value of the totalIdleHours property.
     *
     * @return
     *     possible object is
     *     {@link Double }
     *
     */
    public Double getTotalIdleHours()
    {
        return totalIdleHours;
    }

    /**
     * Gets the value of the vin property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getVin()
    {
        return vin;
    }

    /**
     * Gets the value of the seatBeltUsed property.
     *
     * @return
     *     possible object is
     *     {@link Boolean }
     *
     */
    public Boolean isSeatBeltUsed()
    {
        return seatBeltUsed;
    }

    /**
     * Sets the value of the batteryVoltage property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setBatteryVoltage(Double value)
    {
        this.batteryVoltage = value;
    }

    /**
     * Sets the value of the engineCoolantTemperature property.
     *
     * @param value
     *     allowed object is
     *     {@link Integer }
     *
     */
    public void setEngineCoolantTemperature(Integer value)
    {
        this.engineCoolantTemperature = value;
    }

    /**
     * Sets the value of the engineOilTemperature property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setEngineOilTemperature(Double value)
    {
        this.engineOilTemperature = value;
    }

    /**
     * Sets the value of the engineSpeed property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setEngineSpeed(Double value)
    {
        this.engineSpeed = value;
    }

    /**
     * Sets the value of the highResolutionOdometer property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setHighResolutionOdometer(Double value)
    {
        this.highResolutionOdometer = value;
    }

    /**
     * Sets the value of the jbusProtocol property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setJbusProtocol(String value)
    {
        this.jbusProtocol = value;
    }

    /**
     * Sets the value of the odometer property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setOdometer(Double value)
    {
        this.odometer = value;
    }

    /**
     * Sets the value of the seatBeltUsed property.
     *
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *
     */
    public void setSeatBeltUsed(Boolean value)
    {
        this.seatBeltUsed = value;
    }

    /**
     * Sets the value of the switchedBatteryVoltage property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setSwitchedBatteryVoltage(Double value)
    {
        this.switchedBatteryVoltage = value;
    }

    /**
     * Sets the value of the totalEngineHours property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setTotalEngineHours(Double value)
    {
        this.totalEngineHours = value;
    }

    /**
     * Sets the value of the totalFuel property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setTotalFuel(Double value)
    {
        this.totalFuel = value;
    }

    /**
     * Sets the value of the totalIdleFuel property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setTotalIdleFuel(Double value)
    {
        this.totalIdleFuel = value;
    }

    /**
     * Sets the value of the totalIdleHours property.
     *
     * @param value
     *     allowed object is
     *     {@link Double }
     *
     */
    public void setTotalIdleHours(Double value)
    {
        this.totalIdleHours = value;
    }

    /**
     * Sets the value of the vin property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setVin(String value)
    {
        this.vin = value;
    }
}
