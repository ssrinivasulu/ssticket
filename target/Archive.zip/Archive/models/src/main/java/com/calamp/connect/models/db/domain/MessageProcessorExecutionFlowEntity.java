/**
 * 
 */
package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

import com.calamp.connect.models.db.domain.DeviceEventEntity;

/**
 * @author ssrinivasulu
 *
 */
@Document(collection = "MessageProcessorExecutionFlowEntity")
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)    // all fields are included by default
public class MessageProcessorExecutionFlowEntity extends DeviceEventEntity{
	
}
