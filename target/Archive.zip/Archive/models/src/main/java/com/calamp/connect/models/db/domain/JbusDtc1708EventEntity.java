package com.calamp.connect.models.db.domain;

import java.util.List;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Created by agamulo on 5/26/15.
 */

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusDtc1708EventEntity extends DeviceEventEntity
{

    private List<JbusDtc1708> jbusDtc1708;

    private Integer           sourceAddress;

    public JbusDtc1708EventEntity()
    {
        setMsgType(MsgType.JBUS_DTC1708);
    }

    public List<JbusDtc1708> getJbusDtc1708()
    {
        return jbusDtc1708;
    }

    public void setJbusDtc1708(List<JbusDtc1708> jbusDtc1708)
    {
        this.jbusDtc1708 = jbusDtc1708;
    }

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }
}
