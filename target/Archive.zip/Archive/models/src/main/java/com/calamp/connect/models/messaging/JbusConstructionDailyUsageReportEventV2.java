package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "jbusConstructionDailyUsageReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusConstructionDailyUsageReportEvent")
@JsonTypeName("jbusConstructionDailyUsageReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId",
        "deviceIp", "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "inputs", "machineState", "messageReceivedTime",
        "messageType", "messageUuid", "pegBehaviorId", "port", "rawDeviceHexMessage", "vinResponse" })
@XmlType(name = "jbusConstructionDailyUsageReportEvent", propOrder = { "account", "asset", "assetId", "assetName", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "inputs",
        "machineState", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port", "rawDeviceHexMessage", "vinResponse" })
@ApiVersion("2.0")
public class JbusConstructionDailyUsageReportEventV2 extends JbusConstructionDailyUsageReportEvent
{
    private MachineState                         machineState;
    private JbusConstructionDailyUsageReportData deviceData;
    private JbusConstructionDailyUsageReportData deviceDataConverted;

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusConstructionDailyUsageReportData getDeviceData()
    {
        return (JbusConstructionDailyUsageReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusConstructionDailyUsageReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusConstructionDailyUsageReportData getDeviceDataConverted()
    {
        return (JbusConstructionDailyUsageReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusConstructionDailyUsageReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
