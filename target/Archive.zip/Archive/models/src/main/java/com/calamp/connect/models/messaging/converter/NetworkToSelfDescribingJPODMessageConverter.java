package com.calamp.connect.models.messaging.converter;



import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Accumulator;

import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.DataReportContents;
import com.calamp.connect.models.messaging.DataReportParameter;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.SelfDescribingJPODMessage;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.HexUtil;
import ma.glasnost.orika.MapperFacade;

@Component("networkToSelfDescribingJPODMesssageConverter")
public class NetworkToSelfDescribingJPODMessageConverter extends GenericNetworkToDeviceEventConverter{
	public SelfDescribingJPODMessage convert(NetworkMessage network)
	{
		MapperFacade mapper = mapperFactory.getMapperFacade();
        SelfDescribingJPODMessage appMessage = mapper.map(network, SelfDescribingJPODMessage.class);
        appMessage.setMessageType(NetworkMessageType.SELF_DESCRIBING_JPOD);
        if(network.getMessageDetail() != null){
        	appMessage.setEventTime(new Date(network.getMessageDetail().getLocationTime()));
        	appMessage.setEventCode(network.getMessageDetail().getEventCode());
        }
        if(appMessage.getEventTime() == null)
        {
        	//missing header, give current time for searches - fix status will be false
        	appMessage.setEventTime(new Date());
        }
        
        if(network.getRawJbusMessage() != null) {
        	appMessage.setAppMessageType(network.getRawJbusMessage().getJbusMessageType());
        	if(network.getRawJbusMessage().getUnknownReportRaw() != null){
        		appMessage.setAppMessageMessage(network.getRawJbusMessage().getUnknownReportRaw().getMessage());
        	}
        }
        
        
        if (network.getRawAccumulators() != null)
        {
            List<Accumulator> rawAccumulators = new ArrayList<Accumulator>(network.getRawAccumulators().size());
            int i = 0;
            for (Long rawAccumulator : network.getRawAccumulators())
            {
                if (rawAccumulator != -1)
                {
                    Accumulator acc = new Accumulator();
                    acc.setLabel("Accumulator " + i);
                    acc.setIndex(String.valueOf(i));
                    acc.setValue(String.valueOf(rawAccumulator));
                    rawAccumulators.add(acc);
                }
                i = i + 1;
            }
            AvlDeviceData deviceData = new AvlDeviceData();
            deviceData.setAccumulators(rawAccumulators);

            HeaderData headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getRssi()));
            deviceData.setRssi(headerData);

            headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getAltitude()));
            deviceData.setAltitude(headerData);

            headerData = new HeaderData();
            if(network.getMessageDetail() != null && network.getMessageDetail().getSpeed() != null){
            	headerData.setValue(String.valueOf(network.getMessageDetail().getSpeed()));
            } else if(network.getMessageDetail().getMiniSpeed() !=null){
            	//kp/h to cm/s
            	headerData.setValue(String.valueOf((int) (network.getMessageDetail().getMiniSpeed()*1000/36)));
            } else {
            	headerData.setValue("0");
            }
            deviceData.setGpsSpeed(headerData);

            appMessage.setDeviceData(deviceData);
            AvlDeviceData deviceDataConverted = new AvlDeviceData();
            deviceDataConverted.setAccumulators(rawAccumulators);
            appMessage.setDeviceDataConverted(deviceDataConverted);
        }

        //do the jpod2 dance
        ByteBuffer byteBuffer = ByteBuffer.wrap(network.getRawJbusMessage().getUnknownReportRaw().getMessage());
        DataReportContents drc = new DataReportContents();
        byte dataOptionsByte = byteBuffer.get();
        drc.setDataOptionsValue((int)dataOptionsByte);
        boolean [] dataOptionsBits = BitUtil.getBits(dataOptionsByte);
        drc.setSizeFieldIncluded(dataOptionsBits[7]);
        drc.setParameterDataSourceFieldIncluded(dataOptionsBits[6]);
        drc.setParameterSourceAddressFieldIncluded(dataOptionsBits[5]);
        drc.setParamaterIDFieldIncluded(dataOptionsBits[4]);
        drc.setDataPostionFieldIncluded(dataOptionsBits[3]);
        //0-2 "reserved"
        drc.setReportID((int)byteBuffer.get());
        drc.setMachineState((int)byteBuffer.getShort());
        drc.setParameterGroup((int)byteBuffer.get());
        
        List<DataReportParameter> plist = new ArrayList<DataReportParameter> ();
        
        while(byteBuffer.remaining() > 0){
        	DataReportParameter drp = new DataReportParameter();
        	int size = Byte.toUnsignedInt(byteBuffer.get());
        	drp.setParameterSize(size);
        	if(drc.getParameterDataSourceFieldIncluded()){
        		drp.setParameterDataSourceValue(Byte.toUnsignedInt(byteBuffer.get()));
        		size--;
        	}
        	if(drc.getParameterSourceAddressFieldIncluded()){
        		drp.setParameterSourceAddressValue(Byte.toUnsignedInt(byteBuffer.get()));
        		size--;
        	}
        	if(drc.getParamaterIDFieldIncluded()){
        		drp.setParameterIDValue(Byte.toUnsignedInt(byteBuffer.get()) + Byte.toUnsignedInt(byteBuffer.get()) * 256 + Byte.toUnsignedInt(byteBuffer.get()) *256 *256);
        		size-= 3;
        	}
        	if(drc.getDataPostionFieldIncluded()){
        		drp.setDataPosition(Byte.toUnsignedInt(byteBuffer.get()) + Byte.toUnsignedInt(byteBuffer.get())*256);
        		size-= 2;
        		
        	}
        	byte[] valueBytes = new byte[size];
        	int i = 0;
        	while(size> 0){
        		valueBytes[i] = byteBuffer.get();
        		size--;
        		i++;
        	}
        	drp.setParameterValueHexValue(HexUtil.convertToHexString(valueBytes));
        	plist.add(drp);
        }
        
        drc.setParameterList(plist);
        appMessage.setDataReportContents(drc);
        
        return appMessage;
		
		
	}
}
