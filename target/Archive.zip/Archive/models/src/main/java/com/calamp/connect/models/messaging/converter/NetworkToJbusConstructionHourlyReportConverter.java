package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionHourlyReportData;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEventV2;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component
public class NetworkToJbusConstructionHourlyReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusConstructionHourlyReportConverter.class);

    public JbusConstructionHourlyReportEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionHourlyReportEventV2 jbusConstructionHourlyReportEvent = mapper.map(network, JbusConstructionHourlyReportEventV2.class);
        JbusConstructionHourlyReportData jbusConstructionHourlyReportData = mapper.map(network, JbusConstructionHourlyReportData.class);
        jbusConstructionHourlyReportEvent.setDeviceData(jbusConstructionHourlyReportData);
        jbusConstructionHourlyReportEvent.setDeviceDataConverted(new JbusConstructionHourlyReportData());
        jbusConstructionHourlyReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusConstructionHourlyReportEvent;
    }

}
