package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@XmlRootElement(name = "dataReportParameter")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("dataReportParameter")
@JsonTypeName("dataReportParameter")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType (propOrder = {"parameterSize", "parameterDataSourceValue","parameterSourceAddressValue","parameterIDValue","dataPosition","parameterValueHexValue"})
@JsonPropertyOrder ( {"parameterSize", "parameterDataSourceValue","parameterSourceAddressValue","parameterIDValue","dataPosition","parameterValueHexValue"})
@ApiVersion()
public class DataReportParameter {
		private Integer parameterSize;
		private Integer parameterDataSourceValue;
		private Integer parameterSourceAddressValue;
		private Integer parameterIDValue;
		private Integer dataPosition;
		private String parameterValueHexValue;
		public Integer getParameterSize() {
			return parameterSize;
		}
		public void setParameterSize(Integer parameterSize) {
			this.parameterSize = parameterSize;
		}
		public Integer getParameterSourceAddressValue() {
			return parameterSourceAddressValue;
		}
		public void setParameterSourceAddressValue(Integer parameterSourceAddressValue) {
			this.parameterSourceAddressValue = parameterSourceAddressValue;
		}
		public Integer getParameterIDValue() {
			return parameterIDValue;
		}
		public void setParameterIDValue(Integer parameterIDValue) {
			this.parameterIDValue = parameterIDValue;
		}
		public Integer getDataPosition() {
			return dataPosition;
		}
		public void setDataPosition(Integer dataPosition) {
			this.dataPosition = dataPosition;
		}
		public String getParameterValueHexValue() {
			return parameterValueHexValue;
		}
		public void setParameterValueHexValue(String parameterValueHexValue) {
			this.parameterValueHexValue = parameterValueHexValue;
		}
		public Integer getParameterDataSourceValue() {
			return parameterDataSourceValue;
		}
		public void setParameterDataSourceValue(Integer parameterDataSourceValue) {
			this.parameterDataSourceValue = parameterDataSourceValue;
		}
		
}
