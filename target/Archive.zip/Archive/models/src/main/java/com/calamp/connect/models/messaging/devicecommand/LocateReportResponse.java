package com.calamp.connect.models.messaging.devicecommand;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.models.messaging.DeviceEvent;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_EMPTY)
@XmlType(propOrder = { "deviceIpAddress","altitude", "carrier", "hdop", "heading", "latitude", "longitude", "rssi", "satellites", "speed", "timeOfFix", "updateTime", "commStatus", "fixStatus", "inputs", "accumulatorList"})
@JsonPropertyOrder({ "deviceIpAddress", "altitude", "carrier", "hdop", "heading", "latitude", "longitude", "rssi", "satellites", "speed", "timeOfFix", "updateTime", "commStatus", "fixStatus", "inputs", "accumulatorList" })
public class LocateReportResponse extends DeviceCommandMessageResponse
{
    private List<Accumulator> accumulatorList = new ArrayList<>();
    private Long              altitude;
    private Integer           carrier;
    private CommState         commStatus;
    private FixStatus         fixStatus;
    private Double            hdop;
    private Integer           heading;
    private Double            latitude;
    private Double            longitude;
    private Integer           rssi;
    private Integer           satellites;
    private Long              speed;
    private Date              timeOfFix;
    private Date              updateTime;

    // CHECKSTYLE:OFF
    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        LocateReportResponse that = (LocateReportResponse) o;

        if ((carrier != null)
            ? !carrier.equals(that.carrier)
            : that.carrier != null){
            return false;
        }

        if ((commStatus != null)
            ? !commStatus.equals(that.commStatus)
            : that.commStatus != null){
            return false;
        }

        if ((fixStatus != null)
            ? !fixStatus.equals(that.fixStatus)
            : that.fixStatus != null){
            return false;
        }

        if ((hdop != null)
            ? !hdop.equals(that.hdop)
            : that.hdop != null){
            return false;
        }

        if ((heading != null)
            ? !heading.equals(that.heading)
            : that.heading != null){
            return false;
        }

        if ((latitude != null)
            ? !latitude.equals(that.latitude)
            : that.latitude != null){
            return false;
        }

        if ((longitude != null)
            ? !longitude.equals(that.longitude)
            : that.longitude != null){
            return false;
        }

        if ((satellites != null)
            ? !satellites.equals(that.satellites)
            : that.satellites != null){
            return false;
        }

        if ((timeOfFix != null)
            ? !timeOfFix.equals(that.timeOfFix)
            : that.timeOfFix != null){
            return false;
        }

        if ((updateTime != null)
            ? !updateTime.equals(that.updateTime)
            : that.updateTime != null){
            return false;
        }

        return true;
    }

    // CHECKSTYLE:ON

    // CHECKSTYLE:OFF
    @Override
    public int hashCode()
    {
        int result = (updateTime != null)
                     ? updateTime.hashCode()
                     : 0;

        result = 31 * result + ((timeOfFix != null)
                                ? timeOfFix.hashCode()
                                : 0);
        result = 31 * result + ((latitude != null)
                                ? latitude.hashCode()
                                : 0);
        result = 31 * result + ((longitude != null)
                                ? longitude.hashCode()
                                : 0);
        result = 31 * result + ((heading != null)
                                ? heading.hashCode()
                                : 0);
        result = 31 * result + ((satellites != null)
                                ? satellites.hashCode()
                                : 0);
        result = 31 * result + ((fixStatus != null)
                                ? fixStatus.hashCode()
                                : 0);
        result = 31 * result + ((carrier != null)
                                ? carrier.hashCode()
                                : 0);
        result = 31 * result + ((commStatus != null)
                                ? commStatus.hashCode()
                                : 0);
        result = 31 * result + ((hdop != null)
                                ? hdop.hashCode()
                                : 0);
        return result;
    }

    // CHECKSTYLE:ON

    @Override
    public String toString()
    {
        return "LocateReportResponse{" + "updateTime=" + updateTime + ", timeOfFix=" + timeOfFix + ", latitude="
               + latitude + ", longitude=" + longitude + ", heading="
               + heading + ", satellites=" + satellites + ", fixStatus=" + fixStatus + ", carrier=" + carrier
               + ", commStatus=" + commStatus + ", hdop=" + hdop + '}';
    }


    public Integer getCarrier()
    {
        return carrier;
    }

    public CommState getCommStatus()
    {
        return commStatus;
    }

    public FixStatus getFixStatus()
    {
        return fixStatus;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }


    public Integer getSatellites()
    {
        return satellites;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DeviceEvent.JSON_DATETIME_FORMAT)
    public Date getTimeOfFix()
    {
        return timeOfFix;
    }
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DeviceEvent.JSON_DATETIME_FORMAT)
    public Date getUpdateTime()
    {
        return updateTime;
    }


    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public void setCommStatus(CommState commStatus)
    {
        this.commStatus = commStatus;
    }

    public void setFixStatus(FixStatus fixStatus)
    {
        this.fixStatus = fixStatus;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }


    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }


    public void setTimeOfFix(Date timeOfFix)
    {
        this.timeOfFix = timeOfFix;
    }

    public void setUpdateTime(Date updateTime)
    {
        this.updateTime = updateTime;
    }

    public List<Accumulator> getAccumulatorList()
    {
        return accumulatorList;
    }

    public void setAccumulatorList(List<Accumulator> accumulatorList)
    {
        this.accumulatorList = accumulatorList;
    }

    public Long getAltitude()
    {
        return altitude;
    }

    public void setAltitude(Long altitude)
    {
        this.altitude = altitude;
    }

    public Integer getRssi()
    {
        return rssi;
    }

    public void setRssi(Integer rssi)
    {
        this.rssi = rssi;
    }

    public Long getSpeed()
    {
        return speed;
    }

    public void setSpeed(Long speed)
    {
        this.speed = speed;
    }
    
}
