package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEventV2;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component
public class NetworkToJbusConstructionDailyUsageReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusConstructionDailyUsageReportConverter.class);

    public JbusConstructionDailyUsageReportEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionDailyUsageReportEventV2 jbusConstructionDailyUsageReportEvent = mapper.map(network,
                JbusConstructionDailyUsageReportEventV2.class);
        JbusConstructionDailyUsageReportData jbusConstructionDailyUsageReportDate = mapper.map(network, JbusConstructionDailyUsageReportData.class);
        jbusConstructionDailyUsageReportEvent.setDeviceData(jbusConstructionDailyUsageReportDate);
        jbusConstructionDailyUsageReportEvent.setDeviceDataConverted(new JbusConstructionDailyUsageReportData());
        jbusConstructionDailyUsageReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusConstructionDailyUsageReportEvent;
    }

}
