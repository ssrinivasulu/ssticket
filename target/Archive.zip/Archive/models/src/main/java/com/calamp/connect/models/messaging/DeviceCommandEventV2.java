package com.calamp.connect.models.messaging;

import java.util.Date;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.models.messaging.devicecommand.Command;
import com.calamp.connect.models.messaging.devicecommand.DeviceIdentifier;
import com.calamp.focis.framework.apiversion.ApiVersion;
import com.calamp.focis.framework.hateoas.Link;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "deviceCommandEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("deviceCommandEvent")
@JsonTypeName("deviceCommandEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "autoRetry", "batchId", "batchSeq", "command", "completedOn", "device", "identifiers", "queuedFor", "retries", "sentOn" })
@JsonPropertyOrder({ "autoRetry", "batchId", "batchSeq", "command", "completedOn", "device", "identifiers", "queuedFor", "retries", "sentOn" })
@ApiVersion("2.0")
public class DeviceCommandEventV2 extends DeviceCommandEvent
{
    private int                   retries;
    private Date                  queuedFor;
    private Date                  sentOn;
    private Date                  completedOn;
    private Link                  device;
    private Set<DeviceIdentifier> identifiers;
    private Command               command;
    private String                batchId;
    private int                   batchSeq;
    private boolean               autoRetry = Boolean.TRUE;

    public int getRetries()
    {
        return retries;
    }

    public void setRetries(int retries)
    {
        this.retries = retries;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getQueuedFor()
    {
        return queuedFor;
    }

    public void setQueuedFor(Date queuedFor)
    {
        this.queuedFor = queuedFor;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getSentOn()
    {
        return sentOn;
    }

    public void setSentOn(Date sentOn)
    {
        this.sentOn = sentOn;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getCompletedOn()
    {
        return completedOn;
    }

    public void setCompletedOn(Date completedOn)
    {
        this.completedOn = completedOn;
    }

    public Link getDevice()
    {
        return device;
    }

    public void setDevice(Link device)
    {
        this.device = device;
    }

    public Set<DeviceIdentifier> getIdentifiers()
    {
        return identifiers;
    }

    public void setIdentifiers(Set<DeviceIdentifier> identifiers)
    {
        this.identifiers = identifiers;
    }

    public Command getCommand()
    {
        return command;
    }

    public void setCommand(Command command)
    {
        this.command = command;
    }

    public String getBatchId()
    {
        return batchId;
    }

    public void setBatchId(String batchId)
    {
        this.batchId = batchId;
    }

    public int getBatchSeq()
    {
        return batchSeq;
    }

    public void setBatchSeq(int batchSeq)
    {
        this.batchSeq = batchSeq;
    }

    public boolean isAutoRetry()
    {
        return autoRetry;
    }

    public void setAutoRetry(boolean autoRetry)
    {
        this.autoRetry = autoRetry;
    }

}
