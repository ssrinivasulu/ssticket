package com.calamp.connect.models.db.converter;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.AvlEventV2;
import com.calamp.connect.models.messaging.GpsFixStatus;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class AvlEventV2Converter extends DeviceEventConverter<AvlEventEntity, AvlEventV2>
{
    @Override
    protected AvlEventEntity customConvert(AvlEventV2 model, AvlEventEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        if (model.getGpsFixStatus() != null)
        {
            mapper.map(model.getFixStatus(), entity);
        }

        if (model.getDeviceData() != null)
            entity.setDeviceData(model.getDeviceData());

        if (model.getDeviceDataConverted() != null)
            entity.setDeviceDataConverted(model.getDeviceDataConverted());

        return entity;
    }

    @Override
    protected AvlEventV2 customConvert(AvlEventEntity entity, AvlEventV2 model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        Address address = mapper.map(entity.getAddress(), Address.class);
        if (address != null)
        {
            address.setStreet(address.getAddress1());
            address.setAddress1(null);
            model.setAddress(address);
        }

        GpsFixStatus fixStatus = mapper.map(entity, GpsFixStatus.class);

        if (beanContainsData(fixStatus))
        {
            model.setGpsFixStatus(fixStatus);
        }

        if (entity.getDeviceDataConverted() != null)
            model.setDeviceDataConverted((AvlDeviceData)entity.getDeviceDataConverted());

        return model;
    }

    @Override
    public AvlEventV2 domainToModel(AvlEventEntity avlEntityEvent) throws Exception
    {
        AvlEventV2 avlEvent = super.convert(avlEntityEvent, AvlEventV2.class);

        return avlEvent;
    }

    @Override
    public AvlEventV2 domainToModel(AvlEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public AvlEventEntity modelToDomain(AvlEventV2 avlEvent) throws Exception
    {
        AvlEventEntity avlEventEntity = super.convert(avlEvent, AvlEventEntity.class);

        return avlEventEntity;
    }

    @Override
    public Class<AvlEventV2> getModelType()
    {
        return AvlEventV2.class;
    }

    @Override
    public Class<AvlEventEntity> getDomainType()
    {
        return AvlEventEntity.class;
    }
}
