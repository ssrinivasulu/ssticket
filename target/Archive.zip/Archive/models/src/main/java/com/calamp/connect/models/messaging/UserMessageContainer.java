package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "userMessageContainer")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("pndMessage")
@JsonTypeName("pndMessage")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "userMessageId", "userMessageRoute", "userMessageLength", "userMessage" })
@JsonPropertyOrder({ "userMessageId", "userMessageRoute", "userMessageLength", "userMessage" })
public class UserMessageContainer
{
	private byte[] userMessage;
    private int userMessageId;
    private int userMessageRoute;
    private int userMessageLength;
	public byte[] getUserMessage() {
		return userMessage;
	}
	public void setUserMessage(byte[] userMessage) {
		if(userMessage != null)
			this.setUserMessageLength(userMessage.length);
		else
			this.setUserMessageLength(0);
		this.userMessage = userMessage;
	}
	public int getUserMessageId() {
		return userMessageId;
	}
	public void setUserMessageId(int userMessageId) {
		this.userMessageId = userMessageId;
	}
	public int getUserMessageRoute() {
		return userMessageRoute;
	}
	public void setUserMessageRoute(int userMessageRoute) {
		this.userMessageRoute = userMessageRoute;
	}
	public int getUserMessageLength() {
		return userMessageLength;
	}
	public void setUserMessageLength(int userMessageLength) {
		this.userMessageLength = userMessageLength;
	}

    

    

   
}


