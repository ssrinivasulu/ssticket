package com.calamp.connect.models.messaging.devicecommand;

import java.util.Date;

import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@XmlType(propOrder = { "deviceIpAddress", "externalDeviceId", "port", "sequenceId", "sent" })
@JsonPropertyOrder({ "deviceIpAddress" })
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.WRAPPER_OBJECT, property = "type")
@JsonSubTypes({ @JsonSubTypes.Type(value = LocateReportRequest.class, name = "locateReportRequest"),
        @JsonSubTypes.Type(value = PegActionRequest.class, name = "pegActionRequest"),
        @JsonSubTypes.Type(value = UnitRequest.class, name = "unitRequest"),
        @JsonSubTypes.Type(value = SetAndEnableZoneRequest.class, name = "setAndEnableZoneRequest"),
        @JsonSubTypes.Type(value = IdReportRequest.class, name = "idReportRequest"),
        @JsonSubTypes.Type(value = ParameterRequest.class, name = "parameterRequest"),
        @JsonSubTypes.Type(value = RebootRequest.class, name = "rebootRequest"),
        @JsonSubTypes.Type(value = OtaDownloadRequest.class, name = "otaDownloadRequest")

})
@XmlSeeAlso({ LocateReportRequest.class, PegActionRequest.class, SetAndEnableZoneRequest.class, IdReportRequest.class, ParameterRequest.class,
        RebootRequest.class, OtaDownloadRequest.class })
public abstract class DeviceCommandMessageRequest implements DeviceCommandMessage
{
    public static final String JSON_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXX";
    private String             deviceIpAddress;
    @JsonIgnore
    private String             externalDeviceId;
    @JsonIgnore
    private Integer            sequenceId;
    private Integer            port;
    private Date               sent;

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }

        if ((o == null) || (getClass() != o.getClass()))
        {
            return false;
        }

        DeviceCommandMessageRequest that = (DeviceCommandMessageRequest) o;

        if ((deviceIpAddress != null) ? !deviceIpAddress.equals(that.deviceIpAddress) : that.deviceIpAddress != null)
        {
            return false;
        }

        if ((externalDeviceId != null) ? !externalDeviceId.equals(that.externalDeviceId) : that.externalDeviceId != null)
        {
            return false;
        }

        if ((sequenceId != null) ? !sequenceId.equals(that.sequenceId) : that.sequenceId != null)
        {
            return false;
        }
        if ((port != null) ? !port.equals(that.port) : that.port != null)
        {
            return false;
        }
        if (sent != null ? !sent.equals(that.sent) : that.sent != null)
        {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (externalDeviceId != null) ? externalDeviceId.hashCode() : 0;
        result = 31 * result + ((sequenceId != null) ? sequenceId.hashCode() : 0);
        result = 31 * result + ((port != null) ? port.hashCode() : 0);
        result = 31 * result + ((deviceIpAddress != null) ? deviceIpAddress.hashCode() : 0);
        result = 31 * result + ((sent != null) ? sent.hashCode() : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "DeviceCommandMessageRequest{" + "externalDeviceId='" + externalDeviceId + '\'' + ", sequenceId=" + sequenceId + ", port=" + port
                + ", deviceIpAddress='" + deviceIpAddress + '\'' + ", sent='" + sent + '\'' + '}';
    }

    public String getDeviceIpAddress()
    {
        return deviceIpAddress;
    }

    public String getExternalDeviceId()
    {
        return externalDeviceId;
    }

    public Integer getSequenceId()
    {
        return sequenceId;
    }

    public void setDeviceIpAddress(String deviceIpAddress)
    {
        this.deviceIpAddress = deviceIpAddress;
    }

    public void setExternalDeviceId(String externalDeviceId)
    {
        this.externalDeviceId = externalDeviceId;
    }

    public void setSequenceId(Integer sequenceId)
    {
        this.sequenceId = sequenceId;
    }

    public Integer getPort()
    {
        return port;
    }

    public void setPort(Integer port)
    {
        this.port = port;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getSent()
    {
        return sent;
    }

    public void setSent(Date sent)
    {
        this.sent = sent;
    }

}
