package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@AutoProperty(autoDetect=AutoDetectPolicy.FIELD)
public class VbusIndicatorsEntity {
    
    private boolean ignitionStatus;
    private boolean milStatus;
    private boolean airbagDashIndicator;
    private boolean absDashIndicator;
    private boolean ptoStatus;
    private boolean seatBeltFastened;
    private boolean brakePedalPressed;
    private boolean absActiveLamp;
    private boolean cruiseControlStatus;
    private boolean oilPressureLamp;
    private boolean parkBrakeLight;
    private boolean coolantHotLight;
    private boolean tpmsStatus;

    // VbusIndicator 1
    private boolean misfireMonitor;
    private boolean fuelSystemMonitor;
    private boolean comprehensiveComponentMonitor;
    private boolean catalystMonitor;
    private boolean heatedCatalystMonitor;
    private boolean evaporativeSystemMonitor;
    private boolean secondaryAirSystemMonitor;
    private boolean acSystemRefrigerantMonitor;
    private boolean oxygenSensorMonitor;
    private boolean oxygenSensorHeatedMonitor;
    private boolean egrSystemMonitor;
    private boolean o2SensorCircuitNoActivity;
    private boolean o2SensorHeaterCircuitMalfunction;
    private boolean ho2SHeaterControlMalfunction;
    private boolean ho2SHeaterResistanceMalfunction;
    
    public boolean isIgnitionStatus() {
        return ignitionStatus;
    }

    public void setIgnitionStatus(boolean ignitionStatus) {
        this.ignitionStatus = ignitionStatus;
    }

    public boolean isMilStatus() {
        return milStatus;
    }

    public void setMilStatus(boolean milStatus) {
        this.milStatus = milStatus;
    }

    public boolean isAirbagDashIndicator() {
        return airbagDashIndicator;
    }

    public void setAirbagDashIndicator(boolean airbagDashIndicator) {
        this.airbagDashIndicator = airbagDashIndicator;
    }

    public boolean isAbsDashIndicator() {
        return absDashIndicator;
    }

    public void setAbsDashIndicator(boolean absDashIndicator) {
        this.absDashIndicator = absDashIndicator;
    }

    public boolean isPtoStatus() {
        return ptoStatus;
    }

    public void setPtoStatus(boolean ptoStatus) {
        this.ptoStatus = ptoStatus;
    }

    public boolean isSeatBeltFastened() {
        return seatBeltFastened;
    }

    public void setSeatBeltFastened(boolean seatBeltFastened) {
        this.seatBeltFastened = seatBeltFastened;
    }

    public boolean isBrakePedalPressed() {
        return brakePedalPressed;
    }

    public void setBrakePedalPressed(boolean brakePedalPressed) {
        this.brakePedalPressed = brakePedalPressed;
    }

    public boolean isAbsActiveLamp() {
        return absActiveLamp;
    }

    public void setAbsActiveLamp(boolean absActiveLamp) {
        this.absActiveLamp = absActiveLamp;
    }

    public boolean isCruiseControlStatus() {
        return cruiseControlStatus;
    }

    public void setCruiseControlStatus(boolean cruiseControlStatus) {
        this.cruiseControlStatus = cruiseControlStatus;
    }

    public boolean isOilPressureLamp() {
        return oilPressureLamp;
    }

    public void setOilPressureLamp(boolean oilPressureLamp) {
        this.oilPressureLamp = oilPressureLamp;
    }

    public boolean isParkBrakeLight() {
        return parkBrakeLight;
    }

    public void setParkBrakeLight(boolean parkBrakeLight) {
        this.parkBrakeLight = parkBrakeLight;
    }

    public boolean isCoolantHotLight() {
        return coolantHotLight;
    }

    public void setCoolantHotLight(boolean coolantHotLight) {
        this.coolantHotLight = coolantHotLight;
    }

    public boolean isTpmsStatus() {
        return tpmsStatus;
    }

    public void setTpmsStatus(boolean tpmsStatus) {
        this.tpmsStatus = tpmsStatus;
    }

    public boolean isMisfireMonitor()
    {
        return misfireMonitor;
    }

    public void setMisfireMonitor(boolean misfireMonitor)
    {
        this.misfireMonitor = misfireMonitor;
    }

    public boolean isFuelSystemMonitor()
    {
        return fuelSystemMonitor;
    }

    public void setFuelSystemMonitor(boolean fuelSystemMonitor)
    {
        this.fuelSystemMonitor = fuelSystemMonitor;
    }

    public boolean isComprehensiveComponentMonitor()
    {
        return comprehensiveComponentMonitor;
    }

    public void setComprehensiveComponentMonitor(boolean comprehensiveComponentMonitor)
    {
        this.comprehensiveComponentMonitor = comprehensiveComponentMonitor;
    }

    public boolean isCatalystMonitor()
    {
        return catalystMonitor;
    }

    public void setCatalystMonitor(boolean catalystMonitor)
    {
        this.catalystMonitor = catalystMonitor;
    }

    public boolean isHeatedCatalystMonitor()
    {
        return heatedCatalystMonitor;
    }

    public void setHeatedCatalystMonitor(boolean heatedCatalystMonitor)
    {
        this.heatedCatalystMonitor = heatedCatalystMonitor;
    }

    public boolean isEvaporativeSystemMonitor()
    {
        return evaporativeSystemMonitor;
    }

    public void setEvaporativeSystemMonitor(boolean evaporativeSystemMonitor)
    {
        this.evaporativeSystemMonitor = evaporativeSystemMonitor;
    }

    public boolean isSecondaryAirSystemMonitor()
    {
        return secondaryAirSystemMonitor;
    }

    public void setSecondaryAirSystemMonitor(boolean secondaryAirSystemMonitor)
    {
        this.secondaryAirSystemMonitor = secondaryAirSystemMonitor;
    }

    public boolean isAcSystemRefrigerantMonitor()
    {
        return acSystemRefrigerantMonitor;
    }

    public void setAcSystemRefrigerantMonitor(boolean acSystemRefrigerantMonitor)
    {
        this.acSystemRefrigerantMonitor = acSystemRefrigerantMonitor;
    }

    public boolean isOxygenSensorMonitor()
    {
        return oxygenSensorMonitor;
    }

    public void setOxygenSensorMonitor(boolean oxygenSensorMonitor)
    {
        this.oxygenSensorMonitor = oxygenSensorMonitor;
    }

    public boolean isOxygenSensorHeatedMonitor()
    {
        return oxygenSensorHeatedMonitor;
    }

    public void setOxygenSensorHeatedMonitor(boolean oxygenSensorHeatedMonitor)
    {
        this.oxygenSensorHeatedMonitor = oxygenSensorHeatedMonitor;
    }

    public boolean isEgrSystemMonitor()
    {
        return egrSystemMonitor;
    }

    public void setEgrSystemMonitor(boolean egrSystemMonitor)
    {
        this.egrSystemMonitor = egrSystemMonitor;
    }

    public boolean isO2SensorCircuitNoActivity()
    {
        return o2SensorCircuitNoActivity;
    }

    public void setO2SensorCircuitNoActivity(boolean o2SensorCircuitNoActivity)
    {
        this.o2SensorCircuitNoActivity = o2SensorCircuitNoActivity;
    }

    public boolean isO2SensorHeaterCircuitMalfunction()
    {
        return o2SensorHeaterCircuitMalfunction;
    }

    public void setO2SensorHeaterCircuitMalfunction(boolean o2SensorHeaterCircuitMalfunction)
    {
        this.o2SensorHeaterCircuitMalfunction = o2SensorHeaterCircuitMalfunction;
    }

    public boolean isHo2SHeaterControlMalfunction()
    {
        return ho2SHeaterControlMalfunction;
    }

    public void setHo2SHeaterControlMalfunction(boolean ho2sHeaterControlMalfunction)
    {
        ho2SHeaterControlMalfunction = ho2sHeaterControlMalfunction;
    }

    public boolean isHo2SHeaterResistanceMalfunction()
    {
        return ho2SHeaterResistanceMalfunction;
    }

    public void setHo2SHeaterResistanceMalfunction(boolean ho2sHeaterResistanceMalfunction)
    {
        ho2SHeaterResistanceMalfunction = ho2sHeaterResistanceMalfunction;
    }
    
}