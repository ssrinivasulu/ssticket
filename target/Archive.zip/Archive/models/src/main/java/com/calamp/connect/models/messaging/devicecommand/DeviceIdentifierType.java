package com.calamp.connect.models.messaging.devicecommand;

public enum DeviceIdentifierType
{
    ID("id", Long.class), ESN("esn", String.class), ICCID("iccid", String.class), IMEI("imei", String.class), MDN("mdn", String.class), MEID("meid",
            String.class), MIN("min", String.class);

    public static final String ALL_VALUES = "ID, ESN, ICCID, IMEI, IMSI, MDN, MEID, MIN";
    public final String        name;
    public final Class<?>      dataType;

    private DeviceIdentifierType(String name, Class<?> dataType)
    {
        this.name = name;
        this.dataType = dataType;
    }
}
