package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.calamp.connect.models.messaging.DigitalInput.DigitalInputStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "digitalInputs")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("digitalInputs")
@JsonTypeName("digitalInputs")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)

public class DigitalInputs
{
    List<DigitalInput> inputs;

    public void addInput(int input, boolean value)
    {
        if (inputs == null){
            inputs = new ArrayList<DigitalInput>();
        }

        if (value){
            addInput(input, DigitalInputStatus.ON);
        }
        else{
            addInput(input, DigitalInputStatus.OFF);
        }
    }

    public void addInput(int input, DigitalInputStatus value)
    {
        if (inputs == null){
            inputs = new ArrayList<DigitalInput>();
        }

        inputs.add(new DigitalInput(input, value));
    }

    @XmlElement
    public List<DigitalInput> getInputs()
    {
        return inputs;
    }

    public void setInputs(List<DigitalInput> inputs)
    {
        this.inputs = inputs;
    }

    /*
     * public void setInput(int num, DigitalInputStatus value) {
     *   if ( inputs == null ) {
     *       inputs = new ArrayList<DigitalInput>();
     *   }
     *   inputs.set(num, value);
     * }
     */

}
