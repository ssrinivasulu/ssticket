package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@XmlRootElement(name = "j1939DtcBlock")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("j1939DtcBlock")
@JsonTypeName("j1939DtcBlock")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType (propOrder = {"typeHexValue","hasSourceAddress","unreportedDTCsOnly","length","lampHexValue","flashLampHexValue","codes"})
@JsonPropertyOrder ( {"typeHexValue","hasSourceAddress","unreportedDTCsOnly","length","lampHexValue","flashLampHexValue","codes"})

public class J1939DtcBlock {
	private	String		typeHexValue;
	private Boolean 	hasSourceAddress;
	private Boolean		unreportedDTCsOnly;
	private	int			length;
	private	String	lampHexValue;
	private	String	flashLampHexValue;
	private List<J1939Dtc2Code>	codes;
	public String getTypeHexValue() {
		return typeHexValue;
	}
	public void setTypeHexValue(String typeHexValue) {
		this.typeHexValue = typeHexValue;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public String getLampHexValue() {
		return lampHexValue;
	}
	public void setLampHexValue(String lampHexValue) {
		this.lampHexValue = lampHexValue;
	}
	public String getFlashLampHexValue() {
		return flashLampHexValue;
	}
	public void setFlashLampHexValue(String flashLampHexValue) {
		this.flashLampHexValue = flashLampHexValue;
	}
	public List<J1939Dtc2Code> getCodes() {
		return codes;
	}
	public void setCodes(List<J1939Dtc2Code> codes) {
		this.codes = codes;
	}
	public Boolean getHasSourceAddress() {
		return hasSourceAddress;
	}
	public void setHasSourceAddress(Boolean hasSourceAddress) {
		this.hasSourceAddress = hasSourceAddress;
	}
	public Boolean getUnreportedDTCsOnly() {
		return unreportedDTCsOnly;
	}
	public void setUnreportedDTCsOnly(Boolean unreportedDTCsOnly) {
		this.unreportedDTCsOnly = unreportedDTCsOnly;
	}
	
	
}
