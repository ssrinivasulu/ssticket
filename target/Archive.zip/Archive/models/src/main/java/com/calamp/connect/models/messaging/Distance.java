package com.calamp.connect.models.messaging;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "distance")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "distance")
@JsonRootName("distance")
@JsonTypeName("distance")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class Distance
{
    @XmlAttribute(name = "datetime")
    @XmlJavaTypeAdapter(value = DateAdapter.class, type = Date.class)
    private Date               datetime;
    @XmlElement(name = "OdometerUnits", nillable = true, type = String.class)
    private String             odometerUnits;
    @XmlElement(name = "Odometer", nillable = true, type = String.class)
    private String             odometer;
    public static final String JSON_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public Distance()
    {
    }

    @JsonFormat(shape = Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getDatetime()
    {
        return datetime;
    }

    public void setDatetime(Date datetime)
    {
        this.datetime = datetime;
    }

    public String getOdometerUnits()
    {
        return odometerUnits;
    }

    public void setOdometerUnits(String odometerUnits)
    {
        if (odometerUnits != null)
            this.odometerUnits = odometerUnits;
        else
            this.odometerUnits = "";
    }

    public String getOdometer()
    {
        return odometer;
    }

    public void setOdometer(String odometer)
    {
        if (odometer != null)
            this.odometer = odometer;
        else
            this.odometer = "";
    }

    @Override
    public String toString()
    {
        return "Distance : {datetime:" + datetime + ", odometerUnits:" + odometerUnits + ", odometer:" + odometer + "}";
    }
}
