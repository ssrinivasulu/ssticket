package com.calamp.connect.models.domain.devicecommand;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.calamp.connect.models.db.domain.FixStatusEntity;
import com.calamp.connect.models.messaging.devicecommand.Accumulator;

public class LocateReportResponseEntity extends DeviceCommandMessageResponseEntity
{
    private List<Accumulator> accumulatorList = new ArrayList<>();
    private Long              altitude;
    private Integer           carrier;
    private CommStateEntity   commStatus;
    private FixStatusEntity   fixStatus;
    private Double            hdop;
    private Integer           heading;
    private Double            latitude;
    private Double            longitude;
    private Integer           rssi;
    private Integer           satellites;
    private Long              speed;
    private Date              updateTime;
    private InputsEntity      inputs;

    // CHECKSTYLE:OFF
    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }

        if ((o == null) || (getClass() != o.getClass()))
        {
            return false;
        }

        LocateReportResponseEntity that = (LocateReportResponseEntity) o;

        if ((carrier != null) ? !carrier.equals(that.carrier) : that.carrier != null)
        {
            return false;
        }

        if ((commStatus != null) ? !commStatus.equals(that.commStatus) : that.commStatus != null)
        {
            return false;
        }

        if ((fixStatus != null) ? !fixStatus.equals(that.fixStatus) : that.fixStatus != null)
        {
            return false;
        }

        if ((hdop != null) ? !hdop.equals(that.hdop) : that.hdop != null)
        {
            return false;
        }

        if ((heading != null) ? !heading.equals(that.heading) : that.heading != null)
        {
            return false;
        }

        if ((inputs != null) ? !inputs.equals(that.inputs) : that.inputs != null)
        {
            return false;
        }

        if ((latitude != null) ? !latitude.equals(that.latitude) : that.latitude != null)
        {
            return false;
        }

        if ((longitude != null) ? !longitude.equals(that.longitude) : that.longitude != null)
        {
            return false;
        }

        if ((satellites != null) ? !satellites.equals(that.satellites) : that.satellites != null)
        {
            return false;
        }

        if ((updateTime != null) ? !updateTime.equals(that.updateTime) : that.updateTime != null)
        {
            return false;
        }

        return true;
    }

    // CHECKSTYLE:ON

    // CHECKSTYLE:OFF
    @Override
    public int hashCode()
    {
        int result = (updateTime != null) ? updateTime.hashCode() : 0;

        result = 31 * result + ((latitude != null) ? latitude.hashCode() : 0);
        result = 31 * result + ((longitude != null) ? longitude.hashCode() : 0);
        result = 31 * result + ((heading != null) ? heading.hashCode() : 0);
        result = 31 * result + ((satellites != null) ? satellites.hashCode() : 0);
        result = 31 * result + ((fixStatus != null) ? fixStatus.hashCode() : 0);
        result = 31 * result + ((carrier != null) ? carrier.hashCode() : 0);
        result = 31 * result + ((commStatus != null) ? commStatus.hashCode() : 0);
        result = 31 * result + ((hdop != null) ? hdop.hashCode() : 0);
//        result = 31 * result + ((inputs != null) ? inputs.hashCode() : 0);

        return result;
    }

    // CHECKSTYLE:ON

    @Override
    public String toString()
    {
        return "LocateReportResponse{" + "updateTime=" + updateTime + ", timeOfFix=" + getTimeOfFix() + ", latitude=" + latitude + ", longitude="
                + longitude + ", altitude=" + ", heading=" + heading + ", satellites=" + satellites + ", fixStatus=" + fixStatus + ", carrier="
                + carrier + ", commStatus=" + commStatus + ", hdop=" + hdop + '}' ;//+ ", inputs=" + inputs + '}';
    }

    public Integer getCarrier()
    {
        return carrier;
    }

    public CommStateEntity getCommStatus()
    {
        return commStatus;
    }

    public FixStatusEntity getFixStatus()
    {
        return fixStatus;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public InputsEntity getInputs()
    {
        return inputs;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public Date getUpdateTime()
    {
        return updateTime;
    }

    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public void setCommStatus(CommStateEntity commStatus)
    {
        this.commStatus = commStatus;
    }

    public void setFixStatus(FixStatusEntity fixStatus)
    {
        this.fixStatus = fixStatus;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public void setInputs(InputsEntity inputs)
    {
        this.inputs = inputs;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public void setUpdateTime(Date updateTime)
    {
        this.updateTime = updateTime;
    }

    public List<Accumulator> getAccumulatorList()
    {
        return accumulatorList;
    }

    public void setAccumulatorList(List<Accumulator> accumulatorList)
    {
        this.accumulatorList = accumulatorList;
    }

    public Long getAltitude()
    {
        return altitude;
    }

    public void setAltitude(Long altitude)
    {
        this.altitude = altitude;
    }

    public Integer getRssi()
    {
        return rssi;
    }

    public void setRssi(Integer rssi)
    {
        this.rssi = rssi;
    }

    public Long getSpeed()
    {
        return speed;
    }

    public void setSpeed(Long speed)
    {
        this.speed = speed;
    }
}
