package com.calamp.connect.models.messaging;

public enum GeoZoneType
{
    RECTANGLE, CIRCLE, POLYGON
}