package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.connect.models.network.Network.NetworkMessage;

@Component("networkToAempMesssageConverter")
public class NetworkToAempMessageConverter extends GenericNetworkToDeviceEventConverter
{

    public AempMessageEvent convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        AempMessageEvent aempMessageEvent = mapper.map(network, AempMessageEvent.class);
        aempMessageEvent.setEventTime(new Date(network.getNagReceivedTime()));
        return aempMessageEvent;
    }
}
