package com.calamp.connect.models.messaging.devicecommand;

import java.util.List;

import javax.measure.quantity.Speed;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.Altitude;
import com.calamp.connect.framework.quantity.RSSI;
import com.calamp.connect.models.messaging.DeviceData;
import com.calamp.connect.models.messaging.HeaderData;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonRootName("locateReportResponseData")
@JsonTypeName("locateReportResponseData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = {  "accumulators", "altitude", "gpsSpeed", "rssi" })
@JsonPropertyOrder({  "accumulators", "altitude", "gpsSpeed", "rssi" })
public class LocateReportResponseData extends DeviceData
{
    @ConvertUnit(type = Altitude.class)
    private HeaderData        altitude;

    @ConvertUnit(type = Speed.class)
    private HeaderData        speed;

    @ConvertUnit(type = RSSI.class)
    private HeaderData        rssi;

    private List<Accumulator> accumulators;

    public HeaderData getAltitude()
    {
        return altitude;
    }

    public void setAltitude(HeaderData altitude)
    {
        this.altitude = altitude;
    }

    public HeaderData getSpeed()
    {
        return speed;
    }

    public void setSpeed(HeaderData speed)
    {
        this.speed = speed;
    }

    public HeaderData getRssi()
    {
        return rssi;
    }

    public void setRssi(HeaderData rssi)
    {
        this.rssi = rssi;
    }

    public List<Accumulator> getAccumulators()
    {
        return accumulators;
    }

    public void setAccumulators(List<Accumulator> accumulators)
    {
        this.accumulators = accumulators;
    }
    
}
