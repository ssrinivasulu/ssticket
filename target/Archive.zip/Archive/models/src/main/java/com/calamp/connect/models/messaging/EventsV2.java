package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * Events.java - This is a embedded wrapper class to hold all connect events.
 *
 */
@XmlRootElement(name = "events")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("events")
@JsonTypeName("events")
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "numAvlEvents", "numDtcEvents", "numJbusEvents", "numJbusDtc1708Events", "numJbusDtc1939Events", "numJbusHourlyReportEvents",
        "numJbusDailyReportEvents", "numJbusConstructionDailyReportEvents", "numJbusConstructionDailyUsageReportEvents",
        "numJbusConstructionHourlyReportEvents", "numJbusFaultReportEvents", "numJbusHydraulicReportEvents", "numVehicleBusCapabilitiesEvents",
        "numDeviceCommandEvents", "numAppMessages", "numUserMessages", "numAempMessageEvents", "numMotionLogMessageEvents", "numJbusDiscoveryReportEvents",  
        "numJpod2DTCReports" ,
        "avlEvents",
        "dtcEvents", "jbusEvents", "jbusDtc1708Events", "jbusDtc1939Events", "jbusHourlyReportEvents", "jbusDailyReportEvents",
        "jbusConstructionDailyReportEvents", "jbusConstructionDailyUsageReportEvents", "jbusConstructionHourlyReportEvents", "jbusFaultReportEvents",
        "jbusHydraulicReportEvents", "vehicleBusCapabilitiesEvents", "deviceCommandEvents", "idReportEvents", "extendedIdReportEvents", "appMessages",
        "userMessages", "aempMessageEvents", "motionLogMessageEvents", "jbusDiscoveryReportEvents", "jpod2DTCReports" })
@JsonPropertyOrder({ "numAvlEvents", "numDtcEvents", "numJbusEvents", "numJbusDtc1708Events", "numJbusDtc1939Events", "numJbusHourlyReportEvents",
        "numJbusDailyReportEvents", "numJbusConstructionDailyReportEvents", "numJbusConstructionDailyUsageReportEvents",
        "numJbusConstructionHourlyReportEvents", "numJbusFaultReportEvents", "numJbusHydraulicReportEvents", "numVehicleBusCapabilitiesEvents",
        "numDeviceCommandEvents", "numAppMessages", "numSelfDescribingJPODMessages","numUserMessages", "numAempMessageEvents", "numMotionLogMessageEvents", 
        "numJbusDiscoveryReportEvents", "numJpod2DTCReports", 
        "avlEvents",
        "dtcEvents", "jbusEvents", "jbusDtc1708Events", "jbusDtc1939Events", "jbusHourlyReportEvents", "jbusDailyReportEvents",
        "jbusConstructionDailyReportEvents", "jbusConstructionDailyUsageReportEvents", "jbusConstructionHourlyReportEvents", "jbusFaultReportEvents",
        "jbusHydraulicReportEvents", "vehicleBusCapabilitiesEvents", "deviceCommandEvents", "idReportEvents", "extendedIdReportEvents", "appMessages",
        "userMessages", "selfDescribingJPODMessages","aempMessageEvents", "motionLogMessageEvents", "jbusDiscoveryReportEvents", "jpod2DTCReports" })
public class EventsV2
{
    // J-
    int               numAvlEvents                              = 0;
    int					numJpod2DTCReports						= 0;
    int               numDtcEvents                              = 0;
    int               numJbusEvents                             = 0;
    int               numJbusDtc1708Events                      = 0;
    int               numJbusDtc1939Events                      = 0;
    int               numJbusHourlyReportEvents                 = 0;
    int               numJbusDailyReportEvents                  = 0;
    int               numJbusConstructionDailyReportEvents      = 0;
    int               numJbusConstructionDailyUsageReportEvents = 0;
    int               numJbusConstructionHourlyReportEvents     = 0;
    int               numJbusFaultReportEvents                  = 0;
    int               numJbusDiscoveryReportEvents              = 0;
    int               numJbusHydraulicReportEvents              = 0;
    int               numVehicleBusCapabilitiesEvents           = 0;
    int               numDeviceCommandEvents                    = 0;
    int               numIdReportEvents                         = 0;
    int               numExtendedIdReportEvents                 = 0;
    int               numAppMessages                            = 0;
    int				  numSelfDescribingJPODMessages             = 0;
    int               numUserMessages                           = 0;
    int               numAempMessageEvents                      = 0;
    int               numMotionLogMessageEvents                 = 0;

    @XmlElementWrapper(name = "userMessages")
    @XmlElement(name = "userMessages")
    List<UserMessage> userMessages                              = null;
    
    public void addUserMessage(UserMessage userMessage)
    {
        if (userMessages == null)
        {
            userMessages = new ArrayList<UserMessage>();
        }
        userMessages.add(userMessage);
        numUserMessages++;
    }
    
    
    List<SelfDescribingJPODMessage>				selfDescribingJPODMessages				  = null;
    public void addSelfDescribingJPODMessag(SelfDescribingJPODMessage appMessage)
    {
        if (selfDescribingJPODMessages == null)
        {
        	selfDescribingJPODMessages = new ArrayList<SelfDescribingJPODMessage>();
        }
        selfDescribingJPODMessages.add(appMessage);
        numSelfDescribingJPODMessages++;
    }
    List<Jpod2DTCReport>				jpod2DTCReports				  = null;
    public void addJpod2DTCReport(Jpod2DTCReport appMessage)
    {
        if (jpod2DTCReports == null)
        {
        	jpod2DTCReports = new ArrayList<Jpod2DTCReport>();
        }
        jpod2DTCReports.add(appMessage);
        numJpod2DTCReports++;
    }

    @XmlElementWrapper(name = "appMessages")
    @XmlElement(name = "appMessages")
    List<AppMessage> appMessages = null;

    public void addAppMessage(AppMessage appMessage)
    {
        if (appMessages == null)
        {
            appMessages = new ArrayList<AppMessage>();
        }
        appMessages.add(appMessage);
        numAppMessages++;
    }

    @XmlElementWrapper(name = "aempMessageEvents")
    @XmlElement(name = "aempMessageEvent")
    List<AempMessageEvent>                        aempMessageEvents                      = null;

    @XmlElementWrapper(name = "motionLogEvents")
    @XmlElement(name = "motionLogEvent")
    List<MotionLogsEvent>                         motionLogMessageEvents                 = null;

    @XmlElementWrapper(name = "avlEvents")
    @XmlElement(name = "avlEvent")
    List<AvlEventV2>                              avlEvents                              = null;

    @XmlElementWrapper(name = "dtcEvents")
    @XmlElement(name = "dtcEvent")
    List<DtcEventV2>                              dtcEvents                              = null;

    @XmlElementWrapper(name = "jbusEvents")
    @XmlElement(name = "jbusEvent")
    List<JbusEvent>                               jbusEvents                             = null;

    @XmlElementWrapper(name = "jbusDtc1708Events")
    @XmlElement(name = "jbusDtc1708Events")
    List<JbusDtc1708Event>                        jbusDtc1708Events                      = null;

    @XmlElementWrapper(name = "jbusDtc1939Events")
    @XmlElement(name = "jbusDtc1939Events")
    List<JbusDtc1939Event>                        jbusDtc1939Events                      = null;

    @XmlElementWrapper(name = "jbusHourlyReportEvents")
    @XmlElement(name = "jbusHourlyReportEvents")
    List<JbusHourlyReportEventV2>                 jbusHourlyReportEvents                 = null;

    @XmlElementWrapper(name = "jbusDailyReportEvents")
    @XmlElement(name = "jbusDailyReportEvents")
    List<JbusDailyReportEventV2>                  jbusDailyReportEvents                  = null;

    @XmlElementWrapper(name = "jbusConstructionDailyReportEvents")
    @XmlElement(name = "jbusConstructionDailyReportEvents")
    List<JbusConstructionDailyReportEventV2>      jbusConstructionDailyReportEvents      = null;

    @XmlElementWrapper(name = "jbusConstructionDailyUsageReportEvents")
    @XmlElement(name = "jbusConstructionDailyUsageReportEvents")
    List<JbusConstructionDailyUsageReportEventV2> jbusConstructionDailyUsageReportEvents = null;

    @XmlElementWrapper(name = "jbusConstructionHourlyReportEvents")
    @XmlElement(name = "jbusConstructionHourlyReportEvents")
    List<JbusConstructionHourlyReportEventV2>     jbusConstructionHourlyReportEvents     = null;

    @XmlElementWrapper(name = "jbusFaultReportEvents")
    @XmlElement(name = "jbusFaultReportEvents")
    List<JbusFaultReportEvent>                    jbusFaultReportEvents                  = null;

    @XmlElementWrapper(name = "jbusDiscoveryReportEvents")
    @XmlElement(name = "jbusDiscoveryReportEvents")
    List<JbusDiscoveryReportEvent>                jbusDiscoveryReportEvents              = null;

    @XmlElementWrapper(name = "jbusHydraulicReportEvents")
    @XmlElement(name = "jbusHydraulicReportEvents")
    List<JbusHydraulicReportEventV2>              jbusHydraulicReportEvents              = null;

    @XmlElementWrapper(name = "vehicleBusCapabilitiesEvents")
    @XmlElement(name = "vehicleBusCapabilitiesEvents")
    List<VehicleBusCapabilities>                  vehicleBusCapabilitiesEvents           = null;

    @XmlElementWrapper(name = "deviceCommandEvents")
    @XmlElement(name = "deviceCommandEvents")
    List<DeviceCommandEvent>                      deviceCommandEvents                    = null;

    @XmlElementWrapper(name = "idReportEvents")
    @XmlElement(name = "idReportEvents")
    List<IdReportEvent>                           idReportEvents                         = null;

    @XmlElementWrapper(name = "extendedIdReportEvents")
    @XmlElement(name = "extendedIdReportEvents")
    List<ExtendedIdReportEvent>                   extendedIdReportEvents                 = null;

    // J+

    public void addAempMessageEvent(AempMessageEvent aempMessageEvent)
    {
        if (aempMessageEvents == null)
        {
            aempMessageEvents = new ArrayList<AempMessageEvent>();
        }
        aempMessageEvents.add(aempMessageEvent);
        numAempMessageEvents++;
    }

    public void addMotionLogMessageEvent(MotionLogsEvent motionLogMessageEvent)
    {
        if (motionLogMessageEvents == null)
        {
            motionLogMessageEvents = new ArrayList<MotionLogsEvent>();
        }
        motionLogMessageEvents.add(motionLogMessageEvent);
        numMotionLogMessageEvents++;
    }

    public void addIdReportEvent(IdReportEvent idReportEvent)
    {
        if (idReportEvents == null)
        {
            idReportEvents = new ArrayList<IdReportEvent>();
        }
        idReportEvents.add(idReportEvent);
        numIdReportEvents++;
    }

    public void addExtendedIdReportEvent(ExtendedIdReportEvent extendedIdReportEvent)
    {
        if (extendedIdReportEvents == null)
        {
            extendedIdReportEvents = new ArrayList<ExtendedIdReportEvent>();
        }
        extendedIdReportEvents.add(extendedIdReportEvent);
        numExtendedIdReportEvents++;
    }

    public void addAvlEvent(AvlEventV2 avlEvent)
    {
        if (avlEvents == null)
        {
            avlEvents = new ArrayList<AvlEventV2>();
        }

        avlEvents.add(avlEvent);

        numAvlEvents++;
    }

    public void addDeviceCommandEvent(DeviceCommandEvent deviceCommandEvent)
    {
        if (deviceCommandEvents == null)
        {
            deviceCommandEvents = new ArrayList<DeviceCommandEvent>();
        }

        deviceCommandEvents.add(deviceCommandEvent);

        numDeviceCommandEvents++;
    }

    public void addDtcEvent(DtcEventV2 dtcEvent)
    {
        if (dtcEvents == null)
        {
            dtcEvents = new ArrayList<DtcEventV2>();
        }

        dtcEvents.add(dtcEvent);

        numDtcEvents++;
    }

    public void addJbusDtc1708Event(JbusDtc1708Event jbusDtc1708Event)
    {
        if (jbusDtc1708Events == null)
        {
            jbusDtc1708Events = new ArrayList<JbusDtc1708Event>();
        }

        jbusDtc1708Events.add(jbusDtc1708Event);

        numJbusDtc1708Events++;
    }

    public void addJbusDtc1939Event(JbusDtc1939Event jbusDtc1939Event)
    {
        if (jbusDtc1939Events == null)
        {
            jbusDtc1939Events = new ArrayList<JbusDtc1939Event>();
        }

        jbusDtc1939Events.add(jbusDtc1939Event);

        numJbusDtc1939Events++;
    }

    public void addJbusHourlyReportEvent(JbusHourlyReportEventV2 jbusHourlyReportEvent)
    {
        if (jbusHourlyReportEvents == null)
        {
            jbusHourlyReportEvents = new ArrayList<JbusHourlyReportEventV2>();
        }

        jbusHourlyReportEvents.add(jbusHourlyReportEvent);

        numJbusHourlyReportEvents++;
    }

    public void addJbusDailyReportEvent(JbusDailyReportEventV2 jbusDailyReportEvent)
    {
        if (jbusDailyReportEvents == null)
        {
            jbusDailyReportEvents = new ArrayList<JbusDailyReportEventV2>();
        }

        jbusDailyReportEvents.add(jbusDailyReportEvent);

        numJbusDailyReportEvents++;
    }

    public void addJbusConstructionDailyReportEvent(JbusConstructionDailyReportEventV2 jbusConstructionDailyReportEvent)
    {
        if (jbusConstructionDailyReportEvents == null)
        {
            jbusConstructionDailyReportEvents = new ArrayList<JbusConstructionDailyReportEventV2>();
        }

        jbusConstructionDailyReportEvents.add(jbusConstructionDailyReportEvent);

        numJbusConstructionDailyReportEvents++;
    }

    public void addJbusHydraulicReportEvent(JbusHydraulicReportEventV2 jbusHydraulicReportEvent)
    {
        if (jbusHydraulicReportEvents == null)
        {
            jbusHydraulicReportEvents = new ArrayList<JbusHydraulicReportEventV2>();
        }

        jbusHydraulicReportEvents.add(jbusHydraulicReportEvent);

        numJbusHydraulicReportEvents++;
    }

    public void addJbusConstructionDailyUsageReportEvent(JbusConstructionDailyUsageReportEventV2 jbusConstructionDailyUsageReportEvent)
    {
        if (jbusConstructionDailyUsageReportEvents == null)
        {
            jbusConstructionDailyUsageReportEvents = new ArrayList<JbusConstructionDailyUsageReportEventV2>();
        }

        jbusConstructionDailyUsageReportEvents.add(jbusConstructionDailyUsageReportEvent);

        numJbusConstructionDailyUsageReportEvents++;
    }

    public void addJbusConstructionHourlyReportEvent(JbusConstructionHourlyReportEventV2 jbusConstructionHourlyReportEvent)
    {
        if (jbusConstructionHourlyReportEvents == null)
        {
            jbusConstructionHourlyReportEvents = new ArrayList<JbusConstructionHourlyReportEventV2>();
        }

        jbusConstructionHourlyReportEvents.add(jbusConstructionHourlyReportEvent);

        numJbusConstructionHourlyReportEvents++;
    }

    public void addJbusFaultReportEvent(JbusFaultReportEvent jbusFaultReportEvent)
    {
        if (jbusFaultReportEvents == null)
        {
            jbusFaultReportEvents = new ArrayList<JbusFaultReportEvent>();
        }

        jbusFaultReportEvents.add(jbusFaultReportEvent);

        numJbusFaultReportEvents++;
    }

    public void addJbusDiscoveryReportEvent(JbusDiscoveryReportEvent jbusDiscoveryReportEvent)
    {
        if (jbusDiscoveryReportEvents == null)
        {
            jbusDiscoveryReportEvents = new ArrayList<JbusDiscoveryReportEvent>();
        }

        jbusDiscoveryReportEvents.add(jbusDiscoveryReportEvent);

        numJbusDiscoveryReportEvents++;
    }

    public void addJbusEvent(JbusEvent jbusEvent)
    {
        if (jbusEvents == null)
        {
            jbusEvents = new ArrayList<JbusEvent>();
        }

        jbusEvents.add(jbusEvent);

        numJbusEvents++;
    }

    public void addObdProvisionEvent(VehicleBusCapabilities vehicleBusCapabilitiesEvent)
    {
        if (vehicleBusCapabilitiesEvents == null)
        {
            vehicleBusCapabilitiesEvents = new ArrayList<VehicleBusCapabilities>();
        }

        vehicleBusCapabilitiesEvents.add(vehicleBusCapabilitiesEvent);

        numVehicleBusCapabilitiesEvents++;
    }

    public List<AvlEventV2> getAvlEvents()
    {
        return avlEvents;
    }

    public List<DeviceCommandEvent> getDeviceCommandEvents()
    {
        return deviceCommandEvents;
    }

    public List<DtcEventV2> getDtcEvents()
    {
        return dtcEvents;
    }

    public List<JbusDtc1708Event> getJbusDtc1708Events()
    {
        return jbusDtc1708Events;
    }

    public List<JbusDtc1939Event> getJbusDtc1939Events()
    {
        return jbusDtc1939Events;
    }

    public List<JbusHourlyReportEventV2> getJbusHourlyReportEvents()
    {
        return jbusHourlyReportEvents;
    }

    public List<JbusDailyReportEventV2> getJbusDailyReportEvents()
    {
        return jbusDailyReportEvents;
    }

    public List<VehicleBusCapabilities> getVehicleBusCapabilitiesEvents()
    {
        return vehicleBusCapabilitiesEvents;
    }

    public int getNumJbusConstructionDailyReportEvents()
    {
        return numJbusConstructionDailyReportEvents;
    }

    public List<JbusEvent> getJbusEvents()
    {
        return jbusEvents;
    }

    public int getNumAvlEvents()
    {
        return numAvlEvents;
    }

    public int getNumDeviceCommandEvents()
    {
        return numDeviceCommandEvents;
    }

    public int getNumDtcEvents()
    {
        return numDtcEvents;
    }

    public int getNumJbusEvents()
    {
        return numJbusEvents;
    }

    public int getNumVehicleBusCapabilitiesEvents()
    {
        return numVehicleBusCapabilitiesEvents;
    }

    public int getNumJbusDtc1708Events()
    {
        return numJbusDtc1708Events;
    }

    public int getNumJbusDtc1939Events()
    {
        return numJbusDtc1939Events;
    }

    public int getNumJbusHourlyReportEvents()
    {
        return numJbusHourlyReportEvents;
    }

    public int getNumJbusDailyReportEvents()
    {
        return numJbusDailyReportEvents;
    }

    public List<JbusConstructionDailyReportEventV2> getJbusConstructionDailyReportEvents()
    {
        return jbusConstructionDailyReportEvents;
    }

    public int getNumJbusConstructionDailyUsageReportEvents()
    {
        return numJbusConstructionDailyUsageReportEvents;
    }

    public int getNumJbusConstructionHourlyReportEvents()
    {
        return numJbusConstructionHourlyReportEvents;
    }

    public int getNumJbusFaultReportEvents()
    {
        return numJbusFaultReportEvents;
    }

    public int getNumJbusDiscoveryReportEvents()
    {
        return numJbusDiscoveryReportEvents;
    }

    public int getNumJbusHydraulicReportEvents()
    {
        return numJbusHydraulicReportEvents;
    }

    public List<JbusConstructionDailyUsageReportEventV2> getJbusConstructionDailyUsageReportEvents()
    {
        return jbusConstructionDailyUsageReportEvents;
    }

    public List<JbusConstructionHourlyReportEventV2> getJbusConstructionHourlyReportEvents()
    {
        return jbusConstructionHourlyReportEvents;
    }

    public List<JbusFaultReportEvent> getJbusFaultReportEvents()
    {
        return jbusFaultReportEvents;
    }

    public List<JbusDiscoveryReportEvent> getJbusDiscoveryReportEvents()
    {
        return jbusDiscoveryReportEvents;
    }

    public List<JbusHydraulicReportEventV2> getJbusHydraulicReportEvents()
    {
        return jbusHydraulicReportEvents;
    }

    public void setAvlEvents(List<AvlEventV2> avlEvents)
    {
        this.avlEvents = avlEvents;
    }

    public void setDeviceCommandEvents(List<DeviceCommandEvent> deviceCommandEvents)
    {
        this.deviceCommandEvents = deviceCommandEvents;
    }

    public void setDtcEvents(List<DtcEventV2> dtcEvents)
    {
        this.dtcEvents = dtcEvents;
    }

    public void setJbusDtc1708Events(List<JbusDtc1708Event> jbusDtc1708Events)
    {
        this.jbusDtc1708Events = jbusDtc1708Events;
    }

    public void setJbusDtc1939Events(List<JbusDtc1939Event> jbusDtc1939Events)
    {
        this.jbusDtc1939Events = jbusDtc1939Events;
    }

    public void setJbusHourlyReportEvents(List<JbusHourlyReportEventV2> jbusHourlyReportEvents)
    {
        this.jbusHourlyReportEvents = jbusHourlyReportEvents;
    }

    public void setJbusDailyReportEvents(List<JbusDailyReportEventV2> jbusDailyReportEvents)
    {
        this.jbusDailyReportEvents = jbusDailyReportEvents;
    }

    public void setJbusConstructionDailyReportEvents(List<JbusConstructionDailyReportEventV2> jbusConstructionDailyReportEvents)
    {
        this.jbusConstructionDailyReportEvents = jbusConstructionDailyReportEvents;
    }

    public void setJbusEvents(List<JbusEvent> jbusEvents)
    {
        this.jbusEvents = jbusEvents;
    }

    public void setNumAvlEvents(int numAvlEvents)
    {
        this.numAvlEvents = numAvlEvents;
    }

    public void setNumDeviceCommandEvents(int numDeviceCommandEvents)
    {
        this.numDeviceCommandEvents = numDeviceCommandEvents;
    }

    public void setNumDtcEvents(int numDtcEvents)
    {
        this.numDtcEvents = numDtcEvents;
    }

    public void setNumJbusDtc1708Events(int numJbusDtc1708Events)
    {
        this.numJbusDtc1708Events = numJbusDtc1708Events;
    }

    public void setNumJbusDtc1939Events(int numJbusDtc1939Events)
    {
        this.numJbusDtc1939Events = numJbusDtc1939Events;
    }

    public void setNumJbusHourlyReportEvents(int numJbusHourlyReportEvents)
    {
        this.numJbusHourlyReportEvents = numJbusHourlyReportEvents;
    }

    public void setNumJbusDailyReportEvents(int numJbusDailyReportEvents)
    {
        this.numJbusDailyReportEvents = numJbusDailyReportEvents;
    }

    public void setNumJbusConstructionDailyReportEvents(int numJbusConstructionDailyReportEvents)
    {
        this.numJbusConstructionDailyReportEvents = numJbusConstructionDailyReportEvents;
    }

    public void setNumJbusConstructionDailyUsageReportEvents(int numJbusConstructionDailyUsageReportEvents)
    {
        this.numJbusConstructionDailyUsageReportEvents = numJbusConstructionDailyUsageReportEvents;
    }

    public void setNumJbusConstructionHourlyReportEvents(int numJbusConstructionHourlyReportEvents)
    {
        this.numJbusConstructionHourlyReportEvents = numJbusConstructionHourlyReportEvents;
    }

    public void setNumJbusFaultReportEvents(int numJbusFaultReportEvents)
    {
        this.numJbusFaultReportEvents = numJbusFaultReportEvents;
    }

    public void setNumJbusDiscoveryReportEvents(int numJbusDiscoveryReportEvents)
    {
        this.numJbusDiscoveryReportEvents = numJbusDiscoveryReportEvents;
    }

    public void setNumJbusHydraulicReportEvents(int numJbusHydraulicReportEvents)
    {
        this.numJbusHydraulicReportEvents = numJbusHydraulicReportEvents;
    }

    public void setJbusConstructionDailyUsageReportEvents(List<JbusConstructionDailyUsageReportEventV2> jbusConstructionDailyUsageReportEvents)
    {
        this.jbusConstructionDailyUsageReportEvents = jbusConstructionDailyUsageReportEvents;
    }

    public void setJbusConstructionHourlyReportEvents(List<JbusConstructionHourlyReportEventV2> jbusConstructionHourlyReportEvents)
    {
        this.jbusConstructionHourlyReportEvents = jbusConstructionHourlyReportEvents;
    }

    public void setJbusFaultReportEvents(List<JbusFaultReportEvent> jbusFaultReportEvents)
    {
        this.jbusFaultReportEvents = jbusFaultReportEvents;
    }

    public void setJbusDiscoveryReportEvents(List<JbusDiscoveryReportEvent> jbusDiscoveryReportEvents)
    {
        this.jbusDiscoveryReportEvents = jbusDiscoveryReportEvents;
    }

    public void setJbusHydraulicReportEvents(List<JbusHydraulicReportEventV2> jbusHydraulicReportEvents)
    {
        this.jbusHydraulicReportEvents = jbusHydraulicReportEvents;
    }

    public void setNumJbusEvents(int numJbusEvents)
    {
        this.numJbusEvents = numJbusEvents;
    }

    public void setNumVehicleBusCapabilitiesEvents(int numVehicleBusCapabilitiesEvents)
    {
        this.numVehicleBusCapabilitiesEvents = numVehicleBusCapabilitiesEvents;
    }

    public void setVehicleBusCapabilitiesEvents(List<VehicleBusCapabilities> vehicleBusCapabilitiesEvents)
    {
        this.vehicleBusCapabilitiesEvents = vehicleBusCapabilitiesEvents;
    }

    public int getNumIdReportEvents()
    {
        return numIdReportEvents;
    }

    public void setNumIdReportEvents(int numIdReportEvents)
    {
        this.numIdReportEvents = numIdReportEvents;
    }

    public int getNumExtendedIdReportEvents()
    {
        return numExtendedIdReportEvents;
    }

    public void setNumExtendedIdReportEvents(int numExtendedIdReportEvents)
    {
        this.numExtendedIdReportEvents = numExtendedIdReportEvents;
    }

    public List<IdReportEvent> getIdReportEvents()
    {
        return idReportEvents;
    }

    public void setIdReportEvents(List<IdReportEvent> idReportEvents)
    {
        this.idReportEvents = idReportEvents;
    }

    public List<ExtendedIdReportEvent> getExtendedIdReportEvents()
    {
        return extendedIdReportEvents;
    }

    public void setExtendedIdReportEvents(List<ExtendedIdReportEvent> extendedIdReportEvents)
    {
        this.extendedIdReportEvents = extendedIdReportEvents;
    }

    public int getNumAempMessageEvents()
    {
        return numAempMessageEvents;
    }

    public void setNumAempMessageEvents(int numAempMessageEvents)
    {
        this.numAempMessageEvents = numAempMessageEvents;
    }

    public List<AempMessageEvent> getAempMessageEvents()
    {
        return aempMessageEvents;
    }

    public void setAempMessageEvents(List<AempMessageEvent> aempMessageEvents)
    {
        this.aempMessageEvents = aempMessageEvents;
    }

    public int getNumAppMessages()
    {
        return numAppMessages;
    }

    public void setNumAppMessages(int numAppMessages)
    {
        this.numAppMessages = numAppMessages;
    }

    public int getNumUserMessages()
    {
        return numUserMessages;
    }

    public void setNumUserMessages(int numUserMessages)
    {
        this.numUserMessages = numUserMessages;
    }

    public List<UserMessage> getUserMessages()
    {
        return userMessages;
    }

    public void setUserMessages(List<UserMessage> userMessages)
    {
        this.userMessages = userMessages;
    }

    public List<AppMessage> getAppMessages()
    {
        return appMessages;
    }

    public void setAppMessages(List<AppMessage> appMessages)
    {
        this.appMessages = appMessages;
    }

    public int getNumMotionLogMessageEvents()
    {
        return numMotionLogMessageEvents;
    }

    public void setNumMotionLogMessageEvents(int numMotionLogMessageEvents)
    {
        this.numMotionLogMessageEvents = numMotionLogMessageEvents;
    }

    public List<MotionLogsEvent> getMotionLogMessageEvents()
    {
        return motionLogMessageEvents;
    }

    public void setMotionLogMessageEvents(List<MotionLogsEvent> motionLogMessageEvents)
    {
        this.motionLogMessageEvents = motionLogMessageEvents;
    }

	public int getNumSelfDescribingJPODMessages() {
		return numSelfDescribingJPODMessages;
	}

	public void setNumSelfDescribingJPODMessages(int numSelfDescribingJPODMessages) {
		this.numSelfDescribingJPODMessages = numSelfDescribingJPODMessages;
	}

	public List<SelfDescribingJPODMessage> getSelfDescribingJPODMessages() {
		return selfDescribingJPODMessages;
	}

	public void setSelfDescribingJPODMessages(List<SelfDescribingJPODMessage> selfDescribingJPODMessages) {
		this.selfDescribingJPODMessages = selfDescribingJPODMessages;
	}

	public int getNumJpod2DTCReports() {
		return numJpod2DTCReports;
	}

	public void setNumJpod2DTCReports(int numJpod2DTCReports) {
		this.numJpod2DTCReports = numJpod2DTCReports;
	}

	public List<Jpod2DTCReport> getJpod2DTCReports() {
		return jpod2DTCReports;
	}

	public void setJpod2DTCReports(List<Jpod2DTCReport> jpod2dtcReports) {
		jpod2DTCReports = jpod2dtcReports;
	}
	
    
}
