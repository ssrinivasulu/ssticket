package com.calamp.connect.models.messaging.devicecommand;

import java.math.BigDecimal;
import java.nio.ByteBuffer;

import com.calamp.connect.models.messaging.GeoZoneInformation;
import com.calamp.connect.models.messaging.GeoZoneType;
import com.calamp.connect.models.util.UnsignedByteDecoder;


/**
 * @author Sidlingappa
 *
 */
public class ZoneDecoder implements DeviceCommandParameterDecoder<GeoZoneInformation, GeoZoneInformation>
{
    @Override
    public byte[] toBytes(GeoZoneInformation parameter)
    {
        ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[18]);

        int latitude = convertLatLongToInt(parameter.getLatitude());
        int longitude = convertLatLongToInt(parameter.getLongitude());
        byteBuffer.putInt(latitude);
        byteBuffer.putInt(longitude);
        byteBuffer.putInt(parameter.getDistanceEast());
        byteBuffer.putInt(parameter.getDistanceNorth());
        byteBuffer.put((byte) parameter.getType().ordinal());
        byte convertedHysteresis = UnsignedByteDecoder.signedByteToUnsignedByte((byte) parameter.getHysteresis().intValue());
        byteBuffer.put(convertedHysteresis);

        return byteBuffer.array();
    }

    @Override
    public GeoZoneInformation fromBytes(byte[] array)
    {
        ByteBuffer byteBuffer = ByteBuffer.wrap(array);
        int unconvertedLatitude = byteBuffer.getInt();
        int unconvertedLongitude = byteBuffer.getInt();
        int distanceEast = byteBuffer.getInt();
        int distanceNorth = byteBuffer.getInt();
        byte type = byteBuffer.get();
        int hysteresis = UnsignedByteDecoder.unsignedByteToSignedByte(byteBuffer.get());

        GeoZoneInformation request = new GeoZoneInformation();
        request.setDistanceEast(distanceEast);
        request.setDistanceNorth(distanceNorth);
        request.setType(GeoZoneType.values()[type]);
        request.setHysteresis(hysteresis);
        request.setLatitude(convertIntToLatLong(unconvertedLatitude));
        request.setLongitude(convertIntToLatLong(unconvertedLongitude));
        return request;
    }

    private int convertLatLongToInt(double parameter)
    {
        BigDecimal bigDecimal = new BigDecimal(String.valueOf(parameter));
        bigDecimal = bigDecimal.scaleByPowerOfTen(7);
        return bigDecimal.intValue();
    }

    private double convertIntToLatLong(int parameter)
    {
        BigDecimal bigDecimal = new BigDecimal(String.valueOf(parameter));
        bigDecimal = bigDecimal.scaleByPowerOfTen(-7);
        return bigDecimal.doubleValue();
    }
}
