package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusConstructionDailyReportEntity extends DeviceEventEntity
{

    private MachineStateEntity machineState;

    // version 1 fields we can remove this fields after all documents in mongo are new structure
    private Double             engineTotalFuelUsed;
    private Double             avgEngineFuelRate;
    private Integer            avgActualEngineTorque;
    private Double             minEngineSpeed;
    private Double             maxEngineSpeed;
    private Double             avgEngineSpeed;
    private Double             minDEFConcentration;
    private Double             maxDEFConcentration;
    private Double             avgDEFConcentration;
    private Integer            minDEFTempr;
    private Integer            maxDEFTempr;
    private Integer            avgDEFTempr;
    private Integer            minEngineOilPressure;
    private Integer            maxEngineOilPressure;
    private Integer            avgEngineOilPressure;
    private Double             minEngineOilTempr;
    private Double             maxEngineOilTempr;
    private Double             avgEngineOilTempr;
    private Integer            minEngineCoolantTempr;
    private Integer            maxEngineCoolantTempr;
    private Integer            avgEngineCoolantTempr;
    private Integer            minEngineFuelTempr1;
    private Integer            maxEngineFuelTempr1;
    private Integer            avgEngineFuelTempr1;
    private Double             minAmbientAirTempr;
    private Double             maxAmbientAirTempr;
    private Double             avgAmbientAirTempr;
    private Integer            minAuxiliaryTempr1;
    private Integer            maxAuxiliaryTempr1;
    private Integer            avgAuxiliaryTempr1;

    public JbusConstructionDailyReportEntity()
    {
        setMsgType(MsgType.JBUS_CONSTRUCTION_DAILY_REPORT);
    }

    public MachineStateEntity getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineStateEntity machineState)
    {
        this.machineState = machineState;
    }

    public Double getEngineTotalFuelUsed()
    {
        return engineTotalFuelUsed;
    }

    public void setEngineTotalFuelUsed(Double engineTotalFuelUsed)
    {
        this.engineTotalFuelUsed = engineTotalFuelUsed;
    }

    public Double getAvgEngineFuelRate()
    {
        return avgEngineFuelRate;
    }

    public void setAvgEngineFuelRate(Double avgEngineFuelRate)
    {
        this.avgEngineFuelRate = avgEngineFuelRate;
    }

    public Integer getAvgActualEngineTorque()
    {
        return avgActualEngineTorque;
    }

    public void setAvgActualEngineTorque(Integer avgActualEngineTorque)
    {
        this.avgActualEngineTorque = avgActualEngineTorque;
    }

    public Double getMinEngineSpeed()
    {
        return minEngineSpeed;
    }

    public void setMinEngineSpeed(Double minEngineSpeed)
    {
        this.minEngineSpeed = minEngineSpeed;
    }

    public Double getMaxEngineSpeed()
    {
        return maxEngineSpeed;
    }

    public void setMaxEngineSpeed(Double maxEngineSpeed)
    {
        this.maxEngineSpeed = maxEngineSpeed;
    }

    public Double getAvgEngineSpeed()
    {
        return avgEngineSpeed;
    }

    public void setAvgEngineSpeed(Double avgEngineSpeed)
    {
        this.avgEngineSpeed = avgEngineSpeed;
    }

    public Double getMinDEFConcentration()
    {
        return minDEFConcentration;
    }

    public void setMinDEFConcentration(Double minDEFConcentration)
    {
        this.minDEFConcentration = minDEFConcentration;
    }

    public Double getMaxDEFConcentration()
    {
        return maxDEFConcentration;
    }

    public void setMaxDEFConcentration(Double maxDEFConcentration)
    {
        this.maxDEFConcentration = maxDEFConcentration;
    }

    public Double getAvgDEFConcentration()
    {
        return avgDEFConcentration;
    }

    public void setAvgDEFConcentration(Double avgDEFConcentration)
    {
        this.avgDEFConcentration = avgDEFConcentration;
    }

    public Integer getMinDEFTempr()
    {
        return minDEFTempr;
    }

    public void setMinDEFTempr(Integer minDEFTempr)
    {
        this.minDEFTempr = minDEFTempr;
    }

    public Integer getMaxDEFTempr()
    {
        return maxDEFTempr;
    }

    public void setMaxDEFTempr(Integer maxDEFTempr)
    {
        this.maxDEFTempr = maxDEFTempr;
    }

    public Integer getAvgDEFTempr()
    {
        return avgDEFTempr;
    }

    public void setAvgDEFTempr(Integer avgDEFTempr)
    {
        this.avgDEFTempr = avgDEFTempr;
    }

    public Integer getMinEngineOilPressure()
    {
        return minEngineOilPressure;
    }

    public void setMinEngineOilPressure(Integer minEngineOilPressure)
    {
        this.minEngineOilPressure = minEngineOilPressure;
    }

    public Integer getMaxEngineOilPressure()
    {
        return maxEngineOilPressure;
    }

    public void setMaxEngineOilPressure(Integer maxEngineOilPressure)
    {
        this.maxEngineOilPressure = maxEngineOilPressure;
    }

    public Integer getAvgEngineOilPressure()
    {
        return avgEngineOilPressure;
    }

    public void setAvgEngineOilPressure(Integer avgEngineOilPressure)
    {
        this.avgEngineOilPressure = avgEngineOilPressure;
    }

    public Double getMinEngineOilTempr()
    {
        return minEngineOilTempr;
    }

    public void setMinEngineOilTempr(Double minEngineOilTempr)
    {
        this.minEngineOilTempr = minEngineOilTempr;
    }

    public Double getMaxEngineOilTempr()
    {
        return maxEngineOilTempr;
    }

    public void setMaxEngineOilTempr(Double maxEngineOilTempr)
    {
        this.maxEngineOilTempr = maxEngineOilTempr;
    }

    public Double getAvgEngineOilTempr()
    {
        return avgEngineOilTempr;
    }

    public void setAvgEngineOilTempr(Double avgEngineOilTempr)
    {
        this.avgEngineOilTempr = avgEngineOilTempr;
    }

    public Integer getMinEngineCoolantTempr()
    {
        return minEngineCoolantTempr;
    }

    public void setMinEngineCoolantTempr(Integer minEngineCoolantTempr)
    {
        this.minEngineCoolantTempr = minEngineCoolantTempr;
    }

    public Integer getMaxEngineCoolantTempr()
    {
        return maxEngineCoolantTempr;
    }

    public void setMaxEngineCoolantTempr(Integer maxEngineCoolantTempr)
    {
        this.maxEngineCoolantTempr = maxEngineCoolantTempr;
    }

    public Integer getAvgEngineCoolantTempr()
    {
        return avgEngineCoolantTempr;
    }

    public void setAvgEngineCoolantTempr(Integer avgEngineCoolantTempr)
    {
        this.avgEngineCoolantTempr = avgEngineCoolantTempr;
    }

    public Integer getMinEngineFuelTempr1()
    {
        return minEngineFuelTempr1;
    }

    public void setMinEngineFuelTempr1(Integer minEngineFuelTempr1)
    {
        this.minEngineFuelTempr1 = minEngineFuelTempr1;
    }

    public Integer getMaxEngineFuelTempr1()
    {
        return maxEngineFuelTempr1;
    }

    public void setMaxEngineFuelTempr1(Integer maxEngineFuelTempr1)
    {
        this.maxEngineFuelTempr1 = maxEngineFuelTempr1;
    }

    public Integer getAvgEngineFuelTempr1()
    {
        return avgEngineFuelTempr1;
    }

    public void setAvgEngineFuelTempr1(Integer avgEngineFuelTempr1)
    {
        this.avgEngineFuelTempr1 = avgEngineFuelTempr1;
    }

    public Double getMinAmbientAirTempr()
    {
        return minAmbientAirTempr;
    }

    public void setMinAmbientAirTempr(Double minAmbientAirTempr)
    {
        this.minAmbientAirTempr = minAmbientAirTempr;
    }

    public Double getMaxAmbientAirTempr()
    {
        return maxAmbientAirTempr;
    }

    public void setMaxAmbientAirTempr(Double maxAmbientAirTempr)
    {
        this.maxAmbientAirTempr = maxAmbientAirTempr;
    }

    public Double getAvgAmbientAirTempr()
    {
        return avgAmbientAirTempr;
    }

    public void setAvgAmbientAirTempr(Double avgAmbientAirTempr)
    {
        this.avgAmbientAirTempr = avgAmbientAirTempr;
    }

    public Integer getMinAuxiliaryTempr1()
    {
        return minAuxiliaryTempr1;
    }

    public void setMinAuxiliaryTempr1(Integer minAuxiliaryTempr1)
    {
        this.minAuxiliaryTempr1 = minAuxiliaryTempr1;
    }

    public Integer getMaxAuxiliaryTempr1()
    {
        return maxAuxiliaryTempr1;
    }

    public void setMaxAuxiliaryTempr1(Integer maxAuxiliaryTempr1)
    {
        this.maxAuxiliaryTempr1 = maxAuxiliaryTempr1;
    }

    public Integer getAvgAuxiliaryTempr1()
    {
        return avgAuxiliaryTempr1;
    }

    public void setAvgAuxiliaryTempr1(Integer avgAuxiliaryTempr1)
    {
        this.avgAuxiliaryTempr1 = avgAuxiliaryTempr1;
    }

}
