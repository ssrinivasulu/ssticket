package com.calamp.connect.models.messaging;

import javax.measure.quantity.Dimensionless;
import javax.measure.quantity.ElectricPotential;
import javax.measure.quantity.Pressure;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.FuelEconomy;
import com.calamp.connect.framework.quantity.JBUSTemperature;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("jbusHourlyReportData")
@JsonTypeName("jbusHourlyReportData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "averageFuelEconomy", "engineBatteryVoltage", "engineCoolantPressure", "engineCoolantTemperature", "engineCrankcasePressure",
        "engineFuelTankLevel1", "engineFuelTankLevel2", "engineOilPressure", "engineOilTemperature", "transmissionOilTemperature" })
@JsonPropertyOrder({ "averageFuelEconomy", "engineBatteryVoltage", "engineCoolantPressure", "engineCoolantTemperature", "engineCrankcasePressure",
        "engineFuelTankLevel1", "engineFuelTankLevel2", "engineOilPressure", "engineOilTemperature", "transmissionOilTemperature" })
public class JbusHourlyReportData extends DeviceData
{
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData engineCoolantTemperature;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData engineOilTemperature;
    @ConvertUnit(type = Pressure.class)
    private HeaderData engineOilPressure;
    @ConvertUnit(type = Pressure.class)
    private HeaderData engineCrankcasePressure;
    @ConvertUnit(type = Pressure.class)
    private HeaderData engineCoolantPressure;
    @ConvertUnit(type = ElectricPotential.class)
    private HeaderData engineBatteryVoltage;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData engineFuelTankLevel1;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData engineFuelTankLevel2;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData transmissionOilTemperature;
    @ConvertUnit(type = FuelEconomy.class)
    private HeaderData averageFuelEconomy;

    public HeaderData getEngineCoolantTemperature()
    {
        return engineCoolantTemperature;
    }

    public void setEngineCoolantTemperature(HeaderData engineCoolantTemperature)
    {
        this.engineCoolantTemperature = engineCoolantTemperature;
    }

    public HeaderData getEngineOilTemperature()
    {
        return engineOilTemperature;
    }

    public void setEngineOilTemperature(HeaderData engineOilTemperature)
    {
        this.engineOilTemperature = engineOilTemperature;
    }

    public HeaderData getEngineOilPressure()
    {
        return engineOilPressure;
    }

    public void setEngineOilPressure(HeaderData engineOilPressure)
    {
        this.engineOilPressure = engineOilPressure;
    }

    public HeaderData getEngineCrankcasePressure()
    {
        return engineCrankcasePressure;
    }

    public void setEngineCrankcasePressure(HeaderData engineCrankcasePressure)
    {
        this.engineCrankcasePressure = engineCrankcasePressure;
    }

    public HeaderData getEngineCoolantPressure()
    {
        return engineCoolantPressure;
    }

    public void setEngineCoolantPressure(HeaderData engineCoolantPressure)
    {
        this.engineCoolantPressure = engineCoolantPressure;
    }

    public HeaderData getEngineBatteryVoltage()
    {
        return engineBatteryVoltage;
    }

    public void setEngineBatteryVoltage(HeaderData engineBatteryVoltage)
    {
        this.engineBatteryVoltage = engineBatteryVoltage;
    }

    public HeaderData getEngineFuelTankLevel1()
    {
        return engineFuelTankLevel1;
    }

    public void setEngineFuelTankLevel1(HeaderData engineFuelTankLevel1)
    {
        this.engineFuelTankLevel1 = engineFuelTankLevel1;
    }

    public HeaderData getEngineFuelTankLevel2()
    {
        return engineFuelTankLevel2;
    }

    public void setEngineFuelTankLevel2(HeaderData engineFuelTankLevel2)
    {
        this.engineFuelTankLevel2 = engineFuelTankLevel2;
    }

    public HeaderData getTransmissionOilTemperature()
    {
        return transmissionOilTemperature;
    }

    public void setTransmissionOilTemperature(HeaderData transmissionOilTemperature)
    {
        this.transmissionOilTemperature = transmissionOilTemperature;
    }

    public HeaderData getAverageFuelEconomy()
    {
        return averageFuelEconomy;
    }

    public void setAverageFuelEconomy(HeaderData averageFuelEconomy)
    {
        this.averageFuelEconomy = averageFuelEconomy;
    }

}
