package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "jbusDtc1939Event")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("jbusDtc1939Event")
@JsonTypeName("jbusDtc1939Event")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted",
        "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "inputs",
        "jbusDtc1939ProtocolEvents", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port",
        "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "searchFieldsDisplay", "searchFieldMap", "sourceAddress",
        "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusDtc1939Event", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId",
        "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode",
        "eventTime", "eventType", "inputs", "jbusDtc1939ProtocolEvents", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "searchFieldsDisplay",
        "searchFieldMap", "sourceAddress", "timeOfFix", "vin", "vinResponse" })
public class JbusDtc1939Event extends DeviceEvent
{
    @XmlElementWrapper(name = "jbusDtc1939ProtocolEvents")
    @XmlElement(name = "jbusDtc1939ProtocolEvent")
    private List<JbusDtc1939Protocol> jbusDtc1939ProtocolEvents;

    private Integer                   sourceAddress;

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }

    public List<JbusDtc1939Protocol> getJbusDtc1939ProtocolEvents()
    {
        return jbusDtc1939ProtocolEvents;
    }

    public void setJbusDtc1939ProtocolEvents(List<JbusDtc1939Protocol> jbusDtc1939ProtocolEvents)
    {
        this.jbusDtc1939ProtocolEvents = jbusDtc1939ProtocolEvents;
    }

}
