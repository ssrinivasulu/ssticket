package com.calamp.connect.models.db.converter;

import java.math.BigDecimal;
import java.nio.ByteBuffer;

import javax.measure.Unit;

import com.calamp.connect.framework.measure.CalAmpUnitConverter;
import com.calamp.connect.models.messaging.Acceleration;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.AvlEvent;
import com.calamp.connect.models.messaging.DeviceData;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.VbusIndicators;
import com.calamp.connect.services.fmi.util.HexUtil;

public class QuantityConverter
{

    // None
    @QuantityNameMapping(quantityName = "None")
    public String convertNone(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    // Altitude
    @QuantityNameMapping(quantityName = "Altitude")
    public String convertAltitude(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    // Time
    @QuantityNameMapping(quantityName = "Time")
    public String convertTime(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    // Distance
    @QuantityNameMapping(quantityName = "Distance")
    public String convertDistance(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    // Speed
    @QuantityNameMapping(quantityName = "Speed")
    public String convertSpeed(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    // MaxSpeed
    @QuantityNameMapping(quantityName = "Max Speed")
    public String convertMaxSpeed(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    // ADC
    @QuantityNameMapping(quantityName = "ADC")
    public String convertADC(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    // MaxADC
    @QuantityNameMapping(quantityName = "Max ADC")
    public String convertMaxADC(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    // Zone
    @QuantityNameMapping(quantityName = "Zone")
    public String convertZone(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    // Position Accuracy
    @QuantityNameMapping(quantityName = "Position Accuracy")
    public String convertPositionAccuracy(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    // GeoZone
    @QuantityNameMapping(quantityName = "GeoZone")
    public String convertGeoZone(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    // IO States
    @QuantityNameMapping(quantityName = "IO States")
    public String convertIOStates(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Max Acceleration")
    public String convertMaxAcceleration(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Max Deceleration")
    public String convertMaxDeceleration(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "RSSI")
    public String convertRSSI(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Cell ID")
    public String convertCellID(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Temperature")
    public String convertTemperature(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Speed History")
    public String convertSpeedHistory(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Average ADC")
    public String convertAverageADC(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Network Channel")
    public String convertNetworkChannel(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS: Vehicle Speed")
    public String convertVehicleSpeed(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Engine Speed")
    public String convertEngineSpeed(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Throttle Position")
    public String convertThrottlePosition(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Odometer")
    public String convertOdometer(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Fuel Level Percentage")
    public String convertFuelLevelPercentage(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Fuel Level Remaining3000")
    public String convertFuelLevelRemaining3000(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Transmission Gear")
    public String convertTransmissionGear(Unit fromUnit, Unit toUnit, String value)
    {
        // Output format : "<enumeration value>[<accumulator value converted to decimal>]"
        // 1=Park, 2=Reverse, 3=Neutral, 4=Drive
        int enumValue = Integer.valueOf(value);
        switch (enumValue) {
            case 1:
                return enumValue + "[Park]";
            case 2:
                return enumValue + "[Reverse]";
            case 3:
                return enumValue + "[Neutral]";
            case 4:
                return enumValue + "[Drive]";
            default:
                return "INVALID_GEAR";
        }
    }

    @QuantityNameMapping(quantityName = "VBUS: Engine Coolant Temp")
    public String convertEngineCoolantTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Fuel Rate")
    public String convertFuelRate(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Battery Voltage")
    public String convertBatteryVoltage(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Turn Signal Status")
    public String convertTurnSignalStatus(Unit fromUnit, Unit toUnit, String value)
    {
        // Output format : "<enumeration value>[<accumulator value converted to decimal>]"
        // 0=Off, 1=Left, 2=Right, 3=Left & Right
        int enumValue = Integer.valueOf(value);
        switch (enumValue) {
            case 0:
                return enumValue + "[Off]";
            case 1:
                return enumValue + "[Left]";
            case 2:
                return enumValue + "[Right]";
            case 3:
                return enumValue + "[Left & Right]";
            default:
                return "INVALID_TURN_SIGNAL_STATUS";
        }
    }

    @QuantityNameMapping(quantityName = "VBUS: Calculated Trip Odometer")
    public String convertCalculatedTripOdometer(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Fuel Trip")
    public String convertFuelTrip(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Calculated Fuel Usage")
    public String convertCalculatedFuelUsage(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Derived Engine State")
    public String convertDerivedEngineState(Unit fromUnit, Unit toUnit, String value)
    {
        // Output format : "<enumeration value>[<accumulator value converted to decimal>]"
        // 1=Engine Off, 2=Engine On
        int enumValue = Integer.valueOf(value);
        switch (enumValue) {
            case 1:
                return enumValue + "[Engine Off]";
            case 2:
                return enumValue + "[Engine On]";
            default:
                return "INVALID_ENGINE_STATE";
        }
    }

    @QuantityNameMapping(quantityName = "VBUS: Service Interval Inspection Distance")
    public String convertServiceIntervalInspectionDistance(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Fuel Level Remaining")
    public String convertFuelLevelRemaining(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Service Interval Days Remaining")
    public String convertServiceIntervalDaysRemaining(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Engine Oil Temp")
    public String convertEngineOilTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Fuel Economy")
    public String convertFuelEconomy(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: DTC Count")
    public String convertDTCCount(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS: Service Interval Oil Distance")
    public String convertServiceIntervalOilDistance(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Service Interval Oil Days")
    public String convertServiceIntervalOilDays(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Engine Run Time")
    public String convertEngineRunTime(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Ambient Air Temp")
    public String convertAmbientAirTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: Barometric Pressure")
    public String convertBarometricPressure(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS: CAN TEC")
    public String convertCANTEC(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS: CAN REC")
    public String convertCANREC(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS: CAN Bus Mode")
    public String convertCANBusMode(Unit fromUnit, Unit toUnit, String value)
    {
        // 1. Error Active (<=96 Errors) 2. Warning (>96 but <=237 Errors) 3. Error Passive (>127 but <256 Errors) 4. Bus Off (>255 Errors)
        int mode = Integer.valueOf(value);
        if (mode <= 96)
            return "Error Active";
        else if (mode > 96 && mode <= 237)
            return "Warning";
        else if (mode > 237 && mode <= 255)
            return "Error Passive";
        else
            return "Bus Off";
    }

    @QuantityNameMapping(quantityName = "VBUS: CAN Bus Error Type")
    public String convertCANBusErrorType(Unit fromUnit, Unit toUnit, String value)
    {
        // One of the Following: 0. No Error 1. Stuff Error 2. Form Error 3. Ack Error 4. Bit Recessive Error 5. Bit Dominant Error 6. CRC Error 7.
        // For Software Use
        switch (Integer.valueOf(value)) {
            case 0:
                return "No Error";
            case 1:
                return "Stuff Error";
            case 2:
                return "Form Error";
            case 3:
                return "Ack Error";
            case 4:
                return "Bit Recessive Error";
            case 5:
                return "Bit Dominant Error";
            case 6:
                return "CRC Error";
            case 7:
                return "For Software Use";
            default:
                return "INVALID_ERROR_TYPE";
        }
    }

    @QuantityNameMapping(quantityName = "VBUS Indicator 0")
    public void convertVBUSIndicator0(AvlEvent avlEvent, String value)
    {
        // return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
        int VBUS_OFFSET = 31;
        String binaryString = Long.toBinaryString(Long.valueOf(value));
        StringBuilder builder = new StringBuilder(binaryString);
        // pad string to 32 bit
        while (builder.length() < 32)
        {
            builder.insert(0, "0");
        }

        VbusIndicators vbusIndicators = (avlEvent.getVbusIndicators() != null)?avlEvent.getVbusIndicators():new VbusIndicators();
        vbusIndicators.setIgnitionStatus(bitToBool(builder.charAt(VBUS_OFFSET - 0)));
        vbusIndicators.setMilStatus(bitToBool(builder.charAt(VBUS_OFFSET - 1)));
        vbusIndicators.setAirbagDashIndicator(bitToBool(builder.charAt(VBUS_OFFSET - 2)));
        vbusIndicators.setAbsDashIndicator(bitToBool(builder.charAt(VBUS_OFFSET - 3)));
        vbusIndicators.setPtoStatus(bitToBool(builder.charAt(VBUS_OFFSET - 4)));
        vbusIndicators.setSeatBeltFastened(bitToBool(builder.charAt(VBUS_OFFSET - 5)));
        vbusIndicators.setBrakePedalPressed(bitToBool(builder.charAt(VBUS_OFFSET - 6)));
        vbusIndicators.setAbsActiveLamp(bitToBool(builder.charAt(VBUS_OFFSET - 7)));
        vbusIndicators.setCruiseControlStatus(bitToBool(builder.charAt(VBUS_OFFSET - 8)));
        vbusIndicators.setOilPressureLamp(bitToBool(builder.charAt(VBUS_OFFSET - 9)));
        vbusIndicators.setParkBrakeLight(bitToBool(builder.charAt(VBUS_OFFSET - 10)));
        vbusIndicators.setCoolantHotLight(bitToBool(builder.charAt(VBUS_OFFSET - 11)));
        vbusIndicators.setTpmsStatus(bitToBool(builder.charAt(VBUS_OFFSET - 12)));
        avlEvent.setVbusIndicators(vbusIndicators);
    }

    @QuantityNameMapping(quantityName = "VBUS Indicator 1")
    public void convertVBUSIndicator1(AvlEvent avlEvent, String value)
    {
        // return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
        int VBUS_OFFSET = 31;
        String binaryString = Long.toBinaryString(Long.valueOf(value));
        StringBuilder builder = new StringBuilder(binaryString);
        // pad string to 32 bit
        while (builder.length() < 32)
        {
            builder.insert(0, "0");
        }

        VbusIndicators vbusIndicators = (avlEvent.getVbusIndicators() != null)?avlEvent.getVbusIndicators():new VbusIndicators();
        vbusIndicators.setMisfireMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 0)));
        vbusIndicators.setFuelSystemMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 1)));
        vbusIndicators.setComprehensiveComponentMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 2)));
        vbusIndicators.setCatalystMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 3)));
        vbusIndicators.setHeatedCatalystMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 4)));
        vbusIndicators.setEvaporativeSystemMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 5)));
        vbusIndicators.setSecondaryAirSystemMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 6)));
        vbusIndicators.setAcSystemRefrigerantMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 7)));
        vbusIndicators.setOxygenSensorMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 8)));
        vbusIndicators.setOxygenSensorHeatedMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 9)));
        vbusIndicators.setEgrSystemMonitor(bitToBool(builder.charAt(VBUS_OFFSET - 10)));
        vbusIndicators.setO2SensorCircuitNoActivity(bitToBool(builder.charAt(VBUS_OFFSET - 11)));
        vbusIndicators.setO2SensorHeaterCircuitMalfunction(bitToBool(builder.charAt(VBUS_OFFSET - 12)));
        vbusIndicators.setHo2SHeaterControlMalfunction(bitToBool(builder.charAt(VBUS_OFFSET - 13)));
        vbusIndicators.setHo2SHeaterResistanceMalfunction(bitToBool(builder.charAt(VBUS_OFFSET - 14)));
        avlEvent.setVbusIndicators(vbusIndicators);
    }

    @QuantityNameMapping(quantityName = "Acceleration Event")
    public void convertAccelerationEvent(String label, DeviceData deviceData, DeviceData deviceConvertedData, String value)
    {

        String binaryString = Long.toBinaryString(Long.valueOf(value));

        // make sure there are enough zeros;
        StringBuilder builder = new StringBuilder(binaryString);
        while (builder.length() < 32)
        {
            builder.insert(0, "0");
        }

        String calibration = String.valueOf(Integer.parseInt(builder.substring(0, 1))); // calibration
        // Device will send data by dividing 100. To get actual value do *100
        // To represent in seconds /1000.
        // Now do /10 with value received. To get proper result in presenting in seconds
        float dur = (float) Integer.parseInt(builder.substring(1, 9), 2) / 10;
        String duration = String.valueOf(dur); // duration

        // Device will send data by doing *10
        float startSpeed = (float) Integer.parseInt(builder.substring(9, 19), 2) * 10;
        String startingSpeed = String.valueOf(startSpeed); // startingSpeed
        String accelerationMagnitude = String.valueOf(Integer.parseInt(builder.substring(19, 32), 2)); // accelerationMagnitude

        Acceleration acceleration = new Acceleration();
        acceleration.setLabel(label);
        acceleration.setCalibration(calibration.equals("0") ? "AVERAGE" : "BEST");

        HeaderData headerData = new HeaderData();
        headerData.setValue(duration);
        acceleration.setDuration(headerData);

        headerData = new HeaderData();
        headerData.setValue(startingSpeed);
        acceleration.setStartingSpeed(headerData);

        headerData = new HeaderData();
        headerData.setValue(accelerationMagnitude);
        acceleration.setAccelerationMagnitude(headerData);

        if (deviceData instanceof AvlDeviceData)
            ((AvlDeviceData) deviceData).setAcceleration(acceleration);

        // Below code can be removed have Generic converter for Header
        acceleration = new Acceleration();
        acceleration.setLabel(label);
        acceleration.setCalibration(calibration.equals("0") ? "AVERAGE" : "BEST");

        if (deviceConvertedData instanceof AvlDeviceData)
            ((AvlDeviceData) deviceConvertedData).setAcceleration(acceleration);

    }

    @QuantityNameMapping(quantityName = "Acceleration Latitude")
    public String convertAccelerationLatitude(String value)
    {
        return convertLatLong(value);
    }

    @QuantityNameMapping(quantityName = "Acceleration Longitude")
    public String convertAccelerationLongitude(String value)
    {
        return convertLatLong(value);
    }

    @QuantityNameMapping(quantityName = "Local Area code")
    public String convertLocalAreaCode(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Battery Remaining %")
    public String convertBatteryUsage1(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Battery Used %")
    public String convertBatteryUsage2(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Battery Remaining mAH")
    public String convertBatteryUsage3(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Battery Used mAH")
    public String convertBatteryUsage4(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Schedule")
    public String convertSchedule(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Serial App")
    public String convertSerialApp(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Min ADC")
    public String convertMinADC(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Accumulate ADC (HILO)")
    public String convertAccumulateADC(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Accumulate Speed (HILO)")
    public String convertAccumulateSpeed(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Accumulator Temp (HILO)")
    public String convertAccumulateTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Accumulator RPM (HILO)")
    public String convertAccumulateRPM(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Max RPM")
    public String convertMaxRPM(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Avg of the ADC Reading (HILO)")
    public String convertAvgoftheADCReading(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "Driver ID Error Status")
    public String convertDriverIDErrorStatus(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Humidity")
    public String convertHumidity(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Humidity (HILO)")
    public String convertHumidityHILO(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "RPM")
    public String convertRPM(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Vehicle Speed")
    public String convertMaxVehicleSpeed(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Engine Speed")
    public String convertMaxEngineSpeed(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Throttle Position")
    public String convertMaxThrottlePosition(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Odometer")
    public String convertMaxOdometer(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Fuel Level Percentage")
    public String convertMaxFuelLevelPercentage(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Fuel Level Remaining3000")
    public String convertMaxFuelLevelRemaining3000(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Transmission Gear")
    public String convertMaxTransmissionGear(Unit fromUnit, Unit toUnit, String value)
    {
        // Output format : "<enumeration value>[<accumulator value converted to decimal>]"
        // 1=Park, 2=Reverse, 3=Neutral, 4=Drive
        int enumValue = Integer.valueOf(value);
        switch (enumValue) {
            case 1:
                return enumValue + "[Park]";
            case 2:
                return enumValue + "[Reverse]";
            case 3:
                return enumValue + "[Neutral]";
            case 4:
                return enumValue + "[Drive]";
            default:
                return "INVALID_GEAR";
        }
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Engine Coolant Temp")
    public String convertMaxEngineCoolantTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Fuel Rate")
    public String convertMaxFuelRate(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Battery Voltage")
    public String convertMaxBatteryVoltage(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Turn Signal Status")
    public String convertMaxTurnSignalStatus(Unit fromUnit, Unit toUnit, String value)
    {
        // Output format : "<enumeration value>[<accumulator value converted to decimal>]"
        // 0=Off, 1=Left, 2=Right, 3=Left & Right
        int enumValue = Integer.valueOf(value);
        switch (enumValue) {
            case 0:
                return enumValue + "[Off]";
            case 1:
                return enumValue + "[Left]";
            case 2:
                return enumValue + "[Right]";
            case 3:
                return enumValue + "[Left & Right]";
            default:
                return "INVALID_TURN_SIGNAL_STATUS";
        }
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Calculated Trip Odometer")
    public String convertMaxCalculatedTripOdometer(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Fuel Trip")
    public String convertMaxFuelTrip(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Calculated Fuel Usage")
    public String convertMaxCalculatedFuelUsage(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Derived Engine State")
    public String convertMaxDerivedEngineState(Unit fromUnit, Unit toUnit, String value)
    {
        // Output format : "<enumeration value>[<accumulator value converted to decimal>]"
        // 1=Engine Off, 2=Engine On
        int enumValue = Integer.valueOf(value);
        switch (enumValue) {
            case 1:
                return enumValue + "[Engine Off]";
            case 2:
                return enumValue + "[Engine On]";
            default:
                return "INVALID_ENGINE_STATE";
        }
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Service Interval Inspection Distance")
    public String convertMaxServiceIntervalInspectionDistance(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Fuel Level Remaining")
    public String convertMaxFuelLevelRemaining(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Service Interval Days Remaining")
    public String convertMaxServiceIntervalDaysRemaining(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Engine Oil Temp")
    public String convertMaxEngineOilTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Fuel Economy")
    public String convertMaxFuelEconomy(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: DTC Count")
    public String convertMaxDTCCount(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Service Interval Oil Distance")
    public String convertMaxServiceIntervalOilDistance(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Service Interval Oil Days")
    public String convertMaxServiceIntervalOilDays(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Engine Run Time")
    public String convertMaxEngineRunTime(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Ambient Air Temp")
    public String convertMaxAmbientAirTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBUS Max: Barometric Pressure")
    public String convertMaxBarometricPressure(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "VBus Offset Param")
    public String convertVBusOffsetParam(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Avg Temp (HILO)")
    public String convertAvgTemp(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "BLE RSSI (HILO)")
    public String convertBleRSSI(Unit fromUnit, Unit toUnit, String value)
    {
        return CalAmpUnitConverter.convert(fromUnit, toUnit, value);
    }

    @QuantityNameMapping(quantityName = "BLE FOB Batt")
    public String convertBleFobBatt(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Impact Data")
    public String convertImpactData(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "Input Count")
    public String convertInputCount(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS Max: CAN TEC")
    public String convertMaxCANTEC(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS Max: CAN REC")
    public String convertMaxCANREC(Unit fromUnit, Unit toUnit, String value)
    {
        return value;
    }

    @QuantityNameMapping(quantityName = "VBUS Max: CAN Bus Mode")
    public String convertMaxCANBusMode(Unit fromUnit, Unit toUnit, String value)
    {
        // 1. Error Active (<=96 Errors) 2. Warning (>96 but <=237 Errors) 3. Error Passive (>127 but <256 Errors) 4. Bus Off (>255 Errors)
        int mode = Integer.valueOf(value);
        if (mode <= 96)
            return "Error Active";
        else if (mode > 96 && mode <= 237)
            return "Warning";
        else if (mode > 237 && mode <= 255)
            return "Error Passive";
        else
            return "Bus Off";
    }

    @QuantityNameMapping(quantityName = "VBUS Max: CAN Bus Error Type")
    public String convertMaxCANBusErrorType(Unit fromUnit, Unit toUnit, String value)
    {
        // One of the Following: 0. No Error 1. Stuff Error 2. Form Error 3. Ack Error 4. Bit Recessive Error 5. Bit Dominant Error 6. CRC Error 7.
        // For Software Use
        switch (Integer.valueOf(value)) {
            case 0:
                return "No Error";
            case 1:
                return "Stuff Error";
            case 2:
                return "Form Error";
            case 3:
                return "Ack Error";
            case 4:
                return "Bit Recessive Error";
            case 5:
                return "Bit Dominant Error";
            case 6:
                return "CRC Error";
            case 7:
                return "For Software Use";
            default:
                return "INVALID_ERROR_TYPE";
        }
    }

    private static boolean bitToBool(char c)
    {
        if (c == '1')
            return true;
        else
            return false;
    }

    private String convertLatLong(String value)
    {
        if (value == null)
            return null;
        BigDecimal originalLong;
        try
        {
            byte[] b = HexUtil.convertFromHexString(Long.toHexString(Long.parseLong(value)));
            ByteBuffer byteBuffer = ByteBuffer.wrap(b);
            originalLong = new BigDecimal(byteBuffer.getInt());
        }
        catch (Exception e)
        {
            originalLong = new BigDecimal(value);
        }
        BigDecimal decimalVal = originalLong.scaleByPowerOfTen(-7);
        return decimalVal.toPlainString();
    }

}
