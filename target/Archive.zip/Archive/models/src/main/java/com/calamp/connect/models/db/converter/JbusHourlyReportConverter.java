package com.calamp.connect.models.db.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.models.db.domain.JbusHourlyReportEntity;
import com.calamp.connect.models.messaging.JbusHourlyReportData;
import com.calamp.connect.models.messaging.JbusHourlyReportEvent;

public class JbusHourlyReportConverter extends DeviceEventConverter<JbusHourlyReportEntity, JbusHourlyReportEvent>
{
    private Logger logger = LoggerFactory.getLogger(JbusHourlyReportConverter.class);

    @Override
    public JbusHourlyReportEntity modelToDomain(JbusHourlyReportEvent jbusHourlyReportEvent)
    {
        JbusHourlyReportEntity jbusHourlyReportEntity = super.convert(jbusHourlyReportEvent, JbusHourlyReportEntity.class);

        return customConvert(jbusHourlyReportEvent, jbusHourlyReportEntity);

    }

    @Override
    public JbusHourlyReportEvent domainToModel(JbusHourlyReportEntity jbusHourlyReportEventEntity)
    {
        JbusHourlyReportEvent jbusHourlyReportEvent = super.convert(jbusHourlyReportEventEntity, JbusHourlyReportEvent.class);

        return customConvert(jbusHourlyReportEventEntity, jbusHourlyReportEvent);

    }

    @Override
    protected JbusHourlyReportEntity customConvert(JbusHourlyReportEvent model, JbusHourlyReportEntity entity)
    {
        return entity;
    }

    @Override
    protected JbusHourlyReportEvent customConvert(JbusHourlyReportEntity entity, JbusHourlyReportEvent model)
    {
        if (entity.getDeviceData() != null)
        {
            JbusHourlyReportData hourlyReportData = (JbusHourlyReportData) entity.getDeviceData();
            if (hourlyReportData.getAverageFuelEconomy() != null)
                model.setAverageFuelEconomy(convertHeaderDataToDouble(hourlyReportData.getAverageFuelEconomy()));
            if (hourlyReportData.getEngineBatteryVoltage() != null)
                model.setEngineBatteryVoltage(convertHeaderDataToDouble(hourlyReportData.getEngineBatteryVoltage()));
            if (hourlyReportData.getEngineCoolantPressure() != null)
                model.setEngineCoolantPressure(convertHeaderDataToInt(hourlyReportData.getEngineCoolantPressure()));
            if (hourlyReportData.getEngineCoolantTemperature() != null)
                model.setEngineCoolantTemperature(convertHeaderDataToInt(hourlyReportData.getEngineCoolantTemperature()));
            if (hourlyReportData.getEngineFuelTankLevel1() != null)
                model.setEngineFuelTankLevel1(convertHeaderDataToDouble(hourlyReportData.getEngineFuelTankLevel1()));
            if (hourlyReportData.getEngineFuelTankLevel2() != null)
                model.setEngineFuelTankLevel2(convertHeaderDataToDouble(hourlyReportData.getEngineFuelTankLevel2()));
            if (hourlyReportData.getEngineOilPressure() != null)
                model.setEngineOilPressure(convertHeaderDataToInt(hourlyReportData.getEngineOilPressure()));
            if (hourlyReportData.getTransmissionOilTemperature() != null)
                model.setTransmissionOilTemperature(convertHeaderDataToDouble(hourlyReportData.getTransmissionOilTemperature()));
            if (hourlyReportData.getEngineOilTemperature() != null)
                model.setEngineOilTemperature(convertHeaderDataToDouble(hourlyReportData.getEngineOilTemperature()));
            if (hourlyReportData.getEngineCrankcasePressure() != null)
                model.setEngineCrankcasePressure(convertHeaderDataToDouble(hourlyReportData.getEngineCrankcasePressure()));
        }
        model.setDeviceDataConverted(null);
        return model;
    }

    @Override
    public JbusHourlyReportEvent domainToModel(JbusHourlyReportEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusHourlyReportEntity> getDomainType()
    {
        return JbusHourlyReportEntity.class;
    }

    @Override
    public Class<JbusHourlyReportEvent> getModelType()
    {
        return JbusHourlyReportEvent.class;
    }

}
