package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@XmlRootElement(name = "machineState")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("machineState")
@JsonTypeName("machineState")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NONE
)
@JsonPropertyOrder(
{
	 "engineStatus", "j1708MsgRecvd", "j1939MsgRecvd", "moving",
		"ptoStatus"
})
@XmlType(
        name = "machineState",
        propOrder =
        {
 "engineStatus", "j1708MsgRecvd", "j1939MsgRecvd", "moving",
		"ptoStatus"
        })
    
public class MachineState {
    private boolean engineStatus;
    private boolean ptoStatus;
    private boolean moving;
    private boolean j1708MsgRecvd;
    private boolean j1939MsgRecvd;

    public boolean isEngineStatus() {
        return engineStatus;
    }

    public void setEngineStatus(boolean engineStatus) {
        this.engineStatus = engineStatus;
    }

    public boolean isPtoStatus() {
        return ptoStatus;
    }

    public void setPtoStatus(boolean ptoStatus) {
        this.ptoStatus = ptoStatus;
    }

    public boolean isMoving() {
        return moving;
    }

    public void setMoving(boolean moving) {
        this.moving = moving;
    }

    public boolean isJ1708MsgRecvd() {
        return j1708MsgRecvd;
    }

    public void setJ1708MsgRecvd(boolean j1708MsgRecvd) {
        this.j1708MsgRecvd = j1708MsgRecvd;
    }

    public boolean isJ1939MsgRecvd() {
        return j1939MsgRecvd;
    }

    public void setJ1939MsgRecvd(boolean j1939MsgRecvd) {
        this.j1939MsgRecvd = j1939MsgRecvd;
    }

}
