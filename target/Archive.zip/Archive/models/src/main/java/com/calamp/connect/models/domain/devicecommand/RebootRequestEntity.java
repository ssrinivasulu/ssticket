package com.calamp.connect.models.domain.devicecommand;

public class RebootRequestEntity extends DeviceCommandMessageRequestEntity
{
    @Override
    public String toString()
    {
        return "RebootRequest{" + super.toString() + '}';
    }
}
