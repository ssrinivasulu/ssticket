package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.DurationMinutes;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("jbusConstructionDailyUsageReportData")
@JsonTypeName("jbusConstructionDailyUsageReportData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "engineTorque0To10PercentUsage", "engineTorque10To20PercentUsage", "engineTorque20To30PercentUsage",
        "engineTorque30To40PercentUsage", "engineTorque40To50PercentUsage", "engineTorque50To60PercentUsage", "engineTorque60To70PercentUsage",
        "engineTorque70To80PercentUsage", "engineTorque80To90PercentUsage", "engineTorqueOver90PercentUsage", "positionTorque0To10PercentUsage",
        "positionTorque10To20PercentUsage", "positionTorque20To30PercentUsage", "positionTorque30To40PercentUsage",
        "positionTorque40To50PercentUsage", "positionTorque50To60PercentUsage", "positionTorque60To70PercentUsage",
        "positionTorque70To80PercentUsage", "positionTorque80To90PercentUsage", "positionTorqueOver90PercentUsage" })
@JsonPropertyOrder({ "engineTorque0To10PercentUsage", "engineTorque10To20PercentUsage", "engineTorque20To30PercentUsage",
        "engineTorque30To40PercentUsage", "engineTorque40To50PercentUsage", "engineTorque50To60PercentUsage", "engineTorque60To70PercentUsage",
        "engineTorque70To80PercentUsage", "engineTorque80To90PercentUsage", "engineTorqueOver90PercentUsage", "positionTorque0To10PercentUsage",
        "positionTorque10To20PercentUsage", "positionTorque20To30PercentUsage", "positionTorque30To40PercentUsage",
        "positionTorque40To50PercentUsage", "positionTorque50To60PercentUsage", "positionTorque60To70PercentUsage",
        "positionTorque70To80PercentUsage", "positionTorque80To90PercentUsage", "positionTorqueOver90PercentUsage" })
public class JbusConstructionDailyUsageReportData extends DeviceData
{
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque0To10PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque10To20PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque20To30PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque30To40PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque40To50PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque50To60PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque60To70PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque70To80PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorque80To90PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData engineTorqueOver90PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque0To10PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque10To20PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque20To30PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque30To40PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque40To50PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque50To60PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque60To70PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque70To80PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorque80To90PercentUsage;
    @ConvertUnit(type = DurationMinutes.class)
    private HeaderData positionTorqueOver90PercentUsage;

    public HeaderData getEngineTorque0To10PercentUsage()
    {
        return engineTorque0To10PercentUsage;
    }

    public void setEngineTorque0To10PercentUsage(HeaderData engineTorque0To10PercentUsage)
    {
        this.engineTorque0To10PercentUsage = engineTorque0To10PercentUsage;
    }

    public HeaderData getEngineTorque10To20PercentUsage()
    {
        return engineTorque10To20PercentUsage;
    }

    public void setEngineTorque10To20PercentUsage(HeaderData engineTorque10To20PercentUsage)
    {
        this.engineTorque10To20PercentUsage = engineTorque10To20PercentUsage;
    }

    public HeaderData getEngineTorque20To30PercentUsage()
    {
        return engineTorque20To30PercentUsage;
    }

    public void setEngineTorque20To30PercentUsage(HeaderData engineTorque20To30PercentUsage)
    {
        this.engineTorque20To30PercentUsage = engineTorque20To30PercentUsage;
    }

    public HeaderData getEngineTorque30To40PercentUsage()
    {
        return engineTorque30To40PercentUsage;
    }

    public void setEngineTorque30To40PercentUsage(HeaderData engineTorque30To40PercentUsage)
    {
        this.engineTorque30To40PercentUsage = engineTorque30To40PercentUsage;
    }

    public HeaderData getEngineTorque40To50PercentUsage()
    {
        return engineTorque40To50PercentUsage;
    }

    public void setEngineTorque40To50PercentUsage(HeaderData engineTorque40To50PercentUsage)
    {
        this.engineTorque40To50PercentUsage = engineTorque40To50PercentUsage;
    }

    public HeaderData getEngineTorque50To60PercentUsage()
    {
        return engineTorque50To60PercentUsage;
    }

    public void setEngineTorque50To60PercentUsage(HeaderData engineTorque50To60PercentUsage)
    {
        this.engineTorque50To60PercentUsage = engineTorque50To60PercentUsage;
    }

    public HeaderData getEngineTorque60To70PercentUsage()
    {
        return engineTorque60To70PercentUsage;
    }

    public void setEngineTorque60To70PercentUsage(HeaderData engineTorque60To70PercentUsage)
    {
        this.engineTorque60To70PercentUsage = engineTorque60To70PercentUsage;
    }

    public HeaderData getEngineTorque70To80PercentUsage()
    {
        return engineTorque70To80PercentUsage;
    }

    public void setEngineTorque70To80PercentUsage(HeaderData engineTorque70To80PercentUsage)
    {
        this.engineTorque70To80PercentUsage = engineTorque70To80PercentUsage;
    }

    public HeaderData getEngineTorque80To90PercentUsage()
    {
        return engineTorque80To90PercentUsage;
    }

    public void setEngineTorque80To90PercentUsage(HeaderData engineTorque80To90PercentUsage)
    {
        this.engineTorque80To90PercentUsage = engineTorque80To90PercentUsage;
    }

    public HeaderData getEngineTorqueOver90PercentUsage()
    {
        return engineTorqueOver90PercentUsage;
    }

    public void setEngineTorqueOver90PercentUsage(HeaderData engineTorqueOver90PercentUsage)
    {
        this.engineTorqueOver90PercentUsage = engineTorqueOver90PercentUsage;
    }

    public HeaderData getPositionTorque0To10PercentUsage()
    {
        return positionTorque0To10PercentUsage;
    }

    public void setPositionTorque0To10PercentUsage(HeaderData positionTorque0To10PercentUsage)
    {
        this.positionTorque0To10PercentUsage = positionTorque0To10PercentUsage;
    }

    public HeaderData getPositionTorque10To20PercentUsage()
    {
        return positionTorque10To20PercentUsage;
    }

    public void setPositionTorque10To20PercentUsage(HeaderData positionTorque10To20PercentUsage)
    {
        this.positionTorque10To20PercentUsage = positionTorque10To20PercentUsage;
    }

    public HeaderData getPositionTorque20To30PercentUsage()
    {
        return positionTorque20To30PercentUsage;
    }

    public void setPositionTorque20To30PercentUsage(HeaderData positionTorque20To30PercentUsage)
    {
        this.positionTorque20To30PercentUsage = positionTorque20To30PercentUsage;
    }

    public HeaderData getPositionTorque30To40PercentUsage()
    {
        return positionTorque30To40PercentUsage;
    }

    public void setPositionTorque30To40PercentUsage(HeaderData positionTorque30To40PercentUsage)
    {
        this.positionTorque30To40PercentUsage = positionTorque30To40PercentUsage;
    }

    public HeaderData getPositionTorque40To50PercentUsage()
    {
        return positionTorque40To50PercentUsage;
    }

    public void setPositionTorque40To50PercentUsage(HeaderData positionTorque40To50PercentUsage)
    {
        this.positionTorque40To50PercentUsage = positionTorque40To50PercentUsage;
    }

    public HeaderData getPositionTorque50To60PercentUsage()
    {
        return positionTorque50To60PercentUsage;
    }

    public void setPositionTorque50To60PercentUsage(HeaderData positionTorque50To60PercentUsage)
    {
        this.positionTorque50To60PercentUsage = positionTorque50To60PercentUsage;
    }

    public HeaderData getPositionTorque60To70PercentUsage()
    {
        return positionTorque60To70PercentUsage;
    }

    public void setPositionTorque60To70PercentUsage(HeaderData positionTorque60To70PercentUsage)
    {
        this.positionTorque60To70PercentUsage = positionTorque60To70PercentUsage;
    }

    public HeaderData getPositionTorque70To80PercentUsage()
    {
        return positionTorque70To80PercentUsage;
    }

    public void setPositionTorque70To80PercentUsage(HeaderData positionTorque70To80PercentUsage)
    {
        this.positionTorque70To80PercentUsage = positionTorque70To80PercentUsage;
    }

    public HeaderData getPositionTorque80To90PercentUsage()
    {
        return positionTorque80To90PercentUsage;
    }

    public void setPositionTorque80To90PercentUsage(HeaderData positionTorque80To90PercentUsage)
    {
        this.positionTorque80To90PercentUsage = positionTorque80To90PercentUsage;
    }

    public HeaderData getPositionTorqueOver90PercentUsage()
    {
        return positionTorqueOver90PercentUsage;
    }

    public void setPositionTorqueOver90PercentUsage(HeaderData positionTorqueOver90PercentUsage)
    {
        this.positionTorqueOver90PercentUsage = positionTorqueOver90PercentUsage;
    }

}
