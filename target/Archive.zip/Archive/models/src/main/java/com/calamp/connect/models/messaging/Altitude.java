package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "altitude")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "altitude")
@JsonRootName("altitude")
@JsonTypeName("altitude")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class Altitude
{
    @XmlElement(name = "Meters", nillable = true)
    private Double meters;
    @XmlElement(name = "Feet")
    private Double feet;
    @XmlElement(name = "Inches")
    private Double inches;

    public Altitude()
    {
    }

    public double getMeters()
    {
        return meters;
    }

    public void setMeters(double meters)
    {
        this.meters = meters;
    }

    public Double getFeet()
    {
        return feet;
    }

    public void setFeet(Double feet)
    {
        this.feet = feet;
    }

    public Double getInches()
    {
        return inches;
    }

    public void setInches(Double inches)
    {
        this.inches = inches;
    }
}
