package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "telemetry")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("telemetry")
@JsonTypeName("telemetry")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)
@XmlType(propOrder =
{
 "altitude", "engineHours", "fuelUsage", "odometer", "speed"
})
@JsonPropertyOrder(
{
 "altitude", "engineHours", "fuelUsage", "odometer", "speed"
})
public class Telemetry
{
    private Long    altitude;
    private Long    engineHours;
    private Double   fuelUsage;
    private Double   odometer;
    private Integer speed;

    public Long getAltitude()
    {
        return altitude;
    }

    public Long getEngineHours()
    {
        return engineHours;
    }

    public Double getFuelUsage()
    {
        return fuelUsage;
    }

    public Double getOdometer()
    {
        return odometer;
    }

    public Integer getSpeed()
    {
        return speed;
    }

    public void setAltitude(Long altitude)
    {
        this.altitude = altitude;
    }

    public void setEngineHours(Long engineHours)
    {
        this.engineHours = engineHours;
    }

    public void setFuelUsage(Double fuelUsage)
    {
        this.fuelUsage = fuelUsage;
    }

    public void setOdometer(Double odometer)
    {
        this.odometer = odometer;
    }

    public void setSpeed(Integer speed)
    {
        this.speed = speed;
    }
}
