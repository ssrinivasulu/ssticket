package com.calamp.connect.models.messaging;

import javax.measure.quantity.Speed;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.RSSI;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("dtcDeviceData")
@JsonTypeName("dtcDeviceData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "gpsSpeed", "rssi" })
@JsonPropertyOrder({ "gpsSpeed", "rssi" })
public class DtcDeviceData extends DeviceData
{

    @ConvertUnit(type = Speed.class)
    private HeaderData gpsSpeed;

    @ConvertUnit(type = RSSI.class)
    private HeaderData rssi;

    public HeaderData getGpsSpeed()
    {
        return gpsSpeed;
    }

    public void setGpsSpeed(HeaderData gpsSpeed)
    {
        this.gpsSpeed = gpsSpeed;
    }

    public HeaderData getRssi()
    {
        return rssi;
    }

    public void setRssi(HeaderData rssi)
    {
        this.rssi = rssi;
    }

}
