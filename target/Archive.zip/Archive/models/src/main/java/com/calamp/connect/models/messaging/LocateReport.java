package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

import org.joda.time.DateTime;

@XmlRootElement(name = "locateReport")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("locateReport")
@JsonTypeName("locateReport")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)
public class LocateReport
{
    GPS       gps;
    DateTime  gpsFixTime;
    Telemetry telemetry;

    public GPS getGps()
    {
        return gps;
    }

    public DateTime getGpsFixTime()
    {
        return gpsFixTime;
    }

    public Telemetry getTelemetry()
    {
        return telemetry;
    }

    public void setGps(GPS gps)
    {
        this.gps = gps;
    }

    public void setGpsFixTime(DateTime gpsFixTime)
    {
        this.gpsFixTime = gpsFixTime;
    }

    public void setTelemetry(Telemetry telemetry)
    {
        this.telemetry = telemetry;
    }
}
