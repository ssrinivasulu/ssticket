package com.calamp.connect.models.messaging.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDtc1939Event;
import com.calamp.connect.models.messaging.JbusDtc1939Protocol;
import com.calamp.connect.models.network.Jbus.JbusDtcData;
import com.calamp.connect.models.network.Network.NetworkMessage;
@Component
public class NetworkToJbusDtc1939EventConverter extends 
		GenericNetworkToDeviceEventConverter
{
    
    public JbusDtc1939Event convert(NetworkMessage network)
    {
    	List<JbusDtcData> jbusDtcDataJ1939s = network.getRawJbusMessage().getJbusDtcDataJ1939();
    	JbusDtc1939Event jbusDtc1939Event = new JbusDtc1939Event();
    	List<JbusDtc1939Protocol> jbusDtc1939Protocols = new ArrayList<JbusDtc1939Protocol>();
    	MapperFacade    jbus1939Mapper = mapperFactory.getMapperFacade();
    	jbus1939Mapper.map(network, jbusDtc1939Event);
    	JbusDtc1939Protocol jbusDtc1939Protocol=null;
    	for (JbusDtcData jbusDtcDataJ1939 : jbusDtcDataJ1939s) {
    		jbusDtc1939Protocol = new JbusDtc1939Protocol();
    		jbus1939Mapper.map(jbusDtcDataJ1939, jbusDtc1939Protocol);
    		jbusDtc1939Protocols.add(jbusDtc1939Protocol);
    	}
    	jbusDtc1939Event.setJbusDtc1939ProtocolEvents(jbusDtc1939Protocols);
    	jbusDtc1939Event.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        jbusDtc1939Event.setSourceAddress(network.getRawJbusMessage().getSourceAddress());
        return jbusDtc1939Event;
    }

   
}
