package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "equipmentHeader")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "equipmentHeader")
@JsonRootName("equipmentHeader")
@JsonTypeName("equipmentHeader")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class EquipmentHeader
{
    @XmlElement(name = "Make", nillable = true, type = String.class)
    private String make;
    @XmlElement(name = "Model", nillable = true, type = String.class)
    private String model;
    @XmlElement(name = "EquipmentID", nillable = true, type = String.class)
    private String equipmentID;
    @XmlElement(name = "SerialNumber", nillable = true, type = String.class)
    private String serialNumber;

    public EquipmentHeader()
    {
    }

    public String getMake()
    {
        return make;
    }

    public void setMake(String make)
    {
        if (make != null)
            this.make = make;
        else
            this.make = "";
    }

    public String getModel()
    {
        return model;
    }

    public void setModel(String model)
    {
        if (model != null)
            this.model = model;
        else
            this.model = "";
    }

    public String getEquipmentID()
    {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID)
    {
        if (equipmentID != null)
            this.equipmentID = equipmentID;
        else
            this.equipmentID = "";
    }

    public String getSerialNumber()
    {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber)
    {
        if (serialNumber != null)
            this.serialNumber = serialNumber;
        else
            this.serialNumber = "";
    }

    @Override
    public String toString()
    {
        return "EquipmentHeader : {make:" + make + ", model:" + model + ", equipmentID:" + equipmentID + ", serialNumber:" + serialNumber + "}";
    }
}
