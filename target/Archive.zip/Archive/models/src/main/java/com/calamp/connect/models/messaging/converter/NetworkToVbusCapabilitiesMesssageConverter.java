package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.VehicleBusCapabilities;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class NetworkToVbusCapabilitiesMesssageConverter extends GenericNetworkToDeviceEventConverter  {

	public VehicleBusCapabilities convert(NetworkMessage network) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		VehicleBusCapabilities vehicleBusCapabilities = 
				mapper.map(network, VehicleBusCapabilities.class);
		vehicleBusCapabilities.setEventTime(new Date(network.getProvisionMessage().getLocationTime()));
        return vehicleBusCapabilities;
	}
	
}
