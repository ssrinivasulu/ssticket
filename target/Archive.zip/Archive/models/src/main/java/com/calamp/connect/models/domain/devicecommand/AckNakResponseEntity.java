package com.calamp.connect.models.domain.devicecommand;

public class AckNakResponseEntity extends DeviceCommandMessageResponseEntity
{
    private boolean successfulAck;

    public AckNakResponseEntity() {}

    public AckNakResponseEntity(String externalDeviceId, Integer sequenceId, boolean successfulAck)
    {
        setExternalDeviceId(externalDeviceId);
        setSequenceId(sequenceId);

        this.successfulAck = successfulAck;
    }

    public boolean isSuccessfulAck()
    {
        return successfulAck;
    }

    public void setSuccessfulAck(boolean successfulAck)
    {
        this.successfulAck = successfulAck;
    }
}
