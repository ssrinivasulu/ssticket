package com.calamp.connect.models.messaging;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "aempMessageEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("aempMessageEvent")
@JsonTypeName("aempMessageEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
public class AempMessageEvent extends DeviceEvent
{

    private EquipmentHeader          equipmentHeader;
    private Location                 location;
    private CumulativeOperatingHours cumulativeOperatingHours;
    private Distance                 distance;
    private FuelUsed                 fuelUsed;
    private FuelUsedLast24           fuelUsedLast24;

    public EquipmentHeader getEquipmentHeader()
    {
        return equipmentHeader;
    }

    public void setEquipmentHeader(EquipmentHeader equipmentHeader)
    {
        this.equipmentHeader = equipmentHeader;
    }

    public CumulativeOperatingHours getCumulativeOperatingHours()
    {
        return cumulativeOperatingHours;
    }

    public void setCumulativeOperatingHours(CumulativeOperatingHours cumulativeOperatingHours)
    {
        this.cumulativeOperatingHours = cumulativeOperatingHours;
    }

    public Distance getDistance()
    {
        return distance;
    }

    public void setDistance(Distance distance)
    {
        this.distance = distance;
    }

    public FuelUsed getFuelUsed()
    {
        return fuelUsed;
    }

    public void setFuelUsed(FuelUsed fuelUsed)
    {
        this.fuelUsed = fuelUsed;
    }

    public FuelUsedLast24 getFuelUsedLast24()
    {
        return fuelUsedLast24;
    }

    public void setFuelUsedLast24(FuelUsedLast24 fuelUsedLast24)
    {
        this.fuelUsedLast24 = fuelUsedLast24;
    }

    public Location getLocation()
    {
        return location;
    }

    public void setLocation(Location location)
    {
        this.location = location;
    }

    @Override
    public Long getAssetId()
    {
        return super.getAssetId();
    }

    @Override
    public String getAssetName()
    {
        return super.getAssetName();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public Inputs getInputs()
    {
        return super.getInputs();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public DeviceData getDeviceData()
    {
        return super.getDeviceData();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public Date getTimeOfFix()
    {
        return super.getTimeOfFix();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public String getDeviceAirId()
    {
        return super.getDeviceAirId();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public Integer getEventCode()
    {
        return super.getEventCode();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public DeviceData getDeviceDataConverted()
    {
        return super.getDeviceDataConverted();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public String getRawDeviceHexMessage()
    {
        return super.getRawDeviceHexMessage();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public Long getLmdirectMessageType()
    {
        return super.getLmdirectMessageType();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public String getEventType()
    {
        return super.getEventType();
    }
}
