package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "equipment")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "equipment")
public class Equipment
{
    @XmlElement(name = "EquipmentHeader", required = true, nillable = true)
    private EquipmentHeader          equipmentHeader;
    @XmlElement(name = "Location", required = true, nillable = true)
    private Location                 location;
    @XmlElement(name = "CumulativeOperatingHours", required = true, nillable = true)
    private CumulativeOperatingHours cumulativeOperatingHours;
    @XmlElement(name = "Distance", required = true, nillable = true)
    private Distance distnace;

    public Equipment()
    {
    }

    public void setEquipmentHeader(EquipmentHeader equipmentHeader)
    {
        this.equipmentHeader = equipmentHeader;
    }

    public EquipmentHeader getEquipmentHeader()
    {
        return equipmentHeader;
    }

    public Location getLocation()
    {
        return location;
    }

    public void setLocation(Location location)
    {
        this.location = location;
    }

    public CumulativeOperatingHours getCumulativeOperatingHours()
    {
        return cumulativeOperatingHours;
    }

    public void setCumulativeOperatingHours(CumulativeOperatingHours cumulativeOperatingHours)
    {
        this.cumulativeOperatingHours = cumulativeOperatingHours;

    }
    
    public Distance getDistnace()
    {
        return distnace;
    }

    public void setDistnace(Distance distnace)
    {
        this.distnace = distnace;
    }
}
