package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.hateoas.Link;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonRootName("response")
@JsonPropertyOrder({ "counts", "errors", "results" })
@XmlRootElement(name = "response")
@XmlType(namespace = Link.CALAMP_SERVICES_NS)
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonTypeName("response")
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
public class DpResponse<M>
{
    private final List<String> errors  = new ArrayList<>();
    private final List<M>      results = new ArrayList<>();
    private M                  counts;

    public void addErrors(String... errors)
    {
        if ((errors == null) || (errors.length == 0))
            return;

        for (String s : errors)
            this.errors.add(s);
    }

    @SafeVarargs
    public final void addResults(M... results)
    {
        if ((results == null) || (results.length == 0))
            return;

        for (M r : results)
            this.results.add(r);
    }

    public final void setCounts(M counts)
    {
        this.counts = counts;
    }

    @XmlElementWrapper(name = "errors")
    @XmlElements({ @XmlElement(name = "error", type = String.class) })
    @JsonProperty(value = "errors")
    public List<String> getErrors()
    {
        return errors;
    }

    @JsonProperty("results")
    @JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
    @XmlElementWrapper(name = "results")
    public List<M> getResults()
    {
        return results;
    }

    @JsonProperty("counts")
    @JsonTypeInfo(use = Id.NONE, include = As.WRAPPER_OBJECT)
    @XmlElement
    public M getCounts()
    {
        return counts;
    }

}
