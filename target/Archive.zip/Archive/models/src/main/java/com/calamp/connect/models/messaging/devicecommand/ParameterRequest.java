package com.calamp.connect.models.messaging.devicecommand;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@XmlType(propOrder = { "requestType", "parameters" })
@JsonPropertyOrder({ "deviceIpAddress", "requestType", "parameters" })
public class ParameterRequest extends DeviceCommandMessageRequest
{
    private String requestType;
    private List<ParameterConfigInfo> parameters = new ArrayList<>();

    public String getRequestType()
    {
        return requestType;
    }

    public void setRequestType(String requestType)
    {
        this.requestType = requestType;
    }

    public List<ParameterConfigInfo> getParameters()
    {
        return parameters;
    }

    public void setParameters(List<ParameterConfigInfo> parameters)
    {
        this.parameters = parameters;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        ParameterRequest that = (ParameterRequest) o;

        if (parameters != null ? !parameters.equals(that.parameters) : that.parameters != null) return false;
        if (requestType != null ? !requestType.equals(that.requestType) : that.requestType != null) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = super.hashCode();
        result = 31 * result + (requestType != null ? requestType.hashCode() : 0);
        result = 31 * result + (parameters != null ? parameters.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "ParameterRequest{" +
                "requestType='" + requestType + '\'' +
                ", parameters=" + parameters +
                '}';
    }
}
