package com.calamp.connect.models.messaging.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Accumulator;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.AvlEventV2;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.network.Network.NetworkMessage;

/**
 * @author ssrinivasulu
 *
 */
@Component("networkToAvlMesssageConverter")
public class NetworkToAvlMesssageConverter extends GenericNetworkToDeviceEventConverter
{

    public AvlEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        AvlEventV2 avlEvent = mapper.map(network, AvlEventV2.class);
        avlEvent.setEventTime(new Date(network.getMessageDetail().getLocationTime()));
        if (network.getRawAccumulators() != null)
        {
            List<Accumulator> rawAccumulators = new ArrayList<Accumulator>(network.getRawAccumulators().size());
            int i = 0;
            for (Long rawAccumulator : network.getRawAccumulators())
            {
                if (rawAccumulator != -1)
                {
                    Accumulator acc = new Accumulator();
                    acc.setLabel("Accumulator " + i);
                    acc.setIndex(String.valueOf(i));
                    acc.setValue(String.valueOf(rawAccumulator));
                    rawAccumulators.add(acc);
                }
                i = i + 1;
            }
            AvlDeviceData deviceData = new AvlDeviceData();
            deviceData.setAccumulators(rawAccumulators);

            HeaderData headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getRssi()));
            deviceData.setRssi(headerData);

            headerData = new HeaderData();
            if(network.getMessageDetail().getAltitude() != null){
            	headerData.setValue(String.valueOf(network.getMessageDetail().getAltitude()));
            } else {
            	//setValue('null') was causing conversion issues later, below is not ideal
            	headerData.setValue("0");
            }
            	
            deviceData.setAltitude(headerData);

            headerData = new HeaderData();
            if(network.getMessageDetail().getSpeed() != null){
            	headerData.setValue(String.valueOf(network.getMessageDetail().getSpeed()));
            } else if(network.getMessageDetail().getMiniSpeed() !=null){
            	//kp/h to cm/s
            	headerData.setValue(String.valueOf((int) (network.getMessageDetail().getMiniSpeed()*1000/36)));
            } else {
            	headerData.setValue("0");
            }
            deviceData.setGpsSpeed(headerData);

            avlEvent.setDeviceData(deviceData);
            AvlDeviceData deviceDataConverted = new AvlDeviceData();
            deviceDataConverted.setAccumulators(rawAccumulators);
            avlEvent.setDeviceDataConverted(deviceDataConverted);
        }

        avlEvent.setEventCode(network.getMessageDetail().getEventCode());
        return avlEvent;
    }

}
