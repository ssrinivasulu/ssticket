package com.calamp.connect.models.db.converter;

import java.util.ArrayList;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.JbusDtc1708;
import com.calamp.connect.models.db.domain.JbusDtc1708EventEntity;
import com.calamp.connect.models.messaging.JbusDtc1708Event;
import com.calamp.connect.models.messaging.JbusDtc1708Protocol;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusDtc1708EventConverter extends DeviceEventConverter<JbusDtc1708EventEntity, JbusDtc1708Event>
{

    @Override
    public JbusDtc1708EventEntity modelToDomain(JbusDtc1708Event jbusDtc1708Event)
    {
        JbusDtc1708EventEntity jbusDtc1708EventEntity = super.convert(jbusDtc1708Event, JbusDtc1708EventEntity.class);

        return jbusDtc1708EventEntity;
    }

    @Override
    public JbusDtc1708Event domainToModel(JbusDtc1708EventEntity dtc1708EntityEvent)
    {
        JbusDtc1708Event jbusDtc1708Event = super.convert(dtc1708EntityEvent, JbusDtc1708Event.class);

        return jbusDtc1708Event;
    }

    @Override
    protected JbusDtc1708EventEntity customConvert(JbusDtc1708Event model, JbusDtc1708EventEntity entity)
    {
        List<JbusDtc1708Protocol> jbusDtc1708Protocols = model.getJbusDtc1708ProtocolEvents();
        List<JbusDtc1708> jbusDtc1708Entitys = new ArrayList<JbusDtc1708>();
        MapperFacade jbus1708Mapper = mapperFactory.getMapperFacade();
        if (jbusDtc1708Protocols != null)
        {
            for (JbusDtc1708Protocol jbusDtc1708Protocol : jbusDtc1708Protocols)
            {
                JbusDtc1708 jbusDtc1708 = new JbusDtc1708();
                jbus1708Mapper.map(jbusDtc1708Protocol, jbusDtc1708);
                jbusDtc1708Entitys.add(jbusDtc1708);
            }
        }
        entity.setJbusDtc1708(jbusDtc1708Entitys);
        entity.setSourceAddress(model.getSourceAddress());
        return entity;
    }

    @Override
    protected JbusDtc1708Event customConvert(JbusDtc1708EventEntity entity, JbusDtc1708Event model)
    {
        List<JbusDtc1708> jbusDtc1708Entitys = entity.getJbusDtc1708();
        List<JbusDtc1708Protocol> jbusDtc1708Protocols = new ArrayList<JbusDtc1708Protocol>();
        MapperFacade jbus1708Mapper = mapperFactory.getMapperFacade();
        for (JbusDtc1708 jbusDtc1708 : jbusDtc1708Entitys)
        {
            JbusDtc1708Protocol jbusDtc1708Protocol = new JbusDtc1708Protocol();
            jbus1708Mapper.map(jbusDtc1708, jbusDtc1708Protocol);
            jbusDtc1708Protocols.add(jbusDtc1708Protocol);
        }
        model.setJbusDtc1708ProtocolEvents(jbusDtc1708Protocols);
        model.setSourceAddress(entity.getSourceAddress());
        return model;
    }

    @Override
    public JbusDtc1708Event domainToModel(JbusDtc1708EventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusDtc1708Event> getModelType()
    {
        return JbusDtc1708Event.class;
    }

    @Override
    public Class<JbusDtc1708EventEntity> getDomainType()
    {
        return JbusDtc1708EventEntity.class;
    }
}
