package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@XmlRootElement(name = "avlHardAccelPoint")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("avlHardAccelPoint")
@JsonTypeName("avlHardAccelPoint")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)
@XmlType(propOrder =
{
 "digitalInStatus", "lateralAcceleration", "longitudinalAcceleration", "speed"
})
@JsonPropertyOrder(
{
 "digitalInStatus", "lateralAcceleration", "longitudinalAcceleration", "speed"
})

public class AvlHardAccelPoint {
	private Integer speed;
	private Integer digitalInStatus;
	private Float lateralAcceleration;
	private Float longitudinalAcceleration;
	
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	public Integer getDigitalInStatus() {
		return digitalInStatus;
	}
	public void setDigitalInStatus(Integer digitalInStatus) {
		this.digitalInStatus = digitalInStatus;
	}
	public Float getLateralAcceleration() {
		return lateralAcceleration;
	}
	public void setLateralAcceleration(Float lateralAcceleration) {
		this.lateralAcceleration = lateralAcceleration;
	}
	public Float getLongitudinalAcceleration() {
		return longitudinalAcceleration;
	}
	public void setLongitudinalAcceleration(Float longitudinalAcceleration) {
		this.longitudinalAcceleration = longitudinalAcceleration;
	}
}
