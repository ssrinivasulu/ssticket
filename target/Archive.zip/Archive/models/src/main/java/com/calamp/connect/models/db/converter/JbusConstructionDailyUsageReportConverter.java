package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusConstructionDailyUsageReportEntity;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEvent;

public class JbusConstructionDailyUsageReportConverter extends
        DeviceEventConverter<JbusConstructionDailyUsageReportEntity, JbusConstructionDailyUsageReportEvent>
{

    @Override
    public JbusConstructionDailyUsageReportEvent domainToModel(JbusConstructionDailyUsageReportEntity constructionDailyUsageReportEntity)
    {
        JbusConstructionDailyUsageReportEvent constructionDailyUsageReportEvent = super.convert(constructionDailyUsageReportEntity,
                JbusConstructionDailyUsageReportEvent.class);

        return customConvert(constructionDailyUsageReportEntity, constructionDailyUsageReportEvent);
    }

    @Override
    public JbusConstructionDailyUsageReportEntity modelToDomain(JbusConstructionDailyUsageReportEvent constructionDailyUsageReportEvent)
    {
        JbusConstructionDailyUsageReportEntity constructionDailyUsageReportEntity = super.convert(constructionDailyUsageReportEvent,
                JbusConstructionDailyUsageReportEntity.class);

        return customConvert(constructionDailyUsageReportEvent, constructionDailyUsageReportEntity);
    }

    @Override
    protected JbusConstructionDailyUsageReportEvent customConvert(JbusConstructionDailyUsageReportEntity entity,
            JbusConstructionDailyUsageReportEvent model)
    {
        if (entity.getDeviceData() != null)
        {
            JbusConstructionDailyUsageReportData constructionDailyUsageReportData = (JbusConstructionDailyUsageReportData) entity.getDeviceData();
            if (constructionDailyUsageReportData.getEngineTorque0To10PercentUsage() != null)
                model.setEngineTorque0To10PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData.getEngineTorque0To10PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque10To20PercentUsage() != null)
                model.setEngineTorque10To20PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque10To20PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque20To30PercentUsage() != null)
                model.setEngineTorque20To30PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque20To30PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque30To40PercentUsage() != null)
                model.setEngineTorque30To40PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque30To40PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque40To50PercentUsage() != null)
                model.setEngineTorque40To50PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque40To50PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque50To60PercentUsage() != null)
                model.setEngineTorque50To60PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque50To60PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque60To70PercentUsage() != null)
                model.setEngineTorque60To70PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque60To70PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque70To80PercentUsage() != null)
                model.setEngineTorque70To80PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque70To80PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorque80To90PercentUsage() != null)
                model.setEngineTorque80To90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorque80To90PercentUsage()));
            if (constructionDailyUsageReportData.getEngineTorqueOver90PercentUsage() != null)
                model.setEngineTorqueOver90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getEngineTorqueOver90PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque0To10PercentUsage() != null)
                model.setPositionTorque0To10PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque0To10PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque10To20PercentUsage() != null)
                model.setPositionTorque10To20PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque10To20PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque20To30PercentUsage() != null)
                model.setPositionTorque20To30PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque20To30PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque30To40PercentUsage() != null)
                model.setPositionTorque30To40PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque30To40PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque40To50PercentUsage() != null)
                model.setPositionTorque40To50PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque40To50PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque50To60PercentUsage() != null)
                model.setPositionTorque50To60PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque50To60PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque60To70PercentUsage() != null)
                model.setPositionTorque60To70PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque60To70PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque70To80PercentUsage() != null)
                model.setPositionTorque70To80PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque70To80PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorque80To90PercentUsage() != null)
                model.setPositionTorque80To90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorque80To90PercentUsage()));
            if (constructionDailyUsageReportData.getPositionTorqueOver90PercentUsage() != null)
                model.setPositionTorqueOver90PercentUsage(convertHeaderDataToDouble(constructionDailyUsageReportData
                        .getPositionTorqueOver90PercentUsage()));

        }
        model.setDeviceDataConverted(null);
        return model;
    }

    @Override
    protected JbusConstructionDailyUsageReportEntity customConvert(JbusConstructionDailyUsageReportEvent model,
            JbusConstructionDailyUsageReportEntity entity)
    {
        return entity;
    }

    @Override
    public JbusConstructionDailyUsageReportEvent domainToModel(JbusConstructionDailyUsageReportEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusConstructionDailyUsageReportEntity> getDomainType()
    {
        return JbusConstructionDailyUsageReportEntity.class;
    }

    @Override
    public Class<JbusConstructionDailyUsageReportEvent> getModelType()
    {
        return JbusConstructionDailyUsageReportEvent.class;
    }

}
