package com.calamp.connect.models.messaging;

public class AckNakEvent extends DeviceEvent {
	private int ackedMsgType;
	private boolean ackStatus;

	public int getAckedMsgType() {
		return ackedMsgType;
	}

	public void setAckedMsgType(int ackedMsgType) {
		this.ackedMsgType = ackedMsgType;
	}

	public boolean isAckStatus() {
		return ackStatus;
	}

	public void setAckStatus(boolean ackStatus) {
		this.ackStatus = ackStatus;
	}

	@Override
	public String toString() {
		return "AckNakEvent [ackedMsgType=" + ackedMsgType + ", ackStatus=" + ackStatus + "]";
	}

}
