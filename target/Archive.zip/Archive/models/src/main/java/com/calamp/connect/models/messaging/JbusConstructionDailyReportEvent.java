package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "jbusConstructionDailyReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusConstructionDailyReportEvent")
@JsonTypeName("jbusConstructionDailyReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "avgActualEngineTorque", "avgAmbientAirTempr",
        "avgAuxiliaryTempr1", "avgDEFConcentration", "avgDEFTempr", "avgEngineCoolantTempr", "avgEngineFuelRate", "avgEngineFuelTempr1",
        "avgEngineOilPressure", "avgEngineOilTempr", "avgEngineSpeed", "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId",
        "deviceIp", "deviceName", "deviceMessageSequenceNumber", "engineTotalFuelUsed", "eventCode", "eventTime", "eventType", "inputs",
        "lmdirectMessageType", "machineState", "maxAmbientAirTempr", "maxAuxiliaryTempr1", "maxDEFConcentration", "maxDEFTempr",
        "maxEngineCoolantTempr", "maxEngineFuelTempr1", "maxEngineOilPressure", "maxEngineOilTempr", "maxEngineSpeed", "messageReceivedTime",
        "messageType", "messageUuid", "minAmbientAirTempr", "minAuxiliaryTempr1", "minDEFConcentration", "minDEFTempr", "minEngineCoolantTempr",
        "minEngineFuelTempr1", "minEngineOilPressure", "minEngineOilTempr", "minEngineSpeed", "pegBehaviorId", "port", "primaryOperator",
        "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusConstructionDailyReportEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName",
        "avgActualEngineTorque", "avgAmbientAirTempr", "avgAuxiliaryTempr1", "avgDEFConcentration", "avgDEFTempr", "avgEngineCoolantTempr",
        "avgEngineFuelRate", "avgEngineFuelTempr1", "avgEngineOilPressure", "avgEngineOilTempr", "avgEngineSpeed", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "engineTotalFuelUsed", "eventCode",
        "eventTime", "eventType", "inputs", "lmdirectMessageType", "machineState", "maxAmbientAirTempr", "maxAuxiliaryTempr1", "maxDEFConcentration",
        "maxDEFTempr", "maxEngineCoolantTempr", "maxEngineFuelTempr1", "maxEngineOilPressure", "maxEngineOilTempr", "maxEngineSpeed",
        "messageReceivedTime", "messageType", "messageUuid", "minAmbientAirTempr", "minAuxiliaryTempr1", "minDEFConcentration", "minDEFTempr",
        "minEngineCoolantTempr", "minEngineFuelTempr1", "minEngineOilPressure", "minEngineOilTempr", "minEngineSpeed", "pegBehaviorId", "port",
        "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
public class JbusConstructionDailyReportEvent extends DeviceEvent
{
    private MachineState                    machineState;
    private Double                          engineTotalFuelUsed;
    private Double                          avgEngineFuelRate;
    private Integer                         avgActualEngineTorque;
    private Double                          minEngineSpeed;
    private Double                          maxEngineSpeed;
    private Double                          avgEngineSpeed;
    private Double                          minDEFConcentration;
    private Double                          maxDEFConcentration;
    private Double                          avgDEFConcentration;
    private Integer                         minDEFTempr;
    private Integer                         maxDEFTempr;
    private Integer                         avgDEFTempr;
    private Integer                         minEngineOilPressure;
    private Integer                         maxEngineOilPressure;
    private Integer                         avgEngineOilPressure;
    private Double                          minEngineOilTempr;
    private Double                          maxEngineOilTempr;
    private Double                          avgEngineOilTempr;
    private Integer                         minEngineCoolantTempr;
    private Integer                         maxEngineCoolantTempr;
    private Integer                         avgEngineCoolantTempr;
    private Integer                         minEngineFuelTempr1;
    private Integer                         maxEngineFuelTempr1;
    private Integer                         avgEngineFuelTempr1;
    private Double                          minAmbientAirTempr;
    private Double                          maxAmbientAirTempr;
    private Double                          avgAmbientAirTempr;
    private Integer                         minAuxiliaryTempr1;
    private Integer                         maxAuxiliaryTempr1;
    private Integer                         avgAuxiliaryTempr1;
    private JbusConstructionDailyReportData deviceData;
    private JbusConstructionDailyReportData deviceDataConverted;

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTotalFuelUsed()
    {
        return engineTotalFuelUsed;
    }

    public void setEngineTotalFuelUsed(Double engineTotalFuelUsed)
    {
        this.engineTotalFuelUsed = engineTotalFuelUsed;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getAvgEngineFuelRate()
    {
        return avgEngineFuelRate;
    }

    public void setAvgEngineFuelRate(Double avgEngineFuelRate)
    {
        this.avgEngineFuelRate = avgEngineFuelRate;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getAvgActualEngineTorque()
    {
        return avgActualEngineTorque;
    }

    public void setAvgActualEngineTorque(Integer avgActualEngineTorque)
    {
        this.avgActualEngineTorque = avgActualEngineTorque;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMinEngineSpeed()
    {
        return minEngineSpeed;
    }

    public void setMinEngineSpeed(Double minEngineSpeed)
    {
        this.minEngineSpeed = minEngineSpeed;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMaxEngineSpeed()
    {
        return maxEngineSpeed;
    }

    public void setMaxEngineSpeed(Double maxEngineSpeed)
    {
        this.maxEngineSpeed = maxEngineSpeed;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getAvgEngineSpeed()
    {
        return avgEngineSpeed;
    }

    public void setAvgEngineSpeed(Double avgEngineSpeed)
    {
        this.avgEngineSpeed = avgEngineSpeed;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMinDEFConcentration()
    {
        return minDEFConcentration;
    }

    public void setMinDEFConcentration(Double minDEFConcentration)
    {
        this.minDEFConcentration = minDEFConcentration;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMaxDEFConcentration()
    {
        return maxDEFConcentration;
    }

    public void setMaxDEFConcentration(Double maxDEFConcentration)
    {
        this.maxDEFConcentration = maxDEFConcentration;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getAvgDEFConcentration()
    {
        return avgDEFConcentration;
    }

    public void setAvgDEFConcentration(Double avgDEFConcentration)
    {
        this.avgDEFConcentration = avgDEFConcentration;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMinDEFTempr()
    {
        return minDEFTempr;
    }

    public void setMinDEFTempr(Integer minDEFTempr)
    {
        this.minDEFTempr = minDEFTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMaxDEFTempr()
    {
        return maxDEFTempr;
    }

    public void setMaxDEFTempr(Integer maxDEFTempr)
    {
        this.maxDEFTempr = maxDEFTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getAvgDEFTempr()
    {
        return avgDEFTempr;
    }

    public void setAvgDEFTempr(Integer avgDEFTempr)
    {
        this.avgDEFTempr = avgDEFTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMinEngineOilPressure()
    {
        return minEngineOilPressure;
    }

    public void setMinEngineOilPressure(Integer minEngineOilPressure)
    {
        this.minEngineOilPressure = minEngineOilPressure;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMaxEngineOilPressure()
    {
        return maxEngineOilPressure;
    }

    public void setMaxEngineOilPressure(Integer maxEngineOilPressure)
    {
        this.maxEngineOilPressure = maxEngineOilPressure;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getAvgEngineOilPressure()
    {
        return avgEngineOilPressure;
    }

    public void setAvgEngineOilPressure(Integer avgEngineOilPressure)
    {
        this.avgEngineOilPressure = avgEngineOilPressure;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMinEngineOilTempr()
    {
        return minEngineOilTempr;
    }

    public void setMinEngineOilTempr(Double minEngineOilTempr)
    {
        this.minEngineOilTempr = minEngineOilTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMaxEngineOilTempr()
    {
        return maxEngineOilTempr;
    }

    public void setMaxEngineOilTempr(Double maxEngineOilTempr)
    {
        this.maxEngineOilTempr = maxEngineOilTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getAvgEngineOilTempr()
    {
        return avgEngineOilTempr;
    }

    public void setAvgEngineOilTempr(Double avgEngineOilTempr)
    {
        this.avgEngineOilTempr = avgEngineOilTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMinEngineCoolantTempr()
    {
        return minEngineCoolantTempr;
    }

    public void setMinEngineCoolantTempr(Integer minEngineCoolantTempr)
    {
        this.minEngineCoolantTempr = minEngineCoolantTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMaxEngineCoolantTempr()
    {
        return maxEngineCoolantTempr;
    }

    public void setMaxEngineCoolantTempr(Integer maxEngineCoolantTempr)
    {
        this.maxEngineCoolantTempr = maxEngineCoolantTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getAvgEngineCoolantTempr()
    {
        return avgEngineCoolantTempr;
    }

    public void setAvgEngineCoolantTempr(Integer avgEngineCoolantTempr)
    {
        this.avgEngineCoolantTempr = avgEngineCoolantTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMinEngineFuelTempr1()
    {
        return minEngineFuelTempr1;
    }

    public void setMinEngineFuelTempr1(Integer minEngineFuelTempr1)
    {
        this.minEngineFuelTempr1 = minEngineFuelTempr1;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMaxEngineFuelTempr1()
    {
        return maxEngineFuelTempr1;
    }

    public void setMaxEngineFuelTempr1(Integer maxEngineFuelTempr1)
    {
        this.maxEngineFuelTempr1 = maxEngineFuelTempr1;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getAvgEngineFuelTempr1()
    {
        return avgEngineFuelTempr1;
    }

    public void setAvgEngineFuelTempr1(Integer avgEngineFuelTempr1)
    {
        this.avgEngineFuelTempr1 = avgEngineFuelTempr1;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMinAmbientAirTempr()
    {
        return minAmbientAirTempr;
    }

    public void setMinAmbientAirTempr(Double minAmbientAirTempr)
    {
        this.minAmbientAirTempr = minAmbientAirTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMaxAmbientAirTempr()
    {
        return maxAmbientAirTempr;
    }

    public void setMaxAmbientAirTempr(Double maxAmbientAirTempr)
    {
        this.maxAmbientAirTempr = maxAmbientAirTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getAvgAmbientAirTempr()
    {
        return avgAmbientAirTempr;
    }

    public void setAvgAmbientAirTempr(Double avgAmbientAirTempr)
    {
        this.avgAmbientAirTempr = avgAmbientAirTempr;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMinAuxiliaryTempr1()
    {
        return minAuxiliaryTempr1;
    }

    public void setMinAuxiliaryTempr1(Integer minAuxiliaryTempr1)
    {
        this.minAuxiliaryTempr1 = minAuxiliaryTempr1;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMaxAuxiliaryTempr1()
    {
        return maxAuxiliaryTempr1;
    }

    public void setMaxAuxiliaryTempr1(Integer maxAuxiliaryTempr1)
    {
        this.maxAuxiliaryTempr1 = maxAuxiliaryTempr1;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getAvgAuxiliaryTempr1()
    {
        return avgAuxiliaryTempr1;
    }

    public void setAvgAuxiliaryTempr1(Integer avgAuxiliaryTempr1)
    {
        this.avgAuxiliaryTempr1 = avgAuxiliaryTempr1;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusConstructionDailyReportData getDeviceData()
    {
        return (JbusConstructionDailyReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusConstructionDailyReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusConstructionDailyReportData getDeviceDataConverted()
    {
        return (JbusConstructionDailyReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusConstructionDailyReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
