package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "jbusConstructionHourlyReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusConstructionHourlyReportEvent")
@JsonTypeName("jbusConstructionHourlyReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "defOrNoxTankLevel", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode", "eventTime",
        "eventType", "fuelTankLevel1", "inputs", "lmdirectMessageType", "machineState", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix",
        "totalEngineHours", "vin", "vinResponse" })
@XmlType(name = "jbusConstructionHourlyReportEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName",
        "defOrNoxTankLevel", "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName",
        "deviceMessageSequenceNumber", "eventCode", "eventTime", "eventType", "fuelTankLevel1", "inputs", "lmdirectMessageType", "machineState",
        "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route",
        "routeId", "rawDeviceHexMessage", "timeOfFix", "totalEngineHours", "vin", "vinResponse" })
public class JbusConstructionHourlyReportEvent extends DeviceEvent
{
    private MachineState                     machineState;
    private Double                           totalEngineHours;
    private Double                           defOrNoxTankLevel;
    private Double                           fuelTankLevel1;
    private JbusConstructionHourlyReportData deviceData;
    private JbusConstructionHourlyReportData deviceDataConverted;

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getTotalEngineHours()
    {
        return totalEngineHours;
    }

    public void setTotalEngineHours(Double totalEngineHours)
    {
        this.totalEngineHours = totalEngineHours;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getDefOrNoxTankLevel()
    {
        return defOrNoxTankLevel;
    }

    public void setDefOrNoxTankLevel(Double defOrNoxTankLevel)
    {
        this.defOrNoxTankLevel = defOrNoxTankLevel;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getFuelTankLevel1()
    {
        return fuelTankLevel1;
    }

    public void setFuelTankLevel1(Double fuelTankLevel1)
    {
        this.fuelTankLevel1 = fuelTankLevel1;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusConstructionHourlyReportData getDeviceData()
    {
        return (JbusConstructionHourlyReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusConstructionHourlyReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusConstructionHourlyReportData getDeviceDataConverted()
    {
        return (JbusConstructionHourlyReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusConstructionHourlyReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
