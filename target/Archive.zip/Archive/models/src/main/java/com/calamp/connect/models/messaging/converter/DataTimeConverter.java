package com.calamp.connect.models.messaging.converter;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class DataTimeConverter extends XmlAdapter<String, Date>
{
    private static final String XML_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    
    public String marshal(Date v) throws Exception
    {
        return new SimpleDateFormat(XML_DATETIME_FORMAT).format(v);
    }

    public Date unmarshal(String v) throws Exception
    {
        return new SimpleDateFormat(XML_DATETIME_FORMAT).parse(v);
    }
}
