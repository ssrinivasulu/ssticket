package com.calamp.connect.models.db.converter;

import java.util.ArrayList;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.DtcEventEntity;
import com.calamp.connect.models.messaging.DtcCodes;
import com.calamp.connect.models.messaging.DtcEvent;
import com.calamp.connect.models.messaging.GPS;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class DtcEventConverter extends DeviceEventConverter<DtcEventEntity, DtcEvent>
{
    @Override
    public DtcEventEntity modelToDomain(DtcEvent dtcEvent)
    {
        DtcEventEntity dtcEventEntity = super.convert(dtcEvent, DtcEventEntity.class);

        return dtcEventEntity;
    }

    @Override
    public DtcEvent domainToModel(DtcEventEntity dtcEntityEvent)
    {
        DtcEvent dtcEvent = super.convert(dtcEntityEvent, DtcEvent.class);

        return customConvert(dtcEntityEvent, dtcEvent);
    }

    @Override
    protected DtcEventEntity customConvert(DtcEvent model, DtcEventEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        // Need to remove after ExternalDeviceId is changed in DB
        if (entity.getExternalDeviceId() != null)
        {
            model.setDeviceEsn(entity.getExternalDeviceId());
        }
        if (model.getGps() != null)
        {
            mapper.map(model.getGps(), entity);

            if (model.getGps().getHeading() != null)
            {
                entity.setHeading(model.getGps().getHeading());
            }
        }

        return entity;
    }

    @Override
    protected DtcEvent customConvert(DtcEventEntity entity, DtcEvent model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        // Need to remove after ExternalDeviceId is changed in DB
        if (entity.getExternalDeviceId() != null)
        {
            model.setDeviceEsn(entity.getExternalDeviceId());
        }
        GPS gps = mapper.map(entity, GPS.class);

        if (entity.getHeading() != null)
        {
            gps.setHeading(entity.getHeading());
        }

        if (entity.getDtcCode() != null)
        {
            DtcCodes dtcCode = new DtcCodes();
            dtcCode.setDtcCode(entity.getDtcCode());
            dtcCode.setDescription(entity.getDescription());

            List dtcCodeList = new ArrayList();
            dtcCodeList.add(dtcCode);
            model.setDtcCodes(dtcCodeList);
            model.setDtcCode(null);
            model.setDescription(null);
        }

        model.setGps(gps);
        model.setDeviceDataConverted(null);

        return model;
    }

    @Override
    public DtcEvent domainToModel(DtcEventEntity arg0, boolean arg1) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Class<DtcEventEntity> getDomainType()
    {
        return DtcEventEntity.class;
    }

    @Override
    public Class<DtcEvent> getModelType()
    {
        return DtcEvent.class;
    }

}
