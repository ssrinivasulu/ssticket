package com.calamp.connect.models.messaging.converter;

import ma.glasnost.orika.MapperFacade;

import java.util.Date;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusEventProtocol;
import com.calamp.connect.models.network.Network.NetworkMessage;
@Component
public class NetworkToJbusEventConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusEventConverter.class);
  
    public JbusEventProtocol convert(NetworkMessage network) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusEventProtocol jbusEvent = null;
		if(network.getRawJbusMessage().getJbusData1708()!=null) {
			jbusEvent = mapper.map(network.getRawJbusMessage().getJbusData1708(), JbusEventProtocol.class);
			jbusEvent.setJbusProtocol("1708");
		}	
		else if(network.getRawJbusMessage().getJbusData1939()!=null) {
			jbusEvent = mapper.map(network.getRawJbusMessage().getJbusData1939(), JbusEventProtocol.class);
			jbusEvent.setJbusProtocol("1939");
		}
		jbusEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusEvent;
	}
}
