package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelCalibrationType;
import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelEventType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "avlHardAccelEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("avlHardAccelEvent")
@JsonTypeName("avlHardAccelEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "accelerationType", "calibrationType", "accelerationDuration", "lateralAcceleration", "longitudinalAcceleration",
        "startingSpeed" })
@JsonPropertyOrder({ "accelerationPoints", "accelerationType", "accelerationDuration", "lateralAcceleration", "longitudinalAcceleration",
        "startingSpeed" })
public class AvlHardAccelEvent
{
    private AvlHardAccelEventType       accelerationType;
    private Float                       lateralAcceleration;
    private Float                       longitudinalAcceleration;
    private Float                       accelerationDuration;
    private Float                       startingSpeed;
    private AvlHardAccelCalibrationType calibrationType;

    public AvlHardAccelEventType getAccelerationType()
    {
        return accelerationType;
    }

    public void setAccelerationType(AvlHardAccelEventType accelerationType)
    {
        this.accelerationType = accelerationType;
    }

    public Float getLateralAcceleration()
    {
        return lateralAcceleration;
    }

    public void setLateralAcceleration(Float lateralAcceleration)
    {
        this.lateralAcceleration = lateralAcceleration;
    }

    public Float getLongitudinalAcceleration()
    {
        return longitudinalAcceleration;
    }

    public void setLongitudinalAcceleration(Float longitudinalAcceleration)
    {
        this.longitudinalAcceleration = longitudinalAcceleration;
    }

    public Float getAccelerationDuration()
    {
        return accelerationDuration;
    }

    public void setAccelerationDuration(Float accelerationDuration)
    {
        this.accelerationDuration = accelerationDuration;
    }

    public Float getStartingSpeed()
    {
        return startingSpeed;
    }

    public void setStartingSpeed(Float startingSpeed)
    {
        this.startingSpeed = startingSpeed;
    }

    public AvlHardAccelCalibrationType getCalibrationType()
    {
        return calibrationType;
    }

    public void setCalibrationType(AvlHardAccelCalibrationType calibrationType)
    {
        this.calibrationType = calibrationType;
    }

}
