package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "commState")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("commState")
@JsonTypeName("commState")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "available", "connected", "dataService", "networkService", "roaming", "threeGNetwork", "voiceCallActive" })
@JsonPropertyOrder({ "available", "connected", "dataService", "networkService", "roaming", "threeGNetwork", "voiceCallActive" })
public class CommState
{
    private Boolean available;
    private Boolean connected;
    private Boolean dataService;
    private Boolean networkService;
    private Boolean roaming;
    private Boolean threeGNetwork;
    private Boolean voiceCallActive;

    public Boolean getAvailable()
    {
        return available;
    }

    public Boolean getConnected()
    {
        return connected;
    }

    public Boolean getDataService()
    {
        return dataService;
    }

    public Boolean getNetworkService()
    {
        return networkService;
    }

    public Boolean getRoaming()
    {
        return roaming;
    }

    public Boolean getThreeGNetwork()
    {
        return threeGNetwork;
    }

    public Boolean getVoiceCallActive()
    {
        return voiceCallActive;
    }

    public void setAvailable(Boolean available)
    {
        this.available = available;
    }

    public void setConnected(Boolean connected)
    {
        this.connected = connected;
    }

    public void setDataService(Boolean dataService)
    {
        this.dataService = dataService;
    }

    public void setNetworkService(Boolean networkService)
    {
        this.networkService = networkService;
    }

    public void setRoaming(Boolean roaming)
    {
        this.roaming = roaming;
    }

    public void setThreeGNetwork(Boolean threeGNetwork)
    {
        this.threeGNetwork = threeGNetwork;
    }

    public void setVoiceCallActive(Boolean voiceCallActive)
    {
        this.voiceCallActive = voiceCallActive;
    }
}
