package com.calamp.connect.models.network;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.network.Event.CommGpsStatus;
import com.calamp.connect.models.network.Event.FixStatus;
import com.calamp.connect.models.network.Event.FixStatusAndSatellites;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReport;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReport;
import com.calamp.connect.models.network.Jbus.DailyReport;
import com.calamp.connect.models.network.Jbus.HeaderData;
import com.calamp.connect.models.network.Jbus.HourlyReport;
import com.calamp.connect.models.network.Jbus.JbusData1708;
import com.calamp.connect.models.network.Jbus.JbusData1939;
import com.calamp.connect.models.network.Jbus.JbusDiscoveryReport;
import com.calamp.connect.models.network.Jbus.JbusDtcData;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;
import com.calamp.connect.models.network.Jbus.JbusFaultReport;
import com.calamp.connect.models.network.Jbus.JbusHydraulicReport;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ssrinivasulu
 *
 */
@JsonInclude(Include.NON_NULL)
public final class Network
{

    @JsonInclude(Include.NON_NULL)
    @AutoProperty()
    public static final class NetworkMessage
    {
        private NetworkMessageType       type;
        private AempData				 aempData;
        private MessageDetail            messageDetail;
        private PndMessage               pndMessage;
        private AckMessage               ackMessage;
        private ProvisionMessage         provisionMessage;
        private RawDtcMessage            rawDtcMessage;
        private DigitalOutputMessage     digitalOutputMessage;
        private RawJbusMessage           rawJbusMessage;
        private IdReportMessage          idReportMessage;
        private RawDeviceCommandResponse rawDeviceCommandResponse;
        private OTADownloadMessage       otaDownloadMessage;
        private MotionLogsMessage        motionLogsMessage;
        private long                     deviceId;
        private String                   externalDeviceId;
        private int                      sequenceId;
        private String                   deviceIp;
        private int                      port;
        private long                     nagReceivedTime;
        private List<java.lang.Long>     rawAccumulators;
        private String                   rawDeviceHexMessage;
        private String                   messageUuid;
        private boolean                  ackStatus;
        private int						  lmdirectMessageType;
        private OptionsExtension		 optionsExtension;
        
        
        public OptionsExtension getOptionsExtension() {
			return optionsExtension;
		}

		public void setOptionsExtension(OptionsExtension optionsExtension) {
			this.optionsExtension = optionsExtension;
		}

		public NetworkMessageType getType()
        {
            return type;
        }

        public void setType(NetworkMessageType type)
        {
            this.type = type;
        }
        
        


		public int getLmdirectMessageType() {
			return lmdirectMessageType;
		}

		public void setLmdirectMessageType(int lmdirectMessageType) {
			this.lmdirectMessageType = lmdirectMessageType;
		}

		public MessageDetail getMessageDetail()
        {
            return messageDetail;
        }

        public void setMessageDetail(MessageDetail messageDetail)
        {
            this.messageDetail = messageDetail;
        }

        public PndMessage getPndMessage()
        {
            return pndMessage;
        }

        public void setPndMessage(PndMessage pndMessage)
        {
            this.pndMessage = pndMessage;
        }



        public AckMessage getAckMessage()
        {
            return ackMessage;
        }

        public void setAckMessage(AckMessage ackMessage)
        {
            this.ackMessage = ackMessage;
        }

        public ProvisionMessage getProvisionMessage()
        {
            return provisionMessage;
        }

        public void setProvisionMessage(ProvisionMessage provisionMessage)
        {
            this.provisionMessage = provisionMessage;
        }

        public RawDtcMessage getRawDtcMessage()
        {
            return rawDtcMessage;
        }

        public void setRawDtcMessage(RawDtcMessage rawDtcMessage)
        {
            this.rawDtcMessage = rawDtcMessage;
        }

        public DigitalOutputMessage getDigitalOutputMessage()
        {
            return digitalOutputMessage;
        }

        public void setDigitalOutputMessage(DigitalOutputMessage digitalOutputMessage)
        {
            this.digitalOutputMessage = digitalOutputMessage;
        }

        public RawJbusMessage getRawJbusMessage()
        {
            return rawJbusMessage;
        }

        public void setRawJbusMessage(RawJbusMessage rawJbusMessage)
        {
            this.rawJbusMessage = rawJbusMessage;
        }

        public IdReportMessage getIdReportMessage()
        {
            return idReportMessage;
        }

        public void setIdReportMessage(IdReportMessage idReportMessage)
        {
            this.idReportMessage = idReportMessage;
        }

        public long getDeviceId()
        {
            return deviceId;
        }

        public void setDeviceId(long deviceId)
        {
            this.deviceId = deviceId;
        }

        public String getExternalDeviceId()
        {
            return externalDeviceId;
        }

        public void setExternalDeviceId(String externalDeviceId)
        {
            this.externalDeviceId = externalDeviceId;
        }

        public int getSequenceId()
        {
            return sequenceId;
        }

        public void setSequenceId(int sequenceId)
        {
            this.sequenceId = sequenceId;
        }

        public String getDeviceIp()
        {
            return deviceIp;
        }

        public void setDeviceIp(String deviceIp)
        {
            this.deviceIp = deviceIp;
        }

        public int getPort()
        {
            return port;
        }

        public void setPort(int port)
        {
            this.port = port;
        }

        public long getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(long nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public List<java.lang.Long> getRawAccumulators()
        {
            return rawAccumulators;
        }

        public void setRawAccumulators(List<java.lang.Long> rawAccumulators)
        {
            this.rawAccumulators = rawAccumulators;
        }

        public String getMessageUuid()
        {
            return messageUuid;
        }

        public void setMessageUuid(String messageUuid)
        {
            this.messageUuid = messageUuid;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public RawDeviceCommandResponse getRawDeviceCommandResponse()
        {
            return rawDeviceCommandResponse;
        }

        public void setRawDeviceCommandResponse(RawDeviceCommandResponse rawDeviceCommandResponse)
        {
            this.rawDeviceCommandResponse = rawDeviceCommandResponse;
        }

        public OTADownloadMessage getOtaDownloadMessage() {
			return otaDownloadMessage;
		}

		public void setOtaDownloadMessage(OTADownloadMessage otaDownloadMessage) {
			this.otaDownloadMessage = otaDownloadMessage;
		}

        public MotionLogsMessage getMotionLogsMessage()
        {
            return motionLogsMessage;
        }

        public void setMotionLogsMessage(MotionLogsMessage motionLogsMessage)
        {
            this.motionLogsMessage = motionLogsMessage;
        }

        public boolean isAckStatus()
        {
            return ackStatus;
        }

        public void setAckStatus(boolean ackStatus)
        {
            this.ackStatus = ackStatus;
        }

        public enum NetworkMessageType
        {
            PND_MESSAGE, EVENT_MESSAGE, UNKNOWN_MESSAGE, ACK_MESSAGE, PROVISION_MESSAGE, DTC_MESSAGE, DIGITALOUTPUT_MESSAGE, MOBILE_MESSAGE, JBUS_MESSAGE, ID_REPORT_MESSAGE, CONFIGURATION_PARAMETER, LOCATE_REPORT_MESSAGE, EXTENDED_ID_REPORT_MESSAGE, OTA_DOWNLOAD_MESSAGE, AEMP_MESSAGE, APP_MESSAGE, MOTION_LOGS_MESSAGE, SELF_DESCRIBING_JPOD, DTC_REPORT;
            public static NetworkMessageType getNetworkMessageType(int value)
            {
                for (NetworkMessageType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown NetworkMessageType " + value);
            }

		
        }

        @Override
        public String toString()
        {
            return Pojomatic.toString(this);
        }

		public AempData getAempData() {
			return aempData;
		}

		public void setAempData(AempData aempData) {
			this.aempData = aempData;
		}
    }

    @JsonInclude(Include.NON_NULL)
    public static final class OptionsExtension
    {
    	private String					vin;

		public String getVin() {
			return vin;
		}

		public void setVin(String vIN) {
			vin = vIN;
		}
    	
    }
    
    @JsonInclude(Include.NON_NULL)
    public static final class AempData
    {
        private long                     accountId;
        private EquipmentHeader          equipmentHeader;
        private AempLocation             location; //Location class already exists in IdReport so name is different
        private CumulativeOperatingHours cumulativeOperatingHours;
        private Distance                 distance;
        private FuelUsed                 fuelUsed;
        private FuelUsedLast24           fuelUsedLast24;

        public long getAccountId()
        {
            return accountId;
        }

        public void setAccountId(long accountId)
        {
            this.accountId = accountId;
        }

        public EquipmentHeader getEquipmentHeader()
        {
            return equipmentHeader;
        }

        public void setEquipmentHeader(EquipmentHeader equipmentHeader)
        {
            this.equipmentHeader = equipmentHeader;
        }

        public AempLocation getLocation()
        {
            return location;
        }

        public void setLocation(AempLocation location)
        {
            this.location = location;
        }

        public CumulativeOperatingHours getCumulativeOperatingHours()
        {
            return cumulativeOperatingHours;
        }

        public void setCumulativeOperatingHours(CumulativeOperatingHours cumulativeOperatingHours)
        {
            this.cumulativeOperatingHours = cumulativeOperatingHours;
        }

        public Distance getDistance()
        {
            return distance;
        }

        public void setDistance(Distance distance)
        {
            this.distance = distance;
        }

        public FuelUsed getFuelUsed()
        {
            return fuelUsed;
        }

        public void setFuelUsed(FuelUsed fuelUsed)
        {
            this.fuelUsed = fuelUsed;
        }

        public FuelUsedLast24 getFuelUsedLast24()
        {
            return fuelUsedLast24;
        }

        public void setFuelUsedLast24(FuelUsedLast24 fuelUsedLast24)
        {
            this.fuelUsedLast24 = fuelUsedLast24;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class EquipmentHeader
    {
        private String model;
        private String make;
        private String serialNumber;
        private String equipmentID;

        public String getModel()
        {
            return model;
        }

        public void setModel(String model)
        {
            this.model = model;
        }

        public String getMake()
        {
            return make;
        }

        public void setMake(String make)
        {
            this.make = make;
        }

        public String getSerialNumber()
        {
            return serialNumber;
        }

        public void setSerialNumber(String serialNumber)
        {
            this.serialNumber = serialNumber;
        }

        public String getEquipmentID()
        {
            return equipmentID;
        }

        public void setEquipmentID(String equipmentID)
        {
            this.equipmentID = equipmentID;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class FuelUsedLast24
    {
        private String fuelUnits;
        private Date   datetime;
        private Double fuelConsumed;

        public String getFuelUnits()
        {
            return fuelUnits;
        }

        public void setFuelUnits(String fuelUnits)
        {
            this.fuelUnits = fuelUnits;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public Double getFuelConsumed()
        {
            return fuelConsumed;
        }

        public void setFuelConsumed(Double fuelConsumed)
        {
            this.fuelConsumed = fuelConsumed;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class FuelUsed
    {
        private String fuelUnits;
        private Date   datetime;
        private Double fuelConsumed;

        public String getFuelUnits()
        {
            return fuelUnits;
        }

        public void setFuelUnits(String fuelUnits)
        {
            this.fuelUnits = fuelUnits;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public Double getFuelConsumed()
        {
            return fuelConsumed;
        }

        public void setFuelConsumed(Double fuelConsumed)
        {
            this.fuelConsumed = fuelConsumed;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class AempLocation
    {
        private Double       longitude;
        private String       altitudeUnits;
        private AempAltitude altitude;
        private Date         datetime;
        private Double       latitude;

        public String getAltitudeUnits()
        {
            return altitudeUnits;
        }

        public void setAltitudeUnits(String altitudeUnits)
        {
            this.altitudeUnits = altitudeUnits;
        }

        public AempAltitude getAltitude()
        {
            return altitude;
        }

        public void setAltitude(AempAltitude altitude)
        {
            this.altitude = altitude;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class CumulativeOperatingHours
    {
        private String hour;
        private Date   datetime;

        public String getHour()
        {
            return hour;
        }

        public void setHour(String hour)
        {
            this.hour = hour;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class Distance
    {
        private Date   datetime;
        private String odometerUnits;
        private Double odometer;

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public String getOdometerUnits()
        {
            return odometerUnits;
        }

        public void setOdometerUnits(String odometerUnits)
        {
            this.odometerUnits = odometerUnits;
        }

        public Double getOdometer()
        {
            return odometer;
        }

        public void setOdometer(Double odometer)
        {
            this.odometer = odometer;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class AempAltitude
    {
        private Double meters;
        private Double feet;
        private Double inches;

        public Double getMeters()
        {
            return meters;
        }

        public void setMeters(Double meters)
        {
            this.meters = meters;
        }

        public Double getFeet()
        {
            return feet;
        }

        public void setFeet(Double feet)
        {
            this.feet = feet;
        }

        public Double getInches()
        {
            return inches;
        }

        public void setInches(Double inches)
        {
            this.inches = inches;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class MessageDetail
    {
        private long                      deviceId;
        private String                    externalDeviceId;
        private String                    enterpriseCode;
        private String                    deviceInstanceGuid;
        private Integer                       eventCode;
        private long                      locationTime;
        private double                    latitude;
        private double                    longitude;
        private Long                      altitude;
        private Long                      speed;
        private Long					  miniSpeed;
        private int                       heading;
        private Integer                       satellites;
        private FixStatus                 gpsFixStatus;
        private boolean                   fixStatus;
        private int                       carrier;
        private double                    hdop;
        private int                       rssi;
        private int                       obdSpeed;
        private double                    odometer;
        private String                    directionCode;
        private long                      deviceMsgSeqNumber;
        private int                       maxSpeed;
        private int                       duration;
        private long                      createDate;
        private String                    deviceTypeCode;
        private double                    fuelConsumption;
        private long                      acquiredMessageId;
        private String                    deviceUrn;
        private String                    travelState;
        private String                    travelStatusCode;
        private int                       timeAdjustmentSeconds;
        private double                    rawObdOdometer;
        private double                    rawOdometer;
        private java.lang.String          travelUnitCode;
        private long                      timeStationary;
        private int                       altitudeCertainty;
        private int                       latLongAccuracy;
        private double                    cellSiteLatitude;
        private double                    cellSiteLongitude;
        private int                       speedCertainty;
        private java.lang.String          informationText;
        private long                      currentIdleDuration;
        private long                      currentEngineOffDuration;
        private long                      currentTravelDuration;
        private double                    currentMilesTraveled;
        private String                    ignitionStatus;
        private long                      ignitionStatusChangeTime;
        private long                      currentStopDuration;
        private String                    additionalMessageValue;
        private int                       batteryVoltage;
        private int                       cellSiteId;
        private int                       locationAge;
        private int                       serviceProviderId;
        private int                       serviceProviderNetworkId;
        private int                       timeOffset;
        private int                       wideAreaServiceId;
        private double                    odometerDelta;
        private int                       checkFirstMessageCount;
        private String                    dtc;
        private int                       satelliteCount;
        private String                    locationStatus;
        private double                    currentFuelUsed;
        private long                      stopDuration;
        private long                      dtshId;
        private String                    correlationGuid;
        private String                    compendiumGuid;
        private java.lang.String          errorCondition;
        private int                       deviceActiveFlg;
        private int                       deviceMessageId;
        private AvlHardAccelEvent         avlHardAccelEvent;
        private ProvisionEvent            provisionEvent;
        private DiagnosticAliveEvent      diagnosticAliveEvent;
        private AssetDeviceInformation    assetDeviceInformation;
        private int                       pegZone;
        private ExtendedAccumulatorValues extendedAccumulatorValues;
        private UnitStatus                unitStatus;
        private VbusIndicators            vbusIndicators;
        private String                    zoneCurrent;
        private String                    zonePrevious;
        private Inputs                    inputs;
        private CommState                 commState;
        private Date 					  timeOfFix;
        private CommGpsStatus			  commGpsStatus;
        private FixStatusAndSatellites	  fixStatusAndSatellites;
        

        public FixStatusAndSatellites getFixStatusAndSatellites() {
			return fixStatusAndSatellites;
		}

		public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites) {
			this.fixStatusAndSatellites = fixStatusAndSatellites;
		}

		public CommGpsStatus getCommGpsStatus() {
			return commGpsStatus;
		}

		public void setCommGpsStatus(CommGpsStatus commGpsStatus) {
			this.commGpsStatus = commGpsStatus;
		}

		public long getDeviceId()
        {
            return deviceId;
        }

        public void setDeviceId(long deviceId)
        {
            this.deviceId = deviceId;
        }    
        
        

        
		public Date getTimeOfFix() {
			return timeOfFix;
		}

		public void setTimeOfFix(Date timeOfFix) {
			this.timeOfFix = timeOfFix;
		}

		public String getExternalDeviceId()
        {
            return externalDeviceId;
        }

        public void setExternalDeviceId(String externalDeviceId)
        {
            this.externalDeviceId = externalDeviceId;
        }

        public String getEnterpriseCode()
        {
            return enterpriseCode;
        }

        public void setEnterpriseCode(String enterpriseCode)
        {
            this.enterpriseCode = enterpriseCode;
        }

        public String getDeviceInstanceGuid()
        {
            return deviceInstanceGuid;
        }

        public void setDeviceInstanceGuid(String deviceInstanceGuid)
        {
            this.deviceInstanceGuid = deviceInstanceGuid;
        }

        
        public Integer getEventCode() {
			return eventCode;
		}

		public void setEventCode(Integer eventCode) {
			this.eventCode = eventCode;
		}

		public Integer getSatellites() {
			return satellites;
		}

		public void setSatellites(Integer satellites) {
			this.satellites = satellites;
		}

		public long getLocationTime()
        {
            return locationTime;
        }

        public void setLocationTime(long locationTime)
        {
            this.locationTime = locationTime;
        }

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        
       
        @JsonProperty
        public Long getAltitude() {
			return altitude;
		}
        
        
		public void setAltitude(Long altitude) {
			this.altitude = altitude;
		}
		
        @JsonIgnore
		public void setAltitude(int altitude) {
			this.altitude = (long)altitude;
		}

		public Long getSpeed() {
			return speed;
		}

		public void setSpeed(Long speed) {
			this.speed = speed;
		}
		
		public void setSpeed(int speed) {
			
			this.speed = (long) speed;
		}

		public Long getMiniSpeed() {
			return miniSpeed;
		}

		public void setMiniSpeed(Long miniSpeed) {
			this.miniSpeed = miniSpeed;
		}
		
		public void setMiniSpeed(int miniSpeed) {
			this.miniSpeed = (long) miniSpeed;
		}

		public int getHeading()
        {
            return heading;
        }

        public void setHeading(int heading)
        {
            this.heading = heading;
        }

      

        public FixStatus getGpsFixStatus()
        {
            return gpsFixStatus;
        }

        public void setGpsFixStatus(FixStatus gpsFixStatus)
        {
            this.gpsFixStatus = gpsFixStatus;
        }

        public boolean isFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public int getCarrier()
        {
            return carrier;
        }

        public void setCarrier(int carrier)
        {
            this.carrier = carrier;
        }

        public double getHdop()
        {
            return hdop;
        }

        public void setHdop(double hdop)
        {
            this.hdop = hdop;
        }

        public int getRssi()
        {
            return rssi;
        }

        public void setRssi(int rssi)
        {
            this.rssi = rssi;
        }

        public int getObdSpeed()
        {
            return obdSpeed;
        }

        public void setObdSpeed(int obdSpeed)
        {
            this.obdSpeed = obdSpeed;
        }

        public double getOdometer()
        {
            return odometer;
        }

        public void setOdometer(double odometer)
        {
            this.odometer = odometer;
        }

        public String getDirectionCode()
        {
            return directionCode;
        }

        public void setDirectionCode(String directionCode)
        {
            this.directionCode = directionCode;
        }

        public long getDeviceMsgSeqNumber()
        {
            return deviceMsgSeqNumber;
        }

        public void setDeviceMsgSeqNumber(long deviceMsgSeqNumber)
        {
            this.deviceMsgSeqNumber = deviceMsgSeqNumber;
        }

        public int getMaxSpeed()
        {
            return maxSpeed;
        }

        public void setMaxSpeed(int maxSpeed)
        {
            this.maxSpeed = maxSpeed;
        }

        public int getDuration()
        {
            return duration;
        }

        public void setDuration(int duration)
        {
            this.duration = duration;
        }

        public long getCreateDate()
        {
            return createDate;
        }

        public void setCreateDate(long createDate)
        {
            this.createDate = createDate;
        }

        public String getDeviceTypeCode()
        {
            return deviceTypeCode;
        }

        public void setDeviceTypeCode(String deviceTypeCode)
        {
            this.deviceTypeCode = deviceTypeCode;
        }

        public double getFuelConsumption()
        {
            return fuelConsumption;
        }

        public void setFuelConsumption(double fuelConsumption)
        {
            this.fuelConsumption = fuelConsumption;
        }

        public long getAcquiredMessageId()
        {
            return acquiredMessageId;
        }

        public void setAcquiredMessageId(long acquiredMessageId)
        {
            this.acquiredMessageId = acquiredMessageId;
        }

        public String getDeviceUrn()
        {
            return deviceUrn;
        }

        public void setDeviceUrn(String deviceUrn)
        {
            this.deviceUrn = deviceUrn;
        }

        public String getTravelState()
        {
            return travelState;
        }

        public void setTravelState(String travelState)
        {
            this.travelState = travelState;
        }

        public String getTravelStatusCode()
        {
            return travelStatusCode;
        }

        public void setTravelStatusCode(String travelStatusCode)
        {
            this.travelStatusCode = travelStatusCode;
        }

        public int getTimeAdjustmentSeconds()
        {
            return timeAdjustmentSeconds;
        }

        public void setTimeAdjustmentSeconds(int timeAdjustmentSeconds)
        {
            this.timeAdjustmentSeconds = timeAdjustmentSeconds;
        }

        public double getRawObdOdometer()
        {
            return rawObdOdometer;
        }

        public void setRawObdOdometer(double rawObdOdometer)
        {
            this.rawObdOdometer = rawObdOdometer;
        }

        public double getRawOdometer()
        {
            return rawOdometer;
        }

        public void setRawOdometer(double rawOdometer)
        {
            this.rawOdometer = rawOdometer;
        }

        public java.lang.String getTravelUnitCode()
        {
            return travelUnitCode;
        }

        public void setTravelUnitCode(java.lang.String travelUnitCode)
        {
            this.travelUnitCode = travelUnitCode;
        }

        public long getTimeStationary()
        {
            return timeStationary;
        }

        public void setTimeStationary(long timeStationary)
        {
            this.timeStationary = timeStationary;
        }

        public int getAltitudeCertainty()
        {
            return altitudeCertainty;
        }

        public void setAltitudeCertainty(int altitudeCertainty)
        {
            this.altitudeCertainty = altitudeCertainty;
        }

        public int getLatLongAccuracy()
        {
            return latLongAccuracy;
        }

        public void setLatLongAccuracy(int latLongAccuracy)
        {
            this.latLongAccuracy = latLongAccuracy;
        }

        public double getCellSiteLatitude()
        {
            return cellSiteLatitude;
        }

        public void setCellSiteLatitude(double cellSiteLatitude)
        {
            this.cellSiteLatitude = cellSiteLatitude;
        }

        public double getCellSiteLongitude()
        {
            return cellSiteLongitude;
        }

        public void setCellSiteLongitude(double cellSiteLongitude)
        {
            this.cellSiteLongitude = cellSiteLongitude;
        }

        public int getSpeedCertainty()
        {
            return speedCertainty;
        }

        public void setSpeedCertainty(int speedCertainty)
        {
            this.speedCertainty = speedCertainty;
        }

        public java.lang.String getInformationText()
        {
            return informationText;
        }

        public void setInformationText(java.lang.String informationText)
        {
            this.informationText = informationText;
        }

        public long getCurrentIdleDuration()
        {
            return currentIdleDuration;
        }

        public void setCurrentIdleDuration(long currentIdleDuration)
        {
            this.currentIdleDuration = currentIdleDuration;
        }

        public long getCurrentEngineOffDuration()
        {
            return currentEngineOffDuration;
        }

        public void setCurrentEngineOffDuration(long currentEngineOffDuration)
        {
            this.currentEngineOffDuration = currentEngineOffDuration;
        }

        public long getCurrentTravelDuration()
        {
            return currentTravelDuration;
        }

        public void setCurrentTravelDuration(long currentTravelDuration)
        {
            this.currentTravelDuration = currentTravelDuration;
        }

        public double getCurrentMilesTraveled()
        {
            return currentMilesTraveled;
        }

        public void setCurrentMilesTraveled(double currentMilesTraveled)
        {
            this.currentMilesTraveled = currentMilesTraveled;
        }

        public String getIgnitionStatus()
        {
            return ignitionStatus;
        }

        public void setIgnitionStatus(String ignitionStatus)
        {
            this.ignitionStatus = ignitionStatus;
        }

        public long getIgnitionStatusChangeTime()
        {
            return ignitionStatusChangeTime;
        }

        public void setIgnitionStatusChangeTime(long ignitionStatusChangeTime)
        {
            this.ignitionStatusChangeTime = ignitionStatusChangeTime;
        }

        public long getCurrentStopDuration()
        {
            return currentStopDuration;
        }

        public void setCurrentStopDuration(long currentStopDuration)
        {
            this.currentStopDuration = currentStopDuration;
        }

        public java.lang.String getAdditionalMessageValue()
        {
            return additionalMessageValue;
        }

        public void setAdditionalMessageValue(java.lang.String additionalMessageValue)
        {
            this.additionalMessageValue = additionalMessageValue;
        }

        public int getBatteryVoltage()
        {
            return batteryVoltage;
        }

        public void setBatteryVoltage(int batteryVoltage)
        {
            this.batteryVoltage = batteryVoltage;
        }

        public int getCellSiteId()
        {
            return cellSiteId;
        }

        public void setCellSiteId(int cellSiteId)
        {
            this.cellSiteId = cellSiteId;
        }

        public int getLocationAge()
        {
            return locationAge;
        }

        public void setLocationAge(int locationAge)
        {
            this.locationAge = locationAge;
        }

        public int getServiceProviderId()
        {
            return serviceProviderId;
        }

        public void setServiceProviderId(int serviceProviderId)
        {
            this.serviceProviderId = serviceProviderId;
        }

        public int getServiceProviderNetworkId()
        {
            return serviceProviderNetworkId;
        }

        public void setServiceProviderNetworkId(int serviceProviderNetworkId)
        {
            this.serviceProviderNetworkId = serviceProviderNetworkId;
        }

        public int getTimeOffset()
        {
            return timeOffset;
        }

        public void setTimeOffset(int timeOffset)
        {
            this.timeOffset = timeOffset;
        }

        public int getWideAreaServiceId()
        {
            return wideAreaServiceId;
        }

        public void setWideAreaServiceId(int wideAreaServiceId)
        {
            this.wideAreaServiceId = wideAreaServiceId;
        }

        public double getOdometerDelta()
        {
            return odometerDelta;
        }

        public void setOdometerDelta(double odometerDelta)
        {
            this.odometerDelta = odometerDelta;
        }

        public int getCheckFirstMessageCount()
        {
            return checkFirstMessageCount;
        }

        public void setCheckFirstMessageCount(int checkFirstMessageCount)
        {
            this.checkFirstMessageCount = checkFirstMessageCount;
        }

        public String getDtc()
        {
            return dtc;
        }

        public void setDtc(String dtc)
        {
            this.dtc = dtc;
        }

        public int getSatelliteCount()
        {
            return satelliteCount;
        }

        public void setSatelliteCount(int satelliteCount)
        {
            this.satelliteCount = satelliteCount;
        }

        public String getLocationStatus()
        {
            return locationStatus;
        }

        public void setLocationStatus(String locationStatus)
        {
            this.locationStatus = locationStatus;
        }

        public double getCurrentFuelUsed()
        {
            return currentFuelUsed;
        }

        public void setCurrentFuelUsed(double currentFuelUsed)
        {
            this.currentFuelUsed = currentFuelUsed;
        }

        public long getStopDuration()
        {
            return stopDuration;
        }

        public void setStopDuration(long stopDuration)
        {
            this.stopDuration = stopDuration;
        }

        public long getDtshId()
        {
            return dtshId;
        }

        public void setDtshId(long dtshId)
        {
            this.dtshId = dtshId;
        }

        public String getCorrelationGuid()
        {
            return correlationGuid;
        }

        public void setCorrelationGuid(String correlationGuid)
        {
            this.correlationGuid = correlationGuid;
        }

        public String getCompendiumGuid()
        {
            return compendiumGuid;
        }

        public void setCompendiumGuid(String compendiumGuid)
        {
            this.compendiumGuid = compendiumGuid;
        }

        public java.lang.String getErrorCondition()
        {
            return errorCondition;
        }

        public void setErrorCondition(java.lang.String errorCondition)
        {
            this.errorCondition = errorCondition;
        }

        public int getDeviceActiveFlg()
        {
            return deviceActiveFlg;
        }

        public void setDeviceActiveFlg(int deviceActiveFlg)
        {
            this.deviceActiveFlg = deviceActiveFlg;
        }

        public int getDeviceMessageId()
        {
            return deviceMessageId;
        }

        public void setDeviceMessageId(int deviceMessageId)
        {
            this.deviceMessageId = deviceMessageId;
        }

        public AvlHardAccelEvent getAvlHardAccelEvent()
        {
            return avlHardAccelEvent;
        }

        public void setAvlHardAccelEvent(AvlHardAccelEvent avlHardAccelEvent)
        {
            this.avlHardAccelEvent = avlHardAccelEvent;
        }

        public ProvisionEvent getProvisionEvent()
        {
            return provisionEvent;
        }

        public void setProvisionEvent(ProvisionEvent provisionEvent)
        {
            this.provisionEvent = provisionEvent;
        }

        public DiagnosticAliveEvent getDiagnosticAliveEvent()
        {
            return diagnosticAliveEvent;
        }

        public void setDiagnosticAliveEvent(DiagnosticAliveEvent diagnosticAliveEvent)
        {
            this.diagnosticAliveEvent = diagnosticAliveEvent;
        }

        public AssetDeviceInformation getAssetDeviceInformation()
        {
            return assetDeviceInformation;
        }

        public void setAssetDeviceInformation(AssetDeviceInformation assetDeviceInformation)
        {
            this.assetDeviceInformation = assetDeviceInformation;
        }

        public int getPegZone()
        {
            return pegZone;
        }

        public void setPegZone(int pegZone)
        {
            this.pegZone = pegZone;
        }

        public ExtendedAccumulatorValues getExtendedAccumulatorValues()
        {
            return extendedAccumulatorValues;
        }

        public void setExtendedAccumulatorValues(ExtendedAccumulatorValues extendedAccumulatorValues)
        {
            this.extendedAccumulatorValues = extendedAccumulatorValues;
        }

        public UnitStatus getUnitStatus()
        {
            return unitStatus;
        }

        public void setUnitStatus(UnitStatus unitStatus)
        {
            this.unitStatus = unitStatus;
        }

        public VbusIndicators getVbusIndicators()
        {
            return vbusIndicators;
        }

        public void setVbusIndicators(VbusIndicators vbusIndicators)
        {
            this.vbusIndicators = vbusIndicators;
        }

        public String getZoneCurrent()
        {
            return zoneCurrent;
        }

        public void setZoneCurrent(String zoneCurrent)
        {
            this.zoneCurrent = zoneCurrent;
        }

        public String getZonePrevious()
        {
            return zonePrevious;
        }

        public void setZonePrevious(String zonePrevious)
        {
            this.zonePrevious = zonePrevious;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }
    }

    @JsonInclude(Include.NON_NULL)
    @AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
    public static final class AvlHardAccelEvent
    {
        @JsonIgnore
        private Long                        id;
        private AvlHardAccelEventType       accelerationType;
        private int                         lateralAcceleration;
        private int                         longitudinalAcceleration;
        private int                         accelerationDuration;
        private int                         startingSpeed;
        private AvlHardAccelCalibrationType calibrationState;

        public Long getId()
        {
            return id;
        }

        public enum AvlHardAccelEventType
        {
            DECEL, ACCEL, LATERAL_LEFT, LATERAL_RIGHT;
            public static AvlHardAccelEventType getAvlHardAccelEventType(int value)
            {
                for (AvlHardAccelEventType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown AvlHardAccelEventType " + value);
            }
        }

        public enum AvlHardAccelCalibrationType
        {
            AVERAGE, BEST;
            public static AvlHardAccelCalibrationType getAvlHardAccelCalibrationType(int value)
            {
                for (AvlHardAccelCalibrationType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown AvlHardAccelCalibrationType " + value);
            }
        }

        public int getAccelerationDuration()
        {
            return accelerationDuration;
        }

        public void setAccelerationDuration(int accelerationDuration)
        {
            this.accelerationDuration = accelerationDuration;
        }

        public int getStartingSpeed()
        {
            return startingSpeed;
        }

        public void setStartingSpeed(int startingSpeed)
        {
            this.startingSpeed = startingSpeed;
        }

        public AvlHardAccelCalibrationType getCalibrationState()
        {
            return calibrationState;
        }

        public void setCalibrationState(AvlHardAccelCalibrationType calibrationState)
        {
            this.calibrationState = calibrationState;
        }

        public AvlHardAccelEventType getAccelerationType()
        {
            return accelerationType;
        }

        public void setAccelerationType(AvlHardAccelEventType accelerationType)
        {
            this.accelerationType = accelerationType;
        }

        public int getLateralAcceleration()
        {
            return lateralAcceleration;
        }

        public void setLateralAcceleration(int lateralAcceleration)
        {
            this.lateralAcceleration = lateralAcceleration;
        }

        public int getLongitudinalAcceleration()
        {
            return longitudinalAcceleration;
        }

        public void setLongitudinalAcceleration(int longitudinalAcceleration)
        {
            this.longitudinalAcceleration = longitudinalAcceleration;
        }

        @Override
        public boolean equals(Object o)
        {
            return Pojomatic.equals(this, o);
        }

        @Override
        public int hashCode()
        {
            return Pojomatic.hashCode(this);
        }

        @Override
        public String toString()
        {
            return Pojomatic.toString(this);
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class AvlHardAccelPoint
    {
        private int speed;
        private int digitalInStatus;
        private int lateralAcceleration;
        private int longitudinalAcceleration;

        public int getSpeed()
        {
            return speed;
        }

        public void setSpeed(int speed)
        {
            this.speed = speed;
        }

        public int getDigitalInStatus()
        {
            return digitalInStatus;
        }

        public void setDigitalInStatus(int digitalInStatus)
        {
            this.digitalInStatus = digitalInStatus;
        }

        public int getLateralAcceleration()
        {
            return lateralAcceleration;
        }

        public void setLateralAcceleration(int lateralAcceleration)
        {
            this.lateralAcceleration = lateralAcceleration;
        }

        public int getLongitudinalAcceleration()
        {
            return longitudinalAcceleration;
        }

        public void setLongitudinalAcceleration(int longitudinalAcceleration)
        {
            this.longitudinalAcceleration = longitudinalAcceleration;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class ProvisionEvent
    {
        private int              version;
        private int              id;
        private int              status;
        private java.lang.String iccIdEsn;
        private java.lang.String vehicleId;
        private java.lang.String vin;
        private long             odometer;
        private java.lang.String installerId;
        private int              notesLength;
        private java.lang.String notes;
        private java.lang.String vehicleInfo;
        private java.lang.String ticketNumber;
        private java.lang.String licenseState;
        private java.lang.String licensePlateNumber;

        public int getVersion()
        {
            return version;
        }

        public void setVersion(int version)
        {
            this.version = version;
        }

        public int getId()
        {
            return id;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public int getStatus()
        {
            return status;
        }

        public void setStatus(int status)
        {
            this.status = status;
        }

        public java.lang.String getIccIdEsn()
        {
            return iccIdEsn;
        }

        public void setIccIdEsn(java.lang.String iccIdEsn)
        {
            this.iccIdEsn = iccIdEsn;
        }

        public java.lang.String getVehicleId()
        {
            return vehicleId;
        }

        public void setVehicleId(java.lang.String vehicleId)
        {
            this.vehicleId = vehicleId;
        }

        public java.lang.String getVin()
        {
            return vin;
        }

        public void setVin(java.lang.String vin)
        {
            this.vin = vin;
        }

        public long getOdometer()
        {
            return odometer;
        }

        public void setOdometer(long odometer)
        {
            this.odometer = odometer;
        }

        public java.lang.String getInstallerId()
        {
            return installerId;
        }

        public void setInstallerId(java.lang.String installerId)
        {
            this.installerId = installerId;
        }

        public int getNotesLength()
        {
            return notesLength;
        }

        public void setNotesLength(int notesLength)
        {
            this.notesLength = notesLength;
        }

        public java.lang.String getNotes()
        {
            return notes;
        }

        public void setNotes(java.lang.String notes)
        {
            this.notes = notes;
        }

        public java.lang.String getVehicleInfo()
        {
            return vehicleInfo;
        }

        public void setVehicleInfo(java.lang.String vehicleInfo)
        {
            this.vehicleInfo = vehicleInfo;
        }

        public java.lang.String getTicketNumber()
        {
            return ticketNumber;
        }

        public void setTicketNumber(java.lang.String ticketNumber)
        {
            this.ticketNumber = ticketNumber;
        }

        public java.lang.String getLicenseState()
        {
            return licenseState;
        }

        public void setLicenseState(java.lang.String licenseState)
        {
            this.licenseState = licenseState;
        }

        public java.lang.String getLicensePlateNumber()
        {
            return licensePlateNumber;
        }

        public void setLicensePlateNumber(java.lang.String licensePlateNumber)
        {
            this.licensePlateNumber = licensePlateNumber;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class DiagnosticAliveEvent
    {
        private int    powerUps;
        private int    ignitionOns;
        private int    ignitionFaults;
        private long   sentBytes;
        private long   recvBytes;
        private String diagnosticFields;

        public int getPowerUps()
        {
            return powerUps;
        }

        public void setPowerUps(int powerUps)
        {
            this.powerUps = powerUps;
        }

        public int getIgnitionOns()
        {
            return ignitionOns;
        }

        public void setIgnitionOns(int ignitionOns)
        {
            this.ignitionOns = ignitionOns;
        }

        public int getIgnitionFaults()
        {
            return ignitionFaults;
        }

        public void setIgnitionFaults(int ignitionFaults)
        {
            this.ignitionFaults = ignitionFaults;
        }

        public long getSentBytes()
        {
            return sentBytes;
        }

        public void setSentBytes(long sentBytes)
        {
            this.sentBytes = sentBytes;
        }

        public long getRecvBytes()
        {
            return recvBytes;
        }

        public void setRecvBytes(long recvBytes)
        {
            this.recvBytes = recvBytes;
        }

        public String getDiagnosticFields()
        {
            return diagnosticFields;
        }

        public void setDiagnosticFields(String diagnosticFields)
        {
            this.diagnosticFields = diagnosticFields;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class AssetDeviceInformation
    {
        private long powerOnTime;
        private long awakeDuration;
        private int  batteryLevel;

        public long getPowerOnTime()
        {
            return powerOnTime;
        }

        public void setPowerOnTime(long powerOnTime)
        {
            this.powerOnTime = powerOnTime;
        }

        public long getAwakeDuration()
        {
            return awakeDuration;
        }

        public void setAwakeDuration(long awakeDuration)
        {
            this.awakeDuration = awakeDuration;
        }

        public int getBatteryLevel()
        {
            return batteryLevel;
        }

        public void setBatteryLevel(int batteryLevel)
        {
            this.batteryLevel = batteryLevel;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class ExtendedAccumulatorValues
    {
        // SDC AVL Values
        private double  maxSpeedObd;
        private double  maxSpeedGps;
        private double  maxEngineSpeed;
        private double  maxThrottlePosition;
        private double  fuelLevelPct;
        private double  fuelLevelVolume;
        private double  engineCoolantTemp;
        private double  batteryVoltage;
        private int     daysToService;
        private int     distanceToservice;
        private boolean milStatus;
        private boolean seatBeltFastened;
        private boolean absActiveLamp;
        private boolean oilPressureLamp;
        private boolean parkBrakeLight;
        private boolean coolantHotLight;
        private int     batteryHealth;

        public double getMaxSpeedObd()
        {
            return maxSpeedObd;
        }

        public void setMaxSpeedObd(double maxSpeedObd)
        {
            this.maxSpeedObd = maxSpeedObd;
        }

        public double getMaxSpeedGps()
        {
            return maxSpeedGps;
        }

        public void setMaxSpeedGps(double maxSpeedGps)
        {
            this.maxSpeedGps = maxSpeedGps;
        }

        public double getMaxEngineSpeed()
        {
            return maxEngineSpeed;
        }

        public void setMaxEngineSpeed(double maxEngineSpeed)
        {
            this.maxEngineSpeed = maxEngineSpeed;
        }

        public double getMaxThrottlePosition()
        {
            return maxThrottlePosition;
        }

        public void setMaxThrottlePosition(double maxThrottlePosition)
        {
            this.maxThrottlePosition = maxThrottlePosition;
        }

        public double getFuelLevelPct()
        {
            return fuelLevelPct;
        }

        public void setFuelLevelPct(double fuelLevelPct)
        {
            this.fuelLevelPct = fuelLevelPct;
        }

        public double getFuelLevelVolume()
        {
            return fuelLevelVolume;
        }

        public void setFuelLevelVolume(double fuelLevelVolume)
        {
            this.fuelLevelVolume = fuelLevelVolume;
        }

        public double getEngineCoolantTemp()
        {
            return engineCoolantTemp;
        }

        public void setEngineCoolantTemp(double engineCoolantTemp)
        {
            this.engineCoolantTemp = engineCoolantTemp;
        }

        public double getBatteryVoltage()
        {
            return batteryVoltage;
        }

        public void setBatteryVoltage(double batteryVoltage)
        {
            this.batteryVoltage = batteryVoltage;
        }

        public int getDaysToService()
        {
            return daysToService;
        }

        public void setDaysToService(int daysToService)
        {
            this.daysToService = daysToService;
        }

        public int getDistanceToservice()
        {
            return distanceToservice;
        }

        public void setDistanceToservice(int distanceToservice)
        {
            this.distanceToservice = distanceToservice;
        }

        public boolean isMilStatus()
        {
            return milStatus;
        }

        public void setMilStatus(boolean milStatus)
        {
            this.milStatus = milStatus;
        }

        public boolean isSeatBeltFastened()
        {
            return seatBeltFastened;
        }

        public void setSeatBeltFastened(boolean seatBeltFastened)
        {
            this.seatBeltFastened = seatBeltFastened;
        }

        public boolean isAbsActiveLamp()
        {
            return absActiveLamp;
        }

        public void setAbsActiveLamp(boolean absActiveLamp)
        {
            this.absActiveLamp = absActiveLamp;
        }

        public boolean isOilPressureLamp()
        {
            return oilPressureLamp;
        }

        public void setOilPressureLamp(boolean oilPressureLamp)
        {
            this.oilPressureLamp = oilPressureLamp;
        }

        public boolean isParkBrakeLight()
        {
            return parkBrakeLight;
        }

        public void setParkBrakeLight(boolean parkBrakeLight)
        {
            this.parkBrakeLight = parkBrakeLight;
        }

        public boolean isCoolantHotLight()
        {
            return coolantHotLight;
        }

        public void setCoolantHotLight(boolean coolantHotLight)
        {
            this.coolantHotLight = coolantHotLight;
        }

        public int getBatteryHealth()
        {
            return batteryHealth;
        }

        public void setBatteryHealth(int batteryHealth)
        {
            this.batteryHealth = batteryHealth;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class VbusIndicators
    {
        private boolean ignitionStatus;
        private boolean milStatus;
        private boolean airBagDashIndicator;
        private boolean absDashIndicator;
        private boolean ptoStatus;
        private boolean seatBeltFastened;
        private boolean brakePedalPressed;
        private boolean absActiveLamp;
        private boolean cruiseControlStatus;
        private boolean oilPressureLamp;
        private boolean parkBrakeLight;
        private boolean coolantHotLight;
        private boolean tpmsStatus;

        public boolean isIgnitionStatus()
        {
            return ignitionStatus;
        }

        public void setIgnitionStatus(boolean ignitionStatus)
        {
            this.ignitionStatus = ignitionStatus;
        }

        public boolean isMilStatus()
        {
            return milStatus;
        }

        public void setMilStatus(boolean milStatus)
        {
            this.milStatus = milStatus;
        }

        public boolean isAirBagDashIndicator()
        {
            return airBagDashIndicator;
        }

        public void setAirBagDashIndicator(boolean airbagDashIndicator)
        {
            this.airBagDashIndicator = airbagDashIndicator;
        }

        public boolean isAbsDashIndicator()
        {
            return absDashIndicator;
        }

        public void setAbsDashIndicator(boolean absDashIndicator)
        {
            this.absDashIndicator = absDashIndicator;
        }

        public boolean isPtoStatus()
        {
            return ptoStatus;
        }

        public void setPtoStatus(boolean ptoStatus)
        {
            this.ptoStatus = ptoStatus;
        }

        public boolean isSeatBeltFastened()
        {
            return seatBeltFastened;
        }

        public void setSeatBeltFastened(boolean seatBeltFastened)
        {
            this.seatBeltFastened = seatBeltFastened;
        }

        public boolean isBrakePedalPressed()
        {
            return brakePedalPressed;
        }

        public void setBrakePedalPressed(boolean brakePedalPressed)
        {
            this.brakePedalPressed = brakePedalPressed;
        }

        public boolean isAbsActiveLamp()
        {
            return absActiveLamp;
        }

        public void setAbsActiveLamp(boolean absActiveLamp)
        {
            this.absActiveLamp = absActiveLamp;
        }

        public boolean isCruiseControlStatus()
        {
            return cruiseControlStatus;
        }

        public void setCruiseControlStatus(boolean cruiseControlStatus)
        {
            this.cruiseControlStatus = cruiseControlStatus;
        }

        public boolean isOilPressureLamp()
        {
            return oilPressureLamp;
        }

        public void setOilPressureLamp(boolean oilPressureLamp)
        {
            this.oilPressureLamp = oilPressureLamp;
        }

        public boolean isParkBrakeLight()
        {
            return parkBrakeLight;
        }

        public void setParkBrakeLight(boolean parkBrakeLight)
        {
            this.parkBrakeLight = parkBrakeLight;
        }

        public boolean isCoolantHotLight()
        {
            return coolantHotLight;
        }

        public void setCoolantHotLight(boolean coolantHotLight)
        {
            this.coolantHotLight = coolantHotLight;
        }

        public boolean isTpmsStatus()
        {
            return tpmsStatus;
        }

        public void setTpmsStatus(boolean tpmsStatus)
        {
            this.tpmsStatus = tpmsStatus;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class PndMessage
    {
        private byte[] userMessage;
        private int userMessageId;
        private int userMessageRoute;
		public byte[] getUserMessage() {
			return userMessage;
		}
		public void setUserMessage(byte[] userMessage) {
			this.userMessage = userMessage;
		}
		public int getUserMessageId() {
			return userMessageId;
		}
		public void setUserMessageId(int userMessageId) {
			this.userMessageId = userMessageId;
		}
		public int getUserMessageRoute() {
			return userMessageRoute;
		}
		public void setUserMessageRoute(int userMessageRoute) {
			this.userMessageRoute = userMessageRoute;
		}

        
    }

    

    @JsonInclude(Include.NON_NULL)
    public static final class AckMessage
    {
    	private int     type;
        private int     ackTypeCode;
        private boolean ackStatus;

        public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}

		public int getAckTypeCode()
        {
            return ackTypeCode;
        }

        public void setAckTypeCode(int ackTypeCode)
        {
            this.ackTypeCode = ackTypeCode;
        }

        public boolean isAckStatus()
        {
            return ackStatus;
        }

        public void setAckStatus(boolean ackStatus)
        {
            this.ackStatus = ackStatus;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class ProvisionMessage
    {
        private long                   deviceId;
        private String                 externalDeviceId;
        private String                 enterpriseCode;
        private String                 deviceInstanceGuid;
        private int                    eventCode;
        private long                   locationTime;
        private double                 latitude;
        private double                 longitude;
        private long                   altitude;
        private int                    speed;
        private int                    heading;
        private int                    satellites;
        private boolean                fixStatus;
        private int                    carrier;
        private double                 hdop;
        private int                    satelliteCount;
        private int                    rssi;
        private java.lang.String       vin;
        private java.lang.String       vehicleId;
        private int                    odometer;
        private int                    obiiProtocol;
        private ObdSupportedParameters obdSupportedParameters;
        private ObdSupportedIndicators obdSupportedIndicators;

        public long getDeviceId()
        {
            return deviceId;
        }

        public void setDeviceId(long deviceId)
        {
            this.deviceId = deviceId;
        }

        public String getExternalDeviceId()
        {
            return externalDeviceId;
        }

        public void setExternalDeviceId(String externalDeviceId)
        {
            this.externalDeviceId = externalDeviceId;
        }

        public String getEnterpriseCode()
        {
            return enterpriseCode;
        }

        public void setEnterpriseCode(String enterpriseCode)
        {
            this.enterpriseCode = enterpriseCode;
        }

        public String getDeviceInstanceGuid()
        {
            return deviceInstanceGuid;
        }

        public void setDeviceInstanceGuid(String deviceInstanceGuid)
        {
            this.deviceInstanceGuid = deviceInstanceGuid;
        }

        public int getEventCode()
        {
            return eventCode;
        }

        public void setEventCode(int eventCode)
        {
            this.eventCode = eventCode;
        }

        public long getLocationTime()
        {
            return locationTime;
        }

        public void setLocationTime(long locationTime)
        {
            this.locationTime = locationTime;
        }

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        public long getAltitude()
        {
            return altitude;
        }

        public void setAltitude(long altitude)
        {
            this.altitude = altitude;
        }

        public int getSpeed()
        {
            return speed;
        }

        public void setSpeed(int speed)
        {
            this.speed = speed;
        }

        public int getHeading()
        {
            return heading;
        }

        public void setHeading(int heading)
        {
            this.heading = heading;
        }

        public int getSatellites()
        {
            return satellites;
        }

        public void setSatellites(int satellites)
        {
            this.satellites = satellites;
        }

        public boolean isFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public int getCarrier()
        {
            return carrier;
        }

        public void setCarrier(int carrier)
        {
            this.carrier = carrier;
        }

        public double getHdop()
        {
            return hdop;
        }

        public void setHdop(double hdop)
        {
            this.hdop = hdop;
        }

        public int getSatelliteCount()
        {
            return satelliteCount;
        }

        public void setSatelliteCount(int satelliteCount)
        {
            this.satelliteCount = satelliteCount;
        }

        public int getRssi()
        {
            return rssi;
        }

        public void setRssi(int rssi)
        {
            this.rssi = rssi;
        }

        public java.lang.String getVin()
        {
            return vin;
        }

        public void setVin(java.lang.String vin)
        {
            this.vin = vin;
        }

        public java.lang.String getVehicleId()
        {
            return vehicleId;
        }

        public void setVehicleId(java.lang.String vehicleId)
        {
            this.vehicleId = vehicleId;
        }

        public int getOdometer()
        {
            return odometer;
        }

        public void setOdometer(int odometer)
        {
            this.odometer = odometer;
        }

        public int getObiiProtocol()
        {
            return obiiProtocol;
        }

        public void setObiiProtocol(int obiiProtocol)
        {
            this.obiiProtocol = obiiProtocol;
        }

        public ObdSupportedParameters getObdSupportedParameters()
        {
            return obdSupportedParameters;
        }

        public void setObdSupportedParameters(ObdSupportedParameters obdSupportedParameters)
        {
            this.obdSupportedParameters = obdSupportedParameters;
        }

        public ObdSupportedIndicators getObdSupportedIndicators()
        {
            return obdSupportedIndicators;
        }

        public void setObdSupportedIndicators(ObdSupportedIndicators obdSupportedIndicators)
        {
            this.obdSupportedIndicators = obdSupportedIndicators;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class ObdSupportedParameters
    {
        private boolean vehicleSpeedSupported;
        private boolean engineSpeedSupported;
        private boolean throttlePositionSupported;
        private boolean odometerSupported;
        private boolean fuelLevelSupported;
        private boolean fuelLevelRemainingSupported;
        private boolean transmissionGearSupported;
        private boolean engineCoolantTempSupported;
        private boolean fuelRateSupported;
        private boolean batteryVoltageSupported;
        private boolean turnSignalStatusSupported;
        private boolean tripOdometerSupported;
        private boolean tripFuelConsumptionSupported;
        private boolean calculatedFuelUsageSupported;
        private boolean engineStateSupported;
        private boolean serviceIntervalInspectionDistanceSupported;
        private boolean fuelLevelRemaining3030Supported;
        private boolean serviceIntervalDaysRemainingSupported;
        private boolean engineOilTempSupported;
        private boolean fuelEconomySupported;
        private boolean dtcCountSupported;
        private boolean serviceIntervalOilDistanceSupported;
        private boolean serviceIntervalOilDaysSupported;
        private boolean engineRunTimeSupported;
        private boolean ambientAirTempSupported;
        private boolean barometricPressureSupported;
        private boolean canTecSupported;
        private boolean canRecSupported;
        private boolean canBusModeSupported;
        private boolean canBusErrorTypeSupported;

        public boolean isVehicleSpeedSupported()
        {
            return vehicleSpeedSupported;
        }

        public void setVehicleSpeedSupported(boolean vehicleSpeedSupported)
        {
            this.vehicleSpeedSupported = vehicleSpeedSupported;
        }

        public boolean isEngineSpeedSupported()
        {
            return engineSpeedSupported;
        }

        public void setEngineSpeedSupported(boolean engineSpeedSupported)
        {
            this.engineSpeedSupported = engineSpeedSupported;
        }

        public boolean isThrottlePositionSupported()
        {
            return throttlePositionSupported;
        }

        public void setThrottlePositionSupported(boolean throttlePositionSupported)
        {
            this.throttlePositionSupported = throttlePositionSupported;
        }

        public boolean isOdometerSupported()
        {
            return odometerSupported;
        }

        public void setOdometerSupported(boolean odometerSupported)
        {
            this.odometerSupported = odometerSupported;
        }

        public boolean isFuelLevelSupported()
        {
            return fuelLevelSupported;
        }

        public void setFuelLevelSupported(boolean fuelLevelSupported)
        {
            this.fuelLevelSupported = fuelLevelSupported;
        }

        public boolean isFuelLevelRemainingSupported()
        {
            return fuelLevelRemainingSupported;
        }

        public void setFuelLevelRemainingSupported(boolean fuelLevelRemainingSupported)
        {
            this.fuelLevelRemainingSupported = fuelLevelRemainingSupported;
        }

        public boolean isTransmissionGearSupported()
        {
            return transmissionGearSupported;
        }

        public void setTransmissionGearSupported(boolean transmissionGearSupported)
        {
            this.transmissionGearSupported = transmissionGearSupported;
        }

        public boolean isEngineCoolantTempSupported()
        {
            return engineCoolantTempSupported;
        }

        public void setEngineCoolantTempSupported(boolean engineCoolantTempSupported)
        {
            this.engineCoolantTempSupported = engineCoolantTempSupported;
        }

        public boolean isFuelRateSupported()
        {
            return fuelRateSupported;
        }

        public void setFuelRateSupported(boolean fuelRateSupported)
        {
            this.fuelRateSupported = fuelRateSupported;
        }

        public boolean isBatteryVoltageSupported()
        {
            return batteryVoltageSupported;
        }

        public void setBatteryVoltageSupported(boolean batteryVoltageSupported)
        {
            this.batteryVoltageSupported = batteryVoltageSupported;
        }

        public boolean isTurnSignalStatusSupported()
        {
            return turnSignalStatusSupported;
        }

        public void setTurnSignalStatusSupported(boolean turnSignalStatusSupported)
        {
            this.turnSignalStatusSupported = turnSignalStatusSupported;
        }

        public boolean isTripOdometerSupported()
        {
            return tripOdometerSupported;
        }

        public void setTripOdometerSupported(boolean tripOdometerSupported)
        {
            this.tripOdometerSupported = tripOdometerSupported;
        }

        public boolean isTripFuelConsumptionSupported()
        {
            return tripFuelConsumptionSupported;
        }

        public void setTripFuelConsumptionSupported(boolean tripFuelConsumptionSupported)
        {
            this.tripFuelConsumptionSupported = tripFuelConsumptionSupported;
        }

        public boolean isCalculatedFuelUsageSupported()
        {
            return calculatedFuelUsageSupported;
        }

        public void setCalculatedFuelUsageSupported(boolean calculatedFuelUsageSupported)
        {
            this.calculatedFuelUsageSupported = calculatedFuelUsageSupported;
        }

        public boolean isEngineStateSupported()
        {
            return engineStateSupported;
        }

        public void setEngineStateSupported(boolean engineStateSupported)
        {
            this.engineStateSupported = engineStateSupported;
        }

        public boolean isServiceIntervalInspectionDistanceSupported()
        {
            return serviceIntervalInspectionDistanceSupported;
        }

        public void setServiceIntervalInspectionDistanceSupported(boolean serviceIntervalInspectionDistanceSupported)
        {
            this.serviceIntervalInspectionDistanceSupported = serviceIntervalInspectionDistanceSupported;
        }

        public boolean isFuelLevelRemaining3030Supported()
        {
            return fuelLevelRemaining3030Supported;
        }

        public void setFuelLevelRemaining3030Supported(boolean fuelLevelRemaining3030Supported)
        {
            this.fuelLevelRemaining3030Supported = fuelLevelRemaining3030Supported;
        }

        public boolean isServiceIntervalDaysRemainingSupported()
        {
            return serviceIntervalDaysRemainingSupported;
        }

        public void setServiceIntervalDaysRemainingSupported(boolean serviceIntervalDaysRemainingSupported)
        {
            this.serviceIntervalDaysRemainingSupported = serviceIntervalDaysRemainingSupported;
        }

        public boolean isEngineOilTempSupported()
        {
            return engineOilTempSupported;
        }

        public void setEngineOilTempSupported(boolean engineOilTempSupported)
        {
            this.engineOilTempSupported = engineOilTempSupported;
        }

        public boolean isFuelEconomySupported()
        {
            return fuelEconomySupported;
        }

        public void setFuelEconomySupported(boolean fuelEconomySupported)
        {
            this.fuelEconomySupported = fuelEconomySupported;
        }

        public boolean isDtcCountSupported()
        {
            return dtcCountSupported;
        }

        public void setDtcCountSupported(boolean dtcCountSupported)
        {
            this.dtcCountSupported = dtcCountSupported;
        }

        public boolean isServiceIntervalOilDistanceSupported()
        {
            return serviceIntervalOilDistanceSupported;
        }

        public void setServiceIntervalOilDistanceSupported(boolean serviceIntervalOilDistanceSupported)
        {
            this.serviceIntervalOilDistanceSupported = serviceIntervalOilDistanceSupported;
        }

        public boolean isServiceIntervalOilDaysSupported()
        {
            return serviceIntervalOilDaysSupported;
        }

        public void setServiceIntervalOilDaysSupported(boolean serviceIntervalOilDaysSupported)
        {
            this.serviceIntervalOilDaysSupported = serviceIntervalOilDaysSupported;
        }

        public boolean isEngineRunTimeSupported()
        {
            return engineRunTimeSupported;
        }

        public void setEngineRunTimeSupported(boolean engineRunTimeSupported)
        {
            this.engineRunTimeSupported = engineRunTimeSupported;
        }

        public boolean isAmbientAirTempSupported()
        {
            return ambientAirTempSupported;
        }

        public void setAmbientAirTempSupported(boolean ambientAirTempSupported)
        {
            this.ambientAirTempSupported = ambientAirTempSupported;
        }

        public boolean isBarometricPressureSupported()
        {
            return barometricPressureSupported;
        }

        public void setBarometricPressureSupported(boolean barometricPressureSupported)
        {
            this.barometricPressureSupported = barometricPressureSupported;
        }

        public boolean isCanTecSupported()
        {
            return canTecSupported;
        }

        public void setCanTecSupported(boolean canTecSupported)
        {
            this.canTecSupported = canTecSupported;
        }

        public boolean isCanRecSupported()
        {
            return canRecSupported;
        }

        public void setCanRecSupported(boolean canRecSupported)
        {
            this.canRecSupported = canRecSupported;
        }

        public boolean isCanBusModeSupported()
        {
            return canBusModeSupported;
        }

        public void setCanBusModeSupported(boolean canBusModeSupported)
        {
            this.canBusModeSupported = canBusModeSupported;
        }

        public boolean isCanBusErrorTypeSupported()
        {
            return canBusErrorTypeSupported;
        }

        public void setCanBusErrorTypeSupported(boolean canBusErrorTypeSupported)
        {
            this.canBusErrorTypeSupported = canBusErrorTypeSupported;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class ObdSupportedIndicators
    {
        private boolean ignitionStatus;
        private boolean milStatus;
        private boolean airBagDashIndicator;
        private boolean absDashIndicator;
        private boolean ptoStatus;
        private boolean seatBeltFastened;
        private boolean brakeSwitchStatus;
        private boolean absActiveLamp;
        private boolean cruiseControlStatus;
        private boolean oilPressureLamp;
        private boolean brakeIndicatorLight;
        private boolean coolantHotLight;
        private boolean misfireMonitor;
        private boolean fuelSystemMonitor;
        private boolean comprehensiveComponentMonitor;
        private boolean catalystMonitor;
        private boolean heatedCatalystMonitor;
        private boolean evaporativeSystemMonitor;
        private boolean secondaryAirSystemMonitor;
        private boolean acSystemRefrigerantMonitor;
        private boolean oxygenSensorMonitor;
        private boolean oxygenSensorHeatedMonitor;
        private boolean egrSystemMonitor;
        private boolean maintenanceRequired;
        private boolean o2SensorCircuitNoActivity;
        private boolean o2SensorHeaterCircuitMalfunction;
        private boolean ho2SHeaterControlMalfunction;
        private boolean ho2SHeaterResistanceMalfunction;

        public boolean isIgnitionStatus()
        {
            return ignitionStatus;
        }

        public void setIgnitionStatus(boolean ignitionStatus)
        {
            this.ignitionStatus = ignitionStatus;
        }

        public boolean isMilStatus()
        {
            return milStatus;
        }

        public void setMilStatus(boolean milStatus)
        {
            this.milStatus = milStatus;
        }

        public boolean isAirBagDashIndicator()
        {
            return airBagDashIndicator;
        }

        public void setAirBagDashIndicator(boolean airBagDashIndicator)
        {
            this.airBagDashIndicator = airBagDashIndicator;
        }

        public boolean isAbsDashIndicator()
        {
            return absDashIndicator;
        }

        public void setAbsDashIndicator(boolean absDashIndicator)
        {
            this.absDashIndicator = absDashIndicator;
        }

        public boolean isPtoStatus()
        {
            return ptoStatus;
        }

        public void setPtoStatus(boolean ptoStatus)
        {
            this.ptoStatus = ptoStatus;
        }

        public boolean isSeatBeltFastened()
        {
            return seatBeltFastened;
        }

        public void setSeatbeltFastened(boolean seatbeltFastened)
        {
            this.seatBeltFastened = seatbeltFastened;
        }

        public boolean isBrakeSwitchStatus()
        {
            return brakeSwitchStatus;
        }

        public void setBrakeSwitchStatus(boolean brakeSwitchStatus)
        {
            this.brakeSwitchStatus = brakeSwitchStatus;
        }

        public boolean isAbsActiveLamp()
        {
            return absActiveLamp;
        }

        public void setAbsActiveLamp(boolean absActiveLamp)
        {
            this.absActiveLamp = absActiveLamp;
        }

        public boolean isCruiseControlStatus()
        {
            return cruiseControlStatus;
        }

        public void setCruiseControlStatus(boolean cruiseControlStatus)
        {
            this.cruiseControlStatus = cruiseControlStatus;
        }

        public boolean isOilPressureLamp()
        {
            return oilPressureLamp;
        }

        public void setOilPressureLamp(boolean oilPressureLamp)
        {
            this.oilPressureLamp = oilPressureLamp;
        }

        public boolean isBrakeIndicatorLight()
        {
            return brakeIndicatorLight;
        }

        public void setBrakeIndicatorLight(boolean brakeIndicatorLight)
        {
            this.brakeIndicatorLight = brakeIndicatorLight;
        }

        public boolean isCoolantHotLight()
        {
            return coolantHotLight;
        }

        public void setCoolantHotLight(boolean coolantHotLight)
        {
            this.coolantHotLight = coolantHotLight;
        }

        public boolean isMisfireMonitor()
        {
            return misfireMonitor;
        }

        public void setMisfireMonitor(boolean misfireMonitor)
        {
            this.misfireMonitor = misfireMonitor;
        }

        public boolean isFuelSystemMonitor()
        {
            return fuelSystemMonitor;
        }

        public void setFuelSystemMonitor(boolean fuelSystemMonitor)
        {
            this.fuelSystemMonitor = fuelSystemMonitor;
        }

        public boolean isComprehensiveComponentMonitor()
        {
            return comprehensiveComponentMonitor;
        }

        public void setComprehensiveComponentMonitor(boolean comprehensiveComponentMonitor)
        {
            this.comprehensiveComponentMonitor = comprehensiveComponentMonitor;
        }

        public boolean isCatalystMonitor()
        {
            return catalystMonitor;
        }

        public void setCatalystMonitor(boolean catalystMonitor)
        {
            this.catalystMonitor = catalystMonitor;
        }

        public boolean isHeatedCatalystMonitor()
        {
            return heatedCatalystMonitor;
        }

        public void setHeatedCatalystMonitor(boolean heatedCatalystMonitor)
        {
            this.heatedCatalystMonitor = heatedCatalystMonitor;
        }

        public boolean isEvaporativeSystemMonitor()
        {
            return evaporativeSystemMonitor;
        }

        public void setEvaporativeSystemMonitor(boolean evaporativeSystemMonitor)
        {
            this.evaporativeSystemMonitor = evaporativeSystemMonitor;
        }

        public boolean isSecondaryAirSystemMonitor()
        {
            return secondaryAirSystemMonitor;
        }

        public void setSecondaryAirSystemMonitor(boolean secondaryAirSystemMonitor)
        {
            this.secondaryAirSystemMonitor = secondaryAirSystemMonitor;
        }

        public boolean isAcSystemRefrigerantMonitor()
        {
            return acSystemRefrigerantMonitor;
        }

        public void setAcSystemRefrigerantMonitor(boolean acSystemRefrigerantMonitor)
        {
            this.acSystemRefrigerantMonitor = acSystemRefrigerantMonitor;
        }

        public boolean isOxygenSensorMonitor()
        {
            return oxygenSensorMonitor;
        }

        public void setOxygenSensorMonitor(boolean oxygenSensorMonitor)
        {
            this.oxygenSensorMonitor = oxygenSensorMonitor;
        }

        public boolean isOxygenSensorHeatedMonitor()
        {
            return oxygenSensorHeatedMonitor;
        }

        public void setOxygenSensorHeatedMonitor(boolean oxygenSensorHeatedMonitor)
        {
            this.oxygenSensorHeatedMonitor = oxygenSensorHeatedMonitor;
        }

        public boolean isEgrSystemMonitor()
        {
            return egrSystemMonitor;
        }

        public void setEgrSystemMonitor(boolean egrSystemMonitor)
        {
            this.egrSystemMonitor = egrSystemMonitor;
        }

        public boolean getMaintenanceRequired()
        {
            return maintenanceRequired;
        }

        public void setMaintenanceRequired(boolean maintenanceRequired)
        {
            this.maintenanceRequired = maintenanceRequired;
        }

        public void setSeatBeltFastened(boolean seatBeltFastened)
        {
            this.seatBeltFastened = seatBeltFastened;
        }

        public boolean isO2SensorCircuitNoActivity()
        {
            return o2SensorCircuitNoActivity;
        }

        public void setO2SensorCircuitNoActivity(boolean o2SensorCircuitNoActivity)
        {
            this.o2SensorCircuitNoActivity = o2SensorCircuitNoActivity;
        }

        public boolean isO2SensorHeaterCircuitMalfunction()
        {
            return o2SensorHeaterCircuitMalfunction;
        }

        public void setO2SensorHeaterCircuitMalfunction(boolean o2SensorHeaterCircuitMalfunction)
        {
            this.o2SensorHeaterCircuitMalfunction = o2SensorHeaterCircuitMalfunction;
        }

        public boolean isHo2SHeaterControlMalfunction()
        {
            return ho2SHeaterControlMalfunction;
        }

        public void setHo2SHeaterControlMalfunction(boolean ho2sHeaterControlMalfunction)
        {
            ho2SHeaterControlMalfunction = ho2sHeaterControlMalfunction;
        }

        public boolean isHo2SHeaterResistanceMalfunction()
        {
            return ho2SHeaterResistanceMalfunction;
        }

        public void setHo2SHeaterResistanceMalfunction(boolean ho2sHeaterResistanceMalfunction)
        {
            ho2SHeaterResistanceMalfunction = ho2sHeaterResistanceMalfunction;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class RawDtcMessage
    {
        private long                             locationTime;
        private LocationInformation              locationInformation;
        private java.util.List<java.lang.String> dtcCodes;
        private long                             deviceId;
        private java.lang.String                 externalDeviceId;

        public long getLocationTime()
        {
            return locationTime;
        }

        public void setLocationTime(long locationTime)
        {
            this.locationTime = locationTime;
        }

        public LocationInformation getLocationInformation()
        {
            return locationInformation;
        }

        public void setLocationInformation(LocationInformation locationInformation)
        {
            this.locationInformation = locationInformation;
        }

        public java.util.List<java.lang.String> getDtcCodes()
        {
            return dtcCodes;
        }

        public void setDtcCodes(java.util.List<java.lang.String> dtcCodes)
        {
            this.dtcCodes = dtcCodes;
        }

        public long getDeviceId()
        {
            return deviceId;
        }

        public void setDeviceId(long deviceId)
        {
            this.deviceId = deviceId;
        }

        public java.lang.String getExternalDeviceId()
        {
            return externalDeviceId;
        }

        public void setExternalDeviceId(java.lang.String externalDeviceId)
        {
            this.externalDeviceId = externalDeviceId;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class LocationInformation
    {
        private double     latitude;
        private double     longitude;
        private long       altitude;
        private Long       speed;
        private int        heading;
        private FixStatus  fixStatus;
        private int        carrier;
        private double     hdop;
        private int        satelliteCount;
        private int        rssi;
        private CommState  commState;
        private Inputs     inputs;
        private UnitStatus unitStatus;

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        public long getAltitude()
        {
            return altitude;
        }

        public void setAltitude(long altitude)
        {
            this.altitude = altitude;
        }

        public Long getSpeed()
        {
            return speed;
        }

        public void setSpeed(Long speed)
        {
            this.speed = speed;
        }

        public int getHeading()
        {
            return heading;
        }

        public void setHeading(int heading)
        {
            this.heading = heading;
        }

        public FixStatus getFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(FixStatus fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public int getCarrier()
        {
            return carrier;
        }

        public void setCarrier(int carrier)
        {
            this.carrier = carrier;
        }

        public double getHdop()
        {
            return hdop;
        }

        public void setHdop(double hdop)
        {
            this.hdop = hdop;
        }

        public int getSatelliteCount()
        {
            return satelliteCount;
        }

        public void setSatelliteCount(int satelliteCount)
        {
            this.satelliteCount = satelliteCount;
        }

        public int getRssi()
        {
            return rssi;
        }

        public void setRssi(int rssi)
        {
            this.rssi = rssi;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public UnitStatus getUnitStatus()
        {
            return unitStatus;
        }

        public void setUnitStatus(UnitStatus unitStatus)
        {
            this.unitStatus = unitStatus;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class DigitalOutputMessage
    {
        private java.lang.String actionName;
        private int              port;
        private int              pin;
        private java.lang.String pinStatus;
        private java.lang.String deviceType;
        private java.lang.String statusText;
        private int              statusCode;

        public java.lang.String getActionName()
        {
            return actionName;
        }

        public void setActionName(java.lang.String actionName)
        {
            this.actionName = actionName;
        }

        public int getPort()
        {
            return port;
        }

        public void setPort(int port)
        {
            this.port = port;
        }

        public int getPin()
        {
            return pin;
        }

        public void setPin(int pin)
        {
            this.pin = pin;
        }

        public java.lang.String getPinStatus()
        {
            return pinStatus;
        }

        public void setPinStatus(java.lang.String pinStatus)
        {
            this.pinStatus = pinStatus;
        }

        public java.lang.String getDeviceType()
        {
            return deviceType;
        }

        public void setDeviceType(java.lang.String deviceType)
        {
            this.deviceType = deviceType;
        }

        public java.lang.String getStatusText()
        {
            return statusText;
        }

        public void setStatusText(java.lang.String statusText)
        {
            this.statusText = statusText;
        }

        public int getStatusCode()
        {
            return statusCode;
        }

        public void setStatusCode(int statusCode)
        {
            this.statusCode = statusCode;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class RawJbusMessage
    {
        private long                             locationTime;
        private JbusData1708                     jbusData1708;
        private JbusData1939                     jbusData1939;
        private JbusDtcData                      jbusDtcData;
        private java.util.List<JbusDtcData>      jbusDtcDataJ1939;
        private java.util.List<JbusDtcDataJ1708> jbusDtcDataJ1708;
        private UnknownReportRaw                 unknownReportRaw;
        private DailyReport                      dailyReport;
        private HourlyReport                     hourlyReport;
        private int                              sourceAddress;
        private ConstructionDailyReport          constructionDailyReport;
        private ConstructionDailyUsageReport     constructionDailyUsageReport;
        private ConstructionHourlyReport         constructionHourlyReport;
        private JbusFaultReport                  jbusFaultReport;
        private JbusHydraulicReport              jbusHydraulicReport;
        private JbusDiscoveryReport 			 jbusDiscoveryReport;
        private Date							 timeOfFix;
        private String                           jbusMessageType;

        
        public UnknownReportRaw getUnknownReportRaw() {
			return unknownReportRaw;
		}

		public void setUnknownReportRaw(UnknownReportRaw unknownReportRaw) {
			this.unknownReportRaw = unknownReportRaw;
		}

		public Date getTimeOfFix() {
			return timeOfFix;
		}

		public void setTimeOfFix(Date timeOfFix) {
			this.timeOfFix = timeOfFix;
		}

		public long getLocationTime()
        {
            return locationTime;
        }

        public void setLocationTime(long locationTime)
        {
            this.locationTime = locationTime;
        }

        public JbusData1708 getJbusData1708()
        {
            return jbusData1708;
        }

        public void setJbusData1708(JbusData1708 jbusData1708)
        {
            this.jbusData1708 = jbusData1708;
        }

        public JbusData1939 getJbusData1939()
        {
            return jbusData1939;
        }

        public void setJbusData1939(JbusData1939 jbusData1939)
        {
            this.jbusData1939 = jbusData1939;
        }

        public JbusDtcData getJbusDtcData()
        {
            return jbusDtcData;
        }

        public void setJbusDtcData(JbusDtcData jbusDtcData)
        {
            this.jbusDtcData = jbusDtcData;
        }

        public java.util.List<JbusDtcData> getJbusDtcDataJ1939()
        {
            return jbusDtcDataJ1939;
        }

        public void setJbusDtcDataJ1939(java.util.List<JbusDtcData> jbusDtcDataJ1939)
        {
            this.jbusDtcDataJ1939 = jbusDtcDataJ1939;
        }

        public java.util.List<JbusDtcDataJ1708> getJbusDtcDataJ1708()
        {
            return jbusDtcDataJ1708;
        }

        public void setJbusDtcDataJ1708(java.util.List<JbusDtcDataJ1708> jbusDtcDataJ1708)
        {
            this.jbusDtcDataJ1708 = jbusDtcDataJ1708;
        }

        public DailyReport getDailyReport()
        {
            return dailyReport;
        }

        public void setDailyReport(DailyReport dailyReport)
        {
            this.dailyReport = dailyReport;
        }

        public HourlyReport getHourlyReport()
        {
            return hourlyReport;
        }

        public void setHourlyReport(HourlyReport hourlyReport)
        {
            this.hourlyReport = hourlyReport;
        }

        public int getSourceAddress()
        {
            return sourceAddress;
        }

        public void setSourceAddress(int sourceAddress)
        {
            this.sourceAddress = sourceAddress;
        }

        public String getJbusMessageType()
        {
            return jbusMessageType;
        }

        public void setJbusMessageType(String jbusMessageType)
        {
            this.jbusMessageType = jbusMessageType;
        }

        public ConstructionDailyReport getConstructionDailyReport()
        {
            return constructionDailyReport;
        }

        public void setConstructionDailyReport(ConstructionDailyReport constructionDailyReport)
        {
            this.constructionDailyReport = constructionDailyReport;
        }

        public ConstructionDailyUsageReport getConstructionDailyUsageReport()
        {
            return constructionDailyUsageReport;
        }

        public void setConstructionDailyUsageReport(ConstructionDailyUsageReport constructionDailyUsageReport)
        {
            this.constructionDailyUsageReport = constructionDailyUsageReport;
        }

        public ConstructionHourlyReport getConstructionHourlyReport()
        {
            return constructionHourlyReport;
        }

        public void setConstructionHourlyReport(ConstructionHourlyReport constructionHourlyReport)
        {
            this.constructionHourlyReport = constructionHourlyReport;
        }

        public JbusFaultReport getJbusFaultReport()
        {
            return jbusFaultReport;
        }

        public void setJbusFaultReport(JbusFaultReport jbusFaultReport)
        {
            this.jbusFaultReport = jbusFaultReport;
        }

        public JbusHydraulicReport getJbusHydraulicReport()
        {
            return jbusHydraulicReport;
        }

        public void setJbusHydraulicReport(JbusHydraulicReport jbusHydraulicReport)
        {
            this.jbusHydraulicReport = jbusHydraulicReport;
        }

		public JbusDiscoveryReport getJbusDiscoveryReport() {
			return jbusDiscoveryReport;
		}

		public void setJbusDiscoveryReport(JbusDiscoveryReport jbusDiscoveryReport) {
			this.jbusDiscoveryReport = jbusDiscoveryReport;
		}
    }

    @JsonInclude(Include.NON_NULL)
    public static final class IdReportMessage
    {

        public enum IdReportTransportType
        {
            UDP, HTTP, ;

            public static IdReportTransportType getIdReportTransportType(int value)
            {
                for (IdReportTransportType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown IdReportTransportType " + value);
            }
        }

        public enum MobileIdType
        {
            OFF, ESN, IMEI, IMSI, USER_DEFINED, PHONE_NUMBER, CURRENT_IP;
            public static MobileIdType getMobileIdType(int value)
            {
                for (MobileIdType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown MobileIdType " + value);
            }
        }

        private int                   scriptVersion  = 0;
        private int                   configVersion  = 0;
        private java.lang.String      appVersion;
        private int                   vehicleClass   = 0;
        private UnitStatus            unitStatus;
        private int                   modemSelection = 0;
        private int                   applicationId  = 0;
        private MobileIdType          mobileIdType;
        private double                queryId        = 0D;
        private java.lang.String      esn;
        private java.lang.String      imei;
        private java.lang.String      imsi;
        private java.lang.String      min;
        private java.lang.String      iccId;
        private java.lang.String      extension;
        private IdReportTransportType idReportTransportType;
        private boolean               acknowledged;

        public int getScriptVersion()
        {
            return scriptVersion;
        }

        public void setScriptVersion(int scriptVersion)
        {
            this.scriptVersion = scriptVersion;
        }

        public int getConfigVersion()
        {
            return configVersion;
        }

        public void setConfigVersion(int configVersion)
        {
            this.configVersion = configVersion;
        }

        public java.lang.String getAppVersion()
        {
            return appVersion;
        }

        public void setAppVersion(java.lang.String appVersion)
        {
            this.appVersion = appVersion;
        }

        public int getVehicleClass()
        {
            return vehicleClass;
        }

        public void setVehicleClass(int vehicleClass)
        {
            this.vehicleClass = vehicleClass;
        }

        public UnitStatus getUnitStatus()
        {
            return unitStatus;
        }

        public void setUnitStatus(UnitStatus unitStatus)
        {
            this.unitStatus = unitStatus;
        }

        public int getModemSelection()
        {
            return modemSelection;
        }

        public void setModemSelection(int modemSelection)
        {
            this.modemSelection = modemSelection;
        }

        public int getApplicationId()
        {
            return applicationId;
        }

        public void setApplicationId(int applicationId)
        {
            this.applicationId = applicationId;
        }

        public MobileIdType getMobileIdType()
        {
            return mobileIdType;
        }

        public void setMobileIdType(MobileIdType mobileIdType)
        {
            this.mobileIdType = mobileIdType;
        }

        public double getQueryId()
        {
            return queryId;
        }

        public void setQueryId(double queryId)
        {
            this.queryId = queryId;
        }

        public java.lang.String getEsn()
        {
            return esn;
        }

        public void setEsn(java.lang.String esn)
        {
            this.esn = esn;
        }

        public java.lang.String getImei()
        {
            return imei;
        }

        
        public void setImei(java.lang.String imei)
        {
            this.imei = imei;
        }

        public java.lang.String getImsi()
        {
            return imsi;
        }

        public void setImsi(java.lang.String imsi)
        {
            this.imsi = imsi;
        }

        public java.lang.String getMin()
        {
            return min;
        }

        public void setMin(java.lang.String min)
        {
            this.min = min;
        }

        public java.lang.String getIccId()
        {
            return iccId;
        }

        public void setIccId(java.lang.String iccId)
        {
            this.iccId = iccId;
        }

        public java.lang.String getExtension()
        {
            return extension;
        }

        public void setExtension(java.lang.String extension)
        {
            this.extension = extension;
        }

        public IdReportTransportType getIdReportTransportType()
        {
            return idReportTransportType;
        }

        public void setIdReportTransportType(IdReportTransportType idReportTransportType)
        {
            this.idReportTransportType = idReportTransportType;
        }

        public boolean isAcknowledged()
        {
            return acknowledged;
        }

        public void setAcknowledged(boolean acknowledged)
        {
            this.acknowledged = acknowledged;
        }

    }
    @JsonInclude(Include.NON_NULL)
    public static final class UnknownReportRaw {
    	byte[] message;

		public byte[] getMessage() {
			return message;
		}

		public void setMessage(byte[] message) {
			this.message = message;
		}
    	
    }
    @JsonInclude(Include.NON_NULL)
    public static final class OTADownloadMessage {
    	String deviceEsn;
    	String deviceType;
    	String fileType;
    	String fileSize;
    	String resourceVersion;
    	String protocol;
    	String server;
    	String path;
    	String username;
    	String password;
    	String checksum;
    	String applyDate;
    	String attachedDeviceAddress;
    	String deviceIp;
    	Integer devicePort;
    	Integer sequenceId;
    	
    	public String getDeviceEsn() {
			return deviceEsn;
		}

		public void setDeviceEsn(String deviceEsn) {
			this.deviceEsn = deviceEsn;
		}

		public String getDeviceType() {
    		return deviceType;
    	}

    	public void setDeviceType(String deviceType) {
    		this.deviceType = deviceType;
    	}

    	public String getFileType() {
    		return fileType;
    	}

    	public void setFileType(String fileType) {
    		this.fileType = fileType;
    	}

    	public String getFileSize() {
    		return fileSize;
    	}

    	public void setFileSize(String fileSize) {
    		this.fileSize = fileSize;
    	}

    	public String getResourceVersion() {
    		return resourceVersion;
    	}

    	public void setResourceVersion(String resourceVersion) {
    		this.resourceVersion = resourceVersion;
    	}

    	public String getProtocol() {
    		return protocol;
    	}

    	public void setProtocol(String protocol) {
    		this.protocol = protocol;
    	}

    	public String getServer() {
    		return server;
    	}

    	public void setServer(String server) {
    		this.server = server;
    	}

    	public String getPath() {
    		return path;
    	}

    	public void setPath(String path) {
    		this.path = path;
    	}

    	public String getUsername() {
    		return username;
    	}

    	public void setUsername(String username) {
    		this.username = username;
    	}

    	public String getPassword() {
    		return password;
    	}

    	public void setPassword(String password) {
    		this.password = password;
    	}

    	public String getChecksum() {
    		return checksum;
    	}

    	public void setChecksum(String checksum) {
    		this.checksum = checksum;
    	}

    	public String getApplyDate() {
    		return applyDate;
    	}

    	public void setApplyDate(String applyDate) {
    		this.applyDate = applyDate;
    	}

    	public String getAttachedDeviceAddress() {
    		return attachedDeviceAddress;
    	}

    	public void setAttachedDeviceAddress(String attachedDeviceAddress) {
    		this.attachedDeviceAddress = attachedDeviceAddress;
    	}

    	public String getDeviceIp() {
    		return deviceIp;
    	}

    	public void setDeviceIp(String deviceIp) {
    		this.deviceIp = deviceIp;
    	}

    	public Integer getDevicePort() {
    		return devicePort;
    	}

    	public void setDevicePort(Integer devicePort) {
    		this.devicePort = devicePort;
    	}

		public Integer getSequenceId() {
			return sequenceId;
		}

		public void setSequenceId(Integer sequenceId) {
			this.sequenceId = sequenceId;
		}
    }
    
    @JsonInclude(Include.NON_NULL)
    public static final class UnitStatus
    {
        private boolean memoryTest           = false;
        private boolean gpsAntennaStatus     = false;
        private boolean gpsReceiverSelfTest  = false;
        private boolean gpsReceiverTracking  = false;
        private boolean modemMinTest         = false;
        private boolean gpsExceptionReported = false;

        public boolean isMemoryTest()
        {
            return memoryTest;
        }

        public void setMemoryTest(boolean memoryTest)
        {
            this.memoryTest = memoryTest;
        }

        public boolean isGpsAntennaStatus()
        {
            return gpsAntennaStatus;
        }

        public void setGpsAntennaStatus(boolean gpsAntennaStatus)
        {
            this.gpsAntennaStatus = gpsAntennaStatus;
        }

        public boolean isGpsReceiverSelfTest()
        {
            return gpsReceiverSelfTest;
        }

        public void setGpsReceiverSelfTest(boolean gpsReceiverSelfTest)
        {
            this.gpsReceiverSelfTest = gpsReceiverSelfTest;
        }

        public boolean isGpsReceiverTracking()
        {
            return gpsReceiverTracking;
        }

        public void setGpsReceiverTracking(boolean gpsReceiverTracking)
        {
            this.gpsReceiverTracking = gpsReceiverTracking;
        }

        public boolean isModemMinTest()
        {
            return modemMinTest;
        }

        public void setModemMinTest(boolean modemMinTest)
        {
            this.modemMinTest = modemMinTest;
        }

        public boolean isGpsExceptionReported()
        {
            return gpsExceptionReported;
        }

        public void setGpsExceptionReported(boolean gpsExceptionReported)
        {
            this.gpsExceptionReported = gpsExceptionReported;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class CommState
    {
        private boolean available;
        private boolean connected;
        private boolean dataService;
        private boolean networkService;
        private boolean roaming;
        private boolean threeGNetwork;
        private boolean voiceCallIsActive;

        public boolean isAvailable()
        {
            return available;
        }

        public void setAvailable(boolean available)
        {
            this.available = available;
        }

        public boolean isConnected()
        {
            return connected;
        }

        public void setConnected(boolean connected)
        {
            this.connected = connected;
        }

        public boolean isDataService()
        {
            return dataService;
        }

        public void setDataService(boolean dataService)
        {
            this.dataService = dataService;
        }

        public boolean isNetworkService()
        {
            return networkService;
        }

        public void setNetworkService(boolean networkService)
        {
            this.networkService = networkService;
        }

        public boolean isRoaming()
        {
            return roaming;
        }

        public void setRoaming(boolean roaming)
        {
            this.roaming = roaming;
        }

        public boolean isThreeGNetwork()
        {
            return threeGNetwork;
        }

        public void setThreeGNetwork(boolean threeGNetwork)
        {
            this.threeGNetwork = threeGNetwork;
        }

        public boolean isVoiceCallIsActive()
        {
            return voiceCallIsActive;
        }

        public void setVoiceCallIsActive(boolean voiceCallIsActive)
        {
            this.voiceCallIsActive = voiceCallIsActive;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class Inputs
    {
        private boolean ignition;
        private boolean input1;
        private boolean input2;
        private boolean input3;
        private boolean input4;
        private boolean input5;
        private boolean input6;
        private boolean input7;
        private String  value;

        public boolean isIgnition()
        {
            return ignition;
        }

        public void setIgnition(boolean ignition)
        {
            this.ignition = ignition;
        }

        public boolean isInput1()
        {
            return input1;
        }

        public void setInput1(boolean input1)
        {
            this.input1 = input1;
        }

        public boolean isInput2()
        {
            return input2;
        }

        public void setInput2(boolean input2)
        {
            this.input2 = input2;
        }

        public boolean isInput3()
        {
            return input3;
        }

        public void setInput3(boolean input3)
        {
            this.input3 = input3;
        }

        public boolean isInput4()
        {
            return input4;
        }

        public void setInput4(boolean input4)
        {
            this.input4 = input4;
        }

        public boolean isInput5()
        {
            return input5;
        }

        public void setInput5(boolean input5)
        {
            this.input5 = input5;
        }

        public boolean isInput6()
        {
            return input6;
        }

        public void setInput6(boolean input6)
        {
            this.input6 = input6;
        }

        public boolean isInput7()
        {
            return input7;
        }

        public void setInput7(boolean input7)
        {
            this.input7 = input7;
        }

        public String getValue()
        {
            return value;
        }

        public void setValue(String value)
        {
            this.value = value;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class RawDeviceCommandResponse
    {
        private DeviceCommandResponseTypes type;
        private LocateReport               locateReport;
        private IdReport                   idReport;
        private DeviceCommandStatus        deviceCommandStatus;
        private List<Integer>              invalidParameterIds;
        private List<ParameterInfo>        invalidParameterIndexes;
        private List<ParameterInfo>        parameterInfoList;
        private AckMessage                 ackMessage;
        private Date                       received;

        public DeviceCommandResponseTypes getType()
        {
            return type;
        }

        public void setType(DeviceCommandResponseTypes type)
        {
            this.type = type;
        }

        public LocateReport getLocateReport()
        {
            return locateReport;
        }

        public void setLocateReport(LocateReport locateReport)
        {
            this.locateReport = locateReport;
        }

        public DeviceCommandStatus getDeviceCommandStatus()
        {
            return deviceCommandStatus;
        }

        public void setDeviceCommandStatus(DeviceCommandStatus deviceCommandStatus)
        {
            this.deviceCommandStatus = deviceCommandStatus;
        }

        public List<Integer> getInvalidParameterIds()
        {
            return invalidParameterIds;
        }

        public void setInvalidParameterIds(List<Integer> invalidParameterIds)
        {
            this.invalidParameterIds = invalidParameterIds;
        }

        public List<ParameterInfo> getInvalidParameterIndexes()
        {
            return invalidParameterIndexes;
        }

        public void setInvalidParameterIndexes(List<ParameterInfo> invalidParameterIndexes)
        {
            this.invalidParameterIndexes = invalidParameterIndexes;
        }

        public List<ParameterInfo> getParameterInfoList()
        {
            return parameterInfoList;
        }

        public void setParameterInfoList(List<ParameterInfo> parameterInfoList)
        {
            this.parameterInfoList = parameterInfoList;
        }

        public IdReport getIdReport()
        {
            return idReport;
        }

        public void setIdReport(IdReport idReport)
        {
            this.idReport = idReport;
        }

        public AckMessage getAckMessage()
        {
            return ackMessage;
        }

        public void setAckMessage(AckMessage ackMessage)
        {
            this.ackMessage = ackMessage;
        }

        public Date getReceived()
        {
            return received;
        }

        public void setReceived(Date received)
        {
            this.received = received;
        }

        public enum DeviceCommandResponseTypes
        {
            STATUS, READ_RESPONSE, LOCATE_REPORT, ID_REPORT;

            public static DeviceCommandResponseTypes getDeviceCommandResponseTypes(int value)
            {
                for (DeviceCommandResponseTypes type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown DeviceCommandResponseTypes " + value);
            }
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static class IdReport
    {
        private Integer    scriptVersion;
        private Integer    configVersion;
        private String     appVersion;
        private Integer    vehicleClass;
        private UnitStatus unitStatus;
        private Integer    modemSelection;
        private Integer    applicationId;
        private Integer    mobileIdType;
        private Long       queryId;
        private String     esn;
        private String     imei;
        private String     imsi;
        private String     min;
        private String     iccId;
        private String     extension;

        public Integer getScriptVersion()
        {
            return scriptVersion;
        }

        public void setScriptVersion(Integer scriptVersion)
        {
            this.scriptVersion = scriptVersion;
        }

        public Integer getConfigVersion()
        {
            return configVersion;
        }

        public void setConfigVersion(Integer configVersion)
        {
            this.configVersion = configVersion;
        }

        public String getAppVersion()
        {
            return appVersion;
        }

        public void setAppVersion(String appVersion)
        {
            this.appVersion = appVersion;
        }

        public Integer getVehicleClass()
        {
            return vehicleClass;
        }

        public void setVehicleClass(Integer vehicleClass)
        {
            this.vehicleClass = vehicleClass;
        }

        public UnitStatus getUnitStatus()
        {
            return unitStatus;
        }

        public void setUnitStatus(UnitStatus unitStatus)
        {
            this.unitStatus = unitStatus;
        }

        public Integer getModemSelection()
        {
            return modemSelection;
        }

        public void setModemSelection(Integer modemSelection)
        {
            this.modemSelection = modemSelection;
        }

        public Integer getApplicationId()
        {
            return applicationId;
        }

        public void setApplicationId(Integer applicationId)
        {
            this.applicationId = applicationId;
        }

        public Integer getMobileIdType()
        {
            return mobileIdType;
        }

        public void setMobileIdType(Integer mobileIdType)
        {
            this.mobileIdType = mobileIdType;
        }

        public Long getQueryId()
        {
            return queryId;
        }

        public void setQueryId(Long queryId)
        {
            this.queryId = queryId;
        }

        public String getEsn()
        {
            return esn;
        }

        public void setEsn(String esn)
        {
            this.esn = esn;
        }

        public String getImei()
        {
            return imei;
        }

        public void setImei(String imei)
        {
            this.imei = imei;
        }

        public String getImsi()
        {
            return imsi;
        }

        public void setImsi(String imsi)
        {
            this.imsi = imsi;
        }

        public String getMin()
        {
            return min;
        }

        public void setMin(String min)
        {
            this.min = min;
        }

        public String getIccId()
        {
            return iccId;
        }

        public void setIccId(String iccId)
        {
            this.iccId = iccId;
        }

        public String getExtension()
        {
            return extension;
        }

        public void setExtension(String extension)
        {
            this.extension = extension;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class LocateReport
    {
        private long              gpsFixTime;
        private Location          location;
        private HeaderData        altitude;
        private HeaderData        speed;
        private int               heading;
        private int               satellites;
        private FixStatus         fixStatus;
        private int               carrier;
        private HeaderData        rssi;
        private CommState         commState;
        private double            hdop;
        private Inputs            inputs;
        private UnitStatus        unitStatus;
        private List<Accumulator> accumulators;
        private Date              timeOfFix;
        private Date              updateTime;

        public long getGpsFixTime()
        {
            return gpsFixTime;
        }

        public void setGpsFixTime(long gpsFixTime)
        {
            this.gpsFixTime = gpsFixTime;
        }

        public Location getLocation()
        {
            return location;
        }

        public void setLocation(Location location)
        {
            this.location = location;
        }

        public HeaderData getAltitude()
        {
            return altitude;
        }

        public void setAltitude(HeaderData altitude)
        {
            this.altitude = altitude;
        }

        public HeaderData getSpeed()
        {
            return speed;
        }

        public void setSpeed(HeaderData speed)
        {
            this.speed = speed;
        }

        public int getHeading()
        {
            return heading;
        }

        public void setHeading(int heading)
        {
            this.heading = heading;
        }

        public int getSatellites()
        {
            return satellites;
        }

        public void setSatellites(int satellites)
        {
            this.satellites = satellites;
        }

        public FixStatus getFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(FixStatus fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public int getCarrier()
        {
            return carrier;
        }

        public void setCarrier(int carrier)
        {
            this.carrier = carrier;
        }

        public HeaderData getRssi()
        {
            return rssi;
        }

        public void setRssi(HeaderData rssi)
        {
            this.rssi = rssi;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public double getHdop()
        {
            return hdop;
        }

        public void setHdop(double hdop)
        {
            this.hdop = hdop;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public UnitStatus getUnitStatus()
        {
            return unitStatus;
        }

        public void setUnitStatus(UnitStatus unitStatus)
        {
            this.unitStatus = unitStatus;
        }

        public List<Accumulator> getAccumulators()
        {
            return accumulators;
        }

        public void setAccumulators(List<Accumulator> accumulators)
        {
            this.accumulators = accumulators;
        }

        public Date getTimeOfFix()
        {
            return timeOfFix;
        }

        public void setTimeOfFix(Date timeOfFix)
        {
            this.timeOfFix = timeOfFix;
        }

        public Date getUpdateTime()
        {
            return updateTime;
        }

        public void setUpdateTime(Date updateTime)
        {
            this.updateTime = updateTime;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static class Accumulator
    {
        private Integer index;
        private byte[]  accumulatorValue;

        public Integer getIndex()
        {
            return index;
        }

        public void setIndex(Integer index)
        {
            this.index = index;
        }

        public byte[] getAccumulatorValue()
        {
            return accumulatorValue;
        }

        public void setAccumulatorValue(byte[] accumulatorValue)
        {
            this.accumulatorValue = accumulatorValue;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class Location
    {
        private double  latitude;
        private double  longitude;
        private boolean fixStatus;
        private Address address;

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        public boolean isFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class DeviceCommandStatus
    {
        private DeviceCommandStatuses status;
        private java.lang.String      statusMessage;

        public enum DeviceCommandStatuses
        {
            SUCCESS, ERROR, ;
            public static DeviceCommandStatuses getDeviceCommandStatuses(int value)
            {
                for (DeviceCommandStatuses type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown DeviceCommandStatuses " + value);
            }
        }

        public DeviceCommandStatuses getStatus()
        {
            return status;
        }

        public void setStatus(DeviceCommandStatuses status)
        {
            this.status = status;
        }

        public java.lang.String getStatusMessage()
        {
            return statusMessage;
        }

        public void setStatusMessage(java.lang.String statusMessage)
        {
            this.statusMessage = statusMessage;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static class ParameterInfo
    {

        private Integer parameterId;
        private Integer parameterIndex;
        private byte[]  parameterData;

        /*
         * public ParameterId getParameterId() { return parameterId; }
         * 
         * public void setParameterId(ParameterId parameterId) { this.parameterId = parameterId; }
         */

        public Integer getParameterId()
        {
            return parameterId;
        }

        public void setParameterId(Integer parameterId)
        {
            this.parameterId = parameterId;
        }

        public Integer getParameterIndex()
        {
            return parameterIndex;
        }

        public void setParameterIndex(Integer parameterIndex)
        {
            this.parameterIndex = parameterIndex;
        }

        public byte[] getParameterData()
        {
            return parameterData;
        }

        public void setParameterData(byte[] parameterData)
        {
            this.parameterData = parameterData;
        }

        public enum ParameterId
        {

            NULL_PARAMETER(0, 0),
            // PEG PARAMETERS
            INPUT_EQUATE(256, 1), SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD(257, 2), SPEED_TRIGGER_CONTROLS_DEBOUNCE_TIMER(258, 1), SPEED_TRIGGER_CONTROLS_DELAY_SPEED_BELOW_TIMER(
                    259, 1), SPEED_TRIGGER_CONTROLS_DELAY_SPEED_ABOVE_TIMER(260, 1), ZONE_DEFINITION(261, 18), TIME_DISTANCE_PROFILE_TIME_ELAPSED(
                    262, 4), TIME_DISTANCE_PROFILE_DISTANCE_TRAVELLED(263, 4), TIME_DISTANCE_PROFILE_HEADING_CHANGE(264, 1), TIMER_TIMEOUT(265, 4), ACCUMULATOR_THRESHOLD(
                    266, 4), TIME_OF_DAY_SETTING_TIMER(267, 4), TIME_OF_DAY_SETTING_REPEAT_INTERVAL(268, 2), DAY_OF_WEEK(269, 2), INPUT_TRIGGER_CONTROLS_DEBOUCE_TIMER(
                    270, 1), INPUT_TRIGGER_CONTROLS_DELAY_INPUT_HIGH_TIMER(271, 1), INPUT_TRIGGER_CONTROLS_DELAY_INPUT_LOW_TIMER(272, 1), ENVIRONMENT_MASK(
                    273, 8), TIME_DISTANCE_PROFILE_MINIMUM_TIME_INTERVAL(275, 4), AD_THRESHOLD(276, 2), ACCELERATION_THRESHOLD(277, 4), ACCELERATION_SAMPLE_COUNT(
                    278, 1), ACCUMULATOR_TYPE_DESIGNATION(279, 1), ACCUMULATOR_INDEX(280, 1), ACCELERATION_AVERAGE_WINDOW(282, 1), ACCELERATION_THRESHOLD2(
                    283, 2), // no idea why there are two of them,
            ACCELERATION_MINIMUM_DURATION(284, 2), ACCELERATION_MAXIMUM_DURATION(285, 2), WINDOWS_BASED_SCHEDULING(286, 24), CONDITION_GROUP(287, 16), TIME_DATE_MASK_HOUR_OF_DAY(
                    288, 4), TIME_DATE_MASK_DAY_OF_WEEK(289, 1), TIME_DATE_MASK_MONTH_OF_YEAR(290, 2), EVENT_RECORD(512, 8), EVENT_RECORD_PAGE_2(513,
                    8), EVENT_RECORD_PAGE_3(514, 8),
            // report contents parameters
            INBOUND_IP_ADDRESS_LIST(768, 4), INBOUND_PORT_LIST(769, 2), ACCUMULATOR_COUNT_BY_EVENT_CODE(770, 2), INBOUND_RETRY_SCHEDULE(771, 1), INBOUND_EVENT_REPORT_CONTENTS(
                    772, 4), LOGGED_EVENT_REPORT_CONTENTS(773, 4), LOCAL_UDP_PORT(774, 2), COMM_ROUTE(775, 1), ACCUMULATOR_REPORTING_FORMAT_SELECTION(
                    776, 1), MAP_OF_REPORTED_ACCUMULATORS(777, 4), LOG_MESSAGE_LIMIT(778, 1), EVENT_REPORT_TABLE(779, 1), TCP_INACTIVE_TIMEOUT(780, 1),
            // Acceleration Motion Parameters
            ACCELERATION_MOTION_MODE(896, 1), ACCELERATION_MOTION_PERIOD(897, 1), ACCELERATION_MOTION_IMPACT_CONFIG_2(898, 1), ACCELERATION_MOTION_IMPACT_CONFIG_1(
                    899, 1), ACCELERATION_MOTION_INTERVAL(900, 1), ACCELERATION_MOTION_THRESHOLD(901, 2),
            // General Config Parameters
            S_REGISTERS(1024, 2), SERVICE_ENABLES(1025, 2), MDT_ENABLES(1026, 2), GPS_LOSS_TIMEOUT(1027, 4), GPS_LAST_KNOWN_TIMEOUT(1028, 4), INPUT_WAKE_UP_MONITOR(
                    1029, 2), LOCAL_TIME_ZONE(1030, 2), LOG_RETRY_TIMER_IGNITION_ON(1031, 4), LOG_RETRY_ATTEMPTS_IGNITION_ON(1032, 1), LOG_RETRY_TIMER_IGNITION_OFF(
                    1033, 4), LOG_RETRY_ATTEMPTS_IGNITION_OFF(1034, 1), MOVING_SPEED_THRESHOLD(1035, 2), USER_FLAG(1036, 2), PEG_ENABLES(1037, 4), MOTION_COUNT_LOW(
                    1038, 1), MOTION_COUNT_HIGH(1039, 1), MOTION_COUNT_MAXIMUM(1040, 1), MOTION_WINDOW(1041, 1), BATTERY_CAPACITY(1042, 1), MOTION_LOG_INTERVAL(
                    1043, 2), TIMEZONE_OFFSET(1044, 2), DST_RULE(1045, 1), DTS_PARAMETERS(1046, 4),
            // Access Parameters
            ACCESS_ENABLES(1280, 2), ACCESS_IP_ADDRESS_LIST(1281, 4), REMOTE_HOST_IP_ADDRESS_LIST(1282, 4), PRIMARY_PORT_PASSWORD(1283, 4), MODEM_PASSWORD(
                    1284, 4), MODEM_SIM_PIN(1285, 4),
            // NETWORK PARAMETERS
            NETWORK_DISCRIMINANT_TYPE(1536, 1), NETWORK_DISCRIMINANT_CONDITION(1537, 1), NETWORK_DISCRIMINANT_VALUE(1538, 2), NETWORK_SIDE_PREFERENCE(
                    1539, 1), NETWORK_SLEEP_SETTINGS(1540, 1),
            // Version Parameter
            LMU_APPLICATION_VERSION(1792, 1),
            // TAIP Parameter
            TAIP_ENABLES(2048, 2), TAIP_MESSAGE_SELECTION(2049, 2), TAIP_VEHICLE_ID(2050, 1), LMU_TAIP_LISTENING_PORT(2051, 2), TAIP_REMOTE_IP_ADDRESS(
                    2052, 4), TAIP_REMOTE_PORT(2053, 2),
            // Bluetooth Parameter
            BLUETOOTH_NAME(2080, 16), BLUETOOTH_PIN(2081, 4),
            // Text String Parameters
            TEXT_STRING_LONG(2176, 64), TEXT_STRING_SHOT(2177, 16),
            // Comm Config Parameters,
            MOBILE_ID_USER_DEFINED(2304, 17), MOBILE_ID_MIN(2305, 17), GPRS_CONTEXT_STRING(2306, 64), GPRS_CONTEXT_CURRENT_INDEX(2307, 1), USER_STRING(
                    2308, 17), PASSWORD_STRING(2309, 17), MAINTENANCE_MESSAGE_INBOUND_IP_ADDRESS(2310, 4), MAINTENANCE_MESSAGE_INBOUND_PORT(2311, 2), MAINTENANCE_MESSAGE_CONFIGURATION(
                    2312, 2), NULL_MESSAGE_INTERVAL(2313, 2), NETWORK_USERNAME(2314, 64), NETWORK_PASSWORD(2315, 16), PACKET_DIAL_STRING(2316, 16), PACKET_DIAL_STRING_CURRENT_INDEX(
                    2317, 1), PRL_DIAL_STRING(2318, 16), INBOUND_URL(2319, 64), MAINTENANCE_MESSAGE_URL(2320, 64), SMS_INBOUND_ADDRESS(2321, 16), MAINTENANCE_MESSAGE_INTERVAL(
                    2322, 4), CALLER_ID_STRING(2323, 16), ACCUMULATOR_VALUE(2560, 4),
            // Server Parameters
            LATITUDE(2816, 4), LONGITUDE(2817, 4), SERVER_URL(2818, 65), SERVER_ADDRESS(2819, 4), SERVER_PORT(2820, 2), SERVER_USER_NAME(2821, 65), SERVER_PASSWORD(
                    2822, 17), SERVER_REQUEST(2823, 1), SERVER_POSITION_ACCURACY(2824, 2), SERVER_LATENCY(2825, 1),
            // Stream Port Parameters
            STREAM_ASSIGNMENT(3072, 1), STREAM_BAUD_RATE(3073, 1), STREAM_WORD_DEFINITION(3074, 1),
            // WIFI Parameters
            WIFI_PROFILE_INDEX(3200, 1), WIFI_STATION_MODE(3201, 1), WIFI_ENCRYPTION(3202, 1), WIFI_IP_MODE(3203, 1), WIFI_KEY_INDEX(3204, 1), WIFI_SSID(
                    3205, 65), WIFI_KEY(3206, 65), WIFI_DOMAIN_NAME(3207, 65), WIFI_IP_ADDRESS(3208, 4), WIFI_NETWMASK(3209, 4), WIFI_DEFAULT_ROUTE(
                    3210, 4), WIFI_(3211, 4),
            // VBus Parameters
            VBUS_PARAMETER_ID(3328, 1), VBUS_INDICATOR_ID(3329, 1), VBUS_INDICATORENABLE_BIT_MAP(3330, 2), VBUS_DTC_FILTER_TEXT(3331, 9), VBUS_IGNITION_ON_VOLTAGE(
                    3332, 2), VBUS_SAMPLING_INTERVAL(3333, 2);

            private int value;
            private int dataLength;

            private ParameterId(int value, int length)
            {
                this.value = value;
                this.dataLength = length;
            }

            public int getDataLength()
            {
                return dataLength;
            }

            public int getValue()
            {
                return value;
            }
            

            public static ParameterId getParameterId(int value)
            {
                for (ParameterId type : values())
                {
                    if (type.value == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown ParameterId " + value);
            }
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static class MotionLogsMessage
    {
        List<MotionLogInfo>         motionLogInfo = new ArrayList<MotionLogInfo>();
        private LocationInformation locationInformation;
        private long                locationTime;
        private long                deviceId;
        private java.lang.String    externalDeviceId;
        private int                 recordType;

        public List<MotionLogInfo> getMotionLogInfo()
        {
            return motionLogInfo;
        }

        public void setMotionLogInfo(List<MotionLogInfo> motionLogInfo)
        {
            this.motionLogInfo = motionLogInfo;
        }

        public LocationInformation getLocationInformation()
        {
            return locationInformation;
        }

        public void setLocationInformation(LocationInformation locationInformation)
        {
            this.locationInformation = locationInformation;
        }

        public long getLocationTime()
        {
            return locationTime;
        }

        public void setLocationTime(long locationTime)
        {
            this.locationTime = locationTime;
        }

        public long getDeviceId()
        {
            return deviceId;
        }

        public void setDeviceId(long deviceId)
        {
            this.deviceId = deviceId;
        }

        public java.lang.String getExternalDeviceId()
        {
            return externalDeviceId;
        }

        public void setExternalDeviceId(java.lang.String externalDeviceId)
        {
            this.externalDeviceId = externalDeviceId;
        }

        public int getRecordType()
        {
            return recordType;
        }

        public void setRecordType(int recordType)
        {
            this.recordType = recordType;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static class MotionLogInfo
    {
        private Double  latitude;
        private Double  longitude;
        private Integer speed;
        private Integer heading;
        private Integer satellites;
        private Date    timeOfFix;
        private String  forwardAcceleration;
        private String  lateralAcceleration;
        private String  verticalAcceleration;
        private Long    systemTick;
        private String  accelerationAmplitude;
        private Double  hdop;
        private String  vehicleBusRPM;
        private String  vehicleBusSpeed;
        private Double  altitude;

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Integer getSpeed()
        {
            return speed;
        }

        public void setSpeed(Integer speed)
        {
            this.speed = speed;
        }

        public Integer getHeading()
        {
            return heading;
        }

        public void setHeading(Integer heading)
        {
            this.heading = heading;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }

        public String getForwardAcceleration()
        {
            return forwardAcceleration;
        }

        public void setForwardAcceleration(String forwardAcceleration)
        {
            this.forwardAcceleration = forwardAcceleration;
        }

        public String getLateralAcceleration()
        {
            return lateralAcceleration;
        }

        public void setLateralAcceleration(String lateralAcceleration)
        {
            this.lateralAcceleration = lateralAcceleration;
        }

        public String getVerticalAcceleration()
        {
            return verticalAcceleration;
        }

        public void setVerticalAcceleration(String verticalAcceleration)
        {
            this.verticalAcceleration = verticalAcceleration;
        }

        public Long getSystemTick()
        {
            return systemTick;
        }

        public void setSystemTick(Long systemTick)
        {
            this.systemTick = systemTick;
        }

        public String getAccelerationAmplitude()
        {
            return accelerationAmplitude;
        }

        public void setAccelerationAmplitude(String accelerationAmplitude)
        {
            this.accelerationAmplitude = accelerationAmplitude;
        }

        public Double getHdop()
        {
            return hdop;
        }

        public void setHdop(Double hdop)
        {
            this.hdop = hdop;
        }

        public String getVehicleBusRPM()
        {
            return vehicleBusRPM;
        }

        public void setVehicleBusRPM(String vehicleBusRPM)
        {
            this.vehicleBusRPM = vehicleBusRPM;
        }

        public String getVehicleBusSpeed()
        {
            return vehicleBusSpeed;
        }

        public void setVehicleBusSpeed(String vehicleBusSpeed)
        {
            this.vehicleBusSpeed = vehicleBusSpeed;
        }

        public Double getAltitude()
        {
            return altitude;
        }

        public void setAltitude(Double altitude)
        {
            this.altitude = altitude;
        }

        public Date getTimeOfFix()
        {
            return timeOfFix;
        }

        public void setTimeOfFix(Date timeOfFix)
        {
            this.timeOfFix = timeOfFix;
        }
    }
}
