package com.calamp.connect.models.messaging.converter;



import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Accumulator;

import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.DataReportParameter;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.J1939Dtc2Code;
import com.calamp.connect.models.messaging.J1939DtcBlock;
import com.calamp.connect.models.messaging.Jpod2DTCReport;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.HexUtil;
import ma.glasnost.orika.MapperFacade;

@Component("networkToJpod2DTCReportConverter")
public class NetworkToJpod2DTCReportConverter extends GenericNetworkToDeviceEventConverter{
	public Jpod2DTCReport convert(NetworkMessage network)
	{
		MapperFacade mapper = mapperFactory.getMapperFacade();
        Jpod2DTCReport appMessage = mapper.map(network, Jpod2DTCReport.class);
        appMessage.setMessageType(NetworkMessageType.DTC_REPORT);
        if(network.getMessageDetail() != null){
        	appMessage.setEventTime(new Date(network.getMessageDetail().getLocationTime()));
        	appMessage.setEventCode(network.getMessageDetail().getEventCode());
        }
        if(appMessage.getEventTime() == null)
        {
        	//missing header, give current time for searches - fix status will be false
        	appMessage.setEventTime(new Date());
        }
        
        if(network.getRawJbusMessage() != null) {
        	appMessage.setAppMessageType(network.getRawJbusMessage().getJbusMessageType());
        	if(network.getRawJbusMessage().getUnknownReportRaw() != null){
        		appMessage.setAppMessageMessage(network.getRawJbusMessage().getUnknownReportRaw().getMessage());
        	}
        }
        
        
        if (network.getRawAccumulators() != null)
        {
            List<Accumulator> rawAccumulators = new ArrayList<Accumulator>(network.getRawAccumulators().size());
            int i = 0;
            for (Long rawAccumulator : network.getRawAccumulators())
            {
                if (rawAccumulator != -1)
                {
                    Accumulator acc = new Accumulator();
                    acc.setLabel("Accumulator " + i);
                    acc.setIndex(String.valueOf(i));
                    acc.setValue(String.valueOf(rawAccumulator));
                    rawAccumulators.add(acc);
                }
                i = i + 1;
            }
            AvlDeviceData deviceData = new AvlDeviceData();
            deviceData.setAccumulators(rawAccumulators);

            HeaderData headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getRssi()));
            deviceData.setRssi(headerData);

            headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getAltitude()));
            deviceData.setAltitude(headerData);

            headerData = new HeaderData();
            if(network.getMessageDetail() != null && network.getMessageDetail().getSpeed() != null){
            	headerData.setValue(String.valueOf(network.getMessageDetail().getSpeed()));
            } else if(network.getMessageDetail().getMiniSpeed() !=null){
            	//kp/h to cm/s
            	headerData.setValue(String.valueOf((int) (network.getMessageDetail().getMiniSpeed()*1000/36)));
            } else {
            	headerData.setValue("0");
            }
            deviceData.setGpsSpeed(headerData);

            appMessage.setDeviceData(deviceData);
            AvlDeviceData deviceDataConverted = new AvlDeviceData();	
            deviceDataConverted.setAccumulators(rawAccumulators);
            appMessage.setDeviceDataConverted(deviceDataConverted);
        }

        //do the jpod2 dance
        ByteBuffer byteBuffer = ByteBuffer.wrap(network.getRawJbusMessage().getUnknownReportRaw().getMessage());
        List<J1939DtcBlock> j1939blocks = new ArrayList<J1939DtcBlock> ();
        
        while(byteBuffer.remaining() > 0){
        	byte blockType = byteBuffer.get();
        	int blockTypeInt = Byte.toUnsignedInt(blockType);
        	byte[] blockTypeArray = new byte[1];
        	blockTypeArray[0] = blockType;
        	int blockLength = Byte.toUnsignedInt(byteBuffer.get());
        	boolean [] blockTypeBits = BitUtil.getBits(blockType);
        	if((blockTypeInt & 0x3) == 0){
        		J1939DtcBlock block = new J1939DtcBlock();
        		List<J1939Dtc2Code>	codes = new ArrayList<J1939Dtc2Code>();
        		block.setTypeHexValue(HexUtil.convertToHexString(blockTypeArray));
        		block.setLength(blockLength);
        		block.setHasSourceAddress(blockTypeBits[3]);
        		block.setUnreportedDTCsOnly(blockTypeBits[4]);
        		byte lampByte = byteBuffer.get();
        		byte flashLampByte = byteBuffer.get();
        		blockLength -= 2;
        		byte[] lampByteArray = new byte[1];
        		lampByteArray[0] = lampByte;
        		block.setLampHexValue(HexUtil.convertToHexString(lampByteArray));
        		byte[] flashLampByteArray = new byte[1];
        		flashLampByteArray[0] = flashLampByte;
        		block.setFlashLampHexValue(HexUtil.convertToHexString(flashLampByteArray));
        		while(blockLength > 0)
        		{
        			J1939Dtc2Code code = new J1939Dtc2Code();
        			if(block.getHasSourceAddress())
        			{
        				code.setSourceAddress(Byte.toUnsignedInt(byteBuffer.get()));
        				blockLength--;
        			}
        			int spn = Byte.toUnsignedInt(byteBuffer.get());
        			spn+= 256 * Byte.toUnsignedInt(byteBuffer.get());
        			int byte3value = Byte.toUnsignedInt(byteBuffer.get());
        			spn += (byte3value & 0xE0) / 16 * 256 * 256;
        			code.setSpn(spn);
        			code.setFmi(byte3value & 0x1f);
        			int byte4value = Byte.toUnsignedInt(byteBuffer.get());
        			code.setOccurrenceCount(byte4value & 0x7f);
        			code.setConversionMethod(byte4value / 128);
        			blockLength -= 4;
        			codes.add(code);
        		}
        		block.setCodes(codes);
        		j1939blocks.add(block);
        	}
        	
        }
        appMessage.setJ1939DtcBlocks(j1939blocks);
        return appMessage;
		
		
	}
}
