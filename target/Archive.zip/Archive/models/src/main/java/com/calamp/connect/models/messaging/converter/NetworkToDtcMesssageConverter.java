package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.DtcDeviceData;
import com.calamp.connect.models.messaging.DtcEventV2;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.network.Network.NetworkMessage;

/**
 * @author Anand
 *
 */
@Component("networkToDtcMesssageConverter")
public class NetworkToDtcMesssageConverter extends GenericNetworkToDeviceEventConverter
{

    public DtcEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        DtcEventV2 dtcEvent = mapper.map(network, DtcEventV2.class);
        dtcEvent.setEventTime(new Date(network.getRawDtcMessage().getLocationTime()));

        dtcEvent.setDtcCodesList(network.getRawDtcMessage().getDtcCodes());
        DtcDeviceData deviceData = new DtcDeviceData();

        HeaderData headerData = new HeaderData();
        headerData.setValue(String.valueOf(network.getRawDtcMessage().getLocationInformation().getRssi()));
        deviceData.setRssi(headerData);

        headerData = new HeaderData();
        headerData.setValue(String.valueOf(network.getRawDtcMessage().getLocationInformation().getSpeed()));
        deviceData.setGpsSpeed(headerData);

        dtcEvent.setDeviceData(deviceData);

        DtcDeviceData deviceDataConverted = new DtcDeviceData();
        dtcEvent.setDeviceDataConverted(deviceDataConverted);

        return dtcEvent;
    }

}
