package com.calamp.connect.models.messaging;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.annotation.XmlTransient;

import com.calamp.connect.models.hateos.AssetLink;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;
import com.calamp.focis.framework.hateoas.Link;
import com.calamp.focis.framework.model.GenericModel;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Queryable;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlTransient
@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, include = JsonTypeInfo.As.PROPERTY, property = "@class")
public class DeviceEvent
{
    private String                                                               deviceAirId;
    private String                                                               deviceEsn;
    private Long                                                                 deviceMessageSequenceNumber;
    private Long                                                                 deviceId;
    // @JsonIgnore
    private String                                                               pegBehaviorId;
    private Date                                                                 eventTime;
    private String                                                               messageUuid;
    private AssetLink                                                            asset;
    private String                                                               assetName;
    private Long                                                                 assetId;
    // @JsonIgnore
    private NetworkMessageType                                                   messageType;
    private Long                                                                 lmdirectMessageType;

    // @JsonIgnore
    private Long                                                                 messageReceivedTime;
    private Date                                                                 timeOfFix;
    private String                                                               rawDeviceHexMessage;
    // @JsonIgnore
    private String                                                               deviceIp;
    // @JsonIgnore
    private Integer                                                              port;
    private Link                                                                 account;
    private Integer                                                              eventCode;
    private Inputs                                                               inputs;
    private String                                                               eventType;
    // @JsonIgnore
    private DeviceData                                                           deviceData;
    private DeviceData                                                           deviceDataConverted;
    private VinResponse                                                          vinResponse;
    private String                                                               vin;
    public static final String                                                   JSON_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private Map<String, String>                                                  searchFieldsDisplay  = null;
    private Map<String, SearchableField>                                         searchFieldMap       = null;
    private static final Map<Class<? extends DeviceEvent>, Set<SearchableField>> queryables           = new ConcurrentHashMap<>(500, 1.0f);
    private Long                                                                 accountId;
    private String                                                               accountName;
    private String                                                               deviceName;
    private Link                                                                 route;
    private Long                                                                 routeId;
    private List<Link>                                                           operators;
    private List<Long>                                                           operatorIds;
    private Long                                                                 primaryOperator;
    private OptionsExtension                                                     optionsExtension;

    public DeviceEvent()
    {
        buildSearchableDisplayMap();
    }

    public String getDeviceAirId()
    {
        return deviceAirId;
    }

    @Queryable(modelProperty = "deviceEsn", domainProperty = "externalDeviceId", domainPropertyType = String.class)
    public String getDeviceEsn()
    {
        return deviceEsn;
    }

    @Queryable(modelProperty = "deviceId", domainProperty = "deviceGuid", domainPropertyType = Long.class)
    public Long getDeviceId()
    {
        return deviceId;
    }

    @JsonFormat(shape = Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    @Queryable(modelProperty = "eventTime", domainProperty = "locationTime", domainPropertyType = Date.class)
    public Date getEventTime()
    {
        return eventTime;
    }

    public Long getLmdirectMessageType()
    {
        return lmdirectMessageType;
    }

    public void setLmdirectMessageType(Long lmdirectMessageType)
    {
        this.lmdirectMessageType = lmdirectMessageType;
    }

    @JsonFormat(shape = Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    @Queryable(modelProperty = "timeOfFix", domainProperty = "timeOfFix", domainPropertyType = Date.class)
    public Date getTimeOfFix()
    {
        return timeOfFix;
    }

    public void setTimeOfFix(Date timeOfFix)
    {
        this.timeOfFix = timeOfFix;
    }

    public void setDeviceAirId(String deviceAirId)
    {
        this.deviceAirId = deviceAirId;
    }

    public void setDeviceEsn(String deviceEsn)
    {
        this.deviceEsn = deviceEsn;
    }

    public void setDeviceId(Long deviceId)
    {
        this.deviceId = deviceId;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public String getPegBehaviorId()
    {
        return pegBehaviorId;
    }

    public void setPegBehaviorId(String pegBehaviorId)
    {
        this.pegBehaviorId = pegBehaviorId;
    }

    public void setEventTime(Date eventTime)
    {
        this.eventTime = eventTime;
    }

    public String getMessageUuid()
    {
        return messageUuid;
    }

    public void setMessageUuid(String uuid)
    {
        this.messageUuid = uuid;
    }

    public AssetLink getAsset()
    {
        return asset;
    }

    public void setAsset(AssetLink asset)
    {
        this.asset = asset;
    }

    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public String getAssetName()
    {
        return assetName;
    }

    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    @Queryable(modelProperty = "assetId", domainProperty = "assetId", domainPropertyType = Long.class)
    public Long getAssetId()
    {
        return assetId;
    }

    public void setAssetName(String assetName)
    {
        this.assetName = assetName;
    }

    public void setAssetId(Long assetId)
    {
        this.assetId = assetId;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public NetworkMessageType getMessageType()
    {
        return messageType;
    }

    public void setMessageType(NetworkMessageType messageType)
    {
        this.messageType = messageType;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public Long getMessageReceivedTime()
    {
        return messageReceivedTime;
    }

    public void setMessageReceivedTime(Long messageReceivedTime)
    {
        this.messageReceivedTime = messageReceivedTime;
    }

    public String getRawDeviceHexMessage()
    {
        return rawDeviceHexMessage;
    }

    public void setRawDeviceHexMessage(String rawDeviceHexMessage)
    {
        this.rawDeviceHexMessage = rawDeviceHexMessage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public String getDeviceIp()
    {
        return deviceIp;
    }

    public void setDeviceIp(String deviceIp)
    {
        this.deviceIp = deviceIp;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public Integer getPort()
    {
        return port;
    }

    public void setPort(Integer port)
    {
        this.port = port;
    }

    public Long getDeviceMessageSequenceNumber()
    {
        return deviceMessageSequenceNumber;
    }

    public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
    {
        this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
    }

    public Link getAccount()
    {
        return account;
    }

    public void setAccount(Link account)
    {
        this.account = account;
    }

    public Integer getEventCode()
    {
        return eventCode;
    }

    public void setEventCode(Integer eventCode)
    {
        this.eventCode = eventCode;
    }

    public Inputs getInputs()
    {
        return inputs;
    }

    public void setInputs(Inputs inputs)
    {
        this.inputs = inputs;
    }

    public String getEventType()
    {
        return eventType;
    }

    public void setEventType(String eventType)
    {
        this.eventType = eventType;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public DeviceData getDeviceData()
    {
        return deviceData;
    }

    public void setDeviceData(DeviceData deviceData)
    {
        this.deviceData = deviceData;
    }

    public DeviceData getDeviceDataConverted()
    {
        return deviceDataConverted;
    }

    public void setDeviceDataConverted(DeviceData deviceDataConverted)
    {
        this.deviceDataConverted = deviceDataConverted;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public VinResponse getVinResponse()
    {
        return vinResponse;
    }

    public void setVinResponse(VinResponse vinResponse)
    {
        this.vinResponse = vinResponse;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public String getVin()
    {
        return vin;
    }

    public void setVin(String vin)
    {
        this.vin = vin;
    }

    public final void buildSearchableDisplayMap()
    {
        Set<SearchableField> searchableFields = initializeQuerablesCache(getClass());
        if (searchableFields == null || searchableFields.isEmpty())
            return;

        searchFieldsDisplay = new TreeMap<String, String>();
        searchFieldMap = new HashMap<String, SearchableField>(searchableFields.size(), 1.0f);
        for (SearchableField f : searchableFields)
        {
            searchFieldsDisplay.put(String.format("%s (%s[])", f.modelProperty, f.type.getSimpleName().toLowerCase()), f.notes);
            searchFieldMap.put(f.modelProperty, f);
        }
    }

    private final Set<SearchableField> initializeQuerablesCache(Class<? extends DeviceEvent> modelClass)
    {
        Set<SearchableField> result = null;
        if (modelClass == DeviceEvent.class)
            return result;

        if ((result = queryables.get(modelClass)) != null)
            return result;

        Queryable ann = null;
        result = new TreeSet<SearchableField>();
        for (Method m : modelClass.getMethods())
            if ((ann = m.getAnnotation(Queryable.class)) != null)
            {
                result.add(new SearchableField(modelClass, ann.modelProperty(), ann.domainProperty(), ann.domainPropertyType(), ann.notes()));
                if (GenericModel.class.isAssignableFrom(ann.domainPropertyType()))
                    initializeQuerablesCache(ann.domainPropertyType());
            }

        for (Field f : modelClass.getFields())
            if ((ann = f.getAnnotation(Queryable.class)) != null)
                result.add(new SearchableField(modelClass, ann.modelProperty(), ann.domainProperty(), ann.domainPropertyType(), ann.notes()));

        queryables.put(modelClass, result);
        return result;
    }

    @JsonIgnore
    @XmlTransient
    public Map<String, SearchableField> getSearchableFields()
    {
        return searchFieldMap;
    }

    @JsonIgnore
    @XmlTransient
    public Map<String, String> getSearchFieldsDisplay()
    {
        return searchFieldsDisplay;
    }

    public void setSearchFieldsDisplay(Map<String, String> searchMap)
    {
        searchFieldsDisplay = searchMap;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    @Queryable(modelProperty = "accountId", domainProperty = "accountId", domainPropertyType = Long.class)
    public Long getAccountId()
    {
        return accountId;
    }

    public void setAccountId(Long accountId)
    {
        this.accountId = accountId;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public String getAccountName()
    {
        return accountName;
    }

    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public String getDeviceName()
    {
        return deviceName;
    }

    public void setDeviceName(String deviceName)
    {
        this.deviceName = deviceName;
    }

    public Link getRoute()
    {
        return route;
    }

    public void setRoute(Link route)
    {
        this.route = route;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public Long getRouteId()
    {
        return routeId;
    }

    public void setRouteId(Long routeId)
    {
        this.routeId = routeId;
    }

    public List<Link> getOperators()
    {
        return operators;
    }

    public void setOperators(List<Link> operatorLinks)
    {
        this.operators = operatorLinks;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public List<Long> getOperatorIds()
    {
        return operatorIds;
    }

    public void setOperatorIds(List<Long> operatorIds)
    {
        this.operatorIds = operatorIds;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public Long getPrimaryOperator()
    {
        return primaryOperator;
    }

    public void setPrimaryOperator(Long primaryOperator)
    {
        this.primaryOperator = primaryOperator;
    }

    /**
     * @return optionsExtension
     */
    public OptionsExtension getOptionsExtension()
    {
        return optionsExtension;
    }

    /**
     * @param optionsExtension
     */
    public void setOptionsExtension(OptionsExtension optionsExtension)
    {
        this.optionsExtension = optionsExtension;
    }
   
}
