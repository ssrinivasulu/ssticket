package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@XmlRootElement(name = "dataReportContents")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("dataReportContents")
@JsonTypeName("dataReportContents")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType (propOrder = {"dataOptionsValue","sizeFieldIncluded","parameterDataSourceFieldIncluded","parameterSourceAddressFieldIncluded","paramaterIDFieldIncluded","dataPostionFieldIncluded","reportID","machineState","parameterGroup","parameterList"})
@JsonPropertyOrder ( {"dataOptionsValue","sizeFieldIncluded","parameterDataSourceFieldIncluded","parameterSourceAddressFieldIncluded","paramaterIDFieldIncluded","dataPostionFieldIncluded","reportID","machineState","parameterGroup","parameterList"})
public class DataReportContents {
		private Integer dataOptionsValue;
		private Boolean sizeFieldIncluded;
		private Boolean parameterDataSourceFieldIncluded;
		private Boolean parameterSourceAddressFieldIncluded;
		private Boolean paramaterIDFieldIncluded;
		private Boolean dataPostionFieldIncluded;
		private Integer reportID;
		private Integer machineState;
		private Integer parameterGroup;
		private List<DataReportParameter> parameterList;
		public Integer getDataOptionsValue() {
			return dataOptionsValue;
		}
		public void setDataOptionsValue(Integer dataOptionsValue) {
			this.dataOptionsValue = dataOptionsValue;
		}
		public Boolean getSizeFieldIncluded() {
			return sizeFieldIncluded;
		}
		public void setSizeFieldIncluded(Boolean sizeFieldIncluded) {
			this.sizeFieldIncluded = sizeFieldIncluded;
		}
		public Boolean getParameterDataSourceFieldIncluded() {
			return parameterDataSourceFieldIncluded;
		}
		public void setParameterDataSourceFieldIncluded(Boolean parameterDataSourceFieldIncluded) {
			this.parameterDataSourceFieldIncluded = parameterDataSourceFieldIncluded;
		}
		public Boolean getParameterSourceAddressFieldIncluded() {
			return parameterSourceAddressFieldIncluded;
		}
		public void setParameterSourceAddressFieldIncluded(Boolean parameterSourceAddressFieldIncluded) {
			this.parameterSourceAddressFieldIncluded = parameterSourceAddressFieldIncluded;
		}
		public Boolean getDataPostionFieldIncluded() {
			return dataPostionFieldIncluded;
		}
		public void setDataPostionFieldIncluded(Boolean dataPostionFieldIncluded) {
			this.dataPostionFieldIncluded = dataPostionFieldIncluded;
		}
		public Integer getReportID() {
			return reportID;
		}
		public void setReportID(Integer reportID) {
			this.reportID = reportID;
		}
		public Integer getMachineState() {
			return machineState;
		}
		public void setMachineState(Integer machineState) {
			this.machineState = machineState;
		}
		public Integer getParameterGroup() {
			return parameterGroup;
		}
		public void setParameterGroup(Integer parameterGroup) {
			this.parameterGroup = parameterGroup;
		}
		public List<DataReportParameter> getParameterList() {
			return parameterList;
		}
		public void setParameterList(List<DataReportParameter> parameterList) {
			this.parameterList = parameterList;
		}
		public Boolean getParamaterIDFieldIncluded() {
			return paramaterIDFieldIncluded;
		}
		public void setParamaterIDFieldIncluded(Boolean paramaterIDFieldIncluded) {
			this.paramaterIDFieldIncluded = paramaterIDFieldIncluded;
		}
		
		
		
}
