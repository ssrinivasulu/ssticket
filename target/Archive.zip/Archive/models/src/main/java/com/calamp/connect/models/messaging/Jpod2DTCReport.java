package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@XmlRootElement(name = "jpod2DTCReport")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jpod2DTCReport")
@JsonTypeName("jpod2DTCReport")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType (propOrder = {"j1939DtcBlocks"})
@JsonPropertyOrder ( {"j1939DtcBlocks"})
@ApiVersion()
public class Jpod2DTCReport extends AppMessage {
	private List<J1939DtcBlock> j1939DtcBlocks;

	public List<J1939DtcBlock> getJ1939DtcBlocks() {
		return j1939DtcBlocks;
	}

	public void setJ1939DtcBlocks(List<J1939DtcBlock> j1939DtcBlocks) {
		this.j1939DtcBlocks = j1939DtcBlocks;
	}


	
}
