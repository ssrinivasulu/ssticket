package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "digitalInput")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("digitalInput")
@JsonTypeName("digitalInput")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)

public class DigitalInput
{
    int                input;
    DigitalInputStatus value;

    @XmlType(name = "digitalInputStatus")
    public enum DigitalInputStatus { ON, OFF }

    public DigitalInput() {}

    public DigitalInput(int input, DigitalInputStatus value)
    {
        this.input = input;
        this.value = value;
    }

    public int getInput()
    {
        return input;
    }

    public DigitalInputStatus getValue()
    {
        return value;
    }

    public void setInput(int input)
    {
        this.input = input;
    }

    public void setValue(DigitalInputStatus value)
    {
        this.value = value;
    }
}
