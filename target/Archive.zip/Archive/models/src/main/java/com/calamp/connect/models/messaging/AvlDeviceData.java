package com.calamp.connect.models.messaging;

import java.util.List;

import javax.measure.quantity.Speed;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.Altitude;
import com.calamp.connect.framework.quantity.RSSI;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("avlDeviceData")
@JsonTypeName("avlDeviceData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "acceleration", "accumulators", "altitude", "gpsSpeed", "rssi", "speedEvent" })
@JsonPropertyOrder({ "acceleration", "accumulators", "altitude", "gpsSpeed", "rssi", "speedEvent" })
public class AvlDeviceData extends DeviceData
{

    @ConvertUnit(type = Altitude.class)
    private HeaderData        altitude;

    @ConvertUnit(type = Speed.class)
    private HeaderData        gpsSpeed;

    @ConvertUnit(type = RSSI.class)
    private HeaderData        rssi;

    @ContainHeaderUnit
    private Acceleration      acceleration;

    @ContainHeaderUnit
    private SpeedEventV2      speedEvent;

    private List<Accumulator> accumulators;

    public HeaderData getAltitude()
    {
        return altitude;
    }

    public void setAltitude(HeaderData altitude)
    {
        this.altitude = altitude;
    }

    public HeaderData getGpsSpeed()
    {
        return gpsSpeed;
    }

    public void setGpsSpeed(HeaderData gpsSpeed)
    {
        this.gpsSpeed = gpsSpeed;
    }

    public HeaderData getRssi()
    {
        return rssi;
    }

    public void setRssi(HeaderData rssi)
    {
        this.rssi = rssi;
    }

    public Acceleration getAcceleration()
    {
        return acceleration;
    }

    public void setAcceleration(Acceleration acceleration)
    {
        this.acceleration = acceleration;
    }

    public SpeedEventV2 getSpeedEvent()
    {
        return speedEvent;
    }

    public void setSpeedEvent(SpeedEventV2 speedEvent)
    {
        this.speedEvent = speedEvent;
    }

    public List<Accumulator> getAccumulators()
    {
        return accumulators;
    }

    public void setAccumulators(List<Accumulator> accumulators)
    {
        this.accumulators = accumulators;
    }

}
