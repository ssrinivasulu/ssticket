package com.calamp.connect.models.messaging;

import javax.measure.quantity.Dimensionless;
import javax.measure.quantity.Volume;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.DurationHours;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("jbusDailyReportData")
@JsonTypeName("jbusDailyReportData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "engineCoolantLevel", "engineIdleFuel", "engineIdleHours", "engineOilLevel", "engineTotalHours", "noxTankLevel" })
@JsonPropertyOrder({ "engineCoolantLevel", "engineIdleFuel", "engineIdleHours", "engineOilLevel", "engineTotalHours", "noxTankLevel" })
public class JbusDailyReportData extends DeviceData
{
    @ConvertUnit(type = DurationHours.class)
    private HeaderData engineTotalHours;
    @ConvertUnit(type = DurationHours.class)
    private HeaderData engineIdleHours;
    @ConvertUnit(type = Volume.class)
    private HeaderData engineIdleFuel;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData engineOilLevel;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData engineCoolantLevel;
    @ConvertUnit(type = Dimensionless.class)
    private HeaderData noxTankLevel;

    public HeaderData getEngineTotalHours()
    {
        return engineTotalHours;
    }

    public void setEngineTotalHours(HeaderData engineTotalHours)
    {
        this.engineTotalHours = engineTotalHours;
    }

    public HeaderData getEngineIdleHours()
    {
        return engineIdleHours;
    }

    public void setEngineIdleHours(HeaderData engineIdleHours)
    {
        this.engineIdleHours = engineIdleHours;
    }

    public HeaderData getEngineIdleFuel()
    {
        return engineIdleFuel;
    }

    public void setEngineIdleFuel(HeaderData engineIdleFuel)
    {
        this.engineIdleFuel = engineIdleFuel;
    }

    public HeaderData getEngineOilLevel()
    {
        return engineOilLevel;
    }

    public void setEngineOilLevel(HeaderData engineOilLevel)
    {
        this.engineOilLevel = engineOilLevel;
    }

    public HeaderData getEngineCoolantLevel()
    {
        return engineCoolantLevel;
    }

    public void setEngineCoolantLevel(HeaderData engineCoolantLevel)
    {
        this.engineCoolantLevel = engineCoolantLevel;
    }

    public HeaderData getNoxTankLevel()
    {
        return noxTankLevel;
    }

    public void setNoxTankLevel(HeaderData noxTankLevel)
    {
        this.noxTankLevel = noxTankLevel;
    }

}
