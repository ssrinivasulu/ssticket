package com.calamp.connect.models.db.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.models.db.domain.JbusDailyReportEntity;
import com.calamp.connect.models.messaging.JbusDailyReportData;
import com.calamp.connect.models.messaging.JbusDailyReportEvent;

public class JbusDailyReportConverter extends DeviceEventConverter<JbusDailyReportEntity, JbusDailyReportEvent>
{
    private Logger logger = LoggerFactory.getLogger(JbusDailyReportConverter.class);

    @Override
    public JbusDailyReportEntity modelToDomain(JbusDailyReportEvent jbusDailyReportEvent)
    {
        JbusDailyReportEntity jbusDailyReportEntity = super.convert(jbusDailyReportEvent, JbusDailyReportEntity.class);

        return customConvert(jbusDailyReportEvent, jbusDailyReportEntity);

    }

    @Override
    public JbusDailyReportEvent domainToModel(JbusDailyReportEntity jbusDailyReportEventEntity)
    {
        JbusDailyReportEvent jbusDailyReportEvent = super.convert(jbusDailyReportEventEntity, JbusDailyReportEvent.class);

        return customConvert(jbusDailyReportEventEntity, jbusDailyReportEvent);

    }

    @Override
    protected JbusDailyReportEntity customConvert(JbusDailyReportEvent model, JbusDailyReportEntity entity)
    {
        return entity;
    }

    @Override
    protected JbusDailyReportEvent customConvert(JbusDailyReportEntity entity, JbusDailyReportEvent model)
    {
        if (entity.getDeviceData() != null)
        {
            JbusDailyReportData dailyReportData = (JbusDailyReportData) entity.getDeviceData();
            if (dailyReportData.getEngineCoolantLevel() != null)
                model.setEngineCoolantLevel(convertHeaderDataToDouble(dailyReportData.getEngineCoolantLevel()));
            if (dailyReportData.getEngineIdleFuel() != null)
                model.setEngineIdleFuel(convertHeaderDataToDouble(dailyReportData.getEngineIdleFuel()));
            if (dailyReportData.getEngineIdleHours() != null)
                model.setEngineIdleHours(convertHeaderDataToDouble(dailyReportData.getEngineIdleHours()));
            if (dailyReportData.getEngineOilLevel() != null)
                model.setEngineOilLevel(convertHeaderDataToDouble(dailyReportData.getEngineOilLevel()));
            if (dailyReportData.getEngineTotalHours() != null)
                model.setEngineTotalHours(convertHeaderDataToDouble(dailyReportData.getEngineTotalHours()));
            if (dailyReportData.getNoxTankLevel() != null)
                model.setNoxTankLevel(convertHeaderDataToDouble(dailyReportData.getNoxTankLevel()));
            if (dailyReportData.getNoxTankLevel() != null)
                model.setNoxTankLevel(convertHeaderDataToDouble(dailyReportData.getNoxTankLevel()));
        }
        model.setDeviceDataConverted(null);
        return model;
    }

    @Override
    public JbusDailyReportEvent domainToModel(JbusDailyReportEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusDailyReportEntity> getDomainType()
    {
        return JbusDailyReportEntity.class;
    }

    @Override
    public Class<JbusDailyReportEvent> getModelType()
    {
        return JbusDailyReportEvent.class;
    }

}
