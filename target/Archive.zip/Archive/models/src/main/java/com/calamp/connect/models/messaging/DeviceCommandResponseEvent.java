package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "deviceCommandResponseEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("deviceCommandResponseEvent")
@JsonTypeName("deviceCommandResponseEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)

@XmlType(propOrder =
{
 "account", "asset", "assetId", "assetName", "deviceAirId", "deviceCommandStatus", "deviceEsn",
		"deviceId", "deviceIp", "deviceMessageSequenceNumber", "deviceParameterReadResponses", "eventTime",
		"locateReport", "messageReceivedTime", "messageType", "messageUuid", "port", "rawAccumulators",
		"rawDeviceHexMessage", "type", "vin", "vinResponse"
})
@JsonPropertyOrder(
{
	 "account", "asset", "assetId", "assetName", "deviceAirId", "deviceCommandStatus", "deviceEsn",
		"deviceId", "deviceIp", "deviceMessageSequenceNumber", "deviceParameterReadResponses", "eventTime",
		"locateReport", "messageReceivedTime", "messageType", "messageUuid", "port", "rawAccumulators",
		"rawDeviceHexMessage", "type", "vin", "vinResponse"
})
public class DeviceCommandResponseEvent extends DeviceEvent
{
    private DeviceCommandStatus               deviceCommandStatus;
    private List<DeviceParameterReadResponse> deviceParameterReadResponses;
    private LocateReport                      locateReport;
    private DeviceCommandResponseTypes        type;

    public enum DeviceCommandResponseTypes { STATUS, READ_RESPONSE, LOCATE_REPORT; }

    public void addDeviceParameterReadResponse(DeviceParameterReadResponse deviceParameterReadResponse)
    {
        if (deviceParameterReadResponses == null){
            deviceParameterReadResponses = new ArrayList<DeviceParameterReadResponse>();
        }

        deviceParameterReadResponses.add(deviceParameterReadResponse);
    }

    @XmlElement
    public DeviceCommandStatus getDeviceCommandStatus()
    {
        return deviceCommandStatus;
    }

    @XmlElement
    public List<DeviceParameterReadResponse> getDeviceParameterReadResponses()
    {
        return deviceParameterReadResponses;
    }

    @XmlElement
    public LocateReport getLocateReport()
    {
        return locateReport;
    }

    @XmlElement
    public DeviceCommandResponseTypes getType()
    {
        return type;
    }

    public void setDeviceCommandStatus(DeviceCommandStatus deviceCommandStatus)
    {
        this.deviceCommandStatus = deviceCommandStatus;
    }

    public void setDeviceParameterReadResponses(List<DeviceParameterReadResponse> deviceParameterReadResponses)
    {
        this.deviceParameterReadResponses = deviceParameterReadResponses;
    }

    public void setLocateReport(LocateReport locateReport)
    {
        this.locateReport = locateReport;
    }

    public void setType(DeviceCommandResponseTypes type)
    {
        this.type = type;
    }
}
