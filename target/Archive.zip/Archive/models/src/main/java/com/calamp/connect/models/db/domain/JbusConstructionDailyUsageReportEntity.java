package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusConstructionDailyUsageReportEntity extends DeviceEventEntity
{
    private MachineStateEntity machineState;
    // version 1 fields we can remove this fields after all documents in mongo are new structure
    private Double             engineTorque0To10PercentUsage;
    private Double             engineTorque10To20PercentUsage;
    private Double             engineTorque20To30PercentUsage;
    private Double             engineTorque30To40PercentUsage;
    private Double             engineTorque40To50PercentUsage;
    private Double             engineTorque50To60PercentUsage;
    private Double             engineTorque60To70PercentUsage;
    private Double             engineTorque70To80PercentUsage;
    private Double             engineTorque80To90PercentUsage;
    private Double             engineTorqueOver90PercentUsage;
    private Double             positionTorque0To10PercentUsage;
    private Double             positionTorque10To20PercentUsage;
    private Double             positionTorque20To30PercentUsage;
    private Double             positionTorque30To40PercentUsage;
    private Double             positionTorque40To50PercentUsage;
    private Double             positionTorque50To60PercentUsage;
    private Double             positionTorque60To70PercentUsage;
    private Double             positionTorque70To80PercentUsage;
    private Double             positionTorque80To90PercentUsage;
    private Double             positionTorqueOver90PercentUsage;

    public JbusConstructionDailyUsageReportEntity()
    {
        setMsgType(MsgType.JBUS_CONSTRUCTION_DAILY_USAGE_REPORT);
    }

    public MachineStateEntity getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineStateEntity machineState)
    {
        this.machineState = machineState;
    }

    public Double getEngineTorque0To10PercentUsage()
    {
        return engineTorque0To10PercentUsage;
    }

    public void setEngineTorque0To10PercentUsage(Double engineTorque0To10PercentUsage)
    {
        this.engineTorque0To10PercentUsage = engineTorque0To10PercentUsage;
    }

    public Double getEngineTorque10To20PercentUsage()
    {
        return engineTorque10To20PercentUsage;
    }

    public void setEngineTorque10To20PercentUsage(Double engineTorque10To20PercentUsage)
    {
        this.engineTorque10To20PercentUsage = engineTorque10To20PercentUsage;
    }

    public Double getEngineTorque20To30PercentUsage()
    {
        return engineTorque20To30PercentUsage;
    }

    public void setEngineTorque20To30PercentUsage(Double engineTorque20To30PercentUsage)
    {
        this.engineTorque20To30PercentUsage = engineTorque20To30PercentUsage;
    }

    public Double getEngineTorque30To40PercentUsage()
    {
        return engineTorque30To40PercentUsage;
    }

    public void setEngineTorque30To40PercentUsage(Double engineTorque30To40PercentUsage)
    {
        this.engineTorque30To40PercentUsage = engineTorque30To40PercentUsage;
    }

    public Double getEngineTorque40To50PercentUsage()
    {
        return engineTorque40To50PercentUsage;
    }

    public void setEngineTorque40To50PercentUsage(Double engineTorque40To50PercentUsage)
    {
        this.engineTorque40To50PercentUsage = engineTorque40To50PercentUsage;
    }

    public Double getEngineTorque50To60PercentUsage()
    {
        return engineTorque50To60PercentUsage;
    }

    public void setEngineTorque50To60PercentUsage(Double engineTorque50To60PercentUsage)
    {
        this.engineTorque50To60PercentUsage = engineTorque50To60PercentUsage;
    }

    public Double getEngineTorque60To70PercentUsage()
    {
        return engineTorque60To70PercentUsage;
    }

    public void setEngineTorque60To70PercentUsage(Double engineTorque60To70PercentUsage)
    {
        this.engineTorque60To70PercentUsage = engineTorque60To70PercentUsage;
    }

    public Double getEngineTorque70To80PercentUsage()
    {
        return engineTorque70To80PercentUsage;
    }

    public void setEngineTorque70To80PercentUsage(Double engineTorque70To80PercentUsage)
    {
        this.engineTorque70To80PercentUsage = engineTorque70To80PercentUsage;
    }

    public Double getEngineTorque80To90PercentUsage()
    {
        return engineTorque80To90PercentUsage;
    }

    public void setEngineTorque80To90PercentUsage(Double engineTorque80To90PercentUsage)
    {
        this.engineTorque80To90PercentUsage = engineTorque80To90PercentUsage;
    }

    public Double getEngineTorqueOver90PercentUsage()
    {
        return engineTorqueOver90PercentUsage;
    }

    public void setEngineTorqueOver90PercentUsage(Double engineTorqueOver90PercentUsage)
    {
        this.engineTorqueOver90PercentUsage = engineTorqueOver90PercentUsage;
    }

    public Double getPositionTorque0To10PercentUsage()
    {
        return positionTorque0To10PercentUsage;
    }

    public void setPositionTorque0To10PercentUsage(Double positionTorque0To10PercentUsage)
    {
        this.positionTorque0To10PercentUsage = positionTorque0To10PercentUsage;
    }

    public Double getPositionTorque10To20PercentUsage()
    {
        return positionTorque10To20PercentUsage;
    }

    public void setPositionTorque10To20PercentUsage(Double positionTorque10To20PercentUsage)
    {
        this.positionTorque10To20PercentUsage = positionTorque10To20PercentUsage;
    }

    public Double getPositionTorque20To30PercentUsage()
    {
        return positionTorque20To30PercentUsage;
    }

    public void setPositionTorque20To30PercentUsage(Double positionTorque20To30PercentUsage)
    {
        this.positionTorque20To30PercentUsage = positionTorque20To30PercentUsage;
    }

    public Double getPositionTorque30To40PercentUsage()
    {
        return positionTorque30To40PercentUsage;
    }

    public void setPositionTorque30To40PercentUsage(Double positionTorque30To40PercentUsage)
    {
        this.positionTorque30To40PercentUsage = positionTorque30To40PercentUsage;
    }

    public Double getPositionTorque40To50PercentUsage()
    {
        return positionTorque40To50PercentUsage;
    }

    public void setPositionTorque40To50PercentUsage(Double positionTorque40To50PercentUsage)
    {
        this.positionTorque40To50PercentUsage = positionTorque40To50PercentUsage;
    }

    public Double getPositionTorque50To60PercentUsage()
    {
        return positionTorque50To60PercentUsage;
    }

    public void setPositionTorque50To60PercentUsage(Double positionTorque50To60PercentUsage)
    {
        this.positionTorque50To60PercentUsage = positionTorque50To60PercentUsage;
    }

    public Double getPositionTorque60To70PercentUsage()
    {
        return positionTorque60To70PercentUsage;
    }

    public void setPositionTorque60To70PercentUsage(Double positionTorque60To70PercentUsage)
    {
        this.positionTorque60To70PercentUsage = positionTorque60To70PercentUsage;
    }

    public Double getPositionTorque70To80PercentUsage()
    {
        return positionTorque70To80PercentUsage;
    }

    public void setPositionTorque70To80PercentUsage(Double positionTorque70To80PercentUsage)
    {
        this.positionTorque70To80PercentUsage = positionTorque70To80PercentUsage;
    }

    public Double getPositionTorque80To90PercentUsage()
    {
        return positionTorque80To90PercentUsage;
    }

    public void setPositionTorque80To90PercentUsage(Double positionTorque80To90PercentUsage)
    {
        this.positionTorque80To90PercentUsage = positionTorque80To90PercentUsage;
    }

    public Double getPositionTorqueOver90PercentUsage()
    {
        return positionTorqueOver90PercentUsage;
    }

    public void setPositionTorqueOver90PercentUsage(Double positionTorqueOver90PercentUsage)
    {
        this.positionTorqueOver90PercentUsage = positionTorqueOver90PercentUsage;
    }

}
