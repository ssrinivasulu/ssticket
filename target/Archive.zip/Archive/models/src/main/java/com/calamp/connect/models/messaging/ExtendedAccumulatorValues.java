package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;


@XmlRootElement(name = "extendedAccumulatorValues")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("extendedAccumulatorValues")
@JsonTypeName("extendedAccumulatorValues")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder =
{
 "absActiveLamp", "batteryHealth", "batteryVoltage", "coolantHotLight", "daysToService",
		"distanceToService", "engineCoolantTemp", "fuelLevelPct", "fuelLevelVolume", "maxEngineSpeed", "maxSpeedGps",
		"maxSpeedObd", "maxThrottlePosition", "milStatus", "oilPressureLamp", "parkBrakeLight", "seatBeltFastened",
})
@JsonPropertyOrder(
{
 "absActiveLamp", "batteryHealth", "batteryVoltage", "coolantHotLight", "daysToService",
		"distanceToService", "engineCoolantTemp", "fuelLevelPct", "fuelLevelVolume", "maxEngineSpeed", "maxSpeedGps",
		"maxSpeedObd", "maxThrottlePosition", "milStatus", "oilPressureLamp", "parkBrakeLight", "seatBeltFastened",
})
@JsonTypeInfo(use = Id.NONE)

public class ExtendedAccumulatorValues {

	private Double maxSpeedObd;
	private Double maxSpeedGps;
	private Double maxEngineSpeed;
	private Double maxThrottlePosition;
	private Double fuelLevelPct;
	private Double fuelLevelVolume;
	private Double engineCoolantTemp;
	private Double batteryVoltage;
	private Integer daysToService;
	private Integer distanceToService;
	private Boolean milStatus;
	private Boolean seatBeltFastened;
	private Boolean absActiveLamp;
	private Boolean oilPressureLamp;
	private Boolean parkBrakeLight;
	private Boolean coolantHotLight;
	private Integer batteryHealth;
	
	public Double getMaxSpeedObd() {
		return maxSpeedObd;
	}
	public void setMaxSpeedObd(Double maxSpeedObd) {
		this.maxSpeedObd = maxSpeedObd;
	}
	public Double getMaxSpeedGps() {
		return maxSpeedGps;
	}
	public void setMaxSpeedGps(Double maxSpeedGps) {
		this.maxSpeedGps = maxSpeedGps;
	}
	public Double getMaxEngineSpeed() {
		return maxEngineSpeed;
	}
	public void setMaxEngineSpeed(Double maxEngineSpeed) {
		this.maxEngineSpeed = maxEngineSpeed;
	}
	public Double getMaxThrottlePosition() {
		return maxThrottlePosition;
	}
	public void setMaxThrottlePosition(Double maxThrottlePosition) {
		this.maxThrottlePosition = maxThrottlePosition;
	}
	public Double getFuelLevelPct() {
		return fuelLevelPct;
	}
	public void setFuelLevelPct(Double fuelLevelPct) {
		this.fuelLevelPct = fuelLevelPct;
	}
	public Double getFuelLevelVolume() {
		return fuelLevelVolume;
	}
	public void setFuelLevelVolume(Double fuelLevelVolume) {
		this.fuelLevelVolume = fuelLevelVolume;
	}
	public Double getEngineCoolantTemp() {
		return engineCoolantTemp;
	}
	public void setEngineCoolantTemp(Double engineCoolantTemp) {
		this.engineCoolantTemp = engineCoolantTemp;
	}
	public Double getBatteryVoltage() {
		return batteryVoltage;
	}
	public void setBatteryVoltage(Double batteryVoltage) {
		this.batteryVoltage = batteryVoltage;
	}
	public Integer getDaysToService() {
		return daysToService;
	}
	public void setDaysToService(Integer daysToService) {
		this.daysToService = daysToService;
	}
	public Integer getDistanceToService() {
		return distanceToService;
	}
	public void setDistanceToService(Integer distanceToService) {
		this.distanceToService = distanceToService;
	}
	public Boolean getMilStatus() {
		return milStatus;
	}
	public void setMilStatus(Boolean milStatus) {
		this.milStatus = milStatus;
	}
	public Boolean getSeatBeltFastened() {
		return seatBeltFastened;
	}
	public void setSeatBeltFastened(Boolean seatBeltFastened) {
		this.seatBeltFastened = seatBeltFastened;
	}
	public Boolean getAbsActiveLamp() {
		return absActiveLamp;
	}
	public void setAbsActiveLamp(Boolean absActiveLamp) {
		this.absActiveLamp = absActiveLamp;
	}
	public Boolean getOilPressureLamp() {
		return oilPressureLamp;
	}
	public void setOilPressureLamp(Boolean oilPressureLamp) {
		this.oilPressureLamp = oilPressureLamp;
	}
	public Boolean getParkBrakeLight() {
		return parkBrakeLight;
	}
	public void setParkBrakeLight(Boolean parkBrakeLight) {
		this.parkBrakeLight = parkBrakeLight;
	}
	public Boolean getCoolantHotLight() {
		return coolantHotLight;
	}
	public void setCoolantHotLight(Boolean coolantHotLight) {
		this.coolantHotLight = coolantHotLight;
	}
	public Integer getBatteryHealth() {
		return batteryHealth;
	}
	public void setBatteryHealth(Integer batteryHealth) {
		this.batteryHealth = batteryHealth;
	}
	
}
