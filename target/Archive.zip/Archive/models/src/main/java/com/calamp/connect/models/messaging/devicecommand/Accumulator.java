package com.calamp.connect.models.messaging.devicecommand;

import java.util.Arrays;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.util.BinaryUtils;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

/**
 * User: ericw
 * Date: 5/13/14
 */
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = {  "accumulatorDecodedValue","accumulatorValue","label", "value", "index", "units", "type" })
@JsonPropertyOrder({ "accumulatorDecodedValue","accumulatorValue", "label", "value", "index", "units", "type" })
public class Accumulator
{
	private Integer index;
    private byte[] accumulatorValue;
    private Long accumulatorDecodedValue;
    private String label;
    private String value;
    private String units;
    private String type;
    public Accumulator()
    {
    }

    public Accumulator(Integer index, byte[] accumulatorValue)
    {
        this.index = index;
        this.accumulatorValue = accumulatorValue;
    }

    public byte[] getAccumulatorValue()
    {
        return accumulatorValue;
    }

    public void setAccumulatorValue(byte[] accumulatorValue)
    {
        this.accumulatorValue = accumulatorValue;
    }

    public Long getAccumulatorDecodedValue()
    {
        if(accumulatorValue != null){
            accumulatorDecodedValue = BinaryUtils.convertBase64ToDecimal(accumulatorValue);
        }
        return accumulatorDecodedValue;
    }

    public Integer getIndex()
    {
        return index;
    }

    public void setIndex(Integer index)
    {
        this.index = index;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Accumulator that = (Accumulator) o;

        if (!Arrays.equals(accumulatorValue, that.accumulatorValue)) return false;
        if (index != null ? !index.equals(that.index) : that.index != null) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = index != null ? index.hashCode() : 0;
        result = 31 * result + (accumulatorValue != null ? Arrays.hashCode(accumulatorValue) : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "Accumulator{" +
                "index=" + index +
                ", accumulatorValue=" + Arrays.toString(accumulatorValue) +
                '}';
    }

    public String getLabel()
    {
        return label;
    }

    public void setLabel(String label)
    {
        this.label = label;
    }

    public String getValue()
    {
        if (value == null && accumulatorValue != null)
        {
            value = String.valueOf(BinaryUtils.convertBase64ToDecimal(accumulatorValue));
        }
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }

    public String getUnits()
    {
        return units;
    }

    public void setUnits(String units)
    {
        this.units = units;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public void setAccumulatorDecodedValue(Long accumulatorDecodedValue)
    {
        this.accumulatorDecodedValue = accumulatorDecodedValue;
    }
    
}
