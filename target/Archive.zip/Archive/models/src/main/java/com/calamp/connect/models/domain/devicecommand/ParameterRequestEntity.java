package com.calamp.connect.models.domain.devicecommand;

import java.util.ArrayList;
import java.util.List;

public class ParameterRequestEntity extends DeviceCommandMessageRequestEntity
{
    private String requestType;
    private List<ParameterConfigInfoEntity> parameters = new ArrayList<>();

    public String getRequestType()
    {
        return requestType;
    }

    public void setRequestType(String requestType)
    {
        this.requestType = requestType;
    }

    public List<ParameterConfigInfoEntity> getParameters()
    {
        return parameters;
    }

    public void setParameters(List<ParameterConfigInfoEntity> parameters)
    {
        this.parameters = parameters;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        ParameterRequestEntity that = (ParameterRequestEntity) o;

        if (parameters != null ? !parameters.equals(that.parameters) : that.parameters != null) return false;
        if (requestType != null ? !requestType.equals(that.requestType) : that.requestType != null) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = super.hashCode();
        result = 31 * result + (requestType != null ? requestType.hashCode() : 0);
        result = 31 * result + (parameters != null ? parameters.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "ParameterRequest{" +
                "requestType='" + requestType + '\'' +
                ", parameters=" + parameters +
                '}';
    }
}
