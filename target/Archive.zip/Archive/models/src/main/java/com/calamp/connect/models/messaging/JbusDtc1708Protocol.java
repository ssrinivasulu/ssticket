package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * <p>Java class for JBUSDTC1708Message complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JBUSDTC1708Message"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FMI" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="PID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="OC" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="CSF" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="DCT" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="LCI" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;any processContents='skip' maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */

@XmlRootElement(name = "jbusDtc1708Protocol")
@JsonRootName("jbusDtc1708Protocol")
@JsonTypeName("jbusDtc1708Protocol")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)
@JsonPropertyOrder(
{
 "csf", "dct", "fmi", "lci", "oc", "pid"
})
@XmlType(
    name      = "jbusDtc1708Protocol",
    propOrder =
    {
 "csf", "dct", "fmi", "lci", "oc", "pid"
    }
)
public class JbusDtc1708Protocol
{
    @XmlElement(name = "FMI", required = true, type = Integer.class, nillable = true)
    protected Integer fmi;
    @XmlElement(name = "PID", required = true, type = Integer.class, nillable = true)
    protected Integer pid;
    @XmlElement(name = "OC", required = true, type = Integer.class, nillable = true)
    protected Integer oc;
    @XmlElement(name = "CSF", required = true, type = Boolean.class, nillable = true)
    protected Boolean csf;
    @XmlElement(name = "DCT", required = true, type = Boolean.class, nillable = true)
    protected Boolean dct;
    @XmlElement(name = "LCI", required = true, type = Boolean.class, nillable = true)
    protected Boolean lci;
	/**
	 * @return the fmi
	 */
	public Integer getFmi() {
		return fmi;
	}
	/**
	 * @param fmi the fmi to set
	 */
	public void setFmi(Integer fmi) {
		this.fmi = fmi;
	}
	/**
	 * @return the pid
	 */
	public Integer getPid() {
		return pid;
	}
	/**
	 * @param pid the pid to set
	 */
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	/**
	 * @return the oc
	 */
	public Integer getOc() {
		return oc;
	}
	/**
	 * @param oc the oc to set
	 */
	public void setOc(Integer oc) {
		this.oc = oc;
	}
	/**
	 * @return the csf
	 */
	public Boolean getCsf() {
		return csf;
	}
	/**
	 * @param csf the csf to set
	 */
	public void setCsf(Boolean csf) {
		this.csf = csf;
	}
	/**
	 * @return the dct
	 */
	public Boolean getDct() {
		return dct;
	}
	/**
	 * @param dct the dct to set
	 */
	public void setDct(Boolean dct) {
		this.dct = dct;
	}
	/**
	 * @return the lci
	 */
	public Boolean getLci() {
		return lci;
	}
	/**
	 * @param lci the lci to set
	 */
	public void setLci(Boolean lci) {
		this.lci = lci;
	}
    
}
