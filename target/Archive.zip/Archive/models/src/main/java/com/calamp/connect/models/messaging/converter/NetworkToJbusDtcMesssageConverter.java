package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDtcEvent;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class NetworkToJbusDtcMesssageConverter extends GenericNetworkToDeviceEventConverter {

	public JbusDtcEvent convert(NetworkMessage network) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusDtcEvent jbusDtcEvent = null;
		jbusDtcEvent = mapper.map(network.getRawJbusMessage().getJbusDtcData(), JbusDtcEvent.class);
		jbusDtcEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusDtcEvent;
	}
	
}
