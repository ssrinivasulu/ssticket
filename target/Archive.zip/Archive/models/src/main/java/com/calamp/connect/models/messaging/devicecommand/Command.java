package com.calamp.connect.models.messaging.devicecommand;

import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "command")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("command")
@JsonTypeName("command")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "commandType", "name", "description", "retryCapable", "maxRetries", "ttlSec", "parameters" })
@JsonPropertyOrder({ "commandType", "name", "description", "retryCapable",  "maxRetries", "ttlSec", "parameters" })
public class Command
{
    private DeviceCommandType   commandType;
    private String              name;
    private String              description;
    private Boolean             retryCapable;
    private Integer             maxRetries;
    private Integer             ttlSec;
    private Map<String, String> parameters;

    public DeviceCommandType getCommandType()
    {
        return commandType;
    }

    public void setCommandType(DeviceCommandType commandType)
    {
        this.commandType = commandType;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public Boolean getRetryCapable()
    {
        return retryCapable;
    }

    public void setRetryCapable(Boolean retryCapable)
    {
        this.retryCapable = retryCapable;
    }

    public Integer getMaxRetries()
    {
        return maxRetries;
    }

    public void setMaxRetries(Integer maxRetries)
    {
        this.maxRetries = maxRetries;
    }

    public Integer getTtlSec()
    {
        return ttlSec;
    }

    public void setTtlSec(Integer ttlSec)
    {
        this.ttlSec = ttlSec;
    }

    public Map<String, String> getParameters()
    {
        return parameters;
    }

    public void setParameters(Map<String, String> parameters)
    {
        this.parameters = parameters;
    }

}
