package com.calamp.connect.models.domain.devicecommand;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
    use      = JsonTypeInfo.Id.NAME,
    include  = JsonTypeInfo.As.PROPERTY,
    property = "type"
)
@JsonSubTypes(
{
    @JsonSubTypes.Type(value = LocateReportRequestEntity.class) ,
    @JsonSubTypes.Type(value = PegActionRequestEntity.class) ,
    @JsonSubTypes.Type(value = ParameterResponseEntity.class) , @JsonSubTypes.Type(value = AckNakResponseEntity.class) ,
    @JsonSubTypes.Type(value = LocateReportResponseEntity.class) ,
    @JsonSubTypes.Type(value = SetAndEnableZoneRequestEntity.class)
})
public interface DeviceCommandMessageEntity
{
    public String getExternalDeviceId();

    public Integer getSequenceId();
}
