package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "jbusConstructionDailyUsageReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusConstructionDailyUsageReportEvent")
@JsonTypeName("jbusConstructionDailyUsageReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "deviceAirId", "deviceData", "deviceDataConverted",
        "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "engineTorque0To10PercentUsage",
        "engineTorque10To20PercentUsage", "engineTorque20To30PercentUsage", "engineTorque30To40PercentUsage", "engineTorque40To50PercentUsage",
        "engineTorque50To60PercentUsage", "engineTorque60To70PercentUsage", "engineTorque70To80PercentUsage", "engineTorque80To90PercentUsage",
        "engineTorqueOver90PercentUsage", "eventCode", "eventTime", "eventType", "inputs", "lmdirectMessageType", "machineState",
        "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port", "positionTorque0To10PercentUsage",
        "positionTorque10To20PercentUsage", "positionTorque20To30PercentUsage", "positionTorque30To40PercentUsage",
        "positionTorque40To50PercentUsage", "positionTorque50To60PercentUsage", "positionTorque60To70PercentUsage",
        "positionTorque70To80PercentUsage", "positionTorque80To90PercentUsage", "positionTorqueOver90PercentUsage", "primaryOperator", "operators",
        "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusConstructionDailyUsageReportEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName",
        "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber",
        "engineTorque0To10PercentUsage", "engineTorque10To20PercentUsage", "engineTorque20To30PercentUsage", "engineTorque30To40PercentUsage",
        "engineTorque40To50PercentUsage", "engineTorque50To60PercentUsage", "engineTorque60To70PercentUsage", "engineTorque70To80PercentUsage",
        "engineTorque80To90PercentUsage", "engineTorqueOver90PercentUsage", "eventCode", "eventTime", "eventType", "inputs", "lmdirectMessageType",
        "machineState", "messageReceivedTime", "messageType", "messageUuid", "pegBehaviorId", "port", "positionTorque0To10PercentUsage",
        "positionTorque10To20PercentUsage", "positionTorque20To30PercentUsage", "positionTorque30To40PercentUsage",
        "positionTorque40To50PercentUsage", "positionTorque50To60PercentUsage", "positionTorque60To70PercentUsage",
        "positionTorque70To80PercentUsage", "positionTorque80To90PercentUsage", "positionTorqueOver90PercentUsage", "primaryOperator", "operators",
        "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
public class JbusConstructionDailyUsageReportEvent extends DeviceEvent
{
    private MachineState                         machineState;
    private Double                               engineTorque0To10PercentUsage;
    private Double                               engineTorque10To20PercentUsage;
    private Double                               engineTorque20To30PercentUsage;
    private Double                               engineTorque30To40PercentUsage;
    private Double                               engineTorque40To50PercentUsage;
    private Double                               engineTorque50To60PercentUsage;
    private Double                               engineTorque60To70PercentUsage;
    private Double                               engineTorque70To80PercentUsage;
    private Double                               engineTorque80To90PercentUsage;
    private Double                               engineTorqueOver90PercentUsage;
    private Double                               positionTorque0To10PercentUsage;
    private Double                               positionTorque10To20PercentUsage;
    private Double                               positionTorque20To30PercentUsage;
    private Double                               positionTorque30To40PercentUsage;
    private Double                               positionTorque40To50PercentUsage;
    private Double                               positionTorque50To60PercentUsage;
    private Double                               positionTorque60To70PercentUsage;
    private Double                               positionTorque70To80PercentUsage;
    private Double                               positionTorque80To90PercentUsage;
    private Double                               positionTorqueOver90PercentUsage;
    private JbusConstructionDailyUsageReportData deviceData;
    private JbusConstructionDailyUsageReportData deviceDataConverted;

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque0To10PercentUsage()
    {
        return engineTorque0To10PercentUsage;
    }

    public void setEngineTorque0To10PercentUsage(Double engineTorque0To10PercentUsage)
    {
        this.engineTorque0To10PercentUsage = engineTorque0To10PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque10To20PercentUsage()
    {
        return engineTorque10To20PercentUsage;
    }

    public void setEngineTorque10To20PercentUsage(Double engineTorque10To20PercentUsage)
    {
        this.engineTorque10To20PercentUsage = engineTorque10To20PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque20To30PercentUsage()
    {
        return engineTorque20To30PercentUsage;
    }

    public void setEngineTorque20To30PercentUsage(Double engineTorque20To30PercentUsage)
    {
        this.engineTorque20To30PercentUsage = engineTorque20To30PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque30To40PercentUsage()
    {
        return engineTorque30To40PercentUsage;
    }

    public void setEngineTorque30To40PercentUsage(Double engineTorque30To40PercentUsage)
    {
        this.engineTorque30To40PercentUsage = engineTorque30To40PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque40To50PercentUsage()
    {
        return engineTorque40To50PercentUsage;
    }

    public void setEngineTorque40To50PercentUsage(Double engineTorque40To50PercentUsage)
    {
        this.engineTorque40To50PercentUsage = engineTorque40To50PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque50To60PercentUsage()
    {
        return engineTorque50To60PercentUsage;
    }

    public void setEngineTorque50To60PercentUsage(Double engineTorque50To60PercentUsage)
    {
        this.engineTorque50To60PercentUsage = engineTorque50To60PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque60To70PercentUsage()
    {
        return engineTorque60To70PercentUsage;
    }

    public void setEngineTorque60To70PercentUsage(Double engineTorque60To70PercentUsage)
    {
        this.engineTorque60To70PercentUsage = engineTorque60To70PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque70To80PercentUsage()
    {
        return engineTorque70To80PercentUsage;
    }

    public void setEngineTorque70To80PercentUsage(Double engineTorque70To80PercentUsage)
    {
        this.engineTorque70To80PercentUsage = engineTorque70To80PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorque80To90PercentUsage()
    {
        return engineTorque80To90PercentUsage;
    }

    public void setEngineTorque80To90PercentUsage(Double engineTorque80To90PercentUsage)
    {
        this.engineTorque80To90PercentUsage = engineTorque80To90PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineTorqueOver90PercentUsage()
    {
        return engineTorqueOver90PercentUsage;
    }

    public void setEngineTorqueOver90PercentUsage(Double engineTorqueOver90PercentUsage)
    {
        this.engineTorqueOver90PercentUsage = engineTorqueOver90PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque0To10PercentUsage()
    {
        return positionTorque0To10PercentUsage;
    }

    public void setPositionTorque0To10PercentUsage(Double positionTorque0To10PercentUsage)
    {
        this.positionTorque0To10PercentUsage = positionTorque0To10PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque10To20PercentUsage()
    {
        return positionTorque10To20PercentUsage;
    }

    public void setPositionTorque10To20PercentUsage(Double positionTorque10To20PercentUsage)
    {
        this.positionTorque10To20PercentUsage = positionTorque10To20PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque20To30PercentUsage()
    {
        return positionTorque20To30PercentUsage;
    }

    public void setPositionTorque20To30PercentUsage(Double positionTorque20To30PercentUsage)
    {
        this.positionTorque20To30PercentUsage = positionTorque20To30PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque30To40PercentUsage()
    {
        return positionTorque30To40PercentUsage;
    }

    public void setPositionTorque30To40PercentUsage(Double positionTorque30To40PercentUsage)
    {
        this.positionTorque30To40PercentUsage = positionTorque30To40PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque40To50PercentUsage()
    {
        return positionTorque40To50PercentUsage;
    }

    public void setPositionTorque40To50PercentUsage(Double positionTorque40To50PercentUsage)
    {
        this.positionTorque40To50PercentUsage = positionTorque40To50PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque50To60PercentUsage()
    {
        return positionTorque50To60PercentUsage;
    }

    public void setPositionTorque50To60PercentUsage(Double positionTorque50To60PercentUsage)
    {
        this.positionTorque50To60PercentUsage = positionTorque50To60PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque60To70PercentUsage()
    {
        return positionTorque60To70PercentUsage;
    }

    public void setPositionTorque60To70PercentUsage(Double positionTorque60To70PercentUsage)
    {
        this.positionTorque60To70PercentUsage = positionTorque60To70PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque70To80PercentUsage()
    {
        return positionTorque70To80PercentUsage;
    }

    public void setPositionTorque70To80PercentUsage(Double positionTorque70To80PercentUsage)
    {
        this.positionTorque70To80PercentUsage = positionTorque70To80PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorque80To90PercentUsage()
    {
        return positionTorque80To90PercentUsage;
    }

    public void setPositionTorque80To90PercentUsage(Double positionTorque80To90PercentUsage)
    {
        this.positionTorque80To90PercentUsage = positionTorque80To90PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getPositionTorqueOver90PercentUsage()
    {
        return positionTorqueOver90PercentUsage;
    }

    public void setPositionTorqueOver90PercentUsage(Double positionTorqueOver90PercentUsage)
    {
        this.positionTorqueOver90PercentUsage = positionTorqueOver90PercentUsage;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusConstructionDailyUsageReportData getDeviceData()
    {
        return (JbusConstructionDailyUsageReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusConstructionDailyUsageReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusConstructionDailyUsageReportData getDeviceDataConverted()
    {
        return (JbusConstructionDailyUsageReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusConstructionDailyUsageReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
