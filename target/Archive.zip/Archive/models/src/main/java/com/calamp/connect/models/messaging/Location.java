package com.calamp.connect.models.messaging;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "location")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "location")
@JsonRootName("location")
@JsonTypeName("location")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class Location
{
    @XmlAttribute(name = "datetime")
    @XmlJavaTypeAdapter(value = DateAdapter.class, type = Date.class)
    private Date               datetime;
    @XmlElement(name = "Latitude", nillable = true)
    private double             latitude;
    @XmlElement(name = "Longitude", nillable = true)
    private double             longitude;
    @XmlElement(name = "Altitude", nillable = true)
    private Altitude           altitude;
    @XmlElement(name = "AltitudeUnits", nillable = false)
    private String             altitudeUnits;
    public static final String JSON_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public Location()
    {
    }

    @JsonFormat(shape = Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getDatetime()
    {
        return datetime;
    }

    public void setDatetime(Date datetime)
    {
        this.datetime = datetime;
    }

    public double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(double latitude)
    {
        this.latitude = latitude;
    }

    public double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(double longitude)
    {
        this.longitude = longitude;
    }

    public Altitude getAltitude()
    {
        return altitude;
    }

    public void setAltitude(Altitude altitude)
    {
        this.altitude = altitude;
    }

    public String getAltitudeUnits()
    {
        return altitudeUnits;
    }

    public void setAltitudeUnits(String altitudeUnits)
    {
        this.altitudeUnits = altitudeUnits;
    }

    @Override
    public String toString()
    {
        return "Location : {datetime:" + datetime + ", latitude:" + latitude + ", longitude:" + longitude + ", altitude:" + altitude
                + ", altitudeUnits:" + altitudeUnits + "}";
    }
}
