package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "geoZoneInformation")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("geoZoneInformation")
@JsonTypeName("geoZoneInformation")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GeoZoneInformation
{
    Integer     distanceEast;
    Integer     distanceNorth;
    Integer     hysteresis;
    Double      latitude;
    Double      longitude;
    GeoZoneType type;
    Integer     zoneId;


    public Integer getDistanceEast()
    {
        return distanceEast;
    }

    public Integer getDistanceNorth()
    {
        return distanceNorth;
    }

    public Integer getHysteresis()
    {
        return hysteresis;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public GeoZoneType getType()
    {
        return type;
    }

    public Integer getZoneId()
    {
        return zoneId;
    }

    public void setDistanceEast(Integer distanceEast)
    {
        this.distanceEast = distanceEast;
    }

    public void setDistanceNorth(Integer distanceNorth)
    {
        this.distanceNorth = distanceNorth;
    }

    public void setHysteresis(Integer hysteresis)
    {
        this.hysteresis = hysteresis;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public void setType(GeoZoneType type)
    {
        this.type = type;
    }

    public void setZoneId(Integer zoneId)
    {
        this.zoneId = zoneId;
    }
}
