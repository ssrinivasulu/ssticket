package com.calamp.connect.models.messaging;

import javax.measure.quantity.Pressure;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.calamp.connect.framework.quantity.JBUSTemperature;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("jbusHydraulicReportData")
@JsonTypeName("jbusHydraulicReportData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@XmlType(propOrder = { "avgHydraulicChargePressure", "avgHydraulicOilTemperature", "maxHydraulicChargePressure", "maxHydraulicOilTemperature",
        "minHydraulicChargePressure", "minHydraulicOilTemperature" })
@JsonPropertyOrder({ "avgHydraulicChargePressure", "avgHydraulicOilTemperature", "maxHydraulicChargePressure", "maxHydraulicOilTemperature",
        "minHydraulicChargePressure", "minHydraulicOilTemperature" })
public class JbusHydraulicReportData extends DeviceData
{
    @ConvertUnit(type = Pressure.class)
    private HeaderData minHydraulicChargePressure;
    @ConvertUnit(type = Pressure.class)
    private HeaderData maxHydraulicChargePressure;
    @ConvertUnit(type = Pressure.class)
    private HeaderData avgHydraulicChargePressure;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData minHydraulicOilTemperature;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData maxHydraulicOilTemperature;
    @ConvertUnit(type = JBUSTemperature.class)
    private HeaderData avgHydraulicOilTemperature;

    public HeaderData getMinHydraulicChargePressure()
    {
        return minHydraulicChargePressure;
    }

    public void setMinHydraulicChargePressure(HeaderData minHydraulicChargePressure)
    {
        this.minHydraulicChargePressure = minHydraulicChargePressure;
    }

    public HeaderData getMaxHydraulicChargePressure()
    {
        return maxHydraulicChargePressure;
    }

    public void setMaxHydraulicChargePressure(HeaderData maxHydraulicChargePressure)
    {
        this.maxHydraulicChargePressure = maxHydraulicChargePressure;
    }

    public HeaderData getAvgHydraulicChargePressure()
    {
        return avgHydraulicChargePressure;
    }

    public void setAvgHydraulicChargePressure(HeaderData avgHydraulicChargePressure)
    {
        this.avgHydraulicChargePressure = avgHydraulicChargePressure;
    }

    public HeaderData getMinHydraulicOilTemperature()
    {
        return minHydraulicOilTemperature;
    }

    public void setMinHydraulicOilTemperature(HeaderData minHydraulicOilTemperature)
    {
        this.minHydraulicOilTemperature = minHydraulicOilTemperature;
    }

    public HeaderData getMaxHydraulicOilTemperature()
    {
        return maxHydraulicOilTemperature;
    }

    public void setMaxHydraulicOilTemperature(HeaderData maxHydraulicOilTemperature)
    {
        this.maxHydraulicOilTemperature = maxHydraulicOilTemperature;
    }

    public HeaderData getAvgHydraulicOilTemperature()
    {
        return avgHydraulicOilTemperature;
    }

    public void setAvgHydraulicOilTemperature(HeaderData avgHydraulicOilTemperature)
    {
        this.avgHydraulicOilTemperature = avgHydraulicOilTemperature;
    }

}
