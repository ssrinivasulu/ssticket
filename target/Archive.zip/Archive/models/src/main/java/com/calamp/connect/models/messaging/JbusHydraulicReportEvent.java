package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "jbusHydraulicReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusHydraulicReportEvent")
@JsonTypeName("jbusHydraulicReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "avgHydraulicChargePressure",
        "avgHydraulicOilTemperature", "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp",
        "deviceMessageSequenceNumber", "deviceName", "eventCode", "eventTime", "eventType", "inputs", "lmdirectMessageType", "machineState",
        "maxHydraulicChargePressure", "maxHydraulicOilTemperature", "messageReceivedTime", "messageType", "messageUuid",
        "minHydraulicChargePressure", "minHydraulicOilTemperature", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route",
        "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
@XmlType(name = "jbusHydraulicReportEvent", propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName",
        "avgHydraulicChargePressure", "avgHydraulicOilTemperature", "deviceAirId", "deviceData", "deviceDataConverted", "deviceEsn", "deviceId",
        "deviceIp", "deviceMessageSequenceNumber", "deviceName", "eventCode", "eventTime", "eventType", "inputs", "lmdirectMessageType",
        "machineState", "maxHydraulicChargePressure", "maxHydraulicOilTemperature", "messageReceivedTime", "messageType", "messageUuid",
        "minHydraulicChargePressure", "minHydraulicOilTemperature", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route",
        "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
public class JbusHydraulicReportEvent extends DeviceEvent
{
    private MachineState            machineState;
    private Double                  minHydraulicChargePressure;
    private Double                  maxHydraulicChargePressure;
    private Double                  avgHydraulicChargePressure;
    private Integer                 minHydraulicOilTemperature;
    private Integer                 maxHydraulicOilTemperature;
    private Integer                 avgHydraulicOilTemperature;
    private JbusHydraulicReportData deviceData;
    private JbusHydraulicReportData deviceDataConverted;

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMinHydraulicChargePressure()
    {
        return minHydraulicChargePressure;
    }

    public void setMinHydraulicChargePressure(Double minHydraulicChargePressure)
    {
        this.minHydraulicChargePressure = minHydraulicChargePressure;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getMaxHydraulicChargePressure()
    {
        return maxHydraulicChargePressure;
    }

    public void setMaxHydraulicChargePressure(Double maxHydraulicChargePressure)
    {
        this.maxHydraulicChargePressure = maxHydraulicChargePressure;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getAvgHydraulicChargePressure()
    {
        return avgHydraulicChargePressure;
    }

    public void setAvgHydraulicChargePressure(Double avgHydraulicChargePressure)
    {
        this.avgHydraulicChargePressure = avgHydraulicChargePressure;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMinHydraulicOilTemperature()
    {
        return minHydraulicOilTemperature;
    }

    public void setMinHydraulicOilTemperature(Integer minHydraulicOilTemperature)
    {
        this.minHydraulicOilTemperature = minHydraulicOilTemperature;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getMaxHydraulicOilTemperature()
    {
        return maxHydraulicOilTemperature;
    }

    public void setMaxHydraulicOilTemperature(Integer maxHydraulicOilTemperature)
    {
        this.maxHydraulicOilTemperature = maxHydraulicOilTemperature;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getAvgHydraulicOilTemperature()
    {
        return avgHydraulicOilTemperature;
    }

    public void setAvgHydraulicOilTemperature(Integer avgHydraulicOilTemperature)
    {
        this.avgHydraulicOilTemperature = avgHydraulicOilTemperature;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusHydraulicReportData getDeviceData()
    {
        return (JbusHydraulicReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusHydraulicReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusHydraulicReportData getDeviceDataConverted()
    {
        return (JbusHydraulicReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusHydraulicReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
