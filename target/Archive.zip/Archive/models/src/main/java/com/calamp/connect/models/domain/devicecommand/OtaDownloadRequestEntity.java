package com.calamp.connect.models.domain.devicecommand;
public class OtaDownloadRequestEntity extends DeviceCommandMessageRequestEntity
{
    private String deviceType;
    private String fileType;
    private String fileLength;
    private String fileVersion;
    private String downloadProtocol;
    private String serverName;
    private String filePath;
    private String username;
    private String password;
    private String applyDate;
    private String checksum;
    private String attachedDeviceAddress;
    
    /**
     * @return the deviceType
     */
    public String getDeviceType()
    {
        return deviceType;
    }

    /**
     * @param deviceType the deviceType to set
     */
    public void setDeviceType(String deviceType)
    {
        this.deviceType = deviceType;
    }

    /**
     * @return the fileType
     */
    public String getFileType()
    {
        return fileType;
    }

    /**
     * @param fileType the fileType to set
     */
    public void setFileType(String fileType)
    {
        this.fileType = fileType;
    }

    /**
     * @return the fileLength
     */
    public String getFileLength()
    {
        return fileLength;
    }

    /**
     * @param fileLength the fileLength to set
     */
    public void setFileLength(String fileLength)
    {
        this.fileLength = fileLength;
    }

    /**
     * @return the fileVersion
     */
    public String getFileVersion()
    {
        return fileVersion;
    }

    /**
     * @param fileVersion the fileVersion to set
     */
    public void setFileVersion(String fileVersion)
    {
        this.fileVersion = fileVersion;
    }

    /**
     * @return the downloadProtocol
     */
    public String getDownloadProtocol()
    {
        return downloadProtocol;
    }

    /**
     * @param downloadProtocol the downloadProtocol to set
     */
    public void setDownloadProtocol(String downloadProtocol)
    {
        this.downloadProtocol = downloadProtocol;
    }

    /**
     * @return the serverName
     */
    public String getServerName()
    {
        return serverName;
    }

    /**
     * @param serverName the serverName to set
     */
    public void setServerName(String serverName)
    {
        this.serverName = serverName;
    }

    /**
     * @return the filePath
     */
    public String getFilePath()
    {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath)
    {
        this.filePath = filePath;
    }

    /**
     * @return the username
     */
    public String getUsername()
    {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword()
    {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * @return the applyDate
     */
    public String getApplyDate()
    {
        return applyDate;
    }

    /**
     * @param applyDate the applyDate to set
     */
    public void setApplyDate(String applyDate)
    {
        this.applyDate = applyDate;
    }

    /**
     * @return the checksum
     */
    public String getChecksum()
    {
        return checksum;
    }

    /**
     * @param checksum the checksum to set
     */
    public void setChecksum(String checksum)
    {
        this.checksum = checksum;
    }

    /**
     * @return the attachedDeviceAddress
     */
    public String getAttachedDeviceAddress()
    {
        return attachedDeviceAddress;
    }

    /**
     * @param attachedDeviceAddress the attachedDeviceAddress to set
     */
    public void setAttachedDeviceAddress(String attachedDeviceAddress)
    {
        this.attachedDeviceAddress = attachedDeviceAddress;
    }
    
    @Override
    public String toString()
    {
        return "OtaDownloadRequest{" +
                "deviceType=" + deviceType +
                ", fileType=" + fileType +
                ", fileLength=" + fileLength +
                ", fileVersion=" + fileVersion +
                ", downloadProtocol=" + downloadProtocol +
                ", serverName=" + serverName +
                ", filePath=" + filePath +
                ", username=" + username +
                ", password=" + password +
                ", applyDate=" + applyDate +
                ", checksum=" + checksum +
                ", attachedDeviceAddress=" + attachedDeviceAddress +
                "}";
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OtaDownloadRequestEntity that = (OtaDownloadRequestEntity) o;

        if (deviceType != null ? !deviceType.equals(that.deviceType) : that.deviceType != null) return false;
        if (fileType != null ? !fileType.equals(that.fileType) : that.fileType != null) return false;
        if (fileLength != null ? !fileLength.equals(that.fileLength) : that.fileLength != null) return false;
        if (fileVersion != null ? !fileVersion.equals(that.fileVersion) : that.fileVersion != null) return false;
        if (downloadProtocol != null ? !downloadProtocol.equals(that.downloadProtocol) : that.downloadProtocol != null) return false;
        if (serverName != null ? !serverName.equals(that.serverName) : that.serverName != null) return false;
        if (filePath != null ? !filePath.equals(that.filePath) : that.filePath != null) return false;
        if (username != null ? !username.equals(that.username) : that.username != null) return false;
        if (password != null ? !password.equals(that.password) : that.password != null) return false;
        if (applyDate != null ? !applyDate.equals(that.applyDate) : that.applyDate != null) return false;
        if (checksum != null ? !checksum.equals(that.checksum) : that.checksum != null) return false;
        if (attachedDeviceAddress != null ? !attachedDeviceAddress.equals(that.attachedDeviceAddress) : that.attachedDeviceAddress != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (deviceType != null ? deviceType.hashCode() : 0);
        result = 31 * result + (fileType != null ? fileType.hashCode() : 0);
        result = 31 * result + (fileLength != null ? fileLength.hashCode() : 0);
        result = 31 * result + (fileVersion != null ? fileVersion.hashCode() : 0);
        result = 31 * result + (downloadProtocol != null ? downloadProtocol.hashCode() : 0);
        result = 31 * result + (serverName != null ? serverName.hashCode() : 0);
        result = 31 * result + (filePath != null ? filePath.hashCode() : 0);
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (password != null ? password.hashCode() : 0);
        result = 31 * result + (applyDate != null ? applyDate.hashCode() : 0);
        result = 31 * result + (checksum != null ? checksum.hashCode() : 0);
        result = 31 * result + (attachedDeviceAddress != null ? attachedDeviceAddress.hashCode() : 0);
        
        return result;
    }
}