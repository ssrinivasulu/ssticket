package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "gpsFixStatus")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("gpsFixStatus")
@JsonTypeName("gpsFixStatus")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class GpsFixStatus
{
    private Boolean predicted;              // true = OK, false = Error
    private Boolean differentiallyCorrected; // true = OK, false = Error
    private Boolean lastKnown;              // true = OK, false = Error
    private Boolean invalidFix;             // true=Yes, false=No
    private Boolean twoDFix;                // true = OK, false = error
    private Boolean historic;               // true = OK, false = Error
    private Boolean invalidTime;

    public Boolean getPredicted()
    {
        return predicted;
    }

    public void setPredicted(Boolean predicted)
    {
        this.predicted = predicted;
    }

    public Boolean getDifferentiallyCorrected()
    {
        return differentiallyCorrected;
    }

    public void setDifferentiallyCorrected(Boolean differentiallyCorrected)
    {
        this.differentiallyCorrected = differentiallyCorrected;
    }

    public Boolean getLastKnown()
    {
        return lastKnown;
    }

    public void setLastKnown(Boolean lastKnown)
    {
        this.lastKnown = lastKnown;
    }

    public Boolean getInvalidFix()
    {
        return invalidFix;
    }

    public void setInvalidFix(Boolean invalidFix)
    {
        this.invalidFix = invalidFix;
    }

    public Boolean getTwoDFix()
    {
        return twoDFix;
    }

    public void setTwoDFix(Boolean twoDFix)
    {
        this.twoDFix = twoDFix;
    }

    public Boolean getHistoric()
    {
        return historic;
    }

    public void setHistoric(Boolean historic)
    {
        this.historic = historic;
    }

    public Boolean getInvalidTime()
    {
        return invalidTime;
    }

    public void setInvalidTime(Boolean invalidTime)
    {
        this.invalidTime = invalidTime;
    }

}
