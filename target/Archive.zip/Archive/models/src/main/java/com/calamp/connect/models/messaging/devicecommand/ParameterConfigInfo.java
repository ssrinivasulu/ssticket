package com.calamp.connect.models.messaging.devicecommand;

import java.util.Arrays;

import com.calamp.connect.util.BinaryUtils;


public class ParameterConfigInfo
{
    private Integer parameterId;
    private Integer parameterIndex;
    private byte[] value;
    private Long decodeValue;

    public ParameterConfigInfo()
    {
    }

    public ParameterConfigInfo(Integer parameterId, Integer parameterIndex, byte[] value)
    {
        this.parameterId = parameterId;
        this.parameterIndex = parameterIndex;
        this.value = value;
    }

    public Integer getParameterId()
    {
        return parameterId;
    }

    public Integer getParameterIndex()
    {
        return parameterIndex;
    }

    public Long getDecodeValue()
    {
        if (value != null)
        {
            decodeValue = BinaryUtils.convertBase64ToDecimal(value);
        }
        return decodeValue;
    }

    public void setParameterId(Integer parameterId)
    {
        this.parameterId = parameterId;
    }

    public void setParameterIndex(Integer parameterIndex)
    {
        this.parameterIndex = parameterIndex;
    }

    public void setValue(byte[] value)
    {
        this.value = value;
    }

    public byte[] getValue()
    {
        return value;
    }
 
    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ParameterConfigInfo that = (ParameterConfigInfo) o;

        if (parameterId != null ? !parameterId.equals(that.parameterId) : that.parameterId != null) return false;
        if (parameterIndex != null ? !parameterIndex.equals(that.parameterIndex) : that.parameterIndex != null)
            return false;
        if (!Arrays.equals(value, that.value)) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = parameterId != null ? parameterId.hashCode() : 0;
        result = 31 * result + (parameterIndex != null ? parameterIndex.hashCode() : 0);
        result = 31 * result + (value != null ? Arrays.hashCode(value) : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "ParameterConfigInfo{" +
                "parameterId=" + parameterId +
                ", parameterIndex=" + parameterIndex +
                ", value=" + Arrays.toString(value) +
                '}';
    }
}
