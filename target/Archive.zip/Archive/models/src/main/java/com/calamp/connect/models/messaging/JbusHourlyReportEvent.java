package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * Java class for JBUSHourlyReportEvent complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="JBUSHourlyReportEvent"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GMTTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="deviceID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="vehicleID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="vehicleVIN" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="driverID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="JBUSHourlyReportMessage" type="{http://calamp.com/DataFeedService/}JBUSHourlyReportMessage"/&gt;
 *         &lt;any processContents='skip' maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlRootElement(name = "jbusHourlyReportEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusHourlyReportEvent")
@JsonTypeName("jbusHourlyReportEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@JsonPropertyOrder({ "deviceId", "deviceAirId", "deviceEsn", "deviceName", "messageUuid", "accountId", "accountName", "asset", "assetName",
        "assetId", "eventTime", "engineCoolantTemperature", "engineOilTemperature", "engineOilPressure", "engineCrankcasePressure",
        "engineCoolantPressure", "engineBatteryVoltage", "engineFuelTankLevel1", "engineFuelTankLevel2", "eventType", "lmdirectMessageType",
        "transmissionOilTemperature", "averageFuelEconomy", "vin", "vinResponse", "account", "deviceData", "deviceDataConverted", "deviceIp",
        "deviceMessageSequenceNumber", "eventCode", "inputs", "messageReceivedTime", "messageType", "pegBehaviorId", "port", "primaryOperator",
        "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix" })
@XmlType(name = "jbusHourlyReportEvent", propOrder = { "deviceId", "deviceAirId", "deviceEsn", "deviceName", "messageUuid", "accountId",
        "accountName", "asset", "assetName", "assetId", "eventTime", "engineCoolantTemperature", "engineOilTemperature", "engineOilPressure",
        "engineCrankcasePressure", "engineCoolantPressure", "engineBatteryVoltage", "engineFuelTankLevel1", "engineFuelTankLevel2",
        "lmdirectMessageType", "transmissionOilTemperature", "averageFuelEconomy", "vin", "vinResponse", "account", "deviceData",
        "deviceDataConverted", "deviceIp", "deviceMessageSequenceNumber", "eventCode", "eventType", "inputs", "messageReceivedTime", "messageType",
        "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix" })
public class JbusHourlyReportEvent extends DeviceEvent
{
    private Integer              engineCoolantTemperature;
    private Double               engineOilTemperature;
    private Integer              engineOilPressure;
    private Double               engineCrankcasePressure;
    private Integer              engineCoolantPressure;
    private Double               engineBatteryVoltage;
    private Double               engineFuelTankLevel1;
    private Double               engineFuelTankLevel2;
    private Double               transmissionOilTemperature;
    private Double               averageFuelEconomy;
    private JbusHourlyReportData deviceData;
    private JbusHourlyReportData deviceDataConverted;

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getEngineCoolantTemperature()
    {
        return engineCoolantTemperature;
    }

    public void setEngineCoolantTemperature(Integer engineCoolantTemperature)
    {
        this.engineCoolantTemperature = engineCoolantTemperature;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineOilTemperature()
    {
        return engineOilTemperature;
    }

    public void setEngineOilTemperature(Double engineOilTemperature)
    {
        this.engineOilTemperature = engineOilTemperature;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getEngineOilPressure()
    {
        return engineOilPressure;
    }

    public void setEngineOilPressure(Integer engineOilPressure)
    {
        this.engineOilPressure = engineOilPressure;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineCrankcasePressure()
    {
        return engineCrankcasePressure;
    }

    public void setEngineCrankcasePressure(Double engineCrankcasePressure)
    {
        this.engineCrankcasePressure = engineCrankcasePressure;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Integer getEngineCoolantPressure()
    {
        return engineCoolantPressure;
    }

    public void setEngineCoolantPressure(Integer engineCoolantPressure)
    {
        this.engineCoolantPressure = engineCoolantPressure;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineBatteryVoltage()
    {
        return engineBatteryVoltage;
    }

    public void setEngineBatteryVoltage(Double engineBatteryVoltage)
    {
        this.engineBatteryVoltage = engineBatteryVoltage;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineFuelTankLevel1()
    {
        return engineFuelTankLevel1;
    }

    public void setEngineFuelTankLevel1(Double engineFuelTankLevel1)
    {
        this.engineFuelTankLevel1 = engineFuelTankLevel1;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getEngineFuelTankLevel2()
    {
        return engineFuelTankLevel2;
    }

    public void setEngineFuelTankLevel2(Double engineFuelTankLevel2)
    {
        this.engineFuelTankLevel2 = engineFuelTankLevel2;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getTransmissionOilTemperature()
    {
        return transmissionOilTemperature;
    }

    public void setTransmissionOilTemperature(Double transmissionOilTemperature)
    {
        this.transmissionOilTemperature = transmissionOilTemperature;
    }

    @XmlElement
    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Double getAverageFuelEconomy()
    {
        return averageFuelEconomy;
    }

    public void setAverageFuelEconomy(Double averageFuelEconomy)
    {
        this.averageFuelEconomy = averageFuelEconomy;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public JbusHourlyReportData getDeviceData()
    {
        return (JbusHourlyReportData) super.getDeviceData();
    }

    public void setDeviceData(JbusHourlyReportData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public JbusHourlyReportData getDeviceDataConverted()
    {
        return (JbusHourlyReportData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(JbusHourlyReportData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
