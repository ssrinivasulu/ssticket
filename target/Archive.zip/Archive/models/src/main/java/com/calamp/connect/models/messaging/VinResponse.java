package com.calamp.connect.models.messaging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class VinResponse {
    private static final transient Logger logger = LoggerFactory.getLogger(VinResponse.class);
    private static final String STATUS_SUCCESS = "OK";
    private static final String STATUS_FAIL = "NOT OK";
    private String vin;
    private String vinRegion;
    private String errorCode;
    private String errorMsg;
    private String manufacturer;
    private String year;
    private String make;
    private String model;
    private String engine;
    private String trim;
    private String engineSize;
    private String fuelType;
    private boolean containsNull;
    private String status;

    public VinResponse getVinResponse(String jsonString, String esn_uuid) {
    	 VinResponse vinResponse = new VinResponse();
        try {
            JSONParser parser = new JSONParser();
            JSONObject jsonResponse = (JSONObject) parser.parse(jsonString);
           
            if (jsonResponse.get("ErrorCode") != null) {
            	vinResponse.setStatus(STATUS_FAIL);
            	 containsNull = true;
                vinResponse.setErrorCode(jsonResponse.get("ErrorCode").toString());
                vinResponse.setErrorMsg(jsonResponse.get("ErrorMsg").toString());
            } else if (!containsNull) {
            	vinResponse.setStatus(STATUS_SUCCESS);
                if (jsonResponse.get("Vin") != null) {
                	vinResponse.setVin(jsonResponse.get("Vin").toString());
                } else {
                    containsNull = true;
                }
                if (jsonResponse.get("VinRegion") != null) {
                	vinResponse.setVinRegion(jsonResponse.get("VinRegion").toString());
                } else {
                    containsNull = true;
                }

                if (jsonResponse.get("ExternalYmme") != null) {
                    JSONObject externalYmmeResp = (JSONObject) jsonResponse
                            .get("ExternalYmme");
                    if (externalYmmeResp.get("ManufacturerString") != null) {
                    	vinResponse.setManufacturer(externalYmmeResp.get("ManufacturerString").toString());
                    } else {
                        containsNull = true;
                    }
                    if (externalYmmeResp.get("YearString") != null) {
                    	vinResponse.setYear(externalYmmeResp.get("YearString").toString());
                    } else {
                        containsNull = true;
                    }
                    if (externalYmmeResp.get("MakeString") != null) {
                    	vinResponse.setMake(externalYmmeResp.get("MakeString").toString());
                    } else {
                        containsNull = true;
                    }
                    if (externalYmmeResp.get("ModelString") != null) {
                    	vinResponse.setModel(externalYmmeResp.get("ModelString").toString());
                    } else {
                        containsNull = true;
                    }
                    if (externalYmmeResp.get("EngineString") != null) {
                    	vinResponse.setEngine(externalYmmeResp.get("EngineString").toString());
                    } else {
                        containsNull = true;
                    }
                    if (externalYmmeResp.get("TrimString") != null) {
                    	vinResponse.setTrim(externalYmmeResp.get("TrimString").toString());
                    } else {
                        containsNull = true;
                    }
                    if (externalYmmeResp.get("EngineSizeString") != null) {
                    	vinResponse.setEngineSize(externalYmmeResp.get("EngineSizeString").toString());
                    } else {
                        containsNull = true;
                    }
                    if (externalYmmeResp.get("FuelString") != null) {
                    	vinResponse.setFuelType(externalYmmeResp.get("FuelString").toString());
                    } else {
                        containsNull = true;
                    }
                } else {
                    containsNull = true;
                }
            } 
        } catch (Exception e) {
            logger.error(String.format("%serror parsing json string %s",esn_uuid,jsonString));
            e.printStackTrace();
            logger.error(String.format("%s Error:%s",esn_uuid,e.getMessage()));
        }
		return vinResponse;
    }
    public VinResponse fillNullValues(String jsonString,
			VinResponse vinResponse) {
    	 try {
             JSONParser parser = new JSONParser();
             JSONObject jsonResponse = (JSONObject) parser.parse(jsonString);
             if (jsonResponse.get("ErrorCode") != null) {
            	 vinResponse.setStatus(STATUS_FAIL);
            	 vinResponse.setErrorCode(jsonResponse.get("ErrorCode").toString());
                 vinResponse.setErrorMsg(jsonResponse.get("ErrorMsg").toString());
             }else{

            	 vinResponse.setStatus(STATUS_SUCCESS);
                
                 if (vinResponse.getVin() != null) {
                	 vinResponse.setVin(jsonResponse.get("Vin").toString());
                 }
                 if (vinResponse.getVinRegion() != null) {
                	 vinResponse.setVinRegion(jsonResponse.get("VinRegion").toString());
                 }
                 JSONObject externalYmmeResp = (JSONObject) jsonResponse.get("ExternalYmme");
                 if (externalYmmeResp != null) {
                     if (vinResponse.getManufacturer() != null) {
                    	 vinResponse.setManufacturer(externalYmmeResp
                                 .get("ManufacturerString").toString());
                     }
                     if (vinResponse.getYear() != null) {
                    	 vinResponse.setYear(externalYmmeResp.get(
                                 "YearString").toString());
                     }
                     if (vinResponse.getMake() != null) {
                    	 vinResponse.setMake(externalYmmeResp.get(
                                 "MakeString").toString());
                     }
                     if (vinResponse.getModel() != null) {
                    	 vinResponse.setModel(externalYmmeResp.get(
                                 "ModelString").toString());
                     }
                     if (vinResponse.getEngine() != null) {
                    	 vinResponse.setEngine(externalYmmeResp.get(
                                 "EngineString").toString());
                     }
                     if (vinResponse.getTrim() != null) {
                    	 vinResponse.setTrim(externalYmmeResp.get(
                                 "TrimString").toString());
                     }
                     if (vinResponse.getEngineSize() != null) {
                    	 vinResponse.setEngineSize(externalYmmeResp.get(
                                 "EngineSizeString").toString());
                     }
                     if (vinResponse.getFuelType() != null) {
                    	 vinResponse.setFuelType(externalYmmeResp.get(
                                 "FuelString").toString());
                     }
                 }
                 containsNull=false;
             }
    	 }catch (Exception e) {
             logger.error("error parcing json string" + jsonString);
             e.printStackTrace();
             logger.error(e.getMessage());
         }
		return vinResponse;
	}

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getVinRegion() {
        return vinRegion;
    }

    public void setVinRegion(String vinRegion) {
        this.vinRegion = vinRegion;
    }

    public boolean getStatus() {
        // TODO Auto-generated method stub
        return STATUS_SUCCESS.equals(status);
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public boolean isContainsNull() {
        return containsNull;
    }

    public void setContainsNull(boolean containsNull) {
        this.containsNull = containsNull;
    }

    public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getTrim() {
		return trim;
	}
	public void setTrim(String trim) {
		this.trim = trim;
	}
	public String getEngineSize() {
		return engineSize;
	}
	public void setEngineSize(String engineSize) {
		this.engineSize = engineSize;
	}
	public String getFuelType() {
		return fuelType;
	}
	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}
	public static void main(String[] args) {
        String jsonResponse = ""
                + "{ \"VehicleInfo\": \"LgAjGgAnAAAAbAAAAHIKGvQBAAAdAjQAbQoa9AEAAB1JAABtAAAhAAAAMUmgAFQFAA==\", \"Vin\": \"1G1PC5SB4F7295162\", \"VinRegion\": \"US\", \"ExternalYmme\": "
                + "{ \"ManufacturerString\": \"GENERAL MOTORS\", \"YearString\": \"2015\", \"MakeString\": \"CHEVROLET\", \"ModelString\": \"CRUZE\","
                + " \"EngineString\": \"L4, 1.4L; DOHC; 16V; SEFI; Turbo\", \"TrimString\": \"LT\", \"EngineSizeString\": \"1364\", \"FuelString\": \"Gas\" } }";

        VinResponse response = new VinResponse();
        response.getVinResponse(jsonResponse, "ESN:DummyESN:UUID:DummyUuid");
        System.out.println(response.getVin() + "\n " + response.getEngineSize());
        String errorJsonResponse = ""
                + "{\"ErrorCode\":\"VIN_NOT_DECODABLE\", \"ErrorMsg\":\"Vin is not decodable\" }";
        response.getVinResponse(errorJsonResponse,  "ESN:DummyESN:UUID:DummyUuid");
        System.out.println(response.getVin() + "\n " + response.getErrorCode());
    }

}
