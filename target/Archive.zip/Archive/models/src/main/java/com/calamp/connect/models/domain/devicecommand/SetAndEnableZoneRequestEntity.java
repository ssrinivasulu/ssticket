package com.calamp.connect.models.domain.devicecommand;

import com.fasterxml.jackson.annotation.JsonCreator;

public class SetAndEnableZoneRequestEntity extends DeviceCommandMessageRequestEntity
{
    private int hysteresis;
    private int number;
    private int size;

    @JsonCreator
    public SetAndEnableZoneRequestEntity() {}

    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        if (!super.equals(o)){
            return false;
        }

        SetAndEnableZoneRequestEntity that = (SetAndEnableZoneRequestEntity) o;

        if (hysteresis != that.hysteresis){
            return false;
        }

        if (number != that.number){
            return false;
        }

        if (size != that.size){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = super.hashCode();

        result = 31 * result + number;
        result = 31 * result + hysteresis;
        result = 31 * result + size;

        return result;
    }

    @Override
    public String toString()
    {
        return "SetAndEnableZoneRequest{" + "number=" + number + ", hysteresis=" + hysteresis + ", size=" + size + '}';
    }

    public int getHysteresis()
    {
        return hysteresis;
    }

    public int getNumber()
    {
        return number;
    }

    public int getSize()
    {
        return size;
    }

    public void setHysteresis(int hysteresis)
    {
        this.hysteresis = hysteresis;
    }

    public void setNumber(int number)
    {
        this.number = number;
    }

    public void setSize(int size)
    {
        this.size = size;
    }
}
