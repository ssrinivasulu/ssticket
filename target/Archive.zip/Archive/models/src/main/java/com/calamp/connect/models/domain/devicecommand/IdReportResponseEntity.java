/*
 * 
 */

package com.calamp.connect.models.domain.devicecommand;

import com.calamp.connect.models.db.domain.UnitStatusEntity;

public class IdReportResponseEntity extends DeviceCommandMessageResponseEntity
{
    private Integer          scriptVersion;
    private Integer          configVersion;
    private String           appVersion;
    private Integer          vehicleClass;
    private UnitStatusEntity unitStatus;
    private Integer          modemSelection;
    private Integer          applicationId;
    private Integer          mobileIdType;
    private Long             queryId;
    private String           esn;
    private String           imei;
    private String           imsi;
    private String           min;
    private String           iccId;
    private String           extension;

    /**
     * @return the scriptVersion
     */
    public Integer getScriptVersion()
    {
        return scriptVersion;
    }

    /**
     * @param scriptVersion
     *            the scriptVersion to set
     */
    public void setScriptVersion(Integer scriptVersion)
    {
        this.scriptVersion = scriptVersion;
    }

    /**
     * @return the configVersion
     */
    public Integer getConfigVersion()
    {
        return configVersion;
    }

    /**
     * @param configVersion
     *            the configVersion to set
     */
    public void setConfigVersion(Integer configVersion)
    {
        this.configVersion = configVersion;
    }

    /**
     * @return the appVersion
     */
    public String getAppVersion()
    {
        return appVersion;
    }

    /**
     * @param appVersion
     *            the appVersion to set
     */
    public void setAppVersion(String appVersion)
    {
        this.appVersion = appVersion;
    }

    /**
     * @return the vehicleClass
     */
    public Integer getVehicleClass()
    {
        return vehicleClass;
    }

    /**
     * @param vehicleClass
     *            the vehicleClass to set
     */
    public void setVehicleClass(Integer vehicleClass)
    {
        this.vehicleClass = vehicleClass;
    }

    /**
     * @return the unitStatus
     */
    public UnitStatusEntity getUnitStatus()
    {
        return unitStatus;
    }

    /**
     * @param unitStatus
     *            the unitStatus to set
     */
    public void setUnitStatus(UnitStatusEntity unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    /**
     * @return the modemSelection
     */
    public Integer getModemSelection()
    {
        return modemSelection;
    }

    /**
     * @param modemSelection
     *            the modemSelection to set
     */
    public void setModemSelection(Integer modemSelection)
    {
        this.modemSelection = modemSelection;
    }

    /**
     * @return the applicationId
     */
    public Integer getApplicationId()
    {
        return applicationId;
    }

    /**
     * @param applicationId
     *            the applicationId to set
     */
    public void setApplicationId(Integer applicationId)
    {
        this.applicationId = applicationId;
    }

    /**
     * @return the mobileIdType
     */
    public Integer getMobileIdType()
    {
        return mobileIdType;
    }

    /**
     * @param mobileIdType
     *            the mobileIdType to set
     */
    public void setMobileIdType(Integer mobileIdType)
    {
        this.mobileIdType = mobileIdType;
    }

    /**
     * @return the queryId
     */
    public Long getQueryId()
    {
        return queryId;
    }

    /**
     * @param queryId
     *            the queryId to set
     */
    public void setQueryId(Long queryId)
    {
        this.queryId = queryId;
    }

    /**
     * @return the esn
     */
    public String getEsn()
    {
        return esn;
    }

    /**
     * @param esn
     *            the esn to set
     */
    public void setEsn(String esn)
    {
        this.esn = esn;
    }

    /**
     * @return the imei
     */
    public String getImei()
    {
        return imei;
    }

    /**
     * @param imei
     *            the imei to set
     */
    public void setImei(String imei)
    {
        this.imei = imei;
    }

    /**
     * @return the imsi
     */
    public String getImsi()
    {
        return imsi;
    }

    /**
     * @param imsi
     *            the imsi to set
     */
    public void setImsi(String imsi)
    {
        this.imsi = imsi;
    }

    /**
     * @return the min
     */
    public String getMin()
    {
        return min;
    }

    /**
     * @param min
     *            the min to set
     */
    public void setMin(String min)
    {
        this.min = min;
    }

    /**
     * @return the iccId
     */
    public String getIccId()
    {
        return iccId;
    }

    /**
     * @param iccId
     *            the iccId to set
     */
    public void setIccId(String iccId)
    {
        this.iccId = iccId;
    }

    /**
     * @return the extension
     */
    public String getExtension()
    {
        return extension;
    }

    /**
     * @param extension
     *            the extension to set
     */
    public void setExtension(String extension)
    {
        this.extension = extension;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        IdReportResponseEntity that = (IdReportResponseEntity) o;

        if (scriptVersion != null ? !scriptVersion.equals(that.scriptVersion) : that.scriptVersion != null)
            return false;
        if (configVersion != null ? !configVersion.equals(that.configVersion) : that.configVersion != null)
            return false;
        if (appVersion != null ? !appVersion.equals(that.appVersion) : that.appVersion != null)
            return false;
        if (vehicleClass != null ? !vehicleClass.equals(that.vehicleClass) : that.vehicleClass != null)
            return false;
        if (unitStatus != null ? !unitStatus.equals(that.unitStatus) : that.unitStatus != null)
            return false;
        if (modemSelection != null ? !modemSelection.equals(that.modemSelection) : that.modemSelection != null)
            return false;
        if (applicationId != null ? !applicationId.equals(that.applicationId) : that.applicationId != null)
            return false;
        if (mobileIdType != null ? !mobileIdType.equals(that.mobileIdType) : that.mobileIdType != null)
            return false;
        if (queryId != null ? !queryId.equals(that.queryId) : that.queryId != null)
            return false;
        if (esn != null ? !esn.equals(that.esn) : that.esn != null)
            return false;
        if (imei != null ? !imei.equals(that.imei) : that.imei != null)
            return false;
        if (imsi != null ? !imsi.equals(that.imsi) : that.imsi != null)
            return false;
        if (min != null ? !min.equals(that.min) : that.min != null)
            return false;
        if (iccId != null ? !iccId.equals(that.iccId) : that.iccId != null)
            return false;
        if (extension != null ? !extension.equals(that.extension) : that.extension != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = scriptVersion != null ? scriptVersion.hashCode() : 0;
        result = 31 * result + (configVersion != null ? configVersion.hashCode() : 0);
        result = 31 * result + (appVersion != null ? appVersion.hashCode() : 0);
        result = 31 * result + (vehicleClass != null ? vehicleClass.hashCode() : 0);
        result = 31 * result + (unitStatus != null ? unitStatus.hashCode() : 0);
        result = 31 * result + (modemSelection != null ? modemSelection.hashCode() : 0);
        result = 31 * result + (applicationId != null ? applicationId.hashCode() : 0);
        result = 31 * result + (mobileIdType != null ? mobileIdType.hashCode() : 0);
        result = 31 * result + (queryId != null ? queryId.hashCode() : 0);
        result = 31 * result + (esn != null ? esn.hashCode() : 0);
        result = 31 * result + (imei != null ? imei.hashCode() : 0);
        result = 31 * result + (imsi != null ? imsi.hashCode() : 0);
        result = 31 * result + (min != null ? min.hashCode() : 0);
        result = 31 * result + (iccId != null ? iccId.hashCode() : 0);
        result = 31 * result + (extension != null ? extension.hashCode() : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "IdReportResponse{" + "scriptVersion=" + scriptVersion + ", configVersion=" + configVersion + ", appVersion=" + appVersion
                + ", vehicleClass=" + vehicleClass + ", unitStatus=" + unitStatus + ", modemSelection=" + modemSelection + ", applicationId="
                + applicationId + ", mobileIdType=" + mobileIdType + ", queryId=" + queryId + ", esn=" + esn + ", imei=" + imei + ", imsi=" + imsi
                + ", min=" + min + ", iccId=" + iccId + ", extension=" + extension + '}';
    }
}
