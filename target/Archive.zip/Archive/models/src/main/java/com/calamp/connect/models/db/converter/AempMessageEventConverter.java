package com.calamp.connect.models.db.converter;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.AempMessageEventEntity;
import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class AempMessageEventConverter extends DeviceEventConverter<AempMessageEventEntity, AempMessageEvent>
{

    @Override
    public AempMessageEvent domainToModel(AempMessageEventEntity aempMessageEventEntity) throws Exception
    {
        AempMessageEvent aempMessageEvent = super.convert(aempMessageEventEntity, AempMessageEvent.class);

        return aempMessageEvent;
    }

    @Override
    public AempMessageEvent domainToModel(AempMessageEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<AempMessageEventEntity> getDomainType()
    {
        return AempMessageEventEntity.class;
    }

    @Override
    public Class<AempMessageEvent> getModelType()
    {
        return AempMessageEvent.class;
    }

    @Override
    public AempMessageEventEntity modelToDomain(AempMessageEvent aempMessageEvent) throws Exception
    {
        AempMessageEventEntity aempMessageEventEntity = super.convert(aempMessageEvent, AempMessageEventEntity.class);

        return aempMessageEventEntity;
    }

    @Override
    protected AempMessageEvent customConvert(AempMessageEventEntity entity, AempMessageEvent model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        return model;
    }

    @Override
    protected AempMessageEventEntity customConvert(AempMessageEvent model, AempMessageEventEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        return entity;
    }
}
