/**
 *
 */
package com.calamp.connect.models.db.domain;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

/**
 * @author SSrinivasulu
 *
 */
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
// all fields are included by default
public class VehicleBusCapabilitiesEntity extends DeviceEventEntity
{
    private Boolean absActiveLampIndicator;
    private Boolean absDashIndicator;
    private Boolean acSystemRefrigerantMonitor;
    private Boolean airBagDashIndicator;
    private Boolean batteryVoltageSupported;
    private Boolean brakeIndicatorLightStatus;
    private Boolean brakeSwitchStatusIndicator;
    private Boolean catalystMonitor;
    private Boolean comprehensiveComponentMonitor;
    private Boolean coolantHotLightStatus;
    private Boolean cruiseControlStatus;
    private Boolean egrSystemMonitor;
    private Boolean engineCoolantTemperatureSupported;
    private Boolean engineSpeedSupported;
    private Boolean evaporativeSystemMonitor;
    private Boolean fuelLevelSupported;
    private Boolean fuelLevelRemainingSupported;
    private Boolean fuelRateSupported;
    private Boolean fuelSystemMonitorStatus;
    private Boolean heatedCatalystMonitor;
    private Boolean ho2SHeaterControlMalfunction;
    private Boolean ho2SHeaterResistanceMalfunction;
    private Boolean ignitionStatus;
    private Boolean milStatus;
    private Boolean misfireMonitorStatus;
    private Boolean o2SensorCircuitNoActivity;
    private Boolean o2SensorHeaterCircuitMalfunction;
    private String  obdProtocol;
    private Boolean odometerSupported;
    private Boolean oilPressureLampIndicator;
    private Boolean oxygenSensorHeatedMonitor;
    private Boolean oxygenSensorMonitor;
    private Boolean ptoStatus;
    private Boolean seatBeltFastenedIndicator;
    private Boolean secondaryAirSystemMonitor;
    private Boolean throttlePositionSupported;
    private Boolean transmissionGearSupported;
    private Boolean tripFuelConsumptionSupported;
    private Boolean tripOdometerSupported;
    private Boolean turnSignalStatusSupported;
    private Boolean vehicleSpeedSupported;
    private Boolean calculatedFuelUsageSupported;
    private Boolean engineStateSupported;
    private Boolean serviceIntervalInspectionDistanceSupported;
    private Boolean fuelLevelRemaining3030Supported;
    private Boolean serviceIntervalDaysRemainingSupported;
    private Boolean engineOilTempSupported;
    private Boolean fuelEconomySupported;
    private Boolean dtcCountSupported;
    private Boolean serviceIntervalOilDistanceSupported;
    private Boolean serviceIntervalOilDaysSupported;
    private Boolean engineRunTimeSupported;
    private Boolean ambientAirTempSupported;
    private Boolean barometricPressureSupported;
    private Boolean canTecSupported;
    private Boolean canRecSupported;
    private Boolean canBusModeSupported;
    private Boolean canBusErrorTypeSupported;
    private Boolean maintenanceRequired;
    private String  vin;
    private String  vinRegion;
    private String  manufacturer;
    private String  year;
    private String  make;
    private String  model;
    private String  engine;
    private String  trim;
    private String  engineSize;
    private String  fuelType;

    public VehicleBusCapabilitiesEntity()
    {
        setMsgType(MsgType.VEHICLE_BUS_CAPABILITIES);
    }

    public Boolean getAbsActiveLampIndicator()
    {
        return absActiveLampIndicator;
    }

    public void setAbsActiveLampIndicator(Boolean absActiveLampIndicator)
    {
        this.absActiveLampIndicator = absActiveLampIndicator;
    }

    public Boolean getAbsDashIndicator()
    {
        return absDashIndicator;
    }

    public void setAbsDashIndicator(Boolean absDashIndicator)
    {
        this.absDashIndicator = absDashIndicator;
    }

    public Boolean getAcSystemRefrigerantMonitor()
    {
        return acSystemRefrigerantMonitor;
    }

    public void setAcSystemRefrigerantMonitor(Boolean acSystemRefrigerantMonitor)
    {
        this.acSystemRefrigerantMonitor = acSystemRefrigerantMonitor;
    }

    public Boolean getAirBagDashIndicator()
    {
        return airBagDashIndicator;
    }

    public void setAirBagDashIndicator(Boolean airBagDashIndicator)
    {
        this.airBagDashIndicator = airBagDashIndicator;
    }

    public Boolean getBatteryVoltageSupported()
    {
        return batteryVoltageSupported;
    }

    public void setBatteryVoltageSupported(Boolean batteryVoltageSupported)
    {
        this.batteryVoltageSupported = batteryVoltageSupported;
    }

    public Boolean getBrakeIndicatorLightStatus()
    {
        return brakeIndicatorLightStatus;
    }

    public void setBrakeIndicatorLightStatus(Boolean brakeIndicatorLightStatus)
    {
        this.brakeIndicatorLightStatus = brakeIndicatorLightStatus;
    }

    public Boolean getBrakeSwitchStatusIndicator()
    {
        return brakeSwitchStatusIndicator;
    }

    public void setBrakeSwitchStatusIndicator(Boolean brakeSwitchStatusIndicator)
    {
        this.brakeSwitchStatusIndicator = brakeSwitchStatusIndicator;
    }

    public Boolean getCatalystMonitor()
    {
        return catalystMonitor;
    }

    public void setCatalystMonitor(Boolean catalystMonitor)
    {
        this.catalystMonitor = catalystMonitor;
    }

    public Boolean getComprehensiveComponentMonitor()
    {
        return comprehensiveComponentMonitor;
    }

    public void setComprehensiveComponentMonitor(Boolean comprehensiveComponentMonitor)
    {
        this.comprehensiveComponentMonitor = comprehensiveComponentMonitor;
    }

    public Boolean getCoolantHotLightStatus()
    {
        return coolantHotLightStatus;
    }

    public void setCoolantHotLightStatus(Boolean coolantHotLightStatus)
    {
        this.coolantHotLightStatus = coolantHotLightStatus;
    }

    public Boolean getCruiseControlStatus()
    {
        return cruiseControlStatus;
    }

    public void setCruiseControlStatus(Boolean cruiseControlStatus)
    {
        this.cruiseControlStatus = cruiseControlStatus;
    }

    public Boolean getEgrSystemMonitor()
    {
        return egrSystemMonitor;
    }

    public void setEgrSystemMonitor(Boolean egrSystemMonitor)
    {
        this.egrSystemMonitor = egrSystemMonitor;
    }

    public Boolean getEngineCoolantTemperatureSupported()
    {
        return engineCoolantTemperatureSupported;
    }

    public void setEngineCoolantTemperatureSupported(Boolean engineCoolantTemperatureSupported)
    {
        this.engineCoolantTemperatureSupported = engineCoolantTemperatureSupported;
    }

    public Boolean getEngineSpeedSupported()
    {
        return engineSpeedSupported;
    }

    public void setEngineSpeedSupported(Boolean engineSpeedSupported)
    {
        this.engineSpeedSupported = engineSpeedSupported;
    }

    public Boolean getEvaporativeSystemMonitor()
    {
        return evaporativeSystemMonitor;
    }

    public void setEvaporativeSystemMonitor(Boolean evaporativeSystemMonitor)
    {
        this.evaporativeSystemMonitor = evaporativeSystemMonitor;
    }

    public Boolean getFuelLevelSupported()
    {
        return fuelLevelSupported;
    }

    public void setFuelLevelSupported(Boolean fuelLevelSupported)
    {
        this.fuelLevelSupported = fuelLevelSupported;
    }

    public Boolean getFuelLevelRemainingSupported()
    {
        return fuelLevelRemainingSupported;
    }

    public void setFuelLevelRemainingSupported(Boolean fuelLevelRemainingSupported)
    {
        this.fuelLevelRemainingSupported = fuelLevelRemainingSupported;
    }

    public Boolean getFuelRateSupported()
    {
        return fuelRateSupported;
    }

    public void setFuelRateSupported(Boolean fuelRateSupported)
    {
        this.fuelRateSupported = fuelRateSupported;
    }

    public Boolean getFuelSystemMonitorStatus()
    {
        return fuelSystemMonitorStatus;
    }

    public void setFuelSystemMonitorStatus(Boolean fuelSystemMonitorStatus)
    {
        this.fuelSystemMonitorStatus = fuelSystemMonitorStatus;
    }

    public Boolean getHeatedCatalystMonitor()
    {
        return heatedCatalystMonitor;
    }

    public void setHeatedCatalystMonitor(Boolean heatedCatalystMonitor)
    {
        this.heatedCatalystMonitor = heatedCatalystMonitor;
    }

    public Boolean getHo2SHeaterControlMalfunction()
    {
        return ho2SHeaterControlMalfunction;
    }

    public void setHo2SHeaterControlMalfunction(Boolean ho2sHeaterControlMalfunction)
    {
        ho2SHeaterControlMalfunction = ho2sHeaterControlMalfunction;
    }

    public Boolean getHo2SHeaterResistanceMalfunction()
    {
        return ho2SHeaterResistanceMalfunction;
    }

    public void setHo2SHeaterResistanceMalfunction(Boolean ho2sHeaterResistanceMalfunction)
    {
        ho2SHeaterResistanceMalfunction = ho2sHeaterResistanceMalfunction;
    }

    public Boolean getIgnitionStatus()
    {
        return ignitionStatus;
    }

    public void setIgnitionStatus(Boolean ignitionStatus)
    {
        this.ignitionStatus = ignitionStatus;
    }

    public Boolean getMilStatus()
    {
        return milStatus;
    }

    public void setMilStatus(Boolean milStatus)
    {
        this.milStatus = milStatus;
    }

    public Boolean getMisfireMonitorStatus()
    {
        return misfireMonitorStatus;
    }

    public void setMisfireMonitorStatus(Boolean misfireMonitorStatus)
    {
        this.misfireMonitorStatus = misfireMonitorStatus;
    }

    public Boolean getO2SensorCircuitNoActivity()
    {
        return o2SensorCircuitNoActivity;
    }

    public void setO2SensorCircuitNoActivity(Boolean o2SensorCircuitNoActivity)
    {
        this.o2SensorCircuitNoActivity = o2SensorCircuitNoActivity;
    }

    public Boolean getO2SensorHeaterCircuitMalfunction()
    {
        return o2SensorHeaterCircuitMalfunction;
    }

    public void setO2SensorHeaterCircuitMalfunction(Boolean o2SensorHeaterCircuitMalfunction)
    {
        this.o2SensorHeaterCircuitMalfunction = o2SensorHeaterCircuitMalfunction;
    }

    public String getObdProtocol()
    {
        return obdProtocol;
    }

    public void setObdProtocol(String obdProtocol)
    {
        this.obdProtocol = obdProtocol;
    }

    public Boolean getOdometerSupported()
    {
        return odometerSupported;
    }

    public void setOdometerSupported(Boolean odometerSupported)
    {
        this.odometerSupported = odometerSupported;
    }

    public Boolean getOilPressureLampIndicator()
    {
        return oilPressureLampIndicator;
    }

    public void setOilPressureLampIndicator(Boolean oilPressureLampIndicator)
    {
        this.oilPressureLampIndicator = oilPressureLampIndicator;
    }

    public Boolean getOxygenSensorHeatedMonitor()
    {
        return oxygenSensorHeatedMonitor;
    }

    public void setOxygenSensorHeatedMonitor(Boolean oxygenSensorHeatedMonitor)
    {
        this.oxygenSensorHeatedMonitor = oxygenSensorHeatedMonitor;
    }

    public Boolean getOxygenSensorMonitor()
    {
        return oxygenSensorMonitor;
    }

    public void setOxygenSensorMonitor(Boolean oxygenSensorMonitor)
    {
        this.oxygenSensorMonitor = oxygenSensorMonitor;
    }

    public Boolean getPtoStatus()
    {
        return ptoStatus;
    }

    public void setPtoStatus(Boolean ptoStatus)
    {
        this.ptoStatus = ptoStatus;
    }

    public Boolean getSeatBeltFastenedIndicator()
    {
        return seatBeltFastenedIndicator;
    }

    public void setSeatBeltFastenedIndicator(Boolean seatBeltFastenedIndicator)
    {
        this.seatBeltFastenedIndicator = seatBeltFastenedIndicator;
    }

    public Boolean getSecondaryAirSystemMonitor()
    {
        return secondaryAirSystemMonitor;
    }

    public void setSecondaryAirSystemMonitor(Boolean secondaryAirSystemMonitor)
    {
        this.secondaryAirSystemMonitor = secondaryAirSystemMonitor;
    }

    public Boolean getThrottlePositionSupported()
    {
        return throttlePositionSupported;
    }

    public void setThrottlePositionSupported(Boolean throttlePositionSupported)
    {
        this.throttlePositionSupported = throttlePositionSupported;
    }

    public Boolean getTransmissionGearSupported()
    {
        return transmissionGearSupported;
    }

    public void setTransmissionGearSupported(Boolean transmissionGearSupported)
    {
        this.transmissionGearSupported = transmissionGearSupported;
    }

    public Boolean getTripFuelConsumptionSupported()
    {
        return tripFuelConsumptionSupported;
    }

    public void setTripFuelConsumptionSupported(Boolean tripFuelConsumptionSupported)
    {
        this.tripFuelConsumptionSupported = tripFuelConsumptionSupported;
    }

    public Boolean getTripOdometerSupported()
    {
        return tripOdometerSupported;
    }

    public void setTripOdometerSupported(Boolean tripOdometerSupported)
    {
        this.tripOdometerSupported = tripOdometerSupported;
    }

    public Boolean getTurnSignalStatusSupported()
    {
        return turnSignalStatusSupported;
    }

    public void setTurnSignalStatusSupported(Boolean turnSignalStatusSupported)
    {
        this.turnSignalStatusSupported = turnSignalStatusSupported;
    }

    public Boolean getVehicleSpeedSupported()
    {
        return vehicleSpeedSupported;
    }

    public void setVehicleSpeedSupported(Boolean vehicleSpeedSupported)
    {
        this.vehicleSpeedSupported = vehicleSpeedSupported;
    }

    public Boolean getCalculatedFuelUsageSupported()
    {
        return calculatedFuelUsageSupported;
    }

    public void setCalculatedFuelUsageSupported(Boolean calculatedFuelUsageSupported)
    {
        this.calculatedFuelUsageSupported = calculatedFuelUsageSupported;
    }

    public Boolean getEngineStateSupported()
    {
        return engineStateSupported;
    }

    public void setEngineStateSupported(Boolean engineStateSupported)
    {
        this.engineStateSupported = engineStateSupported;
    }

    public Boolean getServiceIntervalInspectionDistanceSupported()
    {
        return serviceIntervalInspectionDistanceSupported;
    }

    public void setServiceIntervalInspectionDistanceSupported(Boolean serviceIntervalInspectionDistanceSupported)
    {
        this.serviceIntervalInspectionDistanceSupported = serviceIntervalInspectionDistanceSupported;
    }

    public Boolean getFuelLevelRemaining3030Supported()
    {
        return fuelLevelRemaining3030Supported;
    }

    public void setFuelLevelRemaining3030Supported(Boolean fuelLevelRemaining3030Supported)
    {
        this.fuelLevelRemaining3030Supported = fuelLevelRemaining3030Supported;
    }

    public Boolean getServiceIntervalDaysRemainingSupported()
    {
        return serviceIntervalDaysRemainingSupported;
    }

    public void setServiceIntervalDaysRemainingSupported(Boolean serviceIntervalDaysRemainingSupported)
    {
        this.serviceIntervalDaysRemainingSupported = serviceIntervalDaysRemainingSupported;
    }

    public Boolean getEngineOilTempSupported()
    {
        return engineOilTempSupported;
    }

    public void setEngineOilTempSupported(Boolean engineOilTempSupported)
    {
        this.engineOilTempSupported = engineOilTempSupported;
    }

    public Boolean getFuelEconomySupported()
    {
        return fuelEconomySupported;
    }

    public void setFuelEconomySupported(Boolean fuelEconomySupported)
    {
        this.fuelEconomySupported = fuelEconomySupported;
    }

    public Boolean getDtcCountSupported()
    {
        return dtcCountSupported;
    }

    public void setDtcCountSupported(Boolean dtcCountSupported)
    {
        this.dtcCountSupported = dtcCountSupported;
    }

    public Boolean getServiceIntervalOilDistanceSupported()
    {
        return serviceIntervalOilDistanceSupported;
    }

    public void setServiceIntervalOilDistanceSupported(Boolean serviceIntervalOilDistanceSupported)
    {
        this.serviceIntervalOilDistanceSupported = serviceIntervalOilDistanceSupported;
    }

    public Boolean getServiceIntervalOilDaysSupported()
    {
        return serviceIntervalOilDaysSupported;
    }

    public void setServiceIntervalOilDaysSupported(Boolean serviceIntervalOilDaysSupported)
    {
        this.serviceIntervalOilDaysSupported = serviceIntervalOilDaysSupported;
    }

    public Boolean getEngineRunTimeSupported()
    {
        return engineRunTimeSupported;
    }

    public void setEngineRunTimeSupported(Boolean engineRunTimeSupported)
    {
        this.engineRunTimeSupported = engineRunTimeSupported;
    }

    public Boolean getAmbientAirTempSupported()
    {
        return ambientAirTempSupported;
    }

    public void setAmbientAirTempSupported(Boolean ambientAirTempSupported)
    {
        this.ambientAirTempSupported = ambientAirTempSupported;
    }

    public Boolean getBarometricPressureSupported()
    {
        return barometricPressureSupported;
    }

    public void setBarometricPressureSupported(Boolean barometricPressureSupported)
    {
        this.barometricPressureSupported = barometricPressureSupported;
    }

    public Boolean getCanTecSupported()
    {
        return canTecSupported;
    }

    public void setCanTecSupported(Boolean canTecSupported)
    {
        this.canTecSupported = canTecSupported;
    }

    public Boolean getCanRecSupported()
    {
        return canRecSupported;
    }

    public void setCanRecSupported(Boolean canRecSupported)
    {
        this.canRecSupported = canRecSupported;
    }

    public Boolean getCanBusModeSupported()
    {
        return canBusModeSupported;
    }

    public void setCanBusModeSupported(Boolean canBusModeSupported)
    {
        this.canBusModeSupported = canBusModeSupported;
    }

    public Boolean getCanBusErrorTypeSupported()
    {
        return canBusErrorTypeSupported;
    }

    public void setCanBusErrorTypeSupported(Boolean canBusErrorTypeSupported)
    {
        this.canBusErrorTypeSupported = canBusErrorTypeSupported;
    }

    public Boolean getMaintenanceRequired()
    {
        return maintenanceRequired;
    }

    public void setMaintenanceRequired(Boolean maintenanceRequired)
    {
        this.maintenanceRequired = maintenanceRequired;
    }

    public String getVin()
    {
        return vin;
    }

    public void setVin(String vin)
    {
        this.vin = vin;
    }

    public String getVinRegion()
    {
        return vinRegion;
    }

    public void setVinRegion(String vinRegion)
    {
        this.vinRegion = vinRegion;
    }

    public String getManufacturer()
    {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer)
    {
        this.manufacturer = manufacturer;
    }

    public String getYear()
    {
        return year;
    }

    public void setYear(String year)
    {
        this.year = year;
    }

    public String getMake()
    {
        return make;
    }

    public void setMake(String make)
    {
        this.make = make;
    }

    public String getModel()
    {
        return model;
    }

    public void setModel(String model)
    {
        this.model = model;
    }

    public String getEngine()
    {
        return engine;
    }

    public void setEngine(String engine)
    {
        this.engine = engine;
    }

    public String getTrim()
    {
        return trim;
    }

    public void setTrim(String trim)
    {
        this.trim = trim;
    }

    public String getEngineSize()
    {
        return engineSize;
    }

    public void setEngineSize(String engineSize)
    {
        this.engineSize = engineSize;
    }

    public String getFuelType()
    {
        return fuelType;
    }

    public void setFuelType(String fuelType)
    {
        this.fuelType = fuelType;
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }

    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }
}
