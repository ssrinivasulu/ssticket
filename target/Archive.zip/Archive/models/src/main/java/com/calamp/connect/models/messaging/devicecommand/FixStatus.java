package com.calamp.connect.models.messaging.devicecommand;

/**
 * User: ericw
 * Date: 5/14/14
 */
public class FixStatus
{
    private boolean differentiallyCorrected;
    private boolean historic;
    private boolean invalidFix;
    private boolean invalidTime;
    private boolean lastKnown;
    private boolean predicted;
    private boolean twoDFix;

    @Override
    public boolean equals(Object o)
    {

        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        FixStatus fixStatus = (FixStatus) o;

        if (differentiallyCorrected != fixStatus.differentiallyCorrected){
            return false;
        }

        if (historic != fixStatus.historic){
            return false;
        }

        if (invalidFix != fixStatus.invalidFix){
            return false;
        }

        if (invalidTime != fixStatus.invalidTime){
            return false;
        }

        if (lastKnown != fixStatus.lastKnown){
            return false;
        }

        if (predicted != fixStatus.predicted){
            return false;
        }

        if (twoDFix != fixStatus.twoDFix){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (predicted
                      ? 1
                      : 0);

        result = 31 * result + (differentiallyCorrected
                                ? 1
                                : 0);
        result = 31 * result + (lastKnown
                                ? 1
                                : 0);
        result = 31 * result + (invalidFix
                                ? 1
                                : 0);
        result = 31 * result + (twoDFix
                                ? 1
                                : 0);
        result = 31 * result + (historic
                                ? 1
                                : 0);
        result = 31 * result + (invalidTime
                                ? 1
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "FixStatus{" + "predicted=" + predicted + ", differentiallyCorrected=" + differentiallyCorrected
               + ", lastKnown=" + lastKnown + ", invalidFix=" + invalidFix + ", twoDFix=" + twoDFix + ", historic="
               + historic + ", invalidTime=" + invalidTime + '}';
    }

    public boolean isDifferentiallyCorrected()
    {
        return differentiallyCorrected;
    }

    public boolean isHistoric()
    {
        return historic;
    }

    public boolean isInvalidFix()
    {
        return invalidFix;
    }

    public boolean isInvalidTime()
    {
        return invalidTime;
    }

    public boolean isLastKnown()
    {
        return lastKnown;
    }

    public boolean isPredicted()
    {
        return predicted;
    }

    public boolean isTwoDFix()
    {
        return twoDFix;
    }

    public void setDifferentiallyCorrected(boolean differentiallyCorrected)
    {
        this.differentiallyCorrected = differentiallyCorrected;
    }

    public void setHistoric(boolean historic)
    {
        this.historic = historic;
    }

    public void setInvalidFix(boolean invalidFix)
    {
        this.invalidFix = invalidFix;
    }

    public void setInvalidTime(boolean invalidTime)
    {
        this.invalidTime = invalidTime;
    }

    public void setLastKnown(boolean lastKnown)
    {
        this.lastKnown = lastKnown;
    }

    public void setPredicted(boolean predicted)
    {
        this.predicted = predicted;
    }

    public void setTwoDFix(boolean twoDFix)
    {
        this.twoDFix = twoDFix;
    }
}
