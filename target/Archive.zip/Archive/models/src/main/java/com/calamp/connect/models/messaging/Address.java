package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "address")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("address")
@JsonTypeName("address")
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "address1", "address2", "addressLatitude", "addressLongitude", "city", "country", "county", "crossStreet",
        "crossStreetDistance", "postalCode", "postedSpeedLimit", "roadTypeCode", "speedLimitMPH", "speedLimitUnits", "state", "stateProvinceCd",
        "street", "tollRoadFlag", "timeZoneOffset", "timeZoneId"  })
@JsonPropertyOrder({ "address1", "address2", "addressLatitude", "addressLongitude", "city", "country", "county", "crossStreet",
        "crossStreetDistance", "postalCode", "postedSpeedLimit", "roadTypeCode", "speedLimitMPH", "speedLimitUnits", "state", "stateProvinceCd",
        "street", "tollRoadFlag", "timeZoneOffset", "timeZoneId" })
public class Address
{

    String         street;
    String         city;
    String         state;
    String         postalCode;
    String         country;
    String         county;
    String         crossStreet;
    Double         crossStreetDistance;
    String         roadTypeCode;
    String         tollRoadFlag;
    Integer        postedSpeedLimit;

    // Added new fields for messaging
    private String address1;
    private String address2;
    private String stateProvinceCd;
    @JsonIgnore
    private String speedLimitMPH;
    private String speedLimitUnits;
    private Double addressLatitude;
    private Double addressLongitude;
    
    private String timeZoneOffset;
    private String timeZoneId;

    public String getStreet()
    {
        return street;
    }

    public void setStreet(String street)
    {
        this.street = street;
    }

    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getPostalCode()
    {
        return postalCode;
    }

    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }

    public String getCountry()
    {
        return country;
    }

    public void setCountry(String country)
    {
        this.country = country;
    }

    public String getCounty()
    {
        return county;
    }

    public void setCounty(String county)
    {
        this.county = county;
    }

    public String getCrossStreet()
    {
        return crossStreet;
    }

    public void setCrossStreet(String crossStreet)
    {
        this.crossStreet = crossStreet;
    }

    public Double getCrossStreetDistance()
    {
        return crossStreetDistance;
    }

    public void setCrossStreetDistance(Double crossStreetDistance)
    {
        this.crossStreetDistance = crossStreetDistance;
    }

    public String getRoadTypeCode()
    {
        return roadTypeCode;
    }

    public void setRoadTypeCode(String roadTypeCode)
    {
        this.roadTypeCode = roadTypeCode;
    }

    public String getTollRoadFlag()
    {
        return tollRoadFlag;
    }

    public void setTollRoadFlag(String tollRoadFlag)
    {
        this.tollRoadFlag = tollRoadFlag;
    }

    public Integer getPostedSpeedLimit()
    {
        return postedSpeedLimit;
    }

    public void setPostedSpeedLimit(Integer postedSpeedLimit)
    {
        this.postedSpeedLimit = postedSpeedLimit;
    }

    public String getAddress1()
    {
        return address1;
    }

    public void setAddress1(String address1)
    {
        this.address1 = address1;
    }

    public String getAddress2()
    {
        return address2;
    }

    public void setAddress2(String address2)
    {
        this.address2 = address2;
    }

    public String getStateProvinceCd()
    {
        return stateProvinceCd;
    }

    public void setStateProvinceCd(String stateProvinceCd)
    {
        this.stateProvinceCd = stateProvinceCd;
    }

    public String getSpeedLimitMPH()
    {
        return speedLimitMPH;
    }

    public void setSpeedLimitMPH(String speedLimitMPH)
    {
        if (speedLimitMPH != null)
        {
            this.setPostedSpeedLimit(Integer.parseInt(speedLimitMPH));
        }
        this.speedLimitMPH = speedLimitMPH;
    }

    public Double getAddressLatitude()
    {
        return addressLatitude;
    }

    public void setAddressLatitude(Double addressLatitude)
    {
        this.addressLatitude = addressLatitude;
    }

    public Double getAddressLongitude()
    {
        return addressLongitude;
    }

    public void setAddressLongitude(Double addressLongitude)
    {
        this.addressLongitude = addressLongitude;
    }

    public String getSpeedLimitUnits()
    {
        return speedLimitUnits;
    }

    public void setSpeedLimitUnits(String speedLimitUnits)
    {
        this.speedLimitUnits = speedLimitUnits;
    }

    /**
     * @return the timeZoneOffSet
     */
    public String getTimeZoneOffSet()
    {
        return timeZoneOffset;
    }

    /**
     * @param timeZoneOffSet the timeZoneOffSet to set
     */
    public void setTimeZoneOffSet(String timeZoneOffSet)
    {
        this.timeZoneOffset = timeZoneOffSet;
    }
    
    /**
     * @return the timeZoneId
     */
    public String getTimeZoneId()
    {
        return timeZoneId;
    }

    /**
     * @param timeZoneId the timeZone to set
     */
    public void setTimeZoneId(String timeZoneId)
    {
        this.timeZoneId = timeZoneId;
    }

    @Override
    public String toString()
    {
        return "Address{" + "country='" + country + '\'' + ", state='" + state + '\'' + ", county='" + county + '\'' + ", city='" + city + '\''
                + ", address1='" + address1 + '\'' + ", address2='" + address2 + '\'' + ", crossStreet='" + crossStreet + '\''
                + ", crossStreetDistance='" + crossStreetDistance + '\'' + ", stateProvinceCd='" + stateProvinceCd + '\'' + ", speedLimitMPH='"
                + speedLimitMPH + '\'' + ", addressLatitude='" + addressLatitude + '\'' + ", addressLongitude='" + addressLongitude + '\''
                + ", speedLimitUnits='" + speedLimitUnits + '\'' + ", postalCode='" + postalCode + '\'' + ", roadTypeCode='" + roadTypeCode + '\''
                + ", tollRoadFlag='" + tollRoadFlag + '\'' +  ", timeZoneOffset='" + timeZoneOffset + '\'' 
                +  ", timeZoneId='" + timeZoneId + '\'' 
                + '}';
    }

}
