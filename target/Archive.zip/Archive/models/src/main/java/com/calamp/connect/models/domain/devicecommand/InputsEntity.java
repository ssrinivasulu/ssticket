package com.calamp.connect.models.domain.devicecommand;

public class InputsEntity
{
    private boolean ignition;
    private boolean input1;
    private boolean input2;
    private boolean input3;
    private boolean input4;
    private boolean input5;
    private boolean input6;
    private boolean input7;
    private String  value;

    @Override
    public boolean equals(Object o)
    {

        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        InputsEntity inputs = (InputsEntity) o;

        if (ignition != inputs.ignition){
            return false;
        }

        if (input1 != inputs.input1){
            return false;
        }

        if (input2 != inputs.input2){
            return false;
        }

        if (input3 != inputs.input3){
            return false;
        }

        if (input4 != inputs.input4){
            return false;
        }

        if (input5 != inputs.input5){
            return false;
        }

        if (input6 != inputs.input6){
            return false;
        }

        if (input7 != inputs.input7){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (ignition
                      ? 1
                      : 0);

        result = 31 * result + (input1
                                ? 1
                                : 0);
        result = 31 * result + (input2
                                ? 1
                                : 0);
        result = 31 * result + (input3
                                ? 1
                                : 0);
        result = 31 * result + (input4
                                ? 1
                                : 0);
        result = 31 * result + (input5
                                ? 1
                                : 0);
        result = 31 * result + (input6
                                ? 1
                                : 0);
        result = 31 * result + (input7
                                ? 1
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "Inputs{" + "ignition=" + ignition + ", input1=" + input1 + ", input2=" + input2 + ", input3=" + input3
               + ", input4=" + input4 + ", input5=" + input5 + ", input6=" + input6 + ", input7=" + input7 + input7 + ", value=" + value + '}';
    }

    public boolean isIgnition()
    {
        return ignition;
    }

    public boolean isInput1()
    {
        return input1;
    }

    public boolean isInput2()
    {
        return input2;
    }

    public boolean isInput3()
    {
        return input3;
    }

    public boolean isInput4()
    {
        return input4;
    }

    public boolean isInput5()
    {
        return input5;
    }

    public boolean isInput6()
    {
        return input6;
    }

    public boolean isInput7()
    {
        return input7;
    }

    public void setIgnition(boolean ignition)
    {
        this.ignition = ignition;
    }

    public void setInput1(boolean input1)
    {
        this.input1 = input1;
    }

    public void setInput2(boolean input2)
    {
        this.input2 = input2;
    }

    public void setInput3(boolean input3)
    {
        this.input3 = input3;
    }

    public void setInput4(boolean input4)
    {
        this.input4 = input4;
    }

    public void setInput5(boolean input5)
    {
        this.input5 = input5;
    }

    public void setInput6(boolean input6)
    {
        this.input6 = input6;
    }

    public void setInput7(boolean input7)
    {
        this.input7 = input7;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String value)
    {
        this.value = value;
    }
}
