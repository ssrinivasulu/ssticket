package com.calamp.connect.models.messaging;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("idReportDeviceData")
@JsonTypeName("idReportDeviceData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class IdReportDeviceData extends DeviceData {
	private String resourceRevisions;
	private String firmwareVersion;
	private List<RouterModem> modems;

	public String getResourceRevisions() {
		return resourceRevisions;
	}

	public void setResourceRevisions(String resourceRevisions) {
		this.resourceRevisions = resourceRevisions;
	}

	public String getFirmwareVersion() {
		return firmwareVersion;
	}

	public void setFirmwareVersion(String firmwareVersion) {
		this.firmwareVersion = firmwareVersion;
	}

	public List<RouterModem> getModems() {
		return modems;
	}

	public void setModems(List<RouterModem> modems) {
		this.modems = modems;
	}

}
