package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "dtccodes")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("dtccodes")
@JsonTypeName("dtccodes")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "dtcCode", "description" })
@JsonPropertyOrder({ "dtcCode", "description" })
public class DtcCodes
{

    private String dtcCode;
    private String description;

    public String getDtcCode()
    {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode)
    {
        this.dtcCode = dtcCode;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

}
