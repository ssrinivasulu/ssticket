package com.calamp.connect.models.messaging.devicecommand;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.pojomatic.Pojomatic;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "deviceIdentifier")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("deviceIdentifier")
@JsonTypeName("deviceIdentifier")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "identifier", "type" })
@JsonPropertyOrder({ "identifier", "type" })
public class DeviceIdentifier implements Comparable<DeviceIdentifier>
{
    private String               identifier;
    private DeviceIdentifierType type;

    public DeviceIdentifier()
    {

    }

    public DeviceIdentifier(String identifier, DeviceIdentifierType type)
    {
        this.identifier = identifier;
        this.type = type;
    }

    public String getIdentifier()
    {
        return identifier;
    }

    public void setIdentifier(String identifier)
    {
        this.identifier = identifier;
    }

    public DeviceIdentifierType getType()
    {
        return type;
    }

    public void setType(DeviceIdentifierType type)
    {
        this.type = type;
    }

    @Override
    public int compareTo( DeviceIdentifier o )
    {
        if ( o == null )
            return 1;

        int result = identifier.compareTo(o.identifier);
        return result != 0 ? result : type.compareTo(o.type);
    }
    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }
}
