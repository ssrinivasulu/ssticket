package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "motionLogEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("motionLogEvent")
@JsonTypeName("motionLogEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "account", "accountId", "accountName", "altitude", "asset", "assetId", "assetName", "carrier", "commState", "deviceAirId",
        "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode",
        "eventTime", "eventType", "heading", "hdop", "inputs", "latitude", "longitude", "lmdirectMessageType", "messageReceivedTime", "messageType",
        "messageUuid", "motionLogInfo", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId",
        "rawDeviceHexMessage", "recordType", "rssi", "satelliteCount", "speed", "timeOfFix", "unitStatus", "vin", "vinResponse" })
@JsonPropertyOrder({ "account", "accountId", "accountName", "altitude", "asset", "assetId", "assetName", "carrier", "commState", "deviceAirId",
        "deviceData", "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "eventCode",
        "eventTime", "eventType", "heading", "hdop", "inputs", "latitude", "longitude", "lmdirectMessageType", "messageReceivedTime", "messageType",
        "messageUuid", "motionLogInfo", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId",
        "rawDeviceHexMessage", "recordType", "rssi", "satelliteCount", "speed", "timeOfFix", "unitStatus", "vin", "vinResponse" })
public class MotionLogsEvent extends DeviceEvent
{
    private List<MotionLogInfo> motionLogInfo;
    Integer                     recordType;
    private double              latitude;
    private double              longitude;
    private long                altitude;
    private Long                speed;
    private int                 heading;
    private int                 carrier;
    private double              hdop;
    private int                 satelliteCount;
    private int                 rssi;
    private CommState           commState;
    private UnitStatus          unitStatus;

    public List<MotionLogInfo> getMotionLogInfo()
    {
        return motionLogInfo;
    }

    public void setMotionLogInfo(List<MotionLogInfo> motionLogInfo)
    {
        this.motionLogInfo = motionLogInfo;
    }

    public Integer getRecordType()
    {
        return recordType;
    }

    public void setRecordType(Integer recordType)
    {
        this.recordType = recordType;
    }

    public double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(double latitude)
    {
        this.latitude = latitude;
    }

    public double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(double longitude)
    {
        this.longitude = longitude;
    }

    public long getAltitude()
    {
        return altitude;
    }

    public void setAltitude(long altitude)
    {
        this.altitude = altitude;
    }

    public Long getSpeed()
    {
        return speed;
    }

    public void setSpeed(Long speed)
    {
        this.speed = speed;
    }

    public int getHeading()
    {
        return heading;
    }

    public void setHeading(int heading)
    {
        this.heading = heading;
    }

    public int getCarrier()
    {
        return carrier;
    }

    public void setCarrier(int carrier)
    {
        this.carrier = carrier;
    }

    public double getHdop()
    {
        return hdop;
    }

    public void setHdop(double hdop)
    {
        this.hdop = hdop;
    }

    public int getSatelliteCount()
    {
        return satelliteCount;
    }

    public void setSatelliteCount(int satelliteCount)
    {
        this.satelliteCount = satelliteCount;
    }

    public int getRssi()
    {
        return rssi;
    }

    public void setRssi(int rssi)
    {
        this.rssi = rssi;
    }

    public CommState getCommState()
    {
        return commState;
    }

    public void setCommState(CommState commState)
    {
        this.commState = commState;
    }

    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public DeviceData getDeviceData()
    {
        return super.getDeviceData();
    }

    @Override
    @ApiModelProperty(value = "<b>This is internal field. Won't display in response</b>")
    public Integer getEventCode()
    {
        return super.getEventCode();
    }

    @Override
    public String getAssetName()
    {
        return super.getAssetName();
    }

    @Override
    public Long getAssetId()
    {
        return super.getAssetId();
    }
}
