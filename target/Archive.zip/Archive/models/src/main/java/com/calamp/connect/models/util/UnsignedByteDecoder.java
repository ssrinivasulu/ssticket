package com.calamp.connect.models.util;

import com.calamp.connect.models.messaging.devicecommand.DeviceCommandParameterDecoder;

/**
 * @author Sidlingappa
 *
 */
public class UnsignedByteDecoder implements DeviceCommandParameterDecoder<String, Integer>
{

    @Override
    public byte[] toBytes(String parameters)
    {
        int data = Integer.valueOf(parameters);
        byte convertedByte = signedByteToUnsignedByte(data);
        return new byte[] { convertedByte };
    }

    @Override
    public Integer fromBytes(byte[] array)
    {
        return unsignedByteToSignedByte(array[0]);
    }

    public static byte signedByteToUnsignedByte(int data)
    {
        if (data >= Byte.MAX_VALUE)
        {
            // CHECKSTYLE:OFF
            return (byte) (data - 256);
            // CHECKSTYLE:ON
        }
        else
        {
            return (byte) data;
        }
    }

    public static int unsignedByteToSignedByte(byte data)
    {
        if (data < 0)
        {
            // CHECKSTYLE:OFF
            return data + 256;
            // CHECKSTYLE:ON
        }
        else
        {
            return data;
        }
    }
}
