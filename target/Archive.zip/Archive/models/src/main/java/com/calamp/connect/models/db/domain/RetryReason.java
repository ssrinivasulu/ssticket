package com.calamp.connect.models.db.domain;

/**
 * These enum's are used to define the reason for DeviceCommand retry status.
 * 
 * @author Sidlingappa.
 */
public enum RetryReason
{
    MAX_RETRY_REACHED, AUTO_RETRY_FALSE, DEVICE_STATUS_NOT_ENABLED, COMMAND_IS_NOT_RETRY_CAPABLE, TTL_TIME_EXPIRED, USER_TRIGGERED_CANCEL;

}