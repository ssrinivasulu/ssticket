package com.calamp.connect.models.orika.converter;

import ma.glasnost.orika.CustomConverter;
import ma.glasnost.orika.metadata.Type;

import org.joda.time.DateTime;

public class LongTimeToDateTimeConverter extends CustomConverter<DateTime, Long>
{

    @Override
    public Long convert(DateTime source, Type<? extends Long> destinationType)
    {
        return new DateTime(source).getMillis();
    }

}