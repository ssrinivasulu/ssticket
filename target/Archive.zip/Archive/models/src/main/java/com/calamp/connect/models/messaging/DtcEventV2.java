package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "dtcEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("dtcEvent")
@JsonTypeName("dtcEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "account", "address", "asset", "assetId", "assetName", "carrier", "commState", "description", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "dtcCodes", "dtcCodesList", "eventCode",
        "eventTime", "eventType", "hdop", "heading", "inputs", "latitude", "longitude", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "rawDeviceHexMessage", "satellites", "status", "unitStatus", "vin", "vinResponse" })
@JsonPropertyOrder({ "account", "address", "asset", "assetId", "assetName", "carrier", "commState", "description", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceMessageSequenceNumber", "dtcCodes", "dtcCodesList", "eventCode",
        "eventTime", "eventType", "hdop", "heading", "inputs", "latitude", "longitude", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "rawDeviceHexMessage", "satellites", "status", "unitStatus", "vin", "vinResponse" })
@ApiVersion("2.0")
public class DtcEventV2 extends DtcEvent
{
    private List<String>   dtcCodesList;
    private List<DtcCodes> dtcCodes;
    private CommState      commState;
    private Integer        carrier;
    private Double         hdop;
    private Integer        heading;
    private Double         latitude;
    private Double         longitude;
    private Integer        satellites;
    private Address        address;
    @JsonIgnore
    private UnitStatus     unitStatus;
    private DtcDeviceData  deviceData;
    private DtcDeviceData  deviceDataConverted;

    @XmlType(name = "dtcStatus")
    public enum Status
    {
        ON, OFF
    }

    public List<String> getDtcCodesList()
    {
        return dtcCodesList;
    }

    public void setDtcCodesList(List<String> dtcCodesList)
    {
        this.dtcCodesList = dtcCodesList;
    }

    public List<DtcCodes> getDtcCodes()
    {
        return dtcCodes;
    }

    public void setDtcCodes(List<DtcCodes> dtcCodes)
    {
        this.dtcCodes = dtcCodes;
    }

    public CommState getCommState()
    {
        return commState;
    }

    public void setCommState(CommState commState)
    {
        this.commState = commState;
    }

    public Integer getCarrier()
    {
        return carrier;
    }

    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public Address getAddress()
    {
        return address;
    }

    public void setAddress(Address address)
    {
        this.address = address;
    }

    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public DtcDeviceData getDeviceData() {
        return (DtcDeviceData) super.getDeviceData();
    }

    public void setDeviceData(DtcDeviceData deviceData) {
        super.setDeviceData(deviceData);
    }

    public DtcDeviceData getDeviceDataConverted() {
        return (DtcDeviceData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(DtcDeviceData deviceDataConverted) {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
