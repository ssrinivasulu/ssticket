package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "speedEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("speedEvent")
@JsonTypeName("speedEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "duration", "maxSpeed" })
@JsonPropertyOrder({ "duration", "maxSpeed" })
public class SpeedEvent
{
    private Integer maxSpeed;
    private Integer duration;

    public Integer getMaxSpeed()
    {
        return maxSpeed;
    }

    public void setMaxSpeed(Integer maxSpeed)
    {
        this.maxSpeed = maxSpeed;
    }

    public Integer getDuration()
    {
        return duration;
    }

    public void setDuration(Integer duration)
    {
        this.duration = duration;
    }
}
