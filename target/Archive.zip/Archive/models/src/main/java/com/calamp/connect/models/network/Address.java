/**
 * 
 */
package com.calamp.connect.models.network;

/**
 * @author ssrinivasulu
 *
 */
public final class Address {
	private java.lang.String country;
	private java.lang.String state;
	private java.lang.String county;
	private java.lang.String city;
	private java.lang.String address1;
	private java.lang.String address2;
	private java.lang.String crossStreet;
	private double crossStreetDistance;
	private java.lang.String stateProvinceCd;
	private java.lang.String speedLimitMPH;
	private java.lang.String postalCode;
	private java.lang.String roadTypeCode;
	private java.lang.String tollRoadFlag;
	private java.lang.String firstQuery;
	private java.lang.String firstResponse;
	private java.lang.String secondQuery;
	private java.lang.String secondResponse;
	public java.lang.String getCountry() {
		return country;
	}
	public void setCountry(java.lang.String country) {
		this.country = country;
	}
	public java.lang.String getState() {
		return state;
	}
	public void setState(java.lang.String state) {
		this.state = state;
	}
	public java.lang.String getCounty() {
		return county;
	}
	public void setCounty(java.lang.String county) {
		this.county = county;
	}
	public java.lang.String getCity() {
		return city;
	}
	public void setCity(java.lang.String city) {
		this.city = city;
	}
	public java.lang.String getAddress1() {
		return address1;
	}
	public void setAddress1(java.lang.String address1) {
		this.address1 = address1;
	}
	public java.lang.String getAddress2() {
		return address2;
	}
	public void setAddress2(java.lang.String address2) {
		this.address2 = address2;
	}
	public java.lang.String getCrossStreet() {
		return crossStreet;
	}
	public void setCrossStreet(java.lang.String crossStreet) {
		this.crossStreet = crossStreet;
	}
	public double getCrossStreetDistance() {
		return crossStreetDistance;
	}
	public void setCrossStreetDistance(double crossStreetDistance) {
		this.crossStreetDistance = crossStreetDistance;
	}
	public java.lang.String getStateProvinceCd() {
		return stateProvinceCd;
	}
	public void setStateProvinceCd(java.lang.String stateProvinceCd) {
		this.stateProvinceCd = stateProvinceCd;
	}
	public java.lang.String getSpeedLimitMPH() {
		return speedLimitMPH;
	}
	public void setSpeedLimitMPH(java.lang.String speedLimitMPH) {
		this.speedLimitMPH = speedLimitMPH;
	}
	public java.lang.String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(java.lang.String postalCode) {
		this.postalCode = postalCode;
	}
	public java.lang.String getRoadTypeCode() {
		return roadTypeCode;
	}
	public void setRoadTypeCode(java.lang.String roadTypeCode) {
		this.roadTypeCode = roadTypeCode;
	}
	public java.lang.String getTollRoadFlag() {
		return tollRoadFlag;
	}
	public void setTollRoadFlag(java.lang.String tollRoadFlag) {
		this.tollRoadFlag = tollRoadFlag;
	}
	public java.lang.String getFirstQuery() {
		return firstQuery;
	}
	public void setFirstQuery(java.lang.String firstQuery) {
		this.firstQuery = firstQuery;
	}
	public java.lang.String getFirstResponse() {
		return firstResponse;
	}
	public void setFirstResponse(java.lang.String firstResponse) {
		this.firstResponse = firstResponse;
	}
	public java.lang.String getSecondQuery() {
		return secondQuery;
	}
	public void setSecondQuery(java.lang.String secondQuery) {
		this.secondQuery = secondQuery;
	}
	public java.lang.String getSecondResponse() {
		return secondResponse;
	}
	public void setSecondResponse(java.lang.String secondResponse) {
		this.secondResponse = secondResponse;
	}
	
}
