package com.calamp.connect.models.domain.devicecommand;

import java.util.Date;

import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.hateos.AssetLink;
import com.calamp.focis.framework.hateoas.Link;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@Document
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({ @JsonSubTypes.Type(value = ParameterResponseEntity.class), @JsonSubTypes.Type(value = AckNakResponseEntity.class),
        @JsonSubTypes.Type(value = LocateReportResponseEntity.class), @JsonSubTypes.Type(value = IdReportResponseEntity.class)

})
public abstract class DeviceCommandMessageResponseEntity extends DeviceEventEntity implements DeviceCommandMessageEntity
{
    private Integer sequenceId;
    private Date    received;
    private String  nagUuid;

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }

        if ((o == null) || (getClass() != o.getClass()))
        {
            return false;
        }

        DeviceCommandMessageResponseEntity that = (DeviceCommandMessageResponseEntity) o;

        if ((getExternalDeviceId() != null) ? !getExternalDeviceId().equals(that.getExternalDeviceId()) : that.getExternalDeviceId() != null)
        {
            return false;
        }

        if ((sequenceId != null) ? !sequenceId.equals(that.sequenceId) : that.sequenceId != null)
        {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = 0;

        result = 31 * result + ((sequenceId != null) ? sequenceId.hashCode() : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "DeviceCommandMessage{" + "externalDeviceId='" + getExternalDeviceId() + '\'' + ", sequenceId=" + sequenceId + '}';
    }

    public Integer getSequenceId()
    {
        return sequenceId;
    }

    public void setSequenceId(Integer sequenceId)
    {
        this.sequenceId = sequenceId;
    }

    public Date getReceived()
    {
        return received;
    }

    public void setReceived(Date received)
    {
        this.received = received;
    }

    public String getNagUuid()
    {
        return nagUuid;
    }

    public void setNagUuid(String nagUuid)
    {
        this.nagUuid = nagUuid;
    }

    @Transient
    @Override
    public Link getAccount()
    {
        return super.getAccount();
    }

    @Override
    public void setAccount(Link account)
    {
        super.setAccount(account);
    }

    @Transient
    @Override
    public AssetLink getAsset()
    {
        return super.getAsset();
    }

    @Override
    public void setAsset(AssetLink asset)
    {
        super.setAsset(asset);
    }

    @Transient
    @Override
    public String getDeviceGuid()
    {
        return super.getDeviceGuid();
    }

    @Override
    public void setDeviceGuid(String deviceGuid)
    {
        super.setDeviceGuid(deviceGuid);
    }

    @Transient
    @Override
    public String getDeviceAirId()
    {
        return super.getDeviceAirId();
    }

    @Override
    public void setDeviceAirId(String deviceAirId)
    {
        super.setDeviceAirId(deviceAirId);
    }

    @Transient
    @Override
    public Long getDeviceMessageSequenceNumber()
    {
        return super.getDeviceMessageSequenceNumber();
    }

    @Override
    public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
    {
        super.setDeviceMessageSequenceNumber(deviceMessageSequenceNumber);
    }

    @Transient
    @Override
    public String getMessageUuid()
    {
        return super.getMessageUuid();
    }

    @Override
    public void setMessageUuid(String messageUuid)
    {
        super.setMessageUuid(messageUuid);
    }

    @Transient
    @Override
    public Long getLmdirectMessageType()
    {
        return super.getLmdirectMessageType();
    }

    @Override
    public void setLmdirectMessageType(Long lmdirectMessageType)
    {
        super.setLmdirectMessageType(lmdirectMessageType);
    }
}
