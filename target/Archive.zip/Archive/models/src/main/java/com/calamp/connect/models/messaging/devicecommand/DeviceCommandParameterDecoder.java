package com.calamp.connect.models.messaging.devicecommand;

/**
 * @author Sidlingappa
 *
 */
public interface DeviceCommandParameterDecoder<T, M>
{
    public byte[] toBytes(T parameters);

    M fromBytes(byte[] array);
}
