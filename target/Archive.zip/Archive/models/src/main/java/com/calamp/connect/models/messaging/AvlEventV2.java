package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.apiversion.ApiVersion;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "avlEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("avlEvent")
@JsonTypeName("avlEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "address", "carrier", "fixStatus",  "hdop", "heading", "latitude", "longitude", "satellites", "commGpsStatus", "engineHourOffset", "fixStatusAndSatellites","gpsFixStatus", "isAempEvent", "odometerOffset", "geozoneEvents"  })
@JsonPropertyOrder({ "address", "carrier", "fixStatus",  "hdop", "heading", "latitude", "longitude", "satellites", "commGpsStatus", "engineHourOffset", "fixStatusAndSatellites","gpsFixStatus", "isAempEvent", "odometerOffset", "geozoneEvents" })
@ApiVersion("2.0")
public class AvlEventV2 extends AvlEvent
{
    private CommState              commState;
    private VbusIndicators         vbusIndicators;
    private Integer                carrier;
    private Double                 hdop;
    private Integer                heading;
    private Double                 latitude;
    private Double                 longitude;
    private Integer                satellites;
    private Address                address;
    private GpsFixStatus           gpsFixStatus;
    private boolean                fixStatus;
    // @JsonIgnore
    private UnitStatus             unitStatus;
    private AvlDeviceData          deviceData;
    private AvlDeviceData          deviceDataConverted;
    private Long                   engineHourOffset;
    private Long                   odometerOffset;
    private FixStatusAndSatellites fixStatusAndSatellites;
    private CommGpsStatus          commGpsStatus;
    private Boolean                isAempEvent;
    private List<GeozoneEvent>     geozoneEvents;

    public CommGpsStatus getCommGpsStatus()
    {
        return commGpsStatus;
    }

    public void setCommGpsStatus(CommGpsStatus commGpsStatus)
    {
        this.commGpsStatus = commGpsStatus;
    }

    public FixStatusAndSatellites getFixStatusAndSatellites()
    {
        return fixStatusAndSatellites;
    }

    public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites)
    {
        this.fixStatusAndSatellites = fixStatusAndSatellites;
    }

    public CommState getCommState()
    {
        return commState;
    }

    public void setCommState(CommState commState)
    {
        this.commState = commState;
    }

    public VbusIndicators getVbusIndicators()
    {
        return vbusIndicators;
    }

    public void setVbusIndicators(VbusIndicators vbusIndicators)
    {
        this.vbusIndicators = vbusIndicators;
    }

    public Integer getCarrier()
    {
        return carrier;
    }

    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public Address getAddress()
    {
        return address;
    }

    public void setAddress(Address address)
    {
        this.address = address;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public GpsFixStatus getGpsFixStatus()
    {
        return gpsFixStatus;
    }

    public void setGpsFixStatus(GpsFixStatus gpsFixStatus)
    {
        this.gpsFixStatus = gpsFixStatus;
    }

    public boolean getFixStatus()
    {
        return fixStatus;
    }

    public void setFixStatus(boolean fixStatus)
    {
        this.fixStatus = fixStatus;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only</b>")
    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public AvlDeviceData getDeviceData()
    {
        return super.getDeviceData();
    }

    public void setDeviceData(AvlDeviceData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public AvlDeviceData getDeviceDataConverted()
    {
        return super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(AvlDeviceData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

    public Long getEngineHourOffset()
    {
        return engineHourOffset;
    }

    public void setEngineHourOffset(Long engineHourOffset)
    {
        this.engineHourOffset = engineHourOffset;
    }

    public Long getOdometerOffset()
    {
        return odometerOffset;
    }

    public void setOdometerOffset(Long odometerOffset)
    {
        this.odometerOffset = odometerOffset;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public Boolean getIsAempEvent()
    {
        return isAempEvent;
    }

    public void setIsAempEvent(Boolean isAempEvent)
    {
        this.isAempEvent = isAempEvent;
    }

	public List<GeozoneEvent> getGeozoneEvents() {
		return geozoneEvents;
	}

	public void setGeozoneEvents(List<GeozoneEvent> geozoneEvents) {
		this.geozoneEvents = geozoneEvents;
	}
    
}
