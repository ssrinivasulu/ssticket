package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionHourlyReportData;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEventV2;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReport;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusConstructionHourlyReportV2Converter")
public class DeviceEventToJbusConstructionHourlyReportV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusConstructionHourlyReportEventV2, ConstructionHourlyReport>
{

    @Override
    public ConstructionHourlyReport modelToDomain(JbusConstructionHourlyReportEventV2 event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        ConstructionHourlyReport constructionHourly = mapper.map(event, ConstructionHourlyReport.class);
        ConstructionHourlyReportData deviceData = mapper.map(event.getDeviceData(), ConstructionHourlyReportData.class);
        ConstructionHourlyReportData deviceDataConverted = mapper.map(event.getDeviceDataConverted(), ConstructionHourlyReportData.class);
        constructionHourly.setDeviceData(deviceData);
        constructionHourly.setDeviceDataConverted(deviceDataConverted);
        return constructionHourly;

    }

    @Override
    public JbusConstructionHourlyReportEventV2 domainToModel(ConstructionHourlyReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionHourlyReportEventV2 constructionHourlyReport = mapper.map(event, JbusConstructionHourlyReportEventV2.class);
        JbusConstructionHourlyReportData constructionHourlyReportDataConverted = mapper.map(event.getDeviceDataConverted(),
                JbusConstructionHourlyReportData.class);
        constructionHourlyReport.setDeviceDataConverted(constructionHourlyReportDataConverted);
        JbusConstructionHourlyReportData constructionHourlyReportData = mapper.map(event.getDeviceData(),
                JbusConstructionHourlyReportData.class);
        constructionHourlyReport.setDeviceData(constructionHourlyReportData);
        return constructionHourlyReport;
    }

    @Override
    public JbusConstructionHourlyReportEventV2 domainToModel(ConstructionHourlyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<ConstructionHourlyReport> getDomainType()
    {
        return ConstructionHourlyReport.class;
    }

    @Override
    public Class<JbusConstructionHourlyReportEventV2> getModelType()
    {
        return JbusConstructionHourlyReportEventV2.class;
    }
}
