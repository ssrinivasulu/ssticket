package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDailyReportData;
import com.calamp.connect.models.messaging.JbusDailyReportEventV2;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component
public class NetworkToJbusDailyReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusDailyReportConverter.class);

    public JbusDailyReportEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusDailyReportEventV2 jbusDailyReportEvent = mapper.map(network, JbusDailyReportEventV2.class);
        JbusDailyReportData jbusDailyReportData = mapper.map(network, JbusDailyReportData.class);
        jbusDailyReportEvent.setDeviceData(jbusDailyReportData);
        jbusDailyReportEvent.setDeviceDataConverted(new JbusDailyReportData());
        jbusDailyReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusDailyReportEvent;
    }
}
