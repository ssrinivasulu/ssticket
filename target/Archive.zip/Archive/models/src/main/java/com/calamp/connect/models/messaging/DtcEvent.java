package com.calamp.connect.models.messaging;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "dtcEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("dtcEvent")
@JsonTypeName("dtcEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "account", "accountId", "accountName", "asset", "assetId", "assetName", "description", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "dtcCode", "dtcCodes", "endTime",
        "eventCode", "eventTime", "eventType", "gps", "inputs", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "startTime", "status",
        "timeOfFix", "vin", "vinResponse" })
@JsonPropertyOrder({ "account", "accountId", "accountName", "asset", "assetId", "assetName", "description", "deviceAirId", "deviceData",
        "deviceDataConverted", "deviceEsn", "deviceId", "deviceIp", "deviceName", "deviceMessageSequenceNumber", "dtcCode", "dtcCodes", "endTime",
        "eventCode", "eventTime", "eventType", "gps", "inputs", "lmdirectMessageType", "messageReceivedTime", "messageType", "messageUuid",
        "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "startTime", "status",
        "timeOfFix", "vin", "vinResponse" })
public class DtcEvent extends DeviceEvent
{
    private String         dtcCode;
    private String         description;
    private Status         status;
    private DateTime       startTime;
    private DateTime       endTime;
    private GPS            gps;
    private List<DtcCodes> dtcCodes;
    private DtcDeviceData  deviceData;
    private DtcDeviceData  deviceDataConverted;

    @XmlType(name = "dtcStatus")
    public enum Status
    {
        ON, OFF
    }

    public String getDescription()
    {
        return description;
    }

    public String getDtcCode()
    {
        return dtcCode;
    }

    public DateTime getEndTime()
    {
        return endTime;
    }

    public GPS getGps()
    {
        return gps;
    }

    public DateTime getStartTime()
    {
        return startTime;
    }

    public Status getStatus()
    {
        return status;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public void setDtcCode(String dtcCode)
    {
        this.dtcCode = dtcCode;
    }

    public void setEndTime(DateTime endTime)
    {
        this.endTime = endTime;
    }

    public void setGps(GPS gps)
    {
        this.gps = gps;
    }

    public List<DtcCodes> getDtcCodes()
    {
        return dtcCodes;
    }

    public void setDtcCodes(List<DtcCodes> dtcCodes)
    {
        this.dtcCodes = dtcCodes;
    }

    public void setStartTime(DateTime startTime)
    {
        this.startTime = startTime;
    }

    public void setStatus(Status status)
    {
        this.status = status;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public DtcDeviceData getDeviceData()
    {
        return (DtcDeviceData) super.getDeviceData();
    }

    public void setDeviceData(DtcDeviceData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public DtcDeviceData getDeviceDataConverted()
    {
        return (DtcDeviceData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(DtcDeviceData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }
}
