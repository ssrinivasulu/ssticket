package com.calamp.connect.models.messaging;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonRootName("extendedIdReportDeviceData")
@JsonTypeName("extendedIdReportDeviceData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExtendedIdReportDeviceData extends DeviceData {

	private List<RouterModemReport> modemReports;

	public List<RouterModemReport> getModemReports() {
		return modemReports;
	}

	public void setModemReports(List<RouterModemReport> modemReports) {
		this.modemReports = modemReports;
	}

}
