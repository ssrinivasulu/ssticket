package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;

import com.calamp.focis.framework.model.Search;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.facet.FacetCounts;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@JsonInclude(Include.NON_NULL)
@JsonPropertyOrder({ "errors", "searchableProperties", "search", "queryTime", "results" })
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlRootElement(name = "response")
@XmlType(propOrder = { "search", "queryTime" })
@NotThreadSafe
@ApiModel(description = "Results of a Search posted to the services.", value = "searchResults")
public class SearchResult<T> extends Response<T>
{
    private Logger            logger      = LoggerFactory.getLogger(SearchResult.class);

    private Query             query;
    private Integer           queryTime;
    private int               totalResults;
    private List<FacetCounts> facetCounts = new ArrayList<FacetCounts>();
    private Search            search;
    
    public SearchResult() {
    	
    }
    
    public SearchResult(Page<T> page, String pageParam, String sizeParam, String basePath)
    {
    	super(page, pageParam, sizeParam, basePath);
    }

    
    @JsonIgnore
    @XmlTransient
    public List<FacetCounts> getFacetCounts()
    {
        return this.facetCounts;
    }

    @JsonIgnore
    @XmlTransient
    public Query getQuery()
    {
        return this.query;
    }

    @XmlElement(name = "queryTime")
    public Integer getQueryTime()
    {
        return this.queryTime;
    }

    @JsonIgnore
    @JsonProperty("count")
    @JsonInclude(Include.NON_EMPTY)
    @XmlElement(name = "count")
    public Integer getTotalResults()
    {
        return totalResults;
    }
    
    public void setQuery(Query query)
    {
        this.query = query;
    }

    public void setQueryTime(int queryTime)
    {
        this.queryTime = queryTime;
    }

    public void setTotalResults(Integer totalResults)
    {
        if (logger.isDebugEnabled())
        {
            logger.debug(String.format("Incoming totalResults = %s", totalResults == null ? "null" : totalResults.toString()));
        }
        this.totalResults = totalResults;
    }
    
    public void setFacetCounts(List<FacetCounts> facetCounts)
    {
        this.facetCounts = facetCounts;
    }
    
    /**
     * @return the search
     */
    @JsonProperty("search")
    @XmlElement(name = "search", type = Search.class)
    @JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
    public Search getSearch()
    {
        return search;
    }

    /**
     * @param search
     *            the search to set
     */
    public void setSearch(Search search)
    {
        this.search = search;
    }

    @JsonIgnore
    @XmlTransient
    @ApiModelProperty(hidden = true)
    public String getKey()
    {
        return this.query == null ? null : this.query.getQueryString();
    }
}