package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.connect.models.network.Event;
import com.calamp.connect.models.network.Event.AempData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Abhijit
 *
 */
@Component("deviceEventToAempMessageEventConverter")
public class DeviceEventToAempMessageEventConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<AempMessageEvent, Event.AempData>
{
    @Override
    public AempMessageEvent domainToModel(Event.AempData event)
    {
        MapperFacade mapper = this.mapperFactory.getMapperFacade();
        AempMessageEvent aempEvent = (AempMessageEvent) mapper.map(event, AempMessageEvent.class);
        return aempEvent;
    }

    @Override
    public Event.AempData modelToDomain(AempMessageEvent event)
    {
        MapperFacade mapper = this.mapperFactory.getMapperFacade();
        Event.AempData aempEvent = (Event.AempData) mapper.map(event, Event.AempData.class);
        return aempEvent;
    }

    @Override
    public Class<AempData> getDomainType()
    {
        return Event.AempData.class;
    }

    @Override
    public Class<AempMessageEvent> getModelType()
    {
        return AempMessageEvent.class;
    }

    @Override
    public AempMessageEvent domainToModel(AempData arg0, boolean arg1) throws Exception
    {
        return null;
    }
}
