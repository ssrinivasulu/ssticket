package com.calamp.connect.models.datapump.converter;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.MotionLogsEvent;
import com.calamp.connect.models.network.Event;
import com.calamp.focis.framework.converter.ModelEntityConverter;

import ma.glasnost.orika.MapperFacade;

/**
 * @author Abhijit
 *
 */
@Component("deviceEventToMotionLogsEventConverter")
public class DeviceEventToMotionLogsEventConverter extends GenericDeviceEventToEventMessageConverter
        implements ModelEntityConverter<MotionLogsEvent, Event.MotionLogsEvent>
{
    @Override
    public MotionLogsEvent domainToModel(Event.MotionLogsEvent event)
    {
        MapperFacade mapper = this.mapperFactory.getMapperFacade();
        MotionLogsEvent motionLogEvent = (MotionLogsEvent) mapper.map(event, MotionLogsEvent.class);
        return motionLogEvent;
    }

    @Override
    public Event.MotionLogsEvent modelToDomain(MotionLogsEvent event)
    {
        MapperFacade mapper = this.mapperFactory.getMapperFacade();
        Event.MotionLogsEvent motionLogEvent = (Event.MotionLogsEvent) mapper.map(event, Event.MotionLogsEvent.class);
        return motionLogEvent;
    }

    @Override
    public Class<Event.MotionLogsEvent> getDomainType()
    {
        return Event.MotionLogsEvent.class;
    }

    @Override
    public Class<MotionLogsEvent> getModelType()
    {
        return MotionLogsEvent.class;
    }

    @Override
    public MotionLogsEvent domainToModel(Event.MotionLogsEvent arg0, boolean arg1) throws Exception
    {
        return null;
    }
}
