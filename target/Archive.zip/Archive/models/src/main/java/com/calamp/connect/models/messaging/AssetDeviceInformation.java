package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;



@XmlRootElement(name = "assetDeviceInformation")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("assetDeviceInformation")
@JsonTypeName("assetDeviceInformation")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include = As.WRAPPER_OBJECT,
    use     = Id.NAME
)
@XmlType(propOrder =
{
    "awakeDuration", "batteryLevel", "powerOnTime"
})
@JsonPropertyOrder(
{
	"awakeDuration", "batteryLevel", "powerOnTime"
})


public class AssetDeviceInformation {
	private Long powerOnTime;
	private Long awakeDuration;
	private Integer batteryLevel;
	
	public Long getPowerOnTime() {
		return powerOnTime;
	}
	public void setPowerOnTime(Long powerOnTime) {
		this.powerOnTime = powerOnTime;
	}
	public Long getAwakeDuration() {
		return awakeDuration;
	}
	public void setAwakeDuration(Long awakeDuration) {
		this.awakeDuration = awakeDuration;
	}
	public Integer getBatteryLevel() {
		return batteryLevel;
	}
	public void setBatteryLevel(Integer batteryLevel) {
		this.batteryLevel = batteryLevel;
	}

}
