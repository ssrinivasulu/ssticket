package com.calamp.connect.models.messaging;

import javax.measure.quantity.Speed;
import javax.measure.quantity.Time;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.connect.framework.measure.ConvertUnit;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "speedEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("speedEvent")
@JsonTypeName("speedEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "duration", "maxSpeed" })
@JsonPropertyOrder({ "duration", "maxSpeed" })
public class SpeedEventV2
{
    @ConvertUnit(type = Speed.class)
    private HeaderData maxSpeed;
    
    @ConvertUnit(type = Time.class)
    private HeaderData duration;

    public HeaderData getMaxSpeed()
    {
        return maxSpeed;
    }

    public void setMaxSpeed(HeaderData maxSpeed)
    {
        this.maxSpeed = maxSpeed;
    }

    public HeaderData getDuration()
    {
        return duration;
    }

    public void setDuration(HeaderData duration)
    {
        this.duration = duration;
    }
}
