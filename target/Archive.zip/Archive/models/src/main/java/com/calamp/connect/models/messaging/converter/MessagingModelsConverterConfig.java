package com.calamp.connect.models.messaging.converter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.connect.models.messaging.AppMessage;
import com.calamp.connect.models.messaging.AvlEventV2;
import com.calamp.connect.models.messaging.DeviceEvent;
import com.calamp.connect.models.messaging.DtcEventV2;
import com.calamp.connect.models.messaging.ExtendedIdReportEvent;
import com.calamp.connect.models.messaging.IdReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportData;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusDailyReportData;
import com.calamp.connect.models.messaging.JbusDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusDiscoveryReportEvent;
import com.calamp.connect.models.messaging.JbusDtc1708Protocol;
import com.calamp.connect.models.messaging.JbusDtcEvent;
import com.calamp.connect.models.messaging.JbusEventProtocol;
import com.calamp.connect.models.messaging.JbusFaultReportEvent;
import com.calamp.connect.models.messaging.JbusHourlyReportData;
import com.calamp.connect.models.messaging.JbusHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusHydraulicReportData;
import com.calamp.connect.models.messaging.JbusHydraulicReportEventV2;
import com.calamp.connect.models.messaging.Jpod2DTCReport;
import com.calamp.connect.models.messaging.MotionLogsEvent;
import com.calamp.connect.models.messaging.SelfDescribingJPODMessage;
import com.calamp.connect.models.messaging.UserMessage;
import com.calamp.connect.models.messaging.VehicleBusCapabilities;
import com.calamp.connect.models.messaging.devicecommand.AckNakResponse;
import com.calamp.connect.models.messaging.devicecommand.CommState;
import com.calamp.connect.models.messaging.devicecommand.FixStatus;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponse;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData;
import com.calamp.connect.models.messaging.devicecommand.ParameterConfigInfo;
import com.calamp.connect.models.messaging.devicecommand.ParameterResponse;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.ParameterInfo;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * @author ssrinivasulu
 *
 */
@Configuration
@ComponentScan(
		 //useDefaultFilters = false,
	    basePackages  = { "com.calamp.connect.models"})
public class MessagingModelsConverterConfig {
	
	@Bean
    public MapperFactory messageProcessorMapperFactory()
    {
         MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
         mapperFactory.classMap(NetworkMessage.class, DeviceEvent.class)
         .mapNulls(false)
         .field("deviceId", "deviceId")
         .field("externalDeviceId", "deviceEsn")
         .field("sequenceId", "deviceMessageSequenceNumber")
         .field("deviceIp", "deviceIp")
         .field("port", "port")
         .field("nagReceivedTime", "messageReceivedTime")
         .field("rawDeviceHexMessage", "rawDeviceHexMessage")
         .field("type", "messageType")
         .field("messageUuid", "messageUuid")
         .byDefault().register();

         mapperFactory.classMap(NetworkMessage.class, AempMessageEvent.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("type", "messageType")
         .field("aempData.accountId", "accountId")
         .field("messageUuid", "messageUuid")
         .field("nagReceivedTime", "messageReceivedTime")
         .field("aempData.location", "location")
         .field("aempData.location.longitude", "location.longitude")
         .field("aempData.location.latitude", "location.latitude")
         .field("aempData.location.altitudeUnits", "location.altitudeUnits")
         .field("aempData.location.altitude", "location.altitude")
         .field("aempData.location.datetime", "location.datetime")
         .field("aempData.equipmentHeader.model", "equipmentHeader.model")
         .field("aempData.equipmentHeader.make", "equipmentHeader.make")
         .field("aempData.equipmentHeader.serialNumber", "equipmentHeader.serialNumber")
         .field("aempData.equipmentHeader.equipmentID", "equipmentHeader.equipmentID")
         .field("aempData.cumulativeOperatingHours", "cumulativeOperatingHours")
         .field("aempData.cumulativeOperatingHours.hour", "cumulativeOperatingHours.hour")
         .field("aempData.cumulativeOperatingHours.datetime", "cumulativeOperatingHours.datetime")
         .field("aempData.distance", "distance")
         .field("aempData.distance.odometer", "distance.odometer")
         .field("aempData.distance.odometerUnits", "distance.odometerUnits")
         .field("aempData.distance.datetime", "distance.datetime")
         .field("aempData.fuelUsed", "fuelUsed")
         .field("aempData.fuelUsed.fuelUnits", "fuelUsed.fuelUnits")
         .field("aempData.fuelUsed.fuelConsumed", "fuelUsed.fuelConsumed")
         .field("aempData.fuelUsed.datetime", "fuelUsed.datetime")
         .field("aempData.fuelUsedLast24", "fuelUsedLast24")
         .field("aempData.fuelUsedLast24.fuelUnits", "fuelUsedLast24.fuelUnits")
         .field("aempData.fuelUsedLast24.fuelConsumed", "fuelUsedLast24.fuelConsumed")
         .field("aempData.fuelUsedLast24.datetime", "fuelUsedLast24.datetime")
         .byDefault().register();

         mapperFactory.classMap(NetworkMessage.class, MotionLogsEvent.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("motionLogsMessage.locationInformation.carrier" ,"carrier")
         .field("motionLogsMessage.locationInformation.heading", "heading")
         .field("motionLogsMessage.locationInformation.hdop", "hdop")
         .field("motionLogsMessage.locationInformation.latitude" ,"latitude")
         .field("motionLogsMessage.locationInformation.longitude", "longitude")
         .field("motionLogsMessage.locationInformation.satelliteCount", "satelliteCount")
         .field("motionLogsMessage.locationInformation.inputs", "inputs")
         .field("motionLogsMessage.locationInformation.commState","commState")
         .field("motionLogsMessage.locationInformation.commState.voiceCallIsActive","commState.voiceCallActive")
         .field("motionLogsMessage.locationInformation.unitStatus","unitStatus")
         .field("motionLogsMessage.locationInformation.unitStatus.modemMinTest","unitStatus.modemMinTestResults")
         .field("motionLogsMessage.recordType" ,"recordType")
         .field("motionLogsMessage.motionLogInfo" ,"motionLogInfo")
         .byDefault().register();

         mapperFactory.classMap(NetworkMessage.class, IdReportEvent.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("idReportMessage.scriptVersion", "scriptVersion")
         .field("idReportMessage.configVersion", "configVersion")
         .field("idReportMessage.appVersion", "appVersion")
         .field("idReportMessage.vehicleClass", "vehicleClass")
         .field("idReportMessage.imei", "imei")
         .field("idReportMessage.imsi", "imsi")
         .field("idReportMessage.min", "min")
         .field("idReportMessage.iccId", "iccId")
         .field("idReportMessage.extension", "extension")
         .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, ExtendedIdReportEvent.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("idReportMessage.extension", "extension")
         .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, AvlEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("messageDetail.carrier", "carrier")
         .field("messageDetail.fixStatus", "fixStatus")
         .field("messageDetail.heading", "heading")
         .field("messageDetail.hdop", "hdop")
         .field("messageDetail.gpsFixStatus", "gpsFixStatus")
         .field("messageDetail.latitude", "latitude")
         .field("messageDetail.longitude", "longitude")
         .field("messageDetail.satelliteCount", "satellites")
         
         .field("messageDetail.inputs", "inputs")         
         .field("messageDetail.fixStatus","fixStatus")
         .field("messageDetail.commState","commState")
         .field("messageDetail.commState.voiceCallIsActive","commState.voiceCallActive")
         
         .field("messageDetail.unitStatus","unitStatus")
         .field("messageDetail.unitStatus.modemMinTest","unitStatus.modemMinTestResults")
         
         .field("messageDetail.eventCode", "eventCode")
         .field("messageDetail.fixStatusAndSatellites", "fixStatusAndSatellites")
         .field("messageDetail.commGpsStatus", "commGpsStatus")
         .field("messageDetail.timeOfFix", "timeOfFix")
         .byDefault().register();
         
         
         
         mapperFactory.classMap(NetworkMessage.class, UserMessage.class)
         .mapNulls(false).use(NetworkMessage.class, AvlEventV2.class).byDefault().register();
         mapperFactory.classMap(NetworkMessage.class, AppMessage.class)
         .mapNulls(false).use(NetworkMessage.class, AvlEventV2.class).byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, SelfDescribingJPODMessage.class)
         .mapNulls(false).use(NetworkMessage.class, AppMessage.class).byDefault().register();
         mapperFactory.classMap(NetworkMessage.class, Jpod2DTCReport.class)
         .mapNulls(false).use(NetworkMessage.class, AppMessage.class).byDefault().register();
         mapperFactory.classMap(NetworkMessage.class, VehicleBusCapabilities.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("provisionMessage.vin","vin")
         .field("provisionMessage.obiiProtocol", "obdProtocol")
         .field("provisionMessage.obdSupportedIndicators.absActiveLamp", "absActiveLampIndicator")
         .field("provisionMessage.obdSupportedIndicators.absDashIndicator", "absDashIndicator")
         .field("provisionMessage.obdSupportedIndicators.airBagDashIndicator", "airBagDashIndicator")
         .field("provisionMessage.obdSupportedIndicators.acSystemRefrigerantMonitor", "acSystemRefrigerantMonitor")
         .field("provisionMessage.obdSupportedIndicators.brakeIndicatorLight","brakeIndicatorLightStatus")
         .field("provisionMessage.obdSupportedIndicators.brakeSwitchStatus","brakeSwitchStatusIndicator")
         .field("provisionMessage.obdSupportedIndicators.catalystMonitor","catalystMonitor")
         .field("provisionMessage.obdSupportedIndicators.comprehensiveComponentMonitor","comprehensiveComponentMonitor")
         .field("provisionMessage.obdSupportedIndicators.coolantHotLight","coolantHotLightStatus")
         .field("provisionMessage.obdSupportedIndicators.cruiseControlStatus","cruiseControlStatus")
         .field("provisionMessage.obdSupportedIndicators.egrSystemMonitor","egrSystemMonitor")
         .field("provisionMessage.obdSupportedIndicators.evaporativeSystemMonitor","evaporativeSystemMonitor")
         .field("provisionMessage.obdSupportedIndicators.fuelSystemMonitor","fuelSystemMonitorStatus")
         .field("provisionMessage.obdSupportedIndicators.heatedCatalystMonitor","heatedCatalystMonitor")
         .field("provisionMessage.obdSupportedIndicators.ignitionStatus","ignitionStatus")
         .field("provisionMessage.obdSupportedIndicators.milStatus","milStatus")
         .field("provisionMessage.obdSupportedIndicators.misfireMonitor","misfireMonitorStatus")
         .field("provisionMessage.obdSupportedIndicators.oilPressureLamp","oilPressureLampIndicator")
         .field("provisionMessage.obdSupportedIndicators.oxygenSensorHeatedMonitor","oxygenSensorHeatedMonitor")
         .field("provisionMessage.obdSupportedIndicators.oxygenSensorMonitor","oxygenSensorMonitor")
         .field("provisionMessage.obdSupportedIndicators.ptoStatus","ptoStatus")
         .field("provisionMessage.obdSupportedIndicators.seatBeltFastened","seatBeltFastenedIndicator")
         .field("provisionMessage.obdSupportedIndicators.secondaryAirSystemMonitor","secondaryAirSystemMonitor")
         .field("provisionMessage.obdSupportedIndicators.maintenanceRequired", "maintenanceRequired")
         .field("provisionMessage.obdSupportedIndicators.o2SensorCircuitNoActivity","o2SensorCircuitNoActivity")
         .field("provisionMessage.obdSupportedIndicators.o2SensorHeaterCircuitMalfunction","o2SensorHeaterCircuitMalfunction")
         .field("provisionMessage.obdSupportedIndicators.ho2SHeaterControlMalfunction","ho2SHeaterControlMalfunction")
         .field("provisionMessage.obdSupportedIndicators.ho2SHeaterResistanceMalfunction","ho2SHeaterResistanceMalfunction")

         .field("provisionMessage.obdSupportedParameters.batteryVoltageSupported","batteryVoltageSupported")
         .field("provisionMessage.obdSupportedParameters.engineCoolantTempSupported","engineCoolantTemperatureSupported")
         .field("provisionMessage.obdSupportedParameters.engineSpeedSupported", "engineSpeedSupported")
         .field("provisionMessage.obdSupportedParameters.fuelLevelRemainingSupported","fuelLevelRemainingSupported")
         .field("provisionMessage.obdSupportedParameters.fuelLevelSupported","fuelLevelSupported")
         .field("provisionMessage.obdSupportedParameters.fuelRateSupported","fuelRateSupported")
         .field("provisionMessage.obdSupportedParameters.odometerSupported","odometerSupported")
         .field("provisionMessage.obdSupportedParameters.throttlePositionSupported","throttlePositionSupported")
         .field("provisionMessage.obdSupportedParameters.transmissionGearSupported","transmissionGearSupported")
         .field("provisionMessage.obdSupportedParameters.tripFuelConsumptionSupported","tripFuelConsumptionSupported")
         .field("provisionMessage.obdSupportedParameters.tripOdometerSupported","tripOdometerSupported")
         .field("provisionMessage.obdSupportedParameters.turnSignalStatusSupported","turnSignalStatusSupported")
         .field("provisionMessage.obdSupportedParameters.vehicleSpeedSupported", "vehicleSpeedSupported")
         .field("provisionMessage.obdSupportedParameters.calculatedFuelUsageSupported", "calculatedFuelUsageSupported")
         .field("provisionMessage.obdSupportedParameters.engineStateSupported", "engineStateSupported")
         
         .field("provisionMessage.obdSupportedParameters.serviceIntervalInspectionDistanceSupported", "serviceIntervalInspectionDistanceSupported")
         .field("provisionMessage.obdSupportedParameters.fuelLevelRemaining3030Supported", "fuelLevelRemaining3030Supported")
         .field("provisionMessage.obdSupportedParameters.serviceIntervalDaysRemainingSupported", "serviceIntervalDaysRemainingSupported")
         .field("provisionMessage.obdSupportedParameters.engineOilTempSupported", "engineOilTempSupported")
         .field("provisionMessage.obdSupportedParameters.fuelEconomySupported", "fuelEconomySupported")
         .field("provisionMessage.obdSupportedParameters.dtcCountSupported", "dtcCountSupported")
         .field("provisionMessage.obdSupportedParameters.serviceIntervalOilDistanceSupported", "serviceIntervalOilDistanceSupported")
         .field("provisionMessage.obdSupportedParameters.serviceIntervalOilDaysSupported", "serviceIntervalOilDaysSupported")
         .field("provisionMessage.obdSupportedParameters.engineRunTimeSupported", "engineRunTimeSupported")
         .field("provisionMessage.obdSupportedParameters.ambientAirTempSupported", "ambientAirTempSupported")
         .field("provisionMessage.obdSupportedParameters.barometricPressureSupported", "barometricPressureSupported")
         .field("provisionMessage.obdSupportedParameters.canTecSupported", "canTecSupported")
         .field("provisionMessage.obdSupportedParameters.canRecSupported", "canRecSupported")
         .field("provisionMessage.obdSupportedParameters.canBusModeSupported", "canBusModeSupported")
         .field("provisionMessage.obdSupportedParameters.canBusErrorTypeSupported", "canBusErrorTypeSupported")
         .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, DtcEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("rawDtcMessage.locationInformation.carrier" ,"carrier")
         .field("rawDtcMessage.locationInformation.heading", "heading")
         .field("rawDtcMessage.locationInformation.hdop", "hdop")
         .field("rawDtcMessage.locationInformation.latitude" ,"latitude")
         .field("rawDtcMessage.locationInformation.longitude", "longitude")
         .field("rawDtcMessage.locationInformation.satelliteCount", "satellites")
         .field("rawDtcMessage.locationInformation.inputs", "inputs")
         .field("rawDtcMessage.locationInformation.commState","commState")
         .field("rawDtcMessage.locationInformation.commState.voiceCallIsActive","commState.voiceCallActive")
         .field("rawDtcMessage.locationInformation.unitStatus","unitStatus")
         .field("rawDtcMessage.locationInformation.unitStatus.modemMinTest","unitStatus.modemMinTestResults")
         .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, JbusEventProtocol.class)
        .mapNulls(false)
        .use(NetworkMessage.class, DeviceEvent.class)
        .field("rawJbusMessage.jbusData1708.vin", "vin")
     	.field("rawJbusMessage.jbusData1708.odometer", "odometer")
     	.field("rawJbusMessage.jbusData1708.batteryVoltage", "batteryVoltage")
     	.field("rawJbusMessage.jbusData1708.switchedBatteryVoltage", "switchedBatteryVoltage")
     	.field("rawJbusMessage.jbusData1708.engineSpeed", "engineSpeed")
     	.field("rawJbusMessage.jbusData1708.totalFuel", "totalFuel")
     	.field("rawJbusMessage.jbusData1708.totalIdleFuel", "totalIdleFuel")
     	.field("rawJbusMessage.jbusData1708.totalIdleHours", "totalIdleHours")
     	.field("rawJbusMessage.jbusData1708.totalEngineHours", "totalEngineHours")
     	.field("rawJbusMessage.jbusData1708.engineCoolantTemperature", "engineCoolantTemperature")
     	.field("rawJbusMessage.jbusData1708.engineOilTemperature", "engineOilTemperature")
         
     	.field("rawJbusMessage.jbusData1939.vin", "vin")
    	.field("rawJbusMessage.jbusData1939.odometer", "odometer")
    	.field("rawJbusMessage.jbusData1939.highRezOdometer", "highResolutionOdometer")
    	.field("rawJbusMessage.jbusData1939.batteryVoltage", "batteryVoltage")
    	.field("rawJbusMessage.jbusData1939.switchedBatteryVoltage", "switchedBatteryVoltage")
    	.field("rawJbusMessage.jbusData1939.engineSpeed", "engineSpeed")
    	.field("rawJbusMessage.jbusData1939.totalFuel", "totalFuel")
    	.field("rawJbusMessage.jbusData1939.totalIdleFuel", "totalIdleFuel")
    	.field("rawJbusMessage.jbusData1939.totalIdleHours", "totalIdleHours")
    	.field("rawJbusMessage.jbusData1939.totalEngineHours", "totalEngineHours")
    	.field("rawJbusMessage.jbusData1939.engineCoolantTemperature", "engineCoolantTemperature")
    	.field("rawJbusMessage.jbusData1939.engineOilTemperature", "engineOilTemperature")
    	.field("rawJbusMessage.jbusData1939.seatBeltUsed", "seatBeltUsed")
    	.byDefault().register();

    	 mapperFactory.classMap(NetworkMessage.class, JbusDtcEvent.class)
         .mapNulls(false)
        .use(NetworkMessage.class, DeviceEvent.class)
    	.field("rawJbusMessage.jbusDtcData.spn", "spn")
        .field("rawJbusMessage.jbusDtcData.fmi", "fmi")
        .field("rawJbusMessage.jbusDtcData.oc", "oc")
        .byDefault().register();
    	 
    	 mapperFactory.classMap(NetworkMessage.class, JbusDailyReportEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .byDefault().register();
    	
    	 mapperFactory.classMap(NetworkMessage.class, JbusDailyReportData.class)
         .mapNulls(false)
        .field("rawJbusMessage.dailyReport.deviceData.dailyEngineTotalHours.value", "engineTotalHours.value")
        .field("rawJbusMessage.dailyReport.deviceData.dailyEngineIdleHours.value", "engineIdleHours.value")
        .field("rawJbusMessage.dailyReport.deviceData.dailyEngineIdleFuel.value", "engineIdleFuel.value")
        .field("rawJbusMessage.dailyReport.deviceData.dailyEngineOilLevel.value", "engineOilLevel.value")
        .field("rawJbusMessage.dailyReport.deviceData.dailyEngineCoolantLevel.value", "engineCoolantLevel.value")
        .field("rawJbusMessage.dailyReport.deviceData.dailyNoxTankLevel.value", "noxTankLevel.value")
        .byDefault().register();

    	 mapperFactory.classMap(NetworkMessage.class, JbusHourlyReportEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
    	.byDefault().register();
    	 
    	 mapperFactory.classMap(NetworkMessage.class, JbusHourlyReportData.class)
         .mapNulls(false)
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineCoolantTemperature.value", "engineCoolantTemperature.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineOilTemperature.value", "engineOilTemperature.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineOilPressure.value", "engineOilPressure.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineCrankcasePressure.value", "engineCrankcasePressure.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineCoolantPressure.value", "engineCoolantPressure.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineBatteryVoltage.value", "engineBatteryVoltage.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineFuelTankLevel1.value", "engineFuelTankLevel1.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyEngineFuelTankLevel2.value", "engineFuelTankLevel2.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyTransmissionOilTemperature.value", "transmissionOilTemperature.value")
        .field("rawJbusMessage.hourlyReport.deviceData.hourlyAverageFuelEconomy.value", "averageFuelEconomy.value")
        .byDefault().register();
         
    	 mapperFactory.classMap(NetworkMessage.class, JbusConstructionDailyReportEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
        .field("rawJbusMessage.constructionDailyReport.machineState.engineStatus", "machineState.engineStatus")
        .field("rawJbusMessage.constructionDailyReport.machineState.ptoStatus", "machineState.ptoStatus")
        .field("rawJbusMessage.constructionDailyReport.machineState.moving", "machineState.moving")
        .field("rawJbusMessage.constructionDailyReport.machineState.j1708MsgRecvd", "machineState.j1708MsgRecvd")
        .field("rawJbusMessage.constructionDailyReport.machineState.j1939MsgRecvd", "machineState.j1939MsgRecvd")
        .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, JbusConstructionDailyReportData.class)
         .mapNulls(false)
        .field("rawJbusMessage.constructionDailyReport.deviceData.engineTotalFuelUsed.value", "engineTotalFuelUsed.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgEngineFuelRate.value", "avgEngineFuelRate.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgActualEngineTorque.value", "avgActualEngineTorque.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minEngineSpeed.value", "minEngineSpeed.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxEngineSpeed.value", "maxEngineSpeed.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgEngineSpeed.value", "avgEngineSpeed.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minDEFConcentration.value", "minDEFConcentration.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxDEFConcentration.value", "maxDEFConcentration.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgDEFConcentration.value", "avgDEFConcentration.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minDEFTempr.value", "minDEFTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxDEFTempr.value", "maxDEFTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgDEFTempr.value", "avgDEFTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minEngineOilPressure.value", "minEngineOilPressure.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxEngineOilPressure.value", "maxEngineOilPressure.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgEngineOilPressure.value", "avgEngineOilPressure.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minEngineOilTempr.value", "minEngineOilTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxEngineOilTempr.value", "maxEngineOilTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgEngineOilTempr.value", "avgEngineOilTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minEngineCoolantTempr.value", "minEngineCoolantTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxEngineCoolantTempr.value", "maxEngineCoolantTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgEngineCoolantTempr.value", "avgEngineCoolantTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minEngineFuelTempr1.value", "minEngineFuelTempr1.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxEngineFuelTempr1.value", "maxEngineFuelTempr1.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgEngineFuelTempr1.value", "avgEngineFuelTempr1.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minAmbientAirTempr.value", "minAmbientAirTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxAmbientAirTempr.value", "maxAmbientAirTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgAmbientAirTempr.value", "avgAmbientAirTempr.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.minAuxiliaryTempr1.value", "minAuxiliaryTempr1.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.maxAuxiliaryTempr1.value", "maxAuxiliaryTempr1.value")
        .field("rawJbusMessage.constructionDailyReport.deviceData.avgAuxiliaryTempr1.value", "avgAuxiliaryTempr1.value")
        .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, JbusConstructionDailyUsageReportEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("rawJbusMessage.constructionDailyUsageReport.machineState.engineStatus", "machineState.engineStatus")
         .field("rawJbusMessage.constructionDailyUsageReport.machineState.ptoStatus", "machineState.ptoStatus")
         .field("rawJbusMessage.constructionDailyUsageReport.machineState.moving", "machineState.moving")
         .field("rawJbusMessage.constructionDailyUsageReport.machineState.j1708MsgRecvd", "machineState.j1708MsgRecvd")
         .field("rawJbusMessage.constructionDailyUsageReport.machineState.j1939MsgRecvd", "machineState.j1939MsgRecvd")
         .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, JbusConstructionDailyUsageReportData.class)
         .mapNulls(false)
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque0To10PercentUsage.value", "engineTorque0To10PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque10To20PercentUsage.value", "engineTorque10To20PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque20To30PercentUsage.value", "engineTorque20To30PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque30To40PercentUsage.value", "engineTorque30To40PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque40To50PercentUsage.value", "engineTorque40To50PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque50To60PercentUsage.value", "engineTorque50To60PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque60To70PercentUsage.value", "engineTorque60To70PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque70To80PercentUsage.value", "engineTorque70To80PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorque80To90PercentUsage.value", "engineTorque80To90PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.engineTorqueOver90PercentUsage.value", "engineTorqueOver90PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque0To10PercentUsage.value", "positionTorque0To10PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque10To20PercentUsage.value", "positionTorque10To20PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque20To30PercentUsage.value", "positionTorque20To30PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque30To40PercentUsage.value", "positionTorque30To40PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque40To50PercentUsage.value", "positionTorque40To50PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque50To60PercentUsage.value", "positionTorque50To60PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque60To70PercentUsage.value", "positionTorque60To70PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque70To80PercentUsage.value", "positionTorque70To80PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorque80To90PercentUsage.value", "positionTorque80To90PercentUsage.value")
         .field("rawJbusMessage.constructionDailyUsageReport.deviceData.positionTorqueOver90PercentUsage.value", "positionTorqueOver90PercentUsage.value")
         .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, JbusConstructionHourlyReportEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("rawJbusMessage.constructionHourlyReport.machineState.engineStatus", "machineState.engineStatus")
         .field("rawJbusMessage.constructionHourlyReport.machineState.ptoStatus", "machineState.ptoStatus")
         .field("rawJbusMessage.constructionHourlyReport.machineState.moving", "machineState.moving")
         .field("rawJbusMessage.constructionHourlyReport.machineState.j1708MsgRecvd", "machineState.j1708MsgRecvd")
         .field("rawJbusMessage.constructionHourlyReport.machineState.j1939MsgRecvd", "machineState.j1939MsgRecvd")
         .byDefault().register();
        
         mapperFactory.classMap(NetworkMessage.class, JbusConstructionHourlyReportData.class)
         .mapNulls(false)
         .field("rawJbusMessage.constructionHourlyReport.deviceData.totalEngineHours.value", "totalEngineHours.value")
         .field("rawJbusMessage.constructionHourlyReport.deviceData.defOrNoxTankLevel.value", "defOrNoxTankLevel.value")
         .field("rawJbusMessage.constructionHourlyReport.deviceData.fuelTankLevel1.value", "fuelTankLevel1.value")
         .byDefault().register();
    	 
    	 mapperFactory.classMap(NetworkMessage.class, JbusFaultReportEvent.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
    	 .field("rawJbusMessage.jbusFaultReport.sourceAddress", "sourceAddress")
         .field("rawJbusMessage.jbusFaultReport.device", "device")
         .field("rawJbusMessage.jbusFaultReport.function", "function")
         .field("rawJbusMessage.jbusFaultReport.failure", "failure")
         .field("rawJbusMessage.jbusFaultReport.machineState.engineStatus", "machineState.engineStatus")
         .field("rawJbusMessage.jbusFaultReport.machineState.ptoStatus", "machineState.ptoStatus")
         .field("rawJbusMessage.jbusFaultReport.machineState.moving", "machineState.moving")
         .field("rawJbusMessage.jbusFaultReport.machineState.j1708MsgRecvd", "machineState.j1708MsgRecvd")
         .field("rawJbusMessage.jbusFaultReport.machineState.j1939MsgRecvd", "machineState.j1939MsgRecvd")
         .byDefault().register();
    	 
    	  mapperFactory.classMap(NetworkMessage.class, JbusDiscoveryReportEvent.class)
    	 .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
    	 .field("rawJbusMessage.jbusDiscoveryReport.vehicleSpeedFound", "vehicleSpeedFound")
         .field("rawJbusMessage.jbusDiscoveryReport.odometerFound", "odometerFound")
         .field("rawJbusMessage.jbusDiscoveryReport.totalFuelFound", "totalFuelFound")
         .field("rawJbusMessage.jbusDiscoveryReport.vinFound", "vinFound")
         .field("rawJbusMessage.jbusDiscoveryReport.batteryVoltageSourcesFound", "batteryVoltageSourcesFound")
         .field("rawJbusMessage.jbusDiscoveryReport.discoveryReportSourcesFound1", "discoveryReportSourcesFound1")
         .field("rawJbusMessage.jbusDiscoveryReport.discoveryReportSourcesFound2", "discoveryReportSourcesFound2")
         .field("rawJbusMessage.jbusDiscoveryReport.discoveryReportSourcesFound3", "discoveryReportSourcesFound3")
         .field("rawJbusMessage.jbusDiscoveryReport.discoveryReportSourcesFound4", "discoveryReportSourcesFound4")
         .field("rawJbusMessage.jbusDiscoveryReport.fuelTankSourcesFound", "fuelTankSourcesFound")
         .field("rawJbusMessage.jbusDiscoveryReport.averageFuelTankSourcesFound", "averageFuelTankSourcesFound")
         .field("rawJbusMessage.jbusDiscoveryReport.ptoSourcesFound", "ptoSourcesFound")
         .field("rawJbusMessage.jbusDiscoveryReport.ptoSourcesActive", "ptoSourcesActive")
         .field("rawJbusMessage.jbusDiscoveryReport.engineTorqueSourcesFound", "engineTorqueSourcesFound")
         .field("rawJbusMessage.jbusDiscoveryReport.engineThrottleSourcesFound", "engineThrottleSourcesFound")
         .field("rawJbusMessage.jbusDiscoveryReport.machineState.engineStatus", "machineState.engineStatus")
         .field("rawJbusMessage.jbusDiscoveryReport.machineState.ptoStatus", "machineState.ptoStatus")
         .field("rawJbusMessage.jbusDiscoveryReport.machineState.moving", "machineState.moving")
         .field("rawJbusMessage.jbusDiscoveryReport.machineState.j1708MsgRecvd", "machineState.j1708MsgRecvd")
         .field("rawJbusMessage.jbusDiscoveryReport.machineState.j1939MsgRecvd", "machineState.j1939MsgRecvd")
         .byDefault().register();
    	 
    	 mapperFactory.classMap(NetworkMessage.class, JbusHydraulicReportEventV2.class)
         .mapNulls(false)
         .use(NetworkMessage.class, DeviceEvent.class)
         .field("rawJbusMessage.jbusHydraulicReport.machineState.engineStatus", "machineState.engineStatus")
         .field("rawJbusMessage.jbusHydraulicReport.machineState.ptoStatus", "machineState.ptoStatus")
         .field("rawJbusMessage.jbusHydraulicReport.machineState.moving", "machineState.moving")
         .field("rawJbusMessage.jbusHydraulicReport.machineState.j1708MsgRecvd", "machineState.j1708MsgRecvd")
         .field("rawJbusMessage.jbusHydraulicReport.machineState.j1939MsgRecvd", "machineState.j1939MsgRecvd")
         .byDefault().register();
         
         mapperFactory.classMap(NetworkMessage.class, JbusHydraulicReportData.class)
         .mapNulls(false)
         .field("rawJbusMessage.jbusHydraulicReport.deviceData.minHydraulicChargePressure.value", "minHydraulicChargePressure.value")
         .field("rawJbusMessage.jbusHydraulicReport.deviceData.maxHydraulicChargePressure.value", "maxHydraulicChargePressure.value")
         .field("rawJbusMessage.jbusHydraulicReport.deviceData.avgHydraulicChargePressure.value", "avgHydraulicChargePressure.value")
         .field("rawJbusMessage.jbusHydraulicReport.deviceData.minHydraulicOilTemperature.value", "minHydraulicOilTemperature.value")
         .field("rawJbusMessage.jbusHydraulicReport.deviceData.maxHydraulicOilTemperature.value", "maxHydraulicOilTemperature.value")
         .field("rawJbusMessage.jbusHydraulicReport.deviceData.avgHydraulicOilTemperature.value", "avgHydraulicOilTemperature.value")
         .byDefault().register();
    	 
    	 mapperFactory.classMap(JbusDtcDataJ1708.class, JbusDtc1708Protocol.class)
         .mapNulls(false)
    	.byDefault().register();
    	 
    	 mapperFactory.classMap(JbusDtcDataJ1708.class, JbusDtc1708Protocol.class)
         .mapNulls(false)
         .byDefault().register();
    	
    	 mapperFactory.classMap(NetworkMessage.class, LocateReportResponse.class)
         .mapNulls(false)
         .field("deviceId", "deviceId")
         .field("externalDeviceId", "deviceEsn")
         .field("sequenceId", "deviceMessageSequenceNumber")
         .field("deviceIp", "deviceIp")
         .field("port", "port")
         .field("nagReceivedTime", "messageReceivedTime")
         .field("rawDeviceHexMessage", "rawDeviceHexMessage")
         .field("type", "messageType")
         .field("messageUuid", "messageUuid")
         .field("rawDeviceCommandResponse.locateReport.location.latitude","latitude")
         .field("rawDeviceCommandResponse.locateReport.location.longitude","longitude")
         .field("rawDeviceCommandResponse.locateReport.heading", "heading")
         .field("rawDeviceCommandResponse.locateReport.satellites", "satellites")
         .field("rawDeviceCommandResponse.locateReport.fixStatus", "fixStatus")
         .field("rawDeviceCommandResponse.locateReport.carrier", "carrier")
         .field("rawDeviceCommandResponse.locateReport.commState", "commStatus")
         .field("rawDeviceCommandResponse.locateReport.hdop", "hdop")
         .field("rawDeviceCommandResponse.locateReport.timeOfFix", "timeOfFix")
         .field("rawDeviceCommandResponse.locateReport.updateTime", "updateTime")
         .field("rawDeviceCommandResponse.locateReport.inputs", "inputs")
         .exclude("sequenceId")
         .byDefault().register();

    	 mapperFactory.classMap(NetworkMessage.class, LocateReportResponseData.class)
         .mapNulls(false)
         .field("rawDeviceCommandResponse.locateReport.altitude.value", "altitude.value")
         .field("rawDeviceCommandResponse.locateReport.speed.value", "speed.value")
         .field("rawDeviceCommandResponse.locateReport.rssi.value", "rssi.value")
         .field("rawDeviceCommandResponse.locateReport.accumulators", "accumulators")
         .byDefault().register();
    	 
    	 mapperFactory.classMap(NetworkMessage.class, ParameterResponse.class)
         .mapNulls(false)
         .field("deviceId", "deviceId")
         .field("externalDeviceId", "deviceEsn")
         .field("sequenceId", "deviceMessageSequenceNumber")
         .field("deviceIp", "deviceIp")
         .field("port", "port")
         .field("nagReceivedTime", "messageReceivedTime")
         .field("rawDeviceHexMessage", "rawDeviceHexMessage")
         .field("type", "messageType")
         .field("messageUuid", "messageUuid")
         .field("rawDeviceCommandResponse.parameterInfoList", "parameters")
         .field("rawDeviceCommandResponse.invalidParameterIds", "invalidParameters")
         .field("rawDeviceCommandResponse.invalidParameterIndexes", "invalidParameterIndexes")
         .exclude("sequenceId")
         .byDefault().register();
    	 
    	 mapperFactory.classMap(NetworkMessage.class, AckNakResponse.class)
         .mapNulls(false)
         .field("deviceId", "deviceId")
         .field("externalDeviceId", "deviceEsn")
         .field("sequenceId", "deviceMessageSequenceNumber")
         .field("deviceIp", "deviceIp")
         .field("port", "port")
         .field("nagReceivedTime", "messageReceivedTime")
         .field("rawDeviceHexMessage", "rawDeviceHexMessage")
         .field("type", "messageType")
         .field("messageUuid", "messageUuid")
         .field("rawDeviceCommandResponse.ackMessage.ackStatus", "successfulAck")
         .exclude("sequenceId")
         .byDefault().register();
    	 
    	 mapperFactory.classMap(ParameterInfo.class, ParameterConfigInfo.class)
    	 .mapNulls(false)
    	 .field("parameterData", "value")
    	 .byDefault().register();
    	 
    	 mapperFactory.classMap(com.calamp.connect.models.network.Event.FixStatus.class, FixStatus.class)
         .mapNulls(false)
         .byDefault().register();
    	
    	 mapperFactory.classMap(com.calamp.connect.models.network.Network.CommState.class, CommState.class)
         .mapNulls(false)
         .byDefault().register();
    	
    	 mapperFactory.classMap(com.calamp.connect.models.network.Network.Accumulator.class, com.calamp.connect.models.messaging.devicecommand.Accumulator.class)
         .mapNulls(false)
         .byDefault().register();
        return mapperFactory;
    }

}
