package com.calamp.connect.models.messaging.devicecommand;

public interface CommandParamConstant
{
    // For All
    public static final String DEVICE_IP_ADDRESS           = "deviceIpAddress";
    public static final String PORT                        = "port";
    // locate request
    public static final String LOCATE_ACCUMULATOR_COUNT    = "accumulatorCount";
    // parameter read & write request
    public static final String PARAMETER_IDS               = "parameterIds";
    public static final String PARAMETER_INDEXES           = "indexes";
    public static final String PARAMETER_VALUES            = "values";
    // OtaDownload Request
    public static final String OTA_APPLY_DATE              = "applyDate";
    public static final String OTA_ATTACHED_DEVICE_ADDRESS = "attachedDeviceAddress";
    public static final String OTA_CHECKSUM                = "checksum";
    public static final String OTA_DEVICE_TYPE             = "deviceType";
    public static final String OTA_DOWNLOAD_PROTOCOL       = "downloadProtocol";
    public static final String OTA_FILE_LENGTH             = "fileLength";
    public static final String OTA_FILE_PATH               = "filePath";
    public static final String OTA_FILETYPE                = "fileType";
    public static final String OTA_FILEVERSION             = "fileVersion";
    public static final String OTA_PASSWORD                = "password";
    public static final String OTA_USERNAME                = "username";
    public static final String OTA_SERVERNAME              = "serverName";
    // PegAction Request
    public static final String PEG_ACTION_CODE             = "pegActionCode";
    public static final String PEG_ACTION_MODIFIER         = "pegActionModifier";
    // SetAndEnableZone Request
    public static final String ZONE_HYSTERESIS             = "hysteresis";
    public static final String ZONE_NUMBER                 = "number";
    public static final String ZONE_SIZE                   = "size";
    // GeoZone Request
    public static final String GEO_ZONE_HYSTERESIS         = "hysteresis";
    public static final String GEO_ZONE_ID                 = "geoZoneId";
    public static final String GEO_ZONE_DISTANCE_NORTH     = "distanceNorth";
    public static final String GEO_ZONE_DISTANCE_EAST      = "distanceEast";
    public static final String GEO_ZONE_LATITUDE           = "latitude";
    public static final String GEO_ZONE_LONGITUDE          = "longitude";
    public static final String GEO_ZONE_TYPE               = "zoneType";
    public static final String GEO_PARAM_ID                = "paramId";
    public static final String UNIT_ACTION_CODE            = "actionCode";
    public static final String UNIT_8BIT_DATA              = "unitRequest8bitData";
    public static final String UNIT_16BIT_DATA             = "unitRequest16bitData";
    public static final String UNIT_32BIT_DATA             = "unitRequest32bitData";
    public static final String UNIT_ACTION_NAME            = "actionName";

}
