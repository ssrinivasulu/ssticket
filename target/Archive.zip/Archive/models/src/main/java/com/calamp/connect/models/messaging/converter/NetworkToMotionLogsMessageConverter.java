package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.MotionLogsEvent;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component("networkToMotionLogsMessageConverter")
public class NetworkToMotionLogsMessageConverter extends GenericNetworkToDeviceEventConverter
{
    public MotionLogsEvent convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        MotionLogsEvent motionLogsEvent = mapper.map(network, MotionLogsEvent.class);
        motionLogsEvent.setEventTime(new Date(network.getMotionLogsMessage().getLocationTime()));
        return motionLogsEvent;
    }
}
