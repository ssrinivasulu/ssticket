package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionDailyReportEvent;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusConstructionDailyReportConverter")
public class DeviceEventToJbusConstructionDailyReportConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusConstructionDailyReportEvent, ConstructionDailyReport>
{
    @Override
    public ConstructionDailyReport modelToDomain(JbusConstructionDailyReportEvent event)
    {
        return null;
    }

    @Override
    public JbusConstructionDailyReportEvent domainToModel(ConstructionDailyReport event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionDailyReportEvent jbusConstructionDailyReportEvent = mapper.map(event, JbusConstructionDailyReportEvent.class);
        if (event.getDeviceData() != null)
        {
            ConstructionDailyReportData constructionDailyReportData = (ConstructionDailyReportData) event.getDeviceData();

            if (constructionDailyReportData.getEngineTotalFuelUsed() != null)
                jbusConstructionDailyReportEvent.setEngineTotalFuelUsed(convertHeaderDataToDouble(constructionDailyReportData
                        .getEngineTotalFuelUsed()));
            if (constructionDailyReportData.getAvgActualEngineTorque() != null)
                jbusConstructionDailyReportEvent.setAvgActualEngineTorque(convertHeaderDataToInt(constructionDailyReportData
                        .getAvgActualEngineTorque()));
            if (constructionDailyReportData.getAvgAmbientAirTempr() != null)
                jbusConstructionDailyReportEvent
                        .setAvgAmbientAirTempr(convertHeaderDataToDouble(constructionDailyReportData.getAvgAmbientAirTempr()));
            if (constructionDailyReportData.getAvgAuxiliaryTempr1() != null)
                jbusConstructionDailyReportEvent.setAvgAuxiliaryTempr1(convertHeaderDataToInt(constructionDailyReportData.getAvgAuxiliaryTempr1()));
            if (constructionDailyReportData.getAvgDEFConcentration() != null)
                jbusConstructionDailyReportEvent.setAvgDEFConcentration(convertHeaderDataToDouble(constructionDailyReportData
                        .getAvgDEFConcentration()));
            if (constructionDailyReportData.getAvgDEFTempr() != null)
                jbusConstructionDailyReportEvent.setAvgDEFTempr(convertHeaderDataToInt(constructionDailyReportData.getAvgDEFTempr()));
            if (constructionDailyReportData.getAvgEngineCoolantTempr() != null)
                jbusConstructionDailyReportEvent.setAvgEngineCoolantTempr(convertHeaderDataToInt(constructionDailyReportData
                        .getAvgEngineCoolantTempr()));
            if (constructionDailyReportData.getAvgEngineFuelRate() != null)
                jbusConstructionDailyReportEvent.setAvgEngineFuelRate(convertHeaderDataToDouble(constructionDailyReportData.getAvgEngineFuelRate()));
            if (constructionDailyReportData.getAvgEngineFuelTempr1() != null)
                jbusConstructionDailyReportEvent.setAvgEngineFuelTempr1(convertHeaderDataToInt(constructionDailyReportData.getAvgEngineFuelTempr1()));
            if (constructionDailyReportData.getAvgEngineOilPressure() != null)
                jbusConstructionDailyReportEvent
                        .setAvgEngineOilPressure(convertHeaderDataToInt(constructionDailyReportData.getAvgEngineOilPressure()));
            if (constructionDailyReportData.getAvgEngineOilTempr() != null)
                jbusConstructionDailyReportEvent.setAvgEngineOilTempr(convertHeaderDataToDouble(constructionDailyReportData.getAvgEngineOilTempr()));
            if (constructionDailyReportData.getAvgEngineSpeed() != null)
                jbusConstructionDailyReportEvent.setAvgEngineSpeed(convertHeaderDataToDouble(constructionDailyReportData.getAvgEngineSpeed()));

            if (constructionDailyReportData.getMaxAmbientAirTempr() != null)
                jbusConstructionDailyReportEvent
                        .setMaxAmbientAirTempr(convertHeaderDataToDouble(constructionDailyReportData.getMaxAmbientAirTempr()));
            if (constructionDailyReportData.getMaxAuxiliaryTempr1() != null)
                jbusConstructionDailyReportEvent.setMaxAuxiliaryTempr1(convertHeaderDataToInt(constructionDailyReportData.getMaxAuxiliaryTempr1()));
            if (constructionDailyReportData.getMaxDEFConcentration() != null)
                jbusConstructionDailyReportEvent.setMaxDEFConcentration(convertHeaderDataToDouble(constructionDailyReportData
                        .getMaxDEFConcentration()));
            if (constructionDailyReportData.getMaxDEFTempr() != null)
                jbusConstructionDailyReportEvent.setMaxDEFTempr(convertHeaderDataToInt(constructionDailyReportData.getMaxDEFTempr()));
            if (constructionDailyReportData.getMaxEngineCoolantTempr() != null)
                jbusConstructionDailyReportEvent.setMaxEngineCoolantTempr(convertHeaderDataToInt(constructionDailyReportData
                        .getMaxEngineCoolantTempr()));
            if (constructionDailyReportData.getMaxEngineFuelTempr1() != null)
                jbusConstructionDailyReportEvent.setMaxEngineFuelTempr1(convertHeaderDataToInt(constructionDailyReportData.getMaxEngineFuelTempr1()));
            if (constructionDailyReportData.getMaxEngineOilPressure() != null)
                jbusConstructionDailyReportEvent
                        .setMaxEngineOilPressure(convertHeaderDataToInt(constructionDailyReportData.getMaxEngineOilPressure()));
            if (constructionDailyReportData.getMaxEngineOilTempr() != null)
                jbusConstructionDailyReportEvent.setMaxEngineOilTempr(convertHeaderDataToDouble(constructionDailyReportData.getMaxEngineOilTempr()));
            if (constructionDailyReportData.getMaxEngineSpeed() != null)
                jbusConstructionDailyReportEvent.setMaxEngineSpeed(convertHeaderDataToDouble(constructionDailyReportData.getMaxEngineSpeed()));

            if (constructionDailyReportData.getMinAmbientAirTempr() != null)
                jbusConstructionDailyReportEvent
                        .setMinAmbientAirTempr(convertHeaderDataToDouble(constructionDailyReportData.getMinAmbientAirTempr()));
            if (constructionDailyReportData.getMinAuxiliaryTempr1() != null)
                jbusConstructionDailyReportEvent.setMinAuxiliaryTempr1(convertHeaderDataToInt(constructionDailyReportData.getMinAuxiliaryTempr1()));
            if (constructionDailyReportData.getMinDEFConcentration() != null)
                jbusConstructionDailyReportEvent.setMinDEFConcentration(convertHeaderDataToDouble(constructionDailyReportData
                        .getMinDEFConcentration()));
            if (constructionDailyReportData.getMinDEFTempr() != null)
                jbusConstructionDailyReportEvent.setMinDEFTempr(convertHeaderDataToInt(constructionDailyReportData.getMinDEFTempr()));
            if (constructionDailyReportData.getMinEngineCoolantTempr() != null)
                jbusConstructionDailyReportEvent.setMinEngineCoolantTempr(convertHeaderDataToInt(constructionDailyReportData
                        .getMinEngineCoolantTempr()));
            if (constructionDailyReportData.getMinEngineFuelTempr1() != null)
                jbusConstructionDailyReportEvent.setMinEngineFuelTempr1(convertHeaderDataToInt(constructionDailyReportData.getMinEngineFuelTempr1()));
            if (constructionDailyReportData.getMinEngineOilPressure() != null)
                jbusConstructionDailyReportEvent
                        .setMinEngineOilPressure(convertHeaderDataToInt(constructionDailyReportData.getMinEngineOilPressure()));
            if (constructionDailyReportData.getMinEngineOilTempr() != null)
                jbusConstructionDailyReportEvent.setMinEngineOilTempr(convertHeaderDataToDouble(constructionDailyReportData.getMinEngineOilTempr()));
            if (constructionDailyReportData.getMinEngineSpeed() != null)
                jbusConstructionDailyReportEvent.setMinEngineSpeed(convertHeaderDataToDouble(constructionDailyReportData.getMinEngineSpeed()));
        }
        return jbusConstructionDailyReportEvent;
    }

    @Override
    public JbusConstructionDailyReportEvent domainToModel(ConstructionDailyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<ConstructionDailyReport> getDomainType()
    {
        return ConstructionDailyReport.class;
    }

    @Override
    public Class<JbusConstructionDailyReportEvent> getModelType()
    {
        return JbusConstructionDailyReportEvent.class;
    }
}
