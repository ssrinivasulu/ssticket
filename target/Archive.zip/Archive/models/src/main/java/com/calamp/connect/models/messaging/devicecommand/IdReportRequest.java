package com.calamp.connect.models.messaging.devicecommand;

public class IdReportRequest extends DeviceCommandMessageRequest
{
    @Override
    public String toString()
    {
        return "IdReportRequest{" + super.toString() + '}';
    }
}
