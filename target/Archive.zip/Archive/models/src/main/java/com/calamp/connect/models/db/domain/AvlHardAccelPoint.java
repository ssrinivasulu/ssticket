package com.calamp.connect.models.db.domain;

public class AvlHardAccelPoint {
	private Integer speed;
	private Integer digitalInStatus;
	private Float lateralAcceleration;
	private Float longitudinalAcceleration;
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	public Integer getDigitalInStatus() {
		return digitalInStatus;
	}
	public void setDigitalInStatus(Integer digitalInStatus) {
		this.digitalInStatus = digitalInStatus;
	}
	public Float getLateralAcceleration() {
		return lateralAcceleration;
	}
	public void setLateralAcceleration(Float lateralAcceleration) {
		this.lateralAcceleration = lateralAcceleration;
	}
	public Float getLongitudinalAcceleration() {
		return longitudinalAcceleration;
	}
	public void setLongitudinalAcceleration(Float longitudinalAcceleration) {
		this.longitudinalAcceleration = longitudinalAcceleration;
	}
}
