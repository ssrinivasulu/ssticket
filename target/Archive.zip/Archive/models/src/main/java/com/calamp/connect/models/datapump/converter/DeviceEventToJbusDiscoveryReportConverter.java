package com.calamp.connect.models.datapump.converter;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDiscoveryReportEvent;
import com.calamp.connect.models.network.Jbus.JbusDiscoveryReport;

import ma.glasnost.orika.MapperFacade;

/**
 * @author ssrinivasulu
 *
 */
@Component("deviceEventToToJbusDiscoveryReportConverter")
public class DeviceEventToJbusDiscoveryReportConverter extends GenericDeviceEventToEventMessageConverter {

	public JbusDiscoveryReport convertTo(JbusDiscoveryReportEvent event) {

		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusDiscoveryReport jbusDiscoveryReport = mapper.map(event, JbusDiscoveryReport.class);
		return jbusDiscoveryReport;

	}
	
	public JbusDiscoveryReportEvent convertFrom(JbusDiscoveryReport event) {

		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusDiscoveryReportEvent jbusDiscoverReportEvent = mapper.map(event, JbusDiscoveryReportEvent.class);
		return jbusDiscoverReportEvent;

	}
}
