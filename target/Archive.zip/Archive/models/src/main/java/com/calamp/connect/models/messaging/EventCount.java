package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "eventCount")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonRootName("eventCount")
@JsonTypeName("eventCount")
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
@XmlType(propOrder = { "numAvlEvents", "numDtcEvents", "numJbusEvents", "numJbusDtc1708Events", "numJbusDtc1939Events", "numJbusHourlyReportEvents",
        "numJbusDailyReportEvents", "numJbusConstructionDailyReportEvents", "numJbusConstructionDailyUsageReportEvents",
        "numJbusConstructionHourlyReportEvents", "numJbusFaultReportEvents", "numJbusHydraulicReportEvents", "numVehicleBusCapabilitiesEvents",
        "numDeviceCommandEvents", "numIdReportEvents", "numExtendedIdReportEvents", "numAppMessages", "numUserMessages", "numAempMessageEvents",
        "numMotionLogMessageEvents", "numJbusDiscoveryReportEvents", "numSelfDescribingJPODMessages" , "numJpod2DTCReports"})
@JsonPropertyOrder({ "numAvlEvents", "numDtcEvents", "numJbusEvents", "numJbusDtc1708Events", "numJbusDtc1939Events", "numJbusHourlyReportEvents",
        "numJbusDailyReportEvents", "numJbusConstructionDailyReportEvents", "numJbusConstructionDailyUsageReportEvents",
        "numJbusConstructionHourlyReportEvents", "numJbusFaultReportEvents", "numJbusHydraulicReportEvents", "numVehicleBusCapabilitiesEvents",
        "numDeviceCommandEvents", "numIdReportEvents", "numExtendedIdReportEvents", "numAppMessages", "numUserMessages", "numAempMessageEvents",
        "numMotionLogMessageEvents", "numJbusDiscoveryReportEvents", "numSelfDescribingJPODMessages", "numJpod2DTCReports" })
public class EventCount
{

    // J-
    int numAvlEvents                              = 0;
    int numDtcEvents                              = 0;
    int numJbusEvents                             = 0;
    int numJbusDtc1708Events                      = 0;
    int numJbusDtc1939Events                      = 0;
    int numJbusHourlyReportEvents                 = 0;
    int numJbusDailyReportEvents                  = 0;
    int numJbusConstructionDailyReportEvents      = 0;
    int numJbusConstructionDailyUsageReportEvents = 0;
    int numJbusConstructionHourlyReportEvents     = 0;
    int numJbusFaultReportEvents                  = 0;
    int numJbusHydraulicReportEvents              = 0;
    int numVehicleBusCapabilitiesEvents           = 0;
    int numDeviceCommandEvents                    = 0;
    int numIdReportEvents                         = 0;
    int numExtendedIdReportEvents                 = 0;
    int numAppMessages                            = 0;
    int numUserMessages                           = 0;
    int numAempMessageEvents                      = 0;
    int numJbusDiscoveryReportEvents              = 0;
    int numMotionLogMessageEvents                 = 0;
    int numSelfDescribingJPODMessages             = 0;
    int					numJpod2DTCReports						= 0;

    public int getNumSelfDescribingJPODMessages()
    {
        return numSelfDescribingJPODMessages;
    }

    public void setNumSelfDescribingJPODMessages(int numSelfDescribingJPODMessages)
    {
        this.numSelfDescribingJPODMessages = numSelfDescribingJPODMessages;
    }

    public int getNumAppMessages()
    {
        return numAppMessages;
    }

    public void setNumAppMessages(int numAppMessageEvents)
    {
        this.numAppMessages = numAppMessageEvents;
    }

    public int getNumUserMessages()
    {
        return numUserMessages;
    }

    public void setNumUserMessages(int numUserMessageEvents)
    {
        this.numUserMessages = numUserMessageEvents;
    }

    public int getNumAvlEvents()
    {
        return numAvlEvents;
    }

    public int getNumJpod2DTCReports() {
		return numJpod2DTCReports;
	}

	public void setNumJpod2DTCReports(int numJpod2DTCReports) {
		this.numJpod2DTCReports = numJpod2DTCReports;
	}

	public void setNumAvlEvents(int numAvlEvents)
    {
        this.numAvlEvents = numAvlEvents;
    }

    public int getNumDtcEvents()
    {
        return numDtcEvents;
    }

    public void setNumDtcEvents(int numDtcEvents)
    {
        this.numDtcEvents = numDtcEvents;
    }

    public int getNumJbusEvents()
    {
        return numJbusEvents;
    }

    public void setNumJbusEvents(int numJbusEvents)
    {
        this.numJbusEvents = numJbusEvents;
    }

    public int getNumJbusDtc1708Events()
    {
        return numJbusDtc1708Events;
    }

    public void setNumJbusDtc1708Events(int numJbusDtc1708Events)
    {
        this.numJbusDtc1708Events = numJbusDtc1708Events;
    }

    public int getNumJbusDtc1939Events()
    {
        return numJbusDtc1939Events;
    }

    public void setNumJbusDtc1939Events(int numJbusDtc1939Events)
    {
        this.numJbusDtc1939Events = numJbusDtc1939Events;
    }

    public int getNumJbusHourlyReportEvents()
    {
        return numJbusHourlyReportEvents;
    }

    public void setNumJbusHourlyReportEvents(int numJbusHourlyReportEvents)
    {
        this.numJbusHourlyReportEvents = numJbusHourlyReportEvents;
    }

    public int getNumJbusDailyReportEvents()
    {
        return numJbusDailyReportEvents;
    }

    public void setNumJbusDailyReportEvents(int numJbusDailyReportEvents)
    {
        this.numJbusDailyReportEvents = numJbusDailyReportEvents;
    }

    public int getNumJbusConstructionDailyReportEvents()
    {
        return numJbusConstructionDailyReportEvents;
    }

    public void setNumJbusConstructionDailyReportEvents(int numJbusConstructionDailyReportEvents)
    {
        this.numJbusConstructionDailyReportEvents = numJbusConstructionDailyReportEvents;
    }

    public int getNumJbusConstructionDailyUsageReportEvents()
    {
        return numJbusConstructionDailyUsageReportEvents;
    }

    public void setNumJbusConstructionDailyUsageReportEvents(int numJbusConstructionDailyUsageReportEvents)
    {
        this.numJbusConstructionDailyUsageReportEvents = numJbusConstructionDailyUsageReportEvents;
    }

    public int getNumJbusConstructionHourlyReportEvents()
    {
        return numJbusConstructionHourlyReportEvents;
    }

    public void setNumJbusConstructionHourlyReportEvents(int numJbusConstructionHourlyReportEvents)
    {
        this.numJbusConstructionHourlyReportEvents = numJbusConstructionHourlyReportEvents;
    }

    public int getNumJbusFaultReportEvents()
    {
        return numJbusFaultReportEvents;
    }

    public void setNumJbusFaultReportEvents(int numJbusFaultReportEvents)
    {
        this.numJbusFaultReportEvents = numJbusFaultReportEvents;
    }

    public int getNumJbusDiscoveryReportEvents()
    {
        return numJbusDiscoveryReportEvents;
    }

    public void setNumJbusDiscoveryReportEvents(int numJbusDiscoveryReportEvents)
    {
        this.numJbusDiscoveryReportEvents = numJbusDiscoveryReportEvents;
    }

    public int getNumJbusHydraulicReportEvents()
    {
        return numJbusHydraulicReportEvents;
    }

    public void setNumJbusHydraulicReportEvents(int numJbusHydraulicReportEvents)
    {
        this.numJbusHydraulicReportEvents = numJbusHydraulicReportEvents;
    }

    public int getNumVehicleBusCapabilitiesEvents()
    {
        return numVehicleBusCapabilitiesEvents;
    }

    public void setNumVehicleBusCapabilitiesEvents(int numVehicleBusCapabilitiesEvents)
    {
        this.numVehicleBusCapabilitiesEvents = numVehicleBusCapabilitiesEvents;
    }

    public int getNumDeviceCommandEvents()
    {
        return numDeviceCommandEvents;
    }

    public void setNumDeviceCommandEvents(int numDeviceCommandEvents)
    {
        this.numDeviceCommandEvents = numDeviceCommandEvents;
    }

    public int getNumIdReportEvents()
    {
        return numIdReportEvents;
    }

    public void setNumIdReportEvents(int numIdReportEvents)
    {
        this.numIdReportEvents = numIdReportEvents;
    }

    public int getNumExtendedIdReportEvents()
    {
        return numExtendedIdReportEvents;
    }

    public void setNumExtendedIdReportEvents(int numExtendedIdReportEvents)
    {
        this.numExtendedIdReportEvents = numExtendedIdReportEvents;
    }

    public int getNumAempMessageEvents()
    {
        return numAempMessageEvents;
    }

    public void setNumAempMessageEvents(int numAempMessageEvents)
    {
        this.numAempMessageEvents = numAempMessageEvents;
    }

    public int getNumMotionLogMessageEvents()
    {
        return numMotionLogMessageEvents;
    }

    public void setNumMotionLogMessageEvents(int numMotionLogMessageEvents)
    {
        this.numMotionLogMessageEvents = numMotionLogMessageEvents;
    }
}