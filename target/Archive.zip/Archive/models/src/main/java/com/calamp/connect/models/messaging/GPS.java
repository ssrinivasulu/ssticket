package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "gps")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("gps")
@JsonTypeName("gps")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "address", "carrier", "hdop", "heading", "latitude", "longitude", "odometer", "rssi", "satellites", "speed", "gpsValidity" })
@JsonPropertyOrder({ "address", "carrier", "hdop", "heading", "latitude", "longitude", "odometer", "rssi", "satellites", "speed", "gpsValidity" })
public class GPS
{
    private Integer carrier;
    private Boolean gpsValidity;
    private Double  hdop;
    private Integer heading;
    private Double  latitude;
    private Double  longitude;
    private Double  odometer;
    private Integer rssi;
    private Integer satellites;
    @JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
    private Address address;
    private Integer speed;

    public Integer getCarrier()
    {
        return carrier;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public Double getOdometer()
    {
        return odometer;
    }

    public Integer getRssi()
    {
        return rssi;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public Boolean getGpsValidity()
    {
        return gpsValidity;
    }

    public void setGpsValidity(Boolean gpsValidity)
    {
        this.gpsValidity = gpsValidity;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public void setOdometer(Double odometer)
    {
        this.odometer = odometer;
    }

    public void setRssi(Integer rssi)
    {
        this.rssi = rssi;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public Address getAddress()
    {
        return address;
    }

    public void setAddress(Address address)
    {
        this.address = address;
    }

    public Integer getSpeed()
    {
        return speed;
    }

    public void setSpeed(Integer speed)
    {
        this.speed = speed;
    }

}
