package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

/**
 * @author Sidlingappa
 *
 */
@XmlRootElement(name = "optionsExtension")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "optionsExtension")
@JsonRootName("optionsExtension")
@JsonTypeName("optionsExtension")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class OptionsExtension
{
    @XmlElement(name = "vin", nillable = true)
    private String vin;

    /**
     * @return string
     */
    public String getVin()
    {
        return vin;
    }

    /**
     * @param vIN
     */
    public void setVin(String vIN)
    {
        vin = vIN;
    }

}