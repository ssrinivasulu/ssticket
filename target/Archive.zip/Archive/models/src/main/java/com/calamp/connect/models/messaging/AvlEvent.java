package com.calamp.connect.models.messaging;

import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.calamp.focis.framework.search.Queryable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "avlEvent")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("avlEvent")
@JsonTypeName("avlEvent")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
@XmlType(propOrder = { "deviceId", "deviceAirId", "deviceEsn", "messageUuid", "accountId", "accountName", "asset", "assetName", "assetId",
        "eventTime", "eventType", "gps", "telemetry", "deviceName", "digitalInputs", "commState", "unitStatus", "rawAccumulators",
        "avlHardAccelEvent", "assetDeviceInformation", "speedEvent", "extendedAccumulatorValues", "vbusIndicators", "accumulators",
        "pegZonesCurrent", "pegZonesPrevious", "account", "deviceData", "deviceDataConverted", "deviceIp", "deviceMessageSequenceNumber",
        "eventCode", "inputs", "lmdirectMessageType", "messageReceivedTime", "messageType", "pegBehaviorId", "port", "primaryOperator", "operators",
        "operatorIds", "optionsExtension", "route", "routeId", "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
@JsonPropertyOrder({ "deviceId", "deviceAirId", "deviceEsn", "messageUuid", "accountId", "accountName", "asset", "assetName", "assetId", "eventTime",
        "eventType", "gps", "telemetry", "deviceName", "digitalInputs", "commState", "unitStatus", "rawAccumulators", "avlHardAccelEvent",
        "assetDeviceInformation", "speedEvent", "extendedAccumulatorValues", "vbusIndicators", "accumulators", "pegZonesCurrent", "pegZonesPrevious",
        "account", "deviceData", "deviceDataConverted", "deviceIp", "deviceMessageSequenceNumber", "eventCode", "inputs", "lmdirectMessageType",
        "messageReceivedTime", "messageType", "pegBehaviorId", "port", "primaryOperator", "operators", "operatorIds", "optionsExtension",  "route", "routeId",
        "rawDeviceHexMessage", "timeOfFix", "vin", "vinResponse" })
public class AvlEvent extends DeviceEvent
{
    private CommState                 commState;
    private DigitalInputs             digitalInputs;
    private String                    eventType;
    private GPS                       gps;
    private Telemetry                 telemetry;
    private UnitStatus                unitStatus;
    private Map<String, Long>         rawAccumulators;
    private AvlHardAccelEvent         avlHardAccelEvent;
    private AssetDeviceInformation    assetDeviceInformation;
    private SpeedEvent                speedEvent;
    private ExtendedAccumulatorValues extendedAccumulatorValues;
    private VbusIndicators            vbusIndicators;
    private Map<String, String>       accumulators;
    private String                    pegZonesCurrent;
    private String                    pegZonesPrevious;
    private AvlDeviceData             deviceData;
    private AvlDeviceData             deviceDataConverted;

    @XmlElement
    public CommState getCommState()
    {
        return commState;
    }

    @XmlElement
    public DigitalInputs getDigitalInputs()
    {
        return digitalInputs;
    }

    @XmlElement
    @Queryable(modelProperty = "eventType", domainProperty = "eventLabel", domainPropertyType = String.class)
    public String getEventType()
    {
        return eventType;
    }

    @XmlElement
    @Queryable(modelProperty = "eventCode", domainProperty = "eventCode", domainPropertyType = Integer.class)
    public Integer getEventCode()
    {
        return super.getEventCode();
    }

    @XmlElement
    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public GPS getGps()
    {
        return gps;
    }

    @XmlElement
    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public Telemetry getTelemetry()
    {
        return telemetry;
    }

    @XmlElement
    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    @XmlElement
    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public AvlHardAccelEvent getAvlHardAccelEvent()
    {
        return avlHardAccelEvent;
    }

    @XmlElement
    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public AssetDeviceInformation getAssetDeviceInformation()
    {
        return assetDeviceInformation;
    }

    @XmlElement
    public SpeedEvent getSpeedEvent()
    {
        return speedEvent;
    }

    @XmlElement
    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public ExtendedAccumulatorValues getExtendedAccumulatorValues()
    {
        return extendedAccumulatorValues;
    }

    @XmlElement
    public VbusIndicators getVbusIndicators()
    {
        return vbusIndicators;
    }

    public void setCommState(CommState commState)
    {
        this.commState = commState;
    }

    public void setDigitalInputs(DigitalInputs digitalInputs)
    {
        this.digitalInputs = digitalInputs;
    }

    public void setEventType(String eventType)
    {
        this.eventType = eventType;
    }

    public void setEventCode(Integer eventCode)
    {
        super.setEventCode(eventCode);
    }

    public void setGps(GPS gps)
    {
        this.gps = gps;
    }

    public void setTelemetry(Telemetry telemetry)
    {
        this.telemetry = telemetry;
    }

    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public Map<String, Long> getRawAccumulators()
    {
        return rawAccumulators;
    }

    public void setRawAccumulators(Map<String, Long> rawAccumulators)
    {
        this.rawAccumulators = rawAccumulators;
    }

    public void setAvlHardAccelEvent(AvlHardAccelEvent avlHardAccelEvent)
    {
        this.avlHardAccelEvent = avlHardAccelEvent;
    }

    public void setAssetDeviceInformation(AssetDeviceInformation assetDeviceInformation)
    {
        this.assetDeviceInformation = assetDeviceInformation;
    }

    public void setSpeedEvent(SpeedEvent speedEvent)
    {
        this.speedEvent = speedEvent;
    }

    public void setExtendedAccumulatorValues(ExtendedAccumulatorValues extendedAccumulatorValues)
    {
        this.extendedAccumulatorValues = extendedAccumulatorValues;
    }

    public void setVbusIndicators(VbusIndicators vbusIndicators)
    {
        this.vbusIndicators = vbusIndicators;
    }

    @ApiModelProperty(hidden = true, value = "<b>This field is applicable for V1 API's only.</b>")
    public Map<String, String> getAccumulators()
    {
        return accumulators;
    }

    public void setAccumulators(Map<String, String> accumulators)
    {
        this.accumulators = accumulators;
    }

    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public String getPegZonesCurrent()
    {
        return pegZonesCurrent;
    }

    public void setPegZonesCurrent(String pegZonesCurrent)
    {
        this.pegZonesCurrent = pegZonesCurrent;
    }

    @ApiModelProperty(value = "<b>This field is applicable for V1 API's only.</b>")
    public String getPegZonesPrevious()
    {
        return pegZonesPrevious;
    }

    public void setPegZonesPrevious(String pegZonesPrevious)
    {
        this.pegZonesPrevious = pegZonesPrevious;
    }

    @ApiModelProperty(hidden = true, value = "<b>This is internal field. Won't display in response</b>")
    public AvlDeviceData getDeviceData()
    {
        return (AvlDeviceData) super.getDeviceData();
    }

    public void setDeviceData(AvlDeviceData deviceData)
    {
        super.setDeviceData(deviceData);
    }

    public AvlDeviceData getDeviceDataConverted()
    {
        return (AvlDeviceData) super.getDeviceDataConverted();
    }

    public void setDeviceDataConverted(AvlDeviceData deviceDataConverted)
    {
        super.setDeviceDataConverted(deviceDataConverted);
    }

}
