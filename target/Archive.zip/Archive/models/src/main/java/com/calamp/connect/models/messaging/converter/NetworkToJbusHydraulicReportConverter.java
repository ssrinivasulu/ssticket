package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusHydraulicReportData;
import com.calamp.connect.models.messaging.JbusHydraulicReportEventV2;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component
public class NetworkToJbusHydraulicReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusHydraulicReportConverter.class);

    public JbusHydraulicReportEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusHydraulicReportEventV2 jbusHydraulicReportEvent = mapper.map(network, JbusHydraulicReportEventV2.class);
        JbusHydraulicReportData jbusHydraulicReportData = mapper.map(network, JbusHydraulicReportData.class);
        jbusHydraulicReportEvent.setDeviceData(jbusHydraulicReportData);
        jbusHydraulicReportEvent.setDeviceDataConverted(new JbusHydraulicReportData());
        jbusHydraulicReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        logger.debug("NetworkToJbusHydraulicReportConverter completed");
        return jbusHydraulicReportEvent;
    }

}
