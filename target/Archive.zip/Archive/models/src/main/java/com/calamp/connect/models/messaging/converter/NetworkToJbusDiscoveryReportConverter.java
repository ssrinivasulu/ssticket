package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDiscoveryReportEvent;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component
public class NetworkToJbusDiscoveryReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusDiscoveryReportConverter.class);

    public JbusDiscoveryReportEvent convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusDiscoveryReportEvent jbusDiscoveryReportEvent = mapper.map(network, JbusDiscoveryReportEvent.class);
        jbusDiscoveryReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        logger.debug("NetworkToJbusDiscoveryReportConverter completed");
        return jbusDiscoveryReportEvent;
    }

}
