package com.calamp.connect.models.messaging.converter;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.IdReportDeviceData;
import com.calamp.connect.models.messaging.IdReportEvent;
import com.calamp.connect.models.messaging.IdReportEventUtil;
import com.calamp.connect.models.messaging.RouterModem;
import com.calamp.connect.models.network.Network.NetworkMessage;

/**
 * @author xwei
 *
 */
@Component("networkToIdReportMesssageConverter")
public class NetworkToIdReportMesssageConverter extends GenericNetworkToDeviceEventConverter
{   
	private static final String LATITUDE_LONGITUDE_KEY = "LATLON";
	
	public IdReportEvent convert(NetworkMessage network)
    {
        IdReportEvent event = mapperFactory.getMapperFacade().map(network, IdReportEvent.class);
        String extension = event.getExtension();
        if(extension == null)
        	return event;
        
        Map<String, String> extensionMap = IdReportEventUtil.parseExtensionStr(extension);
        if(extensionMap.containsKey(LATITUDE_LONGITUDE_KEY))
        {
        	String[] latlon = extensionMap.get(LATITUDE_LONGITUDE_KEY).split(",");
        	if(latlon.length > 0)
        		event.setLatitude(Double.valueOf(latlon[0]));
        	if(latlon.length > 1)
        		event.setLongitude(Double.valueOf(latlon[1]));
        }
        	
        List<RouterModem> modems = IdReportEventUtil.parseModemInfo(extensionMap);
        if(modems == null)
        	return event;
        
        IdReportDeviceData deviceData = new IdReportDeviceData();
        deviceData.setResourceRevisions(extensionMap.get("RREV"));
        deviceData.setFirmwareVersion(extensionMap.get("FVER"));
        if(modems.size() > 0) {
        	deviceData.setModems(modems);
        }
        event.setDeviceData(deviceData);
        return event;
    }

}
