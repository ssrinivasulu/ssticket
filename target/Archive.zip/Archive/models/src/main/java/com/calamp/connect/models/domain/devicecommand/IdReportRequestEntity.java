package com.calamp.connect.models.domain.devicecommand;

public class IdReportRequestEntity extends DeviceCommandMessageRequestEntity
{
    @Override
    public String toString()
    {
        return "IdReportRequest{" + super.toString() + '}';
    }
}
