package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * @author Abhijit
 *
 */
@XmlRootElement(name = "aempData")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("aempData")
@JsonTypeName("aempData")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
public class AempData
{
    private long                     accountId;
    private EquipmentHeader          equipmentHeader;
    private Location                 location;
    private CumulativeOperatingHours cumulativeOperatingHours;
    private Distance                 distance;
    private FuelUsed                 fuelUsed;
    private FuelUsedLast24           fuelUsedLast24;

    public long getAccountId()
    {
        return accountId;
    }

    public void setAccountId(long accountId)
    {
        this.accountId = accountId;
    }

    public EquipmentHeader getEquipmentHeader()
    {
        return equipmentHeader;
    }

    public void setEquipmentHeader(EquipmentHeader equipmentHeader)
    {
        this.equipmentHeader = equipmentHeader;
    }

    public Location getLocation()
    {
        return location;
    }

    public void setLocation(Location location)
    {
        this.location = location;
    }

    public CumulativeOperatingHours getCumulativeOperatingHours()
    {
        return cumulativeOperatingHours;
    }

    public void setCumulativeOperatingHours(CumulativeOperatingHours cumulativeOperatingHours)
    {
        this.cumulativeOperatingHours = cumulativeOperatingHours;
    }

    public Distance getDistance()
    {
        return distance;
    }

    public void setDistance(Distance distance)
    {
        this.distance = distance;
    }

    public FuelUsed getFuelUsed()
    {
        return fuelUsed;
    }

    public void setFuelUsed(FuelUsed fuelUsed)
    {
        this.fuelUsed = fuelUsed;
    }

    public FuelUsedLast24 getFuelUsedLast24()
    {
        return fuelUsedLast24;
    }

    public void setFuelUsedLast24(FuelUsedLast24 fuelUsedLast24)
    {
        this.fuelUsedLast24 = fuelUsedLast24;
    }

    @Override
    public String toString()
    {
        return "AempData : {accountId:" + accountId + ", equipmentHeader:" + equipmentHeader + ", location:" + location
                + ", cumulativeOperatingHours:" + cumulativeOperatingHours + ", distance:" + distance + ", fuelUsed:" + fuelUsed
                + ", fuelUsedLast24:" + fuelUsedLast24 + "}";
    }
}
