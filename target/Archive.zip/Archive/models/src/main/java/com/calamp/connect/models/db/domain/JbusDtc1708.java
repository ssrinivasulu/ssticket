package com.calamp.connect.models.db.domain;

/**
 * Created by agamulo on 6/4/15.
 */
public class JbusDtc1708 {
    private Integer fmi;
    private Integer oc;
    private Integer pid;
    private Boolean csf;
    private Boolean dct;
    private Boolean lci;

    public Integer getFmi() {
        return fmi;
    }

    public void setFmi(Integer fmi) {
        this.fmi = fmi;
    }

    public Integer getOc() {
        return oc;
    }

    public void setOc(Integer oc) {
        this.oc = oc;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Boolean isCsf() {
        return csf;
    }

    public void setCsf(Boolean csf) {
        this.csf = csf;
    }

    public Boolean isDct() {
        return dct;
    }

    public void setDct(Boolean dct) {
        this.dct = dct;
    }

    public Boolean isLci() {
        return lci;
    }

    public void setLci(Boolean lci) {
        this.lci = lci;
    }
}
