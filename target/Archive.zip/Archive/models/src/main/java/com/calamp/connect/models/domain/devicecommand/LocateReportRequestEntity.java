package com.calamp.connect.models.domain.devicecommand;

import com.fasterxml.jackson.annotation.JsonCreator;

public class LocateReportRequestEntity extends DeviceCommandMessageRequestEntity
{
    private Integer numberOfAccumulators;

    @JsonCreator
    public LocateReportRequestEntity() {}

    @Override
    public boolean equals(Object o)
    {
        if (this == o){
            return true;
        }

        if ((o == null) || (getClass() != o.getClass())){
            return false;
        }

        if (!super.equals(o)){
            return false;
        }

        LocateReportRequestEntity that = (LocateReportRequestEntity) o;

        if ((numberOfAccumulators != null)
            ? !numberOfAccumulators.equals(that.numberOfAccumulators)
            : that.numberOfAccumulators != null){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = super.hashCode();

        result = 31 * result + ((numberOfAccumulators != null)
                                ? numberOfAccumulators.hashCode()
                                : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "LocateReportRequest{" + "numberOfAccumulators=" + numberOfAccumulators + '}';
    }

    public Integer getNumberOfAccumulators()
    {
        return numberOfAccumulators;
    }

    public void setNumberOfAccumulators(Integer numberOfAccumulators)
    {
        this.numberOfAccumulators = numberOfAccumulators;
    }
}
