package com.calamp.connect.models.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * <p>Java class for JBUSDTCMessage complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="JBUSDTCMessage"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SPN" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="FMI" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="OC" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;any processContents='skip' maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 *
 */
@XmlRootElement(name = "jbusDtc1939Protocol")
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonRootName("jbusDtc1939Protocol")
@JsonTypeName("jbusDtc1939Protocol")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    include   = As.WRAPPER_OBJECT,
    use       = Id.NAME
)
@JsonPropertyOrder(
{
 "fmi", "oc", "spn"
})
@XmlType(
    name      = "jbusDtc1939Protocol",
    propOrder =
    {
 "fmi", "oc", "spn"
    }
)
public class JbusDtc1939Protocol 
{
    private Integer fmi;
    private Integer oc;
    private Integer spn;

    @XmlElement
    public Integer getFmi()
    {
        return fmi;
    }

    @XmlElement
    public Integer getOc()
    {
        return oc;
    }

    @XmlElement
    public Integer getSpn()
    {
        return spn;
    }

    public void setFmi(Integer value)
    {
        this.fmi = value;
    }

    public void setOc(Integer value)
    {
        this.oc = value;
    }

    public void setSpn(Integer value)
    {
        this.spn = value;
    }
}
