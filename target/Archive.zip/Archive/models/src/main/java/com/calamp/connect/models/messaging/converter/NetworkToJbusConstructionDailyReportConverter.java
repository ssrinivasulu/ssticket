package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionDailyReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEventV2;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component
public class NetworkToJbusConstructionDailyReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusConstructionDailyReportConverter.class);

    public JbusConstructionDailyReportEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionDailyReportEventV2 jbusConstructionDailyReportEvent = mapper.map(network, JbusConstructionDailyReportEventV2.class);
        JbusConstructionDailyReportData jbusConstruncationDailyReportData = mapper.map(network, JbusConstructionDailyReportData.class);
        jbusConstructionDailyReportEvent.setDeviceData(jbusConstruncationDailyReportData);
        jbusConstructionDailyReportEvent.setDeviceDataConverted(new JbusConstructionDailyReportData());
        jbusConstructionDailyReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusConstructionDailyReportEvent;
    }

}
