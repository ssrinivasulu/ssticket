package com.calamp.connect.models.messaging.devicecommand;

public enum DeviceCommandType
{
    LocateReport, PegAction, SetAndEnableZone, SetGeoZone, IdReport, ParameterRead, ParameterWrite, Reboot, OtaDownload, UnitRequest
}
