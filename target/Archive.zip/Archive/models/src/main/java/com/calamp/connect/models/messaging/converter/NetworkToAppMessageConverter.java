package com.calamp.connect.models.messaging.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Accumulator;
import com.calamp.connect.models.messaging.AppMessage;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component("networkToAppMesssageConverter")
public class NetworkToAppMessageConverter extends GenericNetworkToDeviceEventConverter{
	public AppMessage convert(NetworkMessage network)
	{
		MapperFacade mapper = mapperFactory.getMapperFacade();
        AppMessage appMessage = mapper.map(network, AppMessage.class);;
        if(network.getMessageDetail() != null){
        	appMessage.setEventTime(new Date(network.getMessageDetail().getLocationTime()));
        	appMessage.setEventCode(network.getMessageDetail().getEventCode());
        }
        if(appMessage.getEventTime() == null)
        {
        	//missing header, give current time for searches - fix status will be false
        	appMessage.setEventTime(new Date());
        }
        
        if(network.getRawJbusMessage() != null) {
        	appMessage.setAppMessageType(network.getRawJbusMessage().getJbusMessageType());
        	if(network.getRawJbusMessage().getUnknownReportRaw() != null){
        		appMessage.setAppMessageMessage(network.getRawJbusMessage().getUnknownReportRaw().getMessage());
        	}
        }
        
        
        if (network.getRawAccumulators() != null)
        {
            List<Accumulator> rawAccumulators = new ArrayList<Accumulator>(network.getRawAccumulators().size());
            int i = 0;
            for (Long rawAccumulator : network.getRawAccumulators())
            {
                if (rawAccumulator != -1)
                {
                    Accumulator acc = new Accumulator();
                    acc.setLabel("Accumulator " + i);
                    acc.setIndex(String.valueOf(i));
                    acc.setValue(String.valueOf(rawAccumulator));
                    rawAccumulators.add(acc);
                }
                i = i + 1;
            }
            AvlDeviceData deviceData = new AvlDeviceData();
            deviceData.setAccumulators(rawAccumulators);

            HeaderData headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getRssi()));
            deviceData.setRssi(headerData);

            headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getAltitude()));
            deviceData.setAltitude(headerData);

            headerData = new HeaderData();
            if(network.getMessageDetail() != null && network.getMessageDetail().getSpeed() != null){
            	headerData.setValue(String.valueOf(network.getMessageDetail().getSpeed()));
            } else if(network.getMessageDetail().getMiniSpeed() !=null){
            	//kp/h to cm/s
            	headerData.setValue(String.valueOf((int) (network.getMessageDetail().getMiniSpeed()*1000/36)));
            } else {
            	headerData.setValue("0");
            }
            deviceData.setGpsSpeed(headerData);

            appMessage.setDeviceData(deviceData);
            AvlDeviceData deviceDataConverted = new AvlDeviceData();
            deviceDataConverted.setAccumulators(rawAccumulators);
            appMessage.setDeviceDataConverted(deviceDataConverted);
        }

        
        return appMessage;
		
		
	}
}
