package com.calamp.connect.models.messaging;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.springframework.core.convert.converter.Converter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.ResourceSupport;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * @author ssrinivasulu
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonRootName("response")
@JsonPropertyOrder({ "counts", "errors", "results", "searchableProperties", "sort", "totalPages", "numberOfElements", "totalElements", "firstPage",
        "lastPage", "links" })
@JsonIgnoreProperties(ignoreUnknown = true, value = { "content" })
@XmlRootElement(name = "response")
@XmlType(namespace = com.calamp.focis.framework.hateoas.Link.CALAMP_SERVICES_NS)
@XmlAccessorType(XmlAccessType.PUBLIC_MEMBER)
@JsonTypeName("response")
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NAME)
public class Response<M> extends ResourceSupport implements Page<M>
{
    private final List<String>        errors               = new ArrayList<>();
    private final List<M>             results              = new ArrayList<>();
    private final Map<String, String> searchableProperties = new HashMap<String, String>();

    private M                         counts;
    @JsonIgnore
    private final Page<M>             page;

    public void addErrors(String... errors)
    {
        if ((errors == null) || (errors.length == 0))
            return;

        for (String s : errors)
            this.errors.add(s);
    }

    @SafeVarargs
    public final void addResults(M... results)
    {
        if ((results == null) || (results.length == 0))
            return;

        for (M r : results)
            this.results.add(r);
    }

    public final void addResults(List<M> results)
    {
        this.results.addAll(results);
    }

    public final void setCounts(M counts)
    {
        this.counts = counts;
    }

    @XmlElementWrapper(name = "errors")
    @XmlElements({ @XmlElement(name = "error", type = String.class) })
    @JsonProperty(value = "errors")
    public List<String> getErrors()
    {
        return errors;
    }

    @JsonProperty("results")
    @JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
    @XmlElementWrapper(name = "results")
    public List<M> getResults()
    {
        return results;
    }

    @JsonProperty("counts")
    @JsonTypeInfo(use = Id.NONE, include = As.WRAPPER_OBJECT)
    @XmlElement
    public M getCounts()
    {
        return counts;
    }

    @JsonProperty("searchableProperties")
    @JsonInclude(Include.NON_EMPTY)
    @XmlElement(name = "searchableProperties", type = Map.class)
    public Map<String, String> getSearchableProperties()
    {
        return searchableProperties;
    }

    public void setSearchableProperties(Map<String, String> searchMap)
    {
        searchableProperties.clear();
        if (searchMap != null && !searchMap.isEmpty())
            searchableProperties.putAll(searchMap);
    }

    // Dp jaxb need no-arg default constructor.
    public Response()
    {
        super();
        // if page is null all getter will throw null pointer error
        this.page = new PageImpl<M>(new ArrayList<M>());
    }

    public Response(M m)
    {
        super();
        // if page is null all getter will throw null pointer error
        this.page = new PageImpl<M>(new ArrayList<M>());
        this.addResults(m);
    }

    public Response(Page<M> page, String pageParam, String sizeParam, String basePath)
    {
        super();
        this.page = page;
        this.addResults(page.getContent());

        if (page.hasPrevious())
        {
            String path = createBuilder().replaceQueryParam(pageParam, page.getNumber()).replaceQueryParam(sizeParam, page.getSize()).build()
                    .toUriString();
            path = basePath + path.substring(path.indexOf("/results"), path.length());
            Link link = new Link(path, Link.REL_PREVIOUS);
            add(link);
        }
        if (page.hasNext())
        {
            String path = createBuilder().replaceQueryParam(pageParam, page.getNumber() + 2).replaceQueryParam(sizeParam, page.getSize()).build()
                    .toUriString();
            path = basePath + path.substring(path.indexOf("/results"), path.length());
            Link link = new Link(path, Link.REL_NEXT);
            add(link);
        }

        Link link = buildPageLink(pageParam, 1, sizeParam, page.getSize(), Link.REL_FIRST, basePath);
        add(link);

        int indexOfLastPage = page.getTotalPages();
        link = buildPageLink(pageParam, indexOfLastPage, sizeParam, page.getSize(), Link.REL_LAST, basePath);
        add(link);

        link = buildPageLink(pageParam, page.getNumber() + 1, sizeParam, page.getSize(), Link.REL_SELF, basePath);
        add(link);
    }

    protected ServletUriComponentsBuilder createBuilder()
    {
        return ServletUriComponentsBuilder.fromCurrentRequest();
    }

    private Link buildPageLink(String pageParam, int page, String sizeParam, int size, String rel, String basePath)
    {
        String path = createBuilder().replaceQueryParam(pageParam, page).replaceQueryParam(sizeParam, size).build().toUriString();
        path = basePath + path.substring(path.indexOf("/results"), path.length());
        Link link = new Link(path, rel);
        return link;
    }

    @JsonIgnore
    @Override
    public int getNumber()
    {
        return page.getNumber();
    }

    @JsonIgnore
    @Override
    public int getSize()
    {
        return page.getSize();
    }

    @Override
    public int getTotalPages()
    {
        return page.getTotalPages();
    }

    @Override
    public int getNumberOfElements()
    {
        return page.getNumberOfElements();
    }

    @Override
    public long getTotalElements()
    {
        return page.getTotalElements();
    }

    @Override
    public Iterator<M> iterator()
    {
        return page.iterator();
    }

    @Override
    public List<M> getContent()
    {
        return page.getContent();
    }

    @Override
    public boolean hasContent()
    {
        return page.hasContent();
    }

    @Override
    public Sort getSort()
    {
        return page.getSort();
    }

    @Override
    public boolean isFirst()
    {
        return page.isFirst();
    }

    @Override
    public boolean isLast()
    {
        return page.isLast();
    }

    @Override
    public boolean hasNext()
    {
        return page.hasNext();
    }

    @Override
    public boolean hasPrevious()
    {
        return page.hasPrevious();
    }

    @Override
    public Pageable nextPageable()
    {
        return page.nextPageable();
    }

    @Override
    public Pageable previousPageable()
    {
        return page.previousPageable();
    }

    @Override
    public <S> Page<S> map(Converter<? super M, ? extends S> converter)
    {
        // TODO Auto-generated method stub
        return null;
    }

}
