package com.calamp.connect.models.domain.devicecommand;

import com.calamp.connect.models.messaging.GeoZoneType;


public class GeoZoneInformationEntity
{
    Integer     distanceEast;
    Integer     distanceNorth;
    Integer     hysteresis;
    Double      latitude;
    Double      longitude;
    GeoZoneType type;
    Integer     zoneId;

    public Integer getDistanceEast()
    {
        return distanceEast;
    }

    public Integer getDistanceNorth()
    {
        return distanceNorth;
    }

    public Integer getHysteresis()
    {
        return hysteresis;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public GeoZoneType getType()
    {
        return type;
    }

    public Integer getZoneId()
    {
        return zoneId;
    }

    public void setDistanceEast(Integer distanceEast)
    {
        this.distanceEast = distanceEast;
    }

    public void setDistanceNorth(Integer distanceNorth)
    {
        this.distanceNorth = distanceNorth;
    }

    public void setHysteresis(Integer hysteresis)
    {
        this.hysteresis = hysteresis;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public void setType(GeoZoneType type)
    {
        this.type = type;
    }

    public void setZoneId(Integer zoneId)
    {
        this.zoneId = zoneId;
    }
}
