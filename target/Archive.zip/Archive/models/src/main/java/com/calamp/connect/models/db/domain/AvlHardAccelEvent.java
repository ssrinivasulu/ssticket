package com.calamp.connect.models.db.domain;

import org.springframework.data.mongodb.core.mapping.Document;

import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelCalibrationType;
import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelEventType;

/*
 * message AvlHardAccelEvent {
    enum AvlHardAccelEventType {DECEL=0; ACCEL=1; LATERAL_LEFT=2; LATERAL_RIGHT=3;}
    required AvlHardAccelEventType accelerationType = 1;
    required int32 lateralAcceleration = 2;    //these are in g * 1000   to get G's divide by 1000
    required int32 longitudinalAcceleration = 3; //these are in g * 1000   to get G's divide by 1000
    repeated AvlHardAccelPoint accelerationPoints = 4;
}*/

@Document
public class AvlHardAccelEvent {
	private AvlHardAccelEventType accelerationType;
	private Float lateralAcceleration;
	private Float longitudinalAcceleration;		
	private Float accelerationDuration;
	private Float startingSpeed;
	private AvlHardAccelCalibrationType calibrationType;
	
	public AvlHardAccelEventType getAccelerationType() {
		return accelerationType;
	}
	public void setAccelerationType(AvlHardAccelEventType accelerationType) {
		this.accelerationType = accelerationType;
	}
	public Float getLateralAcceleration() {
		return lateralAcceleration;
	}
	public void setLateralAcceleration(Float lateralAcceleration) {
		this.lateralAcceleration = lateralAcceleration;
	}
	public Float getLongitudinalAcceleration() {
		return longitudinalAcceleration;
	}
	public void setLongitudinalAcceleration(Float longitudinalAcceleration) {
		this.longitudinalAcceleration = longitudinalAcceleration;
	}

	// Proto stores accelerations as G*1000, convert and store in G-units. 
	// Proto has mph * 10
	public static AvlHardAccelEvent fromProto(com.calamp.connect.models.network.Network.AvlHardAccelEvent avlHardAccelEventProto) {
		AvlHardAccelEvent avlHardAccelEvent = new AvlHardAccelEvent();
		
		if (avlHardAccelEventProto.getAccelerationType()!=null)
			avlHardAccelEvent.setAccelerationType(avlHardAccelEventProto.getAccelerationType());
        if (avlHardAccelEventProto.getLateralAcceleration()>=0)
        	avlHardAccelEvent.setLateralAcceleration((float)avlHardAccelEventProto.getLateralAcceleration() / 1000F);
        if (avlHardAccelEventProto.getLongitudinalAcceleration()>=0)
        	avlHardAccelEvent.setLongitudinalAcceleration((float)avlHardAccelEventProto.getLongitudinalAcceleration() / 1000F);
        if (avlHardAccelEventProto.getAccelerationDuration()>=0)
        	avlHardAccelEvent.setAccelerationDuration((float)avlHardAccelEventProto.getAccelerationDuration() / 1000F); // Convert from MS to float seconds
        if (avlHardAccelEventProto.getStartingSpeed()>=0)
        	avlHardAccelEvent.setStartingSpeed((float)avlHardAccelEventProto.getStartingSpeed());
        if (avlHardAccelEventProto.getCalibrationState()!=null)
        	avlHardAccelEvent.setCalibrationType(avlHardAccelEventProto.getCalibrationState());
        
		return avlHardAccelEvent;
	}
	public Float getAccelerationDuration() {
		return accelerationDuration;
	}
	public void setAccelerationDuration(Float accelerationDuration) {
		this.accelerationDuration = accelerationDuration;
	}
	public Float getStartingSpeed() {
		return startingSpeed;
	}
	public void setStartingSpeed(Float startingSpeed) {
		this.startingSpeed = startingSpeed;
	}
	public AvlHardAccelCalibrationType getCalibrationType() {
		return calibrationType;
	}
	public void setCalibrationType(AvlHardAccelCalibrationType calibrationType) {
		this.calibrationType = calibrationType;
	}
	
}
