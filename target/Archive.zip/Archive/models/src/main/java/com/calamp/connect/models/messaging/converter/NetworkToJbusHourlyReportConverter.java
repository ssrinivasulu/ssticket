package com.calamp.connect.models.messaging.converter;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusHourlyReportData;
import com.calamp.connect.models.messaging.JbusHourlyReportEventV2;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component
public class NetworkToJbusHourlyReportConverter extends GenericNetworkToDeviceEventConverter
{
    private Logger logger = LoggerFactory.getLogger(NetworkToJbusHourlyReportConverter.class);

    public JbusHourlyReportEventV2 convert(NetworkMessage network)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusHourlyReportEventV2 jbusHourlyReportEvent = mapper.map(network, JbusHourlyReportEventV2.class);
        JbusHourlyReportData jbusHourlyReportData = mapper.map(network, JbusHourlyReportData.class);
        jbusHourlyReportEvent.setDeviceData(jbusHourlyReportData);
        jbusHourlyReportEvent.setDeviceDataConverted(new JbusHourlyReportData());
        jbusHourlyReportEvent.setEventTime(new Date(network.getRawJbusMessage().getLocationTime()));
        return jbusHourlyReportEvent;
    }

}
