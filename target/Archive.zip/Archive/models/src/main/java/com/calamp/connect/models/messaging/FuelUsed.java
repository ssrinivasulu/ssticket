package com.calamp.connect.models.messaging;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "fuelUsed")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fuelUsed")
@JsonRootName("fuelUsed")
@JsonTypeName("fuelUsed")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class FuelUsed
{
    @XmlAttribute(name = "datetime")
    private Date               datetime;
    @XmlElement(name = "FuelUnits", type = String.class)
    private String             fuelUnits;
    @XmlElement(name = "FuelConsumed", type = Double.class)
    private Double             fuelConsumed;
    public static final String JSON_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    @JsonFormat(shape = Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getDatetime()
    {
        return datetime;
    }

    public void setDatetime(Date datetime)
    {
        this.datetime = datetime;
    }

    public String getFuelUnits()
    {
        return fuelUnits;
    }

    public void setFuelUnits(String fuelUnits)
    {
        this.fuelUnits = fuelUnits;
    }

    public Double getFuelConsumed()
    {
        return fuelConsumed;
    }

    public void setFuelConsumed(Double fuelConsumed)
    {
        this.fuelConsumed = fuelConsumed;
    }

    @Override
    public String toString()
    {
        return "FuelUsed : {datetime:" + datetime + ", fuelUnits:" + fuelUnits + ", fuelConsumed:" + fuelConsumed + "}";
    }
}
