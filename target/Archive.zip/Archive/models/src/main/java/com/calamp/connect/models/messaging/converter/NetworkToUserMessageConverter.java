package com.calamp.connect.models.messaging.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Accumulator;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.UserMessage;
import com.calamp.connect.models.messaging.UserMessageContainer;
import com.calamp.connect.models.network.Network.NetworkMessage;

import ma.glasnost.orika.MapperFacade;

@Component("networkToUserMesssageConverter")
public class NetworkToUserMessageConverter extends GenericNetworkToDeviceEventConverter {
	public UserMessage convert(NetworkMessage network)
	{
		MapperFacade mapper = mapperFactory.getMapperFacade();
        UserMessage userMessage = mapper.map(network, UserMessage.class);;
        if(network.getMessageDetail() != null){
        	userMessage.setEventTime(new Date(network.getMessageDetail().getLocationTime()));
        	userMessage.setEventCode(network.getMessageDetail().getEventCode());
        } 
        
        if(network.getPndMessage() != null) {
        	UserMessageContainer messageContainer = new UserMessageContainer();
        	messageContainer.setUserMessageId(network.getPndMessage().getUserMessageId());
        	messageContainer.setUserMessage(network.getPndMessage().getUserMessage());
        	messageContainer.setUserMessageRoute(network.getPndMessage().getUserMessageRoute());
        	userMessage.setUserMessageContainer(messageContainer);
        }
        
        
        if (network.getRawAccumulators() != null)
        {
            List<Accumulator> rawAccumulators = new ArrayList<Accumulator>(network.getRawAccumulators().size());
            int i = 0;
            for (Long rawAccumulator : network.getRawAccumulators())
            {
                if (rawAccumulator != -1)
                {
                    Accumulator acc = new Accumulator();
                    acc.setLabel("Accumulator " + i);
                    acc.setIndex(String.valueOf(i));
                    acc.setValue(String.valueOf(rawAccumulator));
                    rawAccumulators.add(acc);
                }
                i = i + 1;
            }
            AvlDeviceData deviceData = new AvlDeviceData();
            deviceData.setAccumulators(rawAccumulators);

            HeaderData headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getRssi()));
            deviceData.setRssi(headerData);

            headerData = new HeaderData();
            headerData.setValue(String.valueOf(network.getMessageDetail().getAltitude()));
            deviceData.setAltitude(headerData);

            headerData = new HeaderData();
            if(network.getMessageDetail() != null && network.getMessageDetail().getSpeed() != null){
            	headerData.setValue(String.valueOf(network.getMessageDetail().getSpeed()));
            } else if(network.getMessageDetail().getMiniSpeed() !=null){
            	//kp/h to cm/s
            	headerData.setValue(String.valueOf((int) (network.getMessageDetail().getMiniSpeed()*1000/36)));
            } else {
            	headerData.setValue("0");
            }
            deviceData.setGpsSpeed(headerData);

            userMessage.setDeviceData(deviceData);
            AvlDeviceData deviceDataConverted = new AvlDeviceData();
            deviceDataConverted.setAccumulators(rawAccumulators);
            userMessage.setDeviceDataConverted(deviceDataConverted);
        }

        
        return userMessage;
		
		
	}
	
}
