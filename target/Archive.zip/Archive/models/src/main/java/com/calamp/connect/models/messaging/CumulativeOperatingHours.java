package com.calamp.connect.models.messaging;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

@XmlRootElement(name = "cumulativeOperatingHours")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cumulativeOperatingHours")
@JsonRootName("cumulativeOperatingHours")
@JsonTypeName("cumulativeOperatingHours")
@JsonInclude(Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(include = As.WRAPPER_OBJECT, use = Id.NONE)
public class CumulativeOperatingHours
{
    @XmlAttribute(name = "datetime")
    @XmlJavaTypeAdapter(value = DateAdapter.class, type = Date.class)
    private Date               datetime;
    @XmlElement(name = "Hour", nillable = true)
    private String             hour;
    public static final String JSON_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public CumulativeOperatingHours()
    {
    }

    @JsonFormat(shape = Shape.STRING, pattern = JSON_DATETIME_FORMAT)
    public Date getDatetime()
    {
        return datetime;
    }

    public void setDatetime(Date datetime)
    {
        this.datetime = datetime;
    }

    public String getHour()
    {
        return hour;
    }

    public void setHour(String hour)
    {
        this.hour = hour;
    }

    @Override
    public String toString()
    {
        return "CumulativeOperatingHours : {datetime:" + datetime + ", hour:" + hour + "}";
    }
}
