package com.calamp.connect.services.fmi.util;

import org.apache.commons.codec.binary.Hex;


/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class HexUtil
{
    /**
     * converts a String into a byte array
     *
     * @param javaString
     * @return
     */
    public static byte[] getHexByteArray(String javaString)
    {
        return javaString.getBytes();
    }

    /**
     * convert bytes into a String.
     * @param bytes
     * @return
     */
    public static String getStringFromHexByteArray(byte[] bytes)
    {
        if(bytes.length>0)
            return new String(bytes);
        else
            return null;
    }

    /**
     * converts a byte array to a string representation of the bytes in hex format
     * @param bytes bytes to convert
     * @return String representation of the bytes passed in.
     */
    public static String convertToHexString(byte[] bytes)
    {

        return new String(Hex.encodeHex(bytes));
    }

    /**
     * converts a String of hex into a byte array.
     * @param hexString  String to convert
     * @return byte array from the passed in hex string representation
     */
    public static byte[] convertFromHexString( String hexString ) {
        try
        {
            return Hex.decodeHex(hexString.toCharArray());
        }
        catch(Exception e)
        {
            throw new IllegalArgumentException(" there was a problem decoding the hex String",e);
        }
    }

}
