/**
 * 
 */
package com.calamp.connect.redismq.cmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.redismq.Application;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})
public class CSRDQueuePerformanceTestIT extends AbstractQueueCmdTest {
	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private ReceiveMessageCmd receiveMessageCmd;
	@Autowired
	private SendMessageCmd sendMessageCmd;
	@Autowired
	private DeleteMessageCmd deleteMessageCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	
	
	/*@Test
	public void initatePerformaceCreateSendMessageTesting(int numberOfSeconds){
		long t= System.currentTimeMillis();
		long end = t+numberOfSeconds*1000;
		while(System.currentTimeMillis() < end) {
		 
		}
	}*/
	
	@Test
	public void testDeleteMessage() {
		
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		queueDef.setMessage("Hello World");
		QueueMessage message = sendMessageCmd.exec(queueDef);
		assertNotNull(message.getId());

		queueDef.setUid(message.getId());
		int deleted = deleteMessageCmd.exec(queueDef);
		assertEquals(1, deleted);

		List<QueueMessage> msg = receiveMessageCmd.exec(queueDef);
		assertNull(msg);

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testDeleteMessage_noMessage() {
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);
		
		queueDef.setUid(NONEXISTING_ID);
		int deleted = deleteMessageCmd.exec(queueDef);
		assertEquals(0, deleted);

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testSendReceiveMessage() {

		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		queueDef.setMessage("Hello World");
		QueueMessage queueMessage = sendMessageCmd.exec(queueDef);
		assertNotNull(queueMessage.getId());

		List<QueueMessage> msg = receiveMessageCmd.exec(queueDef);
		assertNotNull(msg);

		assertEquals("Hello World", msg.get(0).getMessage());
		//assertEquals(new Long(1), msg.get(0).getReceivedCount());
		assertEquals(queueMessage.getId(), msg.get(0).getId());

		//deleteQueueCmd.qname(TEST_QNAME).exec();
	}
	
	
	@Test
	public void testSendReceiveResetVisibilityMessage() {

		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		queueDef.setMessage("Hello World");
		QueueMessage queueMessage = sendMessageCmd.exec(queueDef);
		assertNotNull(queueMessage.getId());
		
		//Receive will hide the message for 5 minutes
		List<QueueMessage> msg = receiveMessageCmd.exec(queueDef);
		assertNotNull(msg);
		
		//Reset Message visibility to make it as unread

		assertEquals("Hello World", msg.get(0).getMessage());
		//assertEquals(new Long(1), msg.get(0).getReceivedCount());
		assertEquals(queueMessage.getId(), msg.get(0).getId());

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testSendReceiveMessage_twoMessages() {
		
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		queueDef.setMessage("Hello World 1");
		QueueMessage queueMessage1 = sendMessageCmd.exec(queueDef);
		assertNotNull(queueMessage1.getId());

		queueDef.setMessage("Hello World 2");
		QueueMessage queueMessage2 = sendMessageCmd.exec(queueDef);
		assertNotNull(queueMessage2.getId());
		
		queueDef.setMessage("Hello World 3");
		QueueMessage queueMessage3 = sendMessageCmd.exec(queueDef);
		assertNotNull(queueMessage3.getId());
		
		queueDef.setMessage("Hello World 4");
		QueueMessage queueMessage4 = sendMessageCmd.exec(queueDef);
		assertNotNull(queueMessage4.getId());

		List<QueueMessage> msg1 = receiveMessageCmd.exec(queueDef);
		assertNotNull(msg1);

		assertEquals("Hello World 1", msg1.get(0).getMessage());
		assertEquals(new Long(1), msg1.get(0).getReceivedCount());
		assertEquals(queueMessage1.getId(), msg1.get(0).getId());

		List<QueueMessage>  msg2 = receiveMessageCmd.exec(queueDef);
		assertNotNull(msg2);

		assertEquals("Hello World 2", msg2.get(0).getMessage());
		assertEquals(new Long(1), msg2.get(0).getReceivedCount());
		assertEquals(queueMessage2.getId(), msg2.get(0).getId());
		
		List<QueueMessage>  msg3 = receiveMessageCmd.exec(queueDef);
		assertNotNull(msg3);
		assertEquals(new Long(1), msg3.get(0).getReceivedCount());
		assertEquals(queueMessage3.getId(), msg3.get(0).getId());

		assertTrue(msg1.get(0).getSentTime() <= msg2.get(0).getSentTime());

		deleteQueueCmd.exec(queueDef);
	}

	@Test
	public void testReceiveMessage_noMessage() {

		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		List<QueueMessage> msg = receiveMessageCmd.exec(queueDef);
		assertNull(msg);

		deleteQueueCmd.exec(queueDef);
	}


}
