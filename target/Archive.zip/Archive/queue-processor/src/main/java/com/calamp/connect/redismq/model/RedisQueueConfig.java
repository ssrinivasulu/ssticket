/**
 * 
 */
package com.calamp.connect.redismq.model;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.core.script.RedisScript;
import org.springframework.stereotype.Component;

/**
 * @author ssrinivasulu
 *
 */
@Component
@Profile({"default"})
public class RedisQueueConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(RedisQueueConfig.class);

	@Value("${redis.queue.namespace:'datapump'}")
	private String namespace;
	@Value("${redis.queue.redisns:'datapump:'}")
	private String redisns;
	
	@Autowired
	RedisScript<Long> clearMessageVisibilityScript;
	@Autowired
	RedisScript<Long> changeMessageVisibilityScript;
	@Autowired
	RedisScript<List> receiveMessageScript;
	@Autowired
	RedisScript<List> popMessageScript;
	
	
	/**
	 * @return the namespace
	 */
	public String getNamespace() {
		return namespace;
	}
	/**
	 * @return the redisns
	 */
	public String getRedisns() {
		return redisns;
	}
	/**
	 * @return the changeMessageVisibilityScript
	 */
	public RedisScript<Long> getChangeMessageVisibilityScript() {
		return changeMessageVisibilityScript;
	}
	/**
	 * @return the clearMessageVisibilityScript
	 */
	public RedisScript<Long> getClearMessageVisibilityScript() {
		return clearMessageVisibilityScript;
	}
	/**
	 * @param clearMessageVisibilityScript the clearMessageVisibilityScript to set
	 */
	public void setClearMessageVisibilityScript(RedisScript<Long> clearMessageVisibilityScript) {
		this.clearMessageVisibilityScript = clearMessageVisibilityScript;
	}
	/**
	 * @return the receiveMessageScript
	 */
	public RedisScript<List> getReceiveMessageScript() {
		return receiveMessageScript;
	}
	/**
	 * @return the popMessageScript
	 */
	public RedisScript<List> getPopMessageScript() {
		return popMessageScript;
	}
	/**
	 * @param namespace the namespace to set
	 */
	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
	/**
	 * @param redisns the redisns to set
	 */
	public void setRedisns(String redisns) {
		this.redisns = redisns;
	}
	/**
	 * @param changeMessageVisibilityScript the changeMessageVisibilityScript to set
	 */
	public void setChangeMessageVisibilityScript(RedisScript<Long> changeMessageVisibilityScript) {
		this.changeMessageVisibilityScript = changeMessageVisibilityScript;
	}
	/**
	 * @param receiveMessageScript the receiveMessageScript to set
	 */
	public void setReceiveMessageScript(RedisScript<List> receiveMessageScript) {
		this.receiveMessageScript = receiveMessageScript;
	}
	/**
	 * @param popMessageScript the popMessageScript to set
	 */
	public void setPopMessageScript(RedisScript<List> popMessageScript) {
		this.popMessageScript = popMessageScript;
	}
}
