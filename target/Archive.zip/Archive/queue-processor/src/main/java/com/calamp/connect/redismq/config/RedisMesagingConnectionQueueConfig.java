package com.calamp.connect.redismq.config;

import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.calamp.connect.redismq.serializer.JsonRedisSerializer;

import redis.clients.jedis.JedisPoolConfig;

/**
 * @author SSrinivasulu
 *
 */
@Configuration
public class RedisMesagingConnectionQueueConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(RedisMesagingConnectionQueueConfig.class);

	@Value("${messagingdb.redis.redishostname}")
	private String host;
	@Value("${messagingdb.redis.port}")
	private int port;
	@Value("${redis.queue.timeout:5000}")
	private int timeout;
	@Value("${redis.queue.database:0}")
	private int database;
	@Value("${redis.queue.namespace:'datapump'}")
	private String namespace;
	@Value("${messagingdb.redis.redispasssword:null}")
	private String password;

	@Value("${messagingdb.redis.maxidle}")
	private int redisMaxIdle;
	@Value("${messagingdb.redis.maxtotal}")
	private int redisMaxTotal;
	@Value("${redis.queue.redisns:'datapump:'}")
	private String redisns;
	
	@Bean
	public JedisConnectionFactory jedisConnectionFactory() throws NamingException {

		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxIdle(redisMaxIdle);
		poolConfig.setJmxEnabled(true);
		poolConfig.setMaxTotal(redisMaxTotal);
		poolConfig.setTestOnBorrow(true);
		poolConfig.setTestOnReturn(true);

		JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(poolConfig);
		LOGGER.debug("Printing Redis Hostname" + host + " Jndi " + host);
		jedisConnectionFactory.setHostName(host);
		jedisConnectionFactory.setPort(port);
		jedisConnectionFactory.setUsePool(true);
		//jedisConnectionFactory.setTimeout(0);
		jedisConnectionFactory.setDatabase(database);
		return jedisConnectionFactory;
	}

	@Bean
	@Qualifier(value = "redisQueueTemplate")
	public RedisTemplate<String, Object> redisQueueTemplate() throws NamingException {
		RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
        initializeTemplate(template);
        return template;
	}

	private <T> void initializeTemplate(RedisTemplate<String, T> template) throws NamingException {
		template.setConnectionFactory(jedisConnectionFactory());
		template.setKeySerializer(new StringRedisSerializer());
		template.setValueSerializer(new JsonRedisSerializer());
		template.setHashKeySerializer(new StringRedisSerializer());
	}
	
	@Bean
	public StringRedisSerializer stringRedisSerializer() {
		StringRedisSerializer stringRedisSerializer = new StringRedisSerializer();
		return stringRedisSerializer;
	}

}
