package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.Q;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;
import com.calamp.connect.redismq.model.RedisQueueConfig;
import com.calamp.connect.redismq.model.RedisSMQException;
import com.calamp.connect.redismq.model.Util;

import redis.clients.jedis.Jedis;

/**
 * @author ssrinivasulu
 *
 */
public abstract class BaseQueueCmd<T> implements Cmd<T> {
	
	@Autowired
	private RedisQueueConfig redisQueueConfig;
	
	@Autowired
	private RedisTemplate<String, String> redisQueueTemplate;

	
	/**
	 * Reads a queue from the Redis.
	 */
	public QueueDef getQueue(String qname, boolean generateUid) {
		//execute a transaction
		List<Object> results = redisQueueTemplate.execute(new SessionCallback<List<Object>>() {
		  public List<Object> execute( RedisOperations operations) throws DataAccessException {
		    operations.multi();
		    String key = redisQueueConfig.getRedisns() + qname + Q;
		    String[] queueAttributes = {"vt", "delay", "maxsize"};
		    operations.opsForHash().multiGet(key, Arrays.stream(queueAttributes).collect(Collectors.toList()));
		    // This will contain the results of all ops in the transaction
		    return operations.exec();
		  }
		});
		List<String> respTime = null;
		try (Jedis jedis = ((Jedis)redisQueueTemplate.getConnectionFactory().getConnection().getNativeConnection())) {
			respTime = jedis.time();
			Thread.sleep(60000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		@SuppressWarnings("unchecked")
		List<String> respGet = (List<String>) results.get(0);

		if (respGet.get(0) == null || respGet.get(1) == null || respGet.get(2) == null) {
			throw new RedisSMQException("Queue not found: " + qname);
		}
		
		String ms = Util.formatZeroPad(respTime.get(1), 6);
		long ts = Long.valueOf(respTime.get(0) + ms.substring(0, 3));

		String id = null;
		if (generateUid) {
			id = Util.makeId(22);
			id = Long.toString(Long.valueOf(respTime.get(0) + ms), 36) + id;
		}

		return new QueueDef(qname, Integer.valueOf(respGet.get(0)), Integer.valueOf(respGet.get(1)), Integer.valueOf(respGet.get(2)), ts, id);
	}
	
	/**
	 * Creates a queue message from resulting list.
	 */
	protected QueueMessage createQueueMessage(List result) {
		if (result.isEmpty()) {
			return null;
		}

		return new QueueMessage(
			(String) result.get(0),
			(String) result.get(1),
			(Long) result.get(2),
			Long.parseLong((String)result.get(3)),
			Long.parseLong((String)result.get(4)),
			Long.valueOf(((String)result.get(0)).substring(0, 10), 36) / 1000
		);
	}
	
	/**
	 * Creates a queue message from resulting list.
	 */
	protected List<QueueMessage> createQueueMessageList(List<List<Object>> result) {
		List<QueueMessage> queueMessages = new ArrayList<QueueMessage>();
		if (result.isEmpty()) {
			return null;
		}
		for(List<Object> item : result){
			if(item!=null && item.size()>0) {
				queueMessages.add(new QueueMessage(
						(String)((List)item).get(0),
						(String)((List)item).get(1),
						null,
						null,
						null,
						null));
			}
		}
		return queueMessages;
	}

	/**
	 * @return the redisQueueConfig
	 */
	public RedisQueueConfig getRedisQueueConfig() {
		return redisQueueConfig;
	}

	/**
	 * @return the redisQueueTemplate
	 */
	public RedisTemplate<String, String> getRedisQueueTemplate() {
		return redisQueueTemplate;
	}
}