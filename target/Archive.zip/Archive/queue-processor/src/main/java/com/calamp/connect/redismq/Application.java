package com.calamp.connect.redismq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.data.redis.core.RedisKeyValueAdapter.EnableKeyspaceEvents;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;

import com.calamp.connect.redismq.config.MetricConfig;
import com.calamp.connect.redismq.config.RedisMesagingConnectionQueueConfig;
import com.calamp.connect.redismq.config.RedisMesagingQueueConfig;

/**
 * @author ssrinivasulu
 *
 */
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class})
@EnableAutoConfiguration
@EnableRedisRepositories(considerNestedRepositories = true, enableKeyspaceEvents = EnableKeyspaceEvents.ON_STARTUP)
@Configuration
@EnableCaching
@EnableAspectJAutoProxy(proxyTargetClass = true)
@Import({ RedisMesagingConnectionQueueConfig.class, RedisMesagingQueueConfig.class, MetricConfig.class})
@ComponentScan(
	basePackages      = { "com.calamp.connect.redismq"})

public class Application extends SpringBootServletInitializer
{
	private static Logger logger = LoggerFactory.getLogger(Application.class);
	public static void main(String[] args) throws Exception {
		ApplicationContext ctx = SpringApplication.run(Application.class, args);
	}
		
}
