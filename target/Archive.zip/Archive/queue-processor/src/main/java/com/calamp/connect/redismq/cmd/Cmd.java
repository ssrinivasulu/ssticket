package com.calamp.connect.redismq.cmd;

import com.calamp.connect.redismq.model.QueueDef;

public interface Cmd<T> {

	/**
	 * Executes a command and returns execution value.
	 */
	public T exec(QueueDef queueDef);

}