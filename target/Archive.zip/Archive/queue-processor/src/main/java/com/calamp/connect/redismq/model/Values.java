package com.calamp.connect.redismq.model;

public interface Values {

	int UNSET_VALUE = Integer.MIN_VALUE;

	String Q = ":Q";
	String QUEUES = "QUEUES";
}
