package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.Q;

import java.util.Arrays;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueAttributes;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.RedisSMQException;
import com.calamp.connect.redismq.model.Util;
import com.calamp.connect.redismq.model.Validator;

import redis.clients.jedis.Jedis;

/**
 * Get queue attributes, counter and stats.
 */
@Service("getQueueAttributesCmd")
public class GetQueueAttributesCmd extends BaseQueueCmd<QueueAttributes> {

	/**
	 * @return {@link QueueAttributes}
	 */
	@Override
	public QueueAttributes exec(QueueDef queueDef) {
		Validator.create().assertValidQname(queueDef.getQname());
		List<Object> results = getRedisQueueTemplate().execute(new SessionCallback<List<Object>>() {
			public List<Object> execute(RedisOperations operations) throws DataAccessException {
				List<String> respTime = null;
				try (Jedis jedis = ((Jedis)getRedisQueueTemplate().getConnectionFactory().getConnection().getNativeConnection())) {
					respTime = jedis.time();
				}
				String key = getRedisQueueConfig().getRedisns() + queueDef.getQname();
				operations.multi();
				operations.opsForHash().multiGet(key + Q, Arrays.asList("vt", "delay", "maxsize", "totalrecv", "totalsent", "created", "modified"));
				operations.opsForZSet().zCard(key);
				operations.opsForZSet().count(key, Double.valueOf(respTime.get(0)+ "000"), Double.POSITIVE_INFINITY);
				return operations.exec();
			}
		});

		if (results.get(0) == null) {
			throw new RedisSMQException("Queue not found: " + queueDef.getQname());
		}

		@SuppressWarnings("unchecked")
		List<String> rec0 = (List<String>) results.get(0);
	    
		if (rec0.get(0) == null) {
			throw new RedisSMQException("Queue not found: " + queueDef.getQname());
		}
		
		QueueAttributes qa = new QueueAttributes(
			Integer.parseInt(rec0.get(0)),
			Integer.parseInt(rec0.get(1)),
			Integer.parseInt(rec0.get(2)),
			Util.safeParseLong(rec0.get(3)),
			Util.safeParseLong(rec0.get(4)),
			Long.parseLong(rec0.get(5)),
			Long.parseLong(rec0.get(6)),
			(Long) results.get(1),
			(Long) results.get(2)
		);

		return qa;
	}
}
