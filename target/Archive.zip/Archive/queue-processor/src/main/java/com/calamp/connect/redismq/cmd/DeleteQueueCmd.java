package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.QUEUES;
import static com.calamp.connect.redismq.model.Util.toInt;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.RedisSMQException;
import com.calamp.connect.redismq.model.Validator;
import com.calamp.connect.redismq.model.Values;

/**
 * Delete a queue and all messages.
 */
@Service("deleteQueueCmd")
public class DeleteQueueCmd extends BaseQueueCmd<Integer> {

	/**
	 * @return 1
	 */
	@Override
	public Integer exec(QueueDef queueDef) {
		Validator.create()
			.assertValidQname(queueDef.getQname());
		
		List<Object> results = getRedisQueueTemplate().execute(new SessionCallback<List<Object>>() {
			public List<Object> execute(RedisOperations operations) throws DataAccessException {
				operations.multi();
				String key = getRedisQueueConfig().getRedisns() + queueDef.getQname();
				operations.delete(key + Values.Q);
				operations.delete(key);
				operations.opsForSet().remove(getRedisQueueConfig().getRedisns() + QUEUES, queueDef.getQname());
				return operations.exec();
			}
		});
		
		if (toInt(results, 0) == 0) {
			throw new RedisSMQException("Queue not found: " + queueDef.getQname());
		}
		return 1;
		
	}


}
