/**
 * 
 */
package com.calamp.connect.redismq.repository;

import org.springframework.data.repository.CrudRepository;
import com.calamp.connect.redismq.model.QueueAckExpiryLog;

/**
 * @author ssrinivasulu
 *
 */
public interface AckExpiryLogRepository extends CrudRepository<QueueAckExpiryLog, String> {

}
