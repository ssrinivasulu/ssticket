package com.calamp.connect.redismq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@JsonRootName("queueAttributes")
@JsonTypeName("queueAttributes")
@JsonInclude(Include.ALWAYS)
@JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
public class QueueAttributes {

	private int visibilityTimeout;
	private int delay;
	private int maxSize;
	private long totalRecv;
	private long totalSent;
	private long created;
	private long modified;
	private long msgs;
	private long hiddenMsgs;

	public QueueAttributes(int visibilityTimeout, int delay, int maxSize, long totalRecv, long totalSent, long created, long modified, long msgs, long hiddenMsgs) {
		this.visibilityTimeout = visibilityTimeout;
		this.delay = delay;
		this.maxSize = maxSize;
		this.totalRecv = totalRecv;
		this.totalSent = totalSent;
		this.created = created;
		this.modified = modified;
		this.msgs = msgs;
		this.hiddenMsgs = hiddenMsgs;
	}


	public int getVisibilityTimeout() {
		return visibilityTimeout;
	}

	/**
	 * The visibility timeout for the queue in seconds.
	 */
	public void setVisibilityTimeout(int visibilityTimeout) {
		this.visibilityTimeout = visibilityTimeout;
	}

	public int getDelay() {
		return delay;
	}

	/**
	 * The delay for new messages in seconds.
	 */
	public void setDelay(int delay) {
		this.delay = delay;
	}

	public int getMaxSize() {
		return maxSize;
	}

	/**
	 * The maximum size of a message in bytes.
	 */
	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public long getTotalRecv() {
		return totalRecv;
	}

	/**
	 * Total number of messages received from the queue.
	 */
	public void setTotalRecv(long totalRecv) {
		this.totalRecv = totalRecv;
	}

	public long getTotalSent() {
		return totalSent;
	}

	/**
	 * Total number of messages sent to the queue.
	 */
	public void setTotalSent(long totalSent) {
		this.totalSent = totalSent;
	}

	public long getCreated() {
		return created;
	}
	
	/**
	 * Timestamp (epoch in seconds) when the queue was created
	 */
	public void setCreated(long created) {
		this.created = created;
	}

	public long getModified() {
		return modified;
	}

	/**
	 *  Timestamp (epoch in seconds) when the queue was last modified with setQueueAttributes().
	 */
	public void setModified(long modified) {
		this.modified = modified;
	}

	public long getMsgs() {
		return msgs;
	}

	/**
	 * * Current number of messages in the queue.
	 */
	public void setMsgs(long msgs) {
		this.msgs = msgs;
	}

	public long getHiddenMsgs() {
		return hiddenMsgs;
	}

	/**
	 * Current number of hidden / not visible messages. A message can be hidden while "in flight" due to a vt parameter or when sent with a delay.
	 */
	public void setHiddenMsgs(long hiddenMsgs) {
		this.hiddenMsgs = hiddenMsgs;
	}


	public QueueAttributes() {
	}
}
