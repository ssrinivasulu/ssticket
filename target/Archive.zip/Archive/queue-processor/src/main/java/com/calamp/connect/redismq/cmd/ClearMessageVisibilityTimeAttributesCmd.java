package com.calamp.connect.redismq.cmd;

import java.util.Collections;

import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.Validator;

/**
 * 
 * @author ssrinivasulu
 */
@Service("clearMessageVisibilityTimeAttributesCmd")
public class ClearMessageVisibilityTimeAttributesCmd extends BaseQueueCmd<Integer> {

	/**
	 * 1 if successful, 0 if the message was not found.
	 */
	@Override
	public Integer exec(QueueDef queueDef) {
		Validator.create()
		.assertValidQname(queueDef.getQname())
		.assertValidVt(queueDef.getVisibilityTimeout())
		.assertValidId(queueDef.getUid());

		QueueDef q = getQueue(queueDef.getQname(), false);

		Long foo = (Long) getRedisQueueTemplate().execute(getRedisQueueConfig().getClearMessageVisibilityScript(), 
				Collections.singletonList(getRedisQueueConfig().getRedisns() + queueDef.getQname()), queueDef.getUid());

		return foo.intValue();
	}
}